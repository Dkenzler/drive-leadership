---
name: checklist
description: "Checklisten bauen nach Atul Gawande (The Checklist Manifesto), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand bei wiederkehrenden, komplexen Aufgaben verhindern will, dass etwas übersehen wird. Typische Auslöser: Release- oder Launch-Checkliste erstellen, Handover oder Übergabe absichern, Qualitätskontrolle vor der Auslieferung, Onboarding neuer Mitarbeitender, Vorbereitung wichtiger Meetings, Projektabschluss, wiederkehrendes Reporting, eigene Leadership-Checkliste für den Arbeitstag. Führt durch Auswahl des Moments, Wahl zwischen Do-Confirm und Read-Do und die Reduktion auf fünf bis neun überprüfbare Punkte."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S5 Ensure Quality
  origin: Atul Gawande
  deep_dive: false
  version: "1.0"
---

# Checklist

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Atul Gawande.

## Worum es geht

Im Leadership-Alltag gibt es Momente, in denen man sich fragt: Wie konnte das übersehen werden? Vieles ändert sich von Projekt zu Projekt, aber dieselben Themen tauchen immer wieder auf. Genau dort lohnt sich eine Liste, die man abhaken kann.

Atul Gawande beschreibt in »The Checklist Manifesto«, wie in der Medizin vermeidbare Fehler passieren, nicht weil Ärzte inkompetent sind, sondern weil die Komplexität moderner Eingriffe das menschliche Gedächtnis überfordert. Seine These: Bei komplexen, wiederkehrenden Aufgaben reicht es nicht, gut ausgebildet zu sein. Man braucht ein System, das sicherstellt, dass nichts vergessen wird. Ein Pilot checkt vor jedem Start dieselbe Liste, obwohl er Tausende Starts hinter sich hat. Routine schützt nicht vor Fehlern. Manchmal erhöht sie das Risiko, weil man aufhört, bewusst zu prüfen.

## Wann du sie einsetzt

- **Übergaben und Handovers.** Wenn eine Person ein Projekt übergibt, eine Aufgabe abschließt oder ein Team wechselt, geht am meisten verloren.
- **Qualitätskontrolle und Release.** Bevor ein Produkt oder Feature an Kund:innen geht. Eine Release-Checkliste macht den Unterschied zwischen einem kontrollierten und einem chaotischen Launch.
- **Weitere wiederkehrende Anlässe:** Onboarding neuer Mitarbeitender, Vorbereitung wichtiger Meetings, Abschluss von Projekten, wiederkehrende Reportings.
- **Für dich selbst.** Eine kurze Checkliste zu Beginn und am Ende des Arbeitstags. Die tägliche Start-up- und Shutdown-Checkliste aus Abb. 5.14 ist ein Beispiel dafür. Das Ritual selbst behandelt der Skill `shutdown-ritual`.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welchen wiederkehrenden Moment soll die Checkliste gelten? Wer nutzt sie (Person allein, Team, mehrere Teams)? Was ist zuletzt schiefgegangen oder übersehen worden? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten. Bringt die Person schon eine Liste mit, steig bei Schritt 4 ein und kürze.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist die Liste zu lang? Ist jeder Punkt überprüfbar? Benenne Schwächen direkt und kurz. Kein Lob als Füllmaterial.
- Erfinde keine Punkte über Prozesse, Tools oder Systeme der Person. Schlage Kategorien aus dem Buch vor und lass die Person sie mit ihrem Kontext füllen. Fehlt etwas, markiere es als offen.
- Nutzt ein Team die Checkliste, biete an, sie gemeinsam im Team zu prüfen: Welche Punkte wurden zuletzt übersehen? Welche prüft ohnehin jede Person automatisch?
- Schließe mit der Checkliste im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Den Moment bestimmen.** Wo tauchen immer wieder dieselben Versäumnisse auf? Checklisten sind besonders wertvoll bei Übergaben, Handovers und der Qualitätskontrolle.
   Frage: *»In welchem wiederkehrenden Moment passiert es, dass etwas übersehen wird, und was war das zuletzt?«*
   Gut ist die Antwort, wenn sie einen konkreten, wiederkehrenden Anlass nennt, nicht »Projekte allgemein«.

2. **Den Typ wählen.** Gawande unterscheidet zwei Typen:
   - **Do-Confirm:** Man erledigt die Dinge und bestätigt danach.
   - **Read-Do:** Man liest Punkt für Punkt und führt direkt aus.

   Für Handovers und Releases eignet sich meistens Do-Confirm.
   Frage: *»Arbeiten die Beteiligten den Ablauf aus Routine ab und sollen danach bestätigen, oder brauchen sie die Liste als Anleitung beim Ausführen?«*

3. **Punkte sammeln.** Erst vollständig sammeln, dann kürzen. Das Buch nennt als Beispiele:
   - **Release:** Sind alle Texte korrekt übersetzt? Funktionieren alle Breakpoints? Wurden alle States berücksichtigt? Was muss vor dem Launch grün sein? Welche Tests wurden durchgeführt? Welche Stakeholder sind informiert? Welche Rollback-Strategie existiert?
   - **Handover:** Sind alle relevanten Informationen, offenen Punkte, Zugänge und Kontexte vollständig übergeben?

   Frage: *»Was muss in diesem Moment jedes Mal stimmen? Nenne alles, wir kürzen danach.«*

4. **Auf fünf bis neun Punkte kürzen.** Eine gute Checkliste ist kurz. Gawande empfiehlt fünf bis neun Punkte. Was länger ist, wird nicht konsequent genutzt. Behalte die Punkte, die in diesem Moment immer wieder auftauchen und übersehen werden.
   Frage: *»Welche dieser Punkte sind in diesem Moment schon einmal übersehen worden?«*

5. **Jeden Punkt überprüfbar formulieren.** Jeder Punkt ist präzise, überprüfbar und konkret. »Qualität sicherstellen« ist kein Checklistenpunkt. »Alle Unit-Tests grün« ist einer.
   Gut ist ein Punkt, wenn eine zweite Person eindeutig mit Ja oder Nein abhaken kann.

6. **Verankern.** Festlegen, wann und von wem die Liste durchgegangen wird. Eine Checkliste, die niemand wirklich durchgeht, hat keinen Wert.
   Frage: *»An welcher Stelle im Ablauf wird die Liste durchgegangen, und wer hakt ab?«*

## Beispiel

Ugur, Designer in Dominik Kenzlers Team und heute Lead Designer bei CLARK, erstellte ein Handover-Dokument für die Zusammenarbeit zwischen Design und Entwicklung. Es löste unzählige Hin-und-Her-Meetings und Frustrationen auf, Prozess und Zusammenarbeit wurden spürbar besser. Im Kern war das Dokument eine Checkliste.

Für sich selbst startet Dominik Kenzler jeden Tag mit einer kurzen Checkliste: Kalender gecheckt, Meetings vorbereitet, die wichtigsten Nachrichten beantwortet. Am Ende des Tages folgt eine Shutdown-Checkliste: Was war der wichtigste Win heute? Was sind die Prioritäten für morgen? (Abb. 5.14.)

Julie Zhuo beschreibt in »The Making of a Manager« eine ähnliche Gewohnheit: Jeden Morgen scannt sie ihren Kalender und notiert für jede Person, mit der sie sich trifft, die wichtigsten Fragen. Nicht Antworten, sondern Fragen, in drei Kategorien:
- **Identifizieren, worum es wirklich geht:** Was ist gerade dein wichtigstes Thema? Was sind deine Prioritäten diese Woche? Wie nutzen wir unsere Zeit heute am besten?
- **Verstehen, was dahintersteckt:** Wie sieht dein ideales Ergebnis aus? Was macht es schwer, dorthin zu kommen? Was, glaubst du, ist der beste nächste Schritt?
- **Unterstützen, wo es gebraucht wird:** Wie kann ich dir helfen? Was kann ich tun, damit du erfolgreicher wirst? Was war der nützlichste Teil unseres Gesprächs heute?

Die Fragen sind kein festes Script, sondern ein Startpunkt.

## Worauf du achten musst

- **Zu lang und zu detailliert.** Die häufigste Falle. Checklisten werden erstellt, um vollständig zu sein, nicht, um genutzt zu werden. Besser fünf Punkte, die jedes Mal geprüft werden, als 30, die niemand liest.
- **Unprüfbare Punkte.** »Qualität sicherstellen« lässt sich nicht abhaken. Jeder Punkt muss präzise, überprüfbar und konkret sein.
- **Liste ohne Nutzung.** Eine Checkliste, die niemand wirklich durchgeht, hat keinen Wert.
- **Sich auf Routine verlassen.** Erfahrung ist kein Ersatz für die Liste. Routine kann das Risiko erhöhen, weil man aufhört, bewusst zu prüfen.

## Ergebnis

```markdown
# Checkliste: [Anlass, z. B. Release, Handover, Onboarding]
Gilt für: [Team / Person] · Stand: [Datum]
Typ: Do-Confirm / Read-Do
Wann: [Zeitpunkt im Ablauf] · Wer hakt ab: [Rolle]

- [ ] …
- [ ] …
- [ ] …
- [ ] …
- [ ] …
(5 bis 9 Punkte, jeder mit Ja oder Nein prüfbar)

Bewusst gestrichen: …
Offen: …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hat die Liste höchstens neun Punkte?
- Kann eine zweite Person jeden Punkt eindeutig mit Ja oder Nein abhaken?
- Ist festgelegt, wann und von wem die Liste jedes Mal durchgegangen wird?
- Deckt die Liste die Punkte ab, die zuletzt tatsächlich übersehen wurden?

## Im Flywheel

Modul SHIP, Bereich S5 Ensure Quality.

Verwandte Skills:
- `shutdown-ritual`: Die Daily Start-up- und Shutdown-Checkliste (Abb. 5.14) ist die persönliche Anwendung einer Checkliste. Das Ritual ist dort beschrieben.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S5 Ensure Quality, Checklist, Abb. 5.14. Originalquelle: Atul Gawande: The Checklist Manifesto. Zitierte Praxis: Julie Zhuo: The Making of a Manager.

Original: Atul Gawande: The Checklist Manifesto. How to Get Things Right, 2009.
