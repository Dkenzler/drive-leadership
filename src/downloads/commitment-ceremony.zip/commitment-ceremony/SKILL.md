---
name: commitment-ceremony
description: "Commitment Ceremony aus dem Drive Leadership Playbook von Dominik Kenzler: der formale Abschluss der Planungsphase, in dem Teams ihre Objectives oder OKRs vorstellen, die Führungskraft sie challengt und das Team explizit committet. Nutze diesen Skill, wenn jemand eine Quartalsplanung abschließen, eine Commitment- oder OKR-Runde vorbereiten oder moderieren, Ziele verbindlich machen, Teamziele challengen oder einen Cut-off zwischen Must-do-Commitments und optionalen Themen einführen will. Liefert Ablauf, Fragenkatalog und Ergebnisprotokoll."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S1 Set Goals
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Commitment Ceremony

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Die Commitment Ceremony ist der formale Abschluss der Planungsphase. Die Teams haben ihre Objectives oder Ziele in einem anderen Format formuliert, die Führungskraft hat ihre eigenen Ziele aufgeschrieben. Jetzt folgt der gegenseitige Austausch und das explizite Commitment.

Ohne diesen Schritt bleiben OKRs oft unverbindlich: Teams formulieren Ziele, aber niemand hat sie bestätigt oder hinterfragt. Die Ceremony macht die Verbindlichkeit explizit. Sie ist ein Qualitätsmechanismus: Kann ein Team seine Objectives nicht klar erklären, waren sie nicht genug durchdacht.

Der Unterschied zwischen Commitment und Vorhaben entsteht hier. Commitment heißt: Die letzten Tage vor dem Zieldatum geben alle zusammen Gas. Vorhaben heißt: »Schade, das hat nicht geklappt, wir machen es in den nächsten zwei Wochen fertig.« Ziele sollen ambitioniert sein, aber ein echtes Commitment bleiben.

## Wann du sie einsetzt

- Am Ende jeder Planungsphase, in der Praxis einmal pro Quartal.
- Wenn Ziele auf dem Papier gut aussehen, im Alltag aber keine Verbindlichkeit haben.
- Wenn mehrere Teams ihre Objectives auf dieselben strategischen Ziele ausrichten und Abhängigkeiten geklärt werden müssen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wie viele Teams präsentieren? In welchem Format liegen die Ziele vor (OKRs, andere Zielformate)? Welche strategischen Ziele sind der Bezugspunkt? Frag nichts, was die Person schon gesagt hat.
- Die Ceremony findet im Team statt. Biete an, Agenda, Vorbereitung für die Teams und den Fragenkatalog zu erstellen. Wenn die Person die Ziele eines Teams schon vorliegen hat, spiel die Fragen der Ceremony damit durch.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge gegen »Worauf du achten musst«. Vor allem: Erzeugt die Ceremony echten Dialog, oder nicken alle?
- Erfinde keine Ziele, Ressourcen oder Abhängigkeiten der Teams. Markiere offene Punkte als Klärungsbedarf.
- Schließe mit dem Protokoll im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Vorbereitung.** Die Teams haben ihre Objectives formuliert. Die Führungskraft hat ihre eigenen Ziele aufgeschrieben. Zeitrahmen: meistens zwei bis drei Stunden, einmal pro Quartal, pro Team zehn bis fünfzehn Minuten.
   Frage: *»Liegen die Ziele aller Teams und deine eigenen schriftlich vor?«*

2. **Präsentation je Team.** Jedes Team präsentiert seine Objectives und erklärt, wie sie auf die strategischen Ziele einzahlen.

3. **Challenge durch die Führungskraft.** Die Führungskraft challengt, gibt Feedback und stellt sicher, dass die Ziele ambitioniert genug und realistisch sind. Die Fragen laut Buch:
   - Wie zahlt dieses Objective auf das Company Objective ein?
   - Wie habt ihr die Key Results definiert, und warum genau diese?
   - Was habt ihr bewusst nicht in eure Objectives aufgenommen?
   - Welche Abhängigkeiten habt ihr zu anderen Teams?
   - Was sind eure Datenpunkte, qualitativ oder quantitativ, auf denen die Ziele basieren?
   - Wie hoch ist eure Confidence, dass ihr die Key Results erreicht?
   - Was sind die größten Risiken, die euch daran hindern könnten?

   Gut sind die Antworten, wenn das Team sie ohne Ausweichen geben kann. Kann ein Team nicht erklären, warum ein Ziel wichtig ist, geht es zurück.

4. **Machbarkeit prüfen.** Hat das Team alles, was es braucht? Sind die nötigen Ressourcen vorhanden? Ist ungeplante Arbeit eingeplant? Keine Luftschlösser. Die Spannung zwischen Ambition und Machbarkeit wird bewusst ausbalanciert: realistisch, aber nicht weich.
   Frage: *»Was fehlt dem Team, damit das Ziel ein echtes Commitment ist?«*

5. **Cut-off setzen.** Das Team trennt zwei Kategorien: **Must-do-Commitments**, die in jedem Fall geliefert werden, egal was kommt, und **Themen unterhalb des Cut-offs**, die wenn möglich noch gemacht werden, aber nicht committet sind. Themen unter dem Cut-off werden nicht nach außen kommuniziert und nicht in die Unternehmenskommunikation aufgenommen. Nur die Commitments zählen.
   Frage: *»Was davon liefert ihr in jedem Fall, und was liegt unter dem Cut-off?«*

6. **Explizites Commitment und Abschluss.** Am Ende committet das Team explizit auf seine Objectives. Nach der Session ist klar: Welche Objectives sind aligned und committet? Wo gibt es noch Klärungsbedarf? Welche Abhängigkeiten müssen zwischen Teams gelöst werden?

## Beispiel

Dominik hat die Commitment Ceremony bei CLARK eingeführt. Vorher gab es Ziele, die auf dem Papier gut aussahen, aber im Alltag keine Verbindlichkeit hatten. Danach wussten die Teams, dass sie ihre Ziele verteidigen mussten, und dachten sie vorher besser durch.

Bei sevdesk kam der Cut-off dazu: Must-do-Commitments und Themen darunter. Die besten Teams versuchten, möglichst viele Themen unterhalb des Cut-offs noch zu schaffen. Kommuniziert wurden aber nur die Commitments.

## Worauf du achten musst

- **Präsentationsmarathon.** Alle nicken, niemand fordert heraus. Die Ceremony hat nur Wert, wenn sie echten Dialog erzeugt. Unbequeme Fragen stellen, Klarheit fordern, wenn ein Ziel vage ist.
- **Unklares Warum durchwinken.** Kann ein Team nicht erklären, warum ein Ziel wichtig ist, schick es zurück.
- **Luftschlösser.** Ziele ohne Ressourcen und ohne Puffer für ungeplante Arbeit sind kein Commitment.
- **Weiche Ziele.** Die Ziele müssen ambitioniert genug und realistisch sein. Realistisch heißt nicht weich: Aus »wir machen es in den nächsten zwei Wochen fertig« wird kein Commitment, sondern ein Vorhaben.
- **Optionales nach außen tragen.** Themen unterhalb des Cut-offs gehören nicht in die Unternehmenskommunikation.

## Ergebnis

```markdown
# Commitment Ceremony: [Bereich] · [Quartal / Zyklus]
Datum: [Datum] · Teilnehmende: [Teams, Führungskraft]

## Team [Name]
**Objectives:** …
**Einzahlung auf das Company Objective:** …
**Bewusst nicht aufgenommen:** …
**Datenbasis:** …
**Confidence:** …
**Größte Risiken:** …
**Ressourcen und Puffer für ungeplante Arbeit geklärt:** ja / nein, weil …

| Must-do-Commitments | Unterhalb des Cut-offs (nicht kommuniziert) |
|---|---|
| … | … |

**Status:** committet / zurück zur Überarbeitung, weil …

## Gesamtbild
- Aligned und committet: …
- Klärungsbedarf: …
- Abhängigkeiten zwischen Teams, zu lösen durch / bis: …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hat jedes Team mindestens eine unbequeme Frage bekommen, oder war es ein Präsentationsmarathon?
- Konnte jedes Team erklären, wie sein Objective auf das Company Objective einzahlt?
- Sind Ressourcen und ungeplante Arbeit für jedes Commitment geklärt?
- Ist für jedes Team der Cut-off zwischen Must-do-Commitments und optionalen Themen klar?
- Sind offene Abhängigkeiten zwischen Teams mit Verantwortlichen benannt?

## Im Flywheel

Modul SHIP, Bereich S1 Set Goals.

Verwandte Skills:
- `okrs`: Die Ceremony schließt die OKR-Planung ab.
- `goal-review`: bewertet am Ende des Zyklus, ob geliefert wurde, was committet war.
- `capacity-planning`: macht die verfügbare Kapazität sichtbar, bevor Commitments eingegangen werden.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S1 Set Goals, Abschnitt Commitment Ceremony.
