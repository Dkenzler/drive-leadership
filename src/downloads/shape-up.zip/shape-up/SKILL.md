---
name: shape-up
description: Planen mit Shape Up von Ryan Singer (Basecamp, 37signals), aus dem Drive Leadership Playbook. Die Zeit wird fixiert, der Scope angepasst. Nutze diesen Skill, wenn jemand ein Vorhaben mit festem Zeitrahmen und variablem Umfang planen, ein Problem shapen, einen Pitch schreiben (Problem, Appetite, Solution, Rabbit Holes, No-gos), einen Betting-Prozess aufsetzen, Scopes bilden, Fortschritt mit dem Hill Chart statt in Prozent zeigen, einen Circuit Breaker einführen oder endlose Backlogs und reißende Schätzungen beenden will. Einzelne Bausteine funktionieren auch für sich.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S2 Plan & Prioritize
  origin: Ryan Singer (Basecamp, 37signals)
  deep_dive: true
  version: "1.0"
---

# Shape Up

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Ryan Singer.

## Worum es geht

Shape Up ist ein Planungsansatz, den Ryan Singer bei Basecamp (37signals) entwickelt hat. Der Kerngedanke ist eine Umkehrung: Statt einen festen Scope in variabler Zeit zu planen, wird die Zeit fixiert und der Scope angepasst. Du legst zuerst fest, wie viel Zeit dir eine Sache wert ist, den **Appetite**, und passt den Umfang daran an. Das zwingt zu Entscheidungen, weil nicht alles hineinpasst.

Gearbeitet wird in Zyklen von sechs Wochen, in denen ein Team an einem klar umrissenen Problem arbeitet. Shape Up kennt drei Aktivitäten, die in den meisten Teams vermischt sind: **Shaping** (das Problem formen), **Betting** (entscheiden, worauf ihr setzt) und **Building** (bauen und Fortschritt sichtbar machen). Zwischen den Zyklen liegt eine kurze Cool-down-Phase für Reflexion, kleine Fixes und die Vorbereitung der nächsten Bets.

Shape Up löst zwei klassische Probleme. Erstens zu detaillierte Roadmaps, die nicht zur Realität passen: Weil der Scope variabel bleibt, kann das Team innerhalb des Zeitrahmens das Richtige bauen. Zweitens unendliche Backlogs, die niemand priorisiert: Vor jedem Zyklus wird neu entschieden, worauf gewettet wird. Was es nicht in eine Bet schafft, verschwindet, und wenn es wirklich wichtig ist, taucht es von selbst wieder auf. Die feste Zeitgrenze erzeugt echten Fokus und ist trotzdem lang genug für mehr als kleine inkrementelle Neuerungen.

Das Team bekommt ein geformtes, aber bewusst unfertiges Problem und entscheidet innerhalb der Grenzen, was genau es baut. Kein Mikromanagement, sondern Ownership in klaren Leitplanken.

## Wann du sie einsetzt

- Wenn Projekte kein Ende finden, Schätzungen regelmäßig reißen und Backlogs immer länger werden.
- Wenn ein Vorhaben einen festen Zeitrahmen mit variablem Umfang braucht.
- Für einzelne Bausteine, auch außerhalb reiner Produktentwicklung: feste Zeitrahmen mit variablem Scope, Cool-down-Phase, Pitch-Format, Fat Marker Sketches.

Shape Up muss nicht eins zu eins übernommen werden. Die Bausteine funktionieren für sich.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Geht es um ein einzelnes Vorhaben (dann Pitch) oder um die Einführung von Shape Up im Team (dann Zyklus, Betting, Building)? Welches Problem steht an? Wer shapt, wer entscheidet, wer baut? Frag nichts, was die Person schon gesagt hat.
- Häufigster Einstieg ist ein Pitch. Geh dann die Shaping-Schritte durch und schließe mit dem Pitch (siehe `templates/pitch.md`).
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge gegen »Worauf du achten musst«. Vor allem: Steht der Appetite vor der Lösung? Wird er aufgeweicht, sobald es eng wird?
- Halte die Lösung grob. Wenn die Person ins Detail-Design geht, hol sie auf Fat-Marker-Niveau zurück.
- Erfinde keine Anforderungen, Nutzerprobleme oder technischen Risiken. Markiere Unklares als offene Frage oder mögliches Rabbit Hole.
- Wenn das Team eine Betting-Runde plant, biete Agenda und Entscheidungsfragen an.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

### Shaping: das Problem formen

Shaping ist Arbeit für wenige, erfahrene Personen und passiert, bevor ein Zyklus beginnt. Zuerst werden rohe Ideen und Anfragen gesammelt und priorisiert, dann so weit ausgearbeitet, dass ein Konzept steht und erste Risiken identifiziert sind.

1. **Problem benennen.** Die Rohidee, ein Use Case oder etwas Beobachtetes, das motiviert, daran zu arbeiten.
   Frage: *»Welches Problem, welcher Anlass steht hinter der Idee?«* Gut ist die Antwort, wenn sie ein Problem beschreibt, nicht schon eine Lösung.

2. **Appetite vor die Lösung setzen.** Lege zuerst fest, wie viel Zeit dir die Sache wert ist: ein kleiner Teil eines Zyklus oder sechs Wochen. Der Appetite kommt vor der Lösung und bestimmt, wie groß sie überhaupt werden darf.
   Frage: *»Wie viel Zeit ist euch das wert, unabhängig davon, was alles möglich wäre?«* Gut ist die Antwort, wenn sie eine feste Zeit nennt und nicht aus einer Schätzung abgeleitet ist.

3. **Lösung grob skizzieren.** In niedriger Auflösung arbeiten. Singer nutzt **Fat Marker Sketches**, Skizzen mit so dickem Stift, dass Details gar nicht möglich sind, und **Breadboarding**, bei dem nur Bausteine und ihre Verbindungen festgehalten werden, ohne Layout. So bleibt Raum für das Team, und niemand verliebt sich zu früh in ein Design.
   Frage: *»Was sind die Kernelemente der Lösung, so grob, dass sie auf eine Skizze mit dickem Stift passen?«*

4. **Rabbit Holes suchen und No-gos benennen.** Stellen durchgehen, an denen sich das Team verlieren könnte, und sie vorab entschärfen. Ebenso klar benennen, was bewusst nicht Teil der Lösung ist, um in den Appetite zu passen. Beides schützt die feste Zeit.
   Frage: *»Wo könnte sich das Team verlieren, und was lasst ihr bewusst weg?«*

5. **Zum Pitch verdichten.** Problem, Appetite, Lösung in groben Zügen, Rabbit Holes, No-gos. Ein guter Pitch ist so kurz, dass man ihn schnell versteht.

### Betting: entscheiden, worauf ihr setzt

6. **Bets in der Cool-down-Phase auswählen.** Am Ende eines Zyklus wählt eine kleine Runde von Entscheidern aus den Pitches die wenigen aus, die in den nächsten Zyklus gehen. Keine lange Backlog-Sichtung, sondern eine knappe Wette auf die vielversprechendsten geformten Probleme. Leitgedanke: Die Zeit muss für die Umsetzung reichen. Wer wettet, verpflichtet sich, dem Team die volle Zeit ungestört zu geben.
   Frage: *»Welche Pitches kommen in den nächsten Zyklus, und könnt ihr dem Team die volle Zeit ungestört garantieren?«*

### Building: bauen und Fortschritt sichtbar machen

7. **Arbeit abgeben, Team bildet Scopes.** Das Team zerlegt die Arbeit nicht in Aufgaben von oben, sondern in **Scopes**: zusammenhängende Teile, die sich unabhängig fertigstellen lassen und jeweils einen sinnvollen Ausschnitt des Ganzen abbilden. Scopes entstehen beim Bauen, wenn das Team das Terrain versteht, nicht vorab am Reißbrett.

8. **Fortschritt mit dem Hill Chart messen.** Fortschritt als Hügel statt in Prozent. Die erste Hälfte, der Aufstieg, ist das Herausfinden: Unbekanntes klären, offene Fragen beantworten, Risiken auflösen. Die zweite Hälfte, der Abstieg, ist die reine Umsetzung von etwas, das bereits verstanden ist. Ein Scope, der noch bergauf geht, ist gefährlicher als einer, der schon bergab läuft.
   Frage: *»Welche Scopes sind noch im Aufstieg, welche schon im Abstieg?«*

9. **Zeitgrenze mit dem Circuit Breaker schützen.** Die wichtigste Disziplin. Wird eine Bet im Appetite nicht fertig, stoppt sie standardmäßig, statt stillschweigend verlängert zu werden. Wer weitermachen will, muss neu pitchen und neu wetten.

10. **Scope kürzen statt Zeit dehnen.** Wird es eng, stellt sich die Frage, was ihr weglasst. Singer nennt das **Scope Hammering**: bewusstes Kürzen auf das Essenzielle, damit das Wichtigste in der festen Zeit fertig wird.
    Frage: *»Was ist wirklich essenziell, und was kann raus, damit es in der Zeit fertig wird?«*

## Beispiel

Ein Pitch in Kurzform, angelehnt an den Payment-Form-Pitch aus Shape Up (Abb. 5.18a):

- **Problem:** Die Kundschaft will über das Produkt eine Zahlung einsammeln, ein einfaches Formular fehlt.
- **Appetite:** ein fest gesetzter Zeitrahmen, der die Lösung bewusst klein hält. Nicht, was alles möglich wäre, sondern, was in dieser Zeit möglich ist.
- **Lösung:** ein schlankes Formular, das eine Zahlung entgegennimmt und sich mit Logo und eigener Überschrift anpassen lässt. Grob skizziert.
- **Rabbit Holes:** Für die erste Version laufen die Formularadressen nicht über eigene Domains der Kundschaft. Dieser eine Satz schützt das Team davor, sich in der Domainverwaltung zu verlieren.
- **No-gos:** kein freies Drag-and-drop-Editing. Anpassung nur über Logo und Überschrift auf einer separaten Seite.

Dominik hat Shape Up nie vollständig end-to-end angewendet, aber viele Teile übernommen: feste Zeitrahmen mit variablem Scope, die Cool-down-Phase zwischen Zyklen, das Pitch-Format für neue Ideen und Fat Marker Sketches in der frühen Konzeptphase.

## Worauf du achten musst

- **Direkt ins Bauen springen.** Shape Up funktioniert nicht als reines Delivery-Framework. Ohne ordentliches Shaping landet das Team in den Problemen, die es vermeiden wollte, nur mit laufender Uhr. Das Formen ist die halbe Miete.
- **Appetite nachträglich aufweichen.** Wird der Appetite verhandelbar, sobald es eng wird, verliert das System seinen Sinn. Die feste Zeit ist die Bedingung für echte Priorisierung.
- **Aufgaben statt Scopes vergeben.** Fertige Aufgabenlisten nehmen dem Team das Verständnis für das Ganze und die Fähigkeit, sinnvoll zu kürzen.
- **Prozent statt Hügel messen.** »80 Prozent fertig« sagt nichts darüber, was in den restlichen 20 Prozent steckt. Sind es klare Umsetzungsschritte, ist das Projekt fast durch. Sind es ungelöste Fragen, kann es noch kippen.
- **Lösung zu früh ausdetaillieren.** Wer im Shaping ins Design geht, nimmt dem Team den Raum und verliebt sich in eine Lösung.

## Ergebnis

Je nach Einstieg ein Pitch (Vorlage: `templates/pitch.md`) oder ein Zyklus-Überblick.

```markdown
# Pitch: [Titel]
Stand: [Datum] · Shaping: [Namen oder Rollen]

**Problem:** …
**Appetite:** [kleiner Teil eines Zyklus / sechs Wochen]
**Lösung (grob, Fat Marker Sketch / Breadboard):** …
**Rabbit Holes:** …
**No-gos:** …
**Offene Fragen:** …
```

```markdown
# Zyklus [Nummer]: [Zeitraum]
**Bets (aus der Betting-Runde):** …
**Entscheidende Runde:** … · **Team:** …

| Scope | Aufstieg (Herausfinden) / Abstieg (Umsetzen) | Offene Fragen |
|---|---|---|
| … | … | … |

**Circuit Breaker:** Nicht fertig am [Datum] heißt Stopp, Weitermachen nur mit neuem Pitch.
**Scope Hammering, bewusst gekürzt:** …
```

## Mini-Check

- Steht der Appetite, also die feste Zeit vor der Lösung, fest, und bleibt er unverhandelbar?
- Ist das Problem vor dem Zyklus geformt worden, mit grober Lösung, Rabbit Holes und No-gos?
- Bildet das Team seine Scopes selbst, oder bekommt es Aufgaben von oben?
- Misst du den Fortschritt danach, ob etwas noch herausgefunden oder nur noch umgesetzt wird?
- Greift bei euch der Circuit Breaker, stoppt eine Bet standardmäßig, wenn die Zeit nicht reicht?

## Im Flywheel

Modul SHIP, Bereich S2 Plan & Prioritize.

Verwandte Skills:
- `now-next-later`: Strategische Roadmaps und das Now-Next-Later-Format aus DRIVE zeigen die langfristige Richtung. Shape Up arbeitet eine Ebene darunter, im konkreten Umsetzungszyklus. Beides schließt sich nicht aus: Richtung über die Roadmap kommunizieren, einzelne Vorhaben darin als Bets formen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S2 Plan & Prioritize, Abschnitt Shape Up (Abb. 5.5, 5.6) und Deep Dive Shape Up (Abb. 5.18a, 5.18b). Originalquelle: Ryan Singer: Shape Up, Basecamp (frei verfügbar).
Original: Ryan Singer: Shape Up. Stop Running in Circles and Ship Work that Matters, Basecamp, 2019. https://basecamp.com/shapeup
