# Shape Up Pitch

Nach dem Pitch-Format im Drive Leadership Playbook (Beispiel in Abb. 5.18a), nach Ryan Singer (Basecamp).

**Titel:**
**Datum:**
**Shaping durch:**

## 1. Problem
The raw idea, a use case, or something we’ve seen that motivates us to work on this.

## 2. Appetite
How much time we want to spend and how that constrains the solution?

## 3. Solution
The core elements we came up with, presented in a form that's easy for people to immediately understand. (Fat Marker Sketch oder Breadboard, kein Detail-Design.)

## 4. Rabbit Holes
Details about the solution worth calling out to avoid problems.

## 5. No-gos
Anything specifically excluded from the concept: functionality or use cases we intentionally aren’t covering to fit the appetite or make the problem tractable.
