---
name: 5-bold-steps
description: Eine Vision gemeinsam mit einem Team auf eine Seite bringen mit der 5 Bold Steps Vision® Canvas von David Sibbet (The Grove Consultants International), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Vision für Unternehmen, Bereich oder Team formulieren, eine Visions-Session oder einen Workshop vorbereiten, die großen Schritte zur Vision festlegen oder Stärken und Hindernisse auf dem Weg sichtbar machen will. Führt durch Vision Statement, zentrale Themen, fünf Bold Steps, Supports und Challenges.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D1 Target Picture
  origin: David Sibbet, The Grove Consultants International
  deep_dive: false
  version: "1.0"
---

# 5 Bold Steps Vision

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach David Sibbet, The Grove Consultants International. 5 Bold Steps Vision® ist eine Marke von The Grove Consultants International.

## Worum es geht

Die 5 Bold Steps Vision® ist eine Canvas, ein visuelles Werkzeug, um eine Gruppe zu fokussieren und auszurichten. Sie gibt einer Session eine klare Struktur und leitet ein Team an, die wenigen Schritte zu identifizieren, die nötig sind, um eine Vision zu erreichen. Sie fördert mutiges Denken und stärkt die gemeinsame Planungsfähigkeit.

Der größte Vorteil: Am Ende steht die ganze Vision inklusive Schritte, Stärken und Hindernisse auf einem einzigen Blatt, nicht in einem übermächtigen Foliensatz. Das macht sie leicht zu teilen und leicht in konkrete Entscheidungen zu übersetzen.

Die Canvas hat fünf Bereiche, die zusammen eine Geschichte ergeben:

- **Vision Statement** (Mitte): Wie sieht die Zukunft eures Geschäfts aus, und wie helft ihr eurer Kundschaft?
- **Themes** (um das Vision Statement): die zentralen Stoßrichtungen, die die Vision tragen, in ein oder zwei Worten.
- **5 Bold Steps** (darunter): die großen Schritte, mit denen ihr die Vision erreichen wollt.
- **Supports** (links): was euch auf dem Weg stärkt.
- **Challenges** (rechts): was euch auf dem Weg behindert.

Bekannt wurde die Canvas unter anderem durch die Visionsarbeit der ING Bank und durch das Buch »Design a Better Business« von Patrick van der Pijl, Justin Lokitz und Lisa Kay Solomon.

## Wann du sie einsetzt

- Eine Vision für Unternehmen, Organisation, Bereich oder Team gemeinsam erarbeiten.
- Eine Gruppe auf ein gemeinsames Zielbild ausrichten und die wenigen großen Schritte dorthin festlegen.
- Ein Ergebnis schaffen, das auf eine Seite passt und danach als gemeinsamer Bezugspunkt dient.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Ebene gilt die Vision (Unternehmen, Bereich, Team, Produkt)? Wer soll an der Session teilnehmen? Gibt es schon eine formulierte Vision oder Vorarbeit? Frag nichts, was die Person schon gesagt hat.
- Die Canvas ist für die Arbeit in der Gruppe gedacht. Bereitet die Person eine Session vor, biete Teilnehmendenliste, Ablauf und Moderationsfragen an. Arbeitet sie allein, füll mit ihr einen ersten Entwurf aus und markiere, was in der Gruppe geklärt werden muss.
- Halte die Reihenfolge ein: Vision Statement, Themes, Bold Steps, dann Supports und Challenges. Springt die Person vor, führe sie zurück.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz.
- Erfinde keine Fakten über die Organisation. Was offen ist, markierst du als offen.
- Schließe mit der ausgefüllten Canvas im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Set-up.** Holt die richtigen Menschen an den Tisch: die entscheidenden ebenso wie die Visionsträger. Arbeitet visuell mit Klebezetteln, statt nur zu reden. Das hält die Gruppe in Bewegung und macht Unterschiede sichtbar.

1. **Vision Statement.** Wie sieht die Zukunft eures Geschäfts aus, und wie helft ihr eurer Kundschaft? Was wollt ihr langfristig erreichen?
   Frage: *»Wie sieht die Zukunft aus, die ihr erreichen wollt, und was habt ihr dann für eure Kundschaft verändert?«*
   Gut ist die Antwort, wenn klar ist, was erreicht werden soll. Die perfekte Formulierung ist hier nicht das Ziel, sie lässt sich später schärfen.

2. **Themes.** Die zentralen Stoßrichtungen sammeln, die die Vision tragen. Drei bis fünf, jeweils in ein oder zwei Worten.
   Frage: *»Welche drei bis fünf Themen müssen tragen, damit diese Vision Wirklichkeit wird?«*
   Gut ist die Antwort, wenn jedes Thema in wenigen Worten steht und die Themen zusammen das Vision Statement abdecken.

3. **5 Bold Steps.** Erst jetzt die konkreten großen Schritte, mit denen ihr die Vision erreichen wollt. Jeden Schritt einem Thema zuordnen.
   Frage: *»Welches sind die fünf großen Schritte auf dem Weg, und zu welchem Thema gehört jeder?«*
   Gut ist die Antwort, wenn es große Schritte sind, keine Aufgabenliste, und jeder Schritt einem Thema zugeordnet ist.

4. **Supports und Challenges.** Zuletzt, denn sie ergeben erst Sinn, wenn Vision, Themes und Steps stehen. Was stärkt euch auf dem Weg zur Vision? Welche Herausforderungen hindern euch?
   Frage: *»Was stärkt euch auf diesem Weg, und was steht euch im Weg?«*
   Gut ist die Antwort, wenn sie sich auf die konkreten Steps bezieht und nicht allgemein bleibt.

5. **Canvas nutzen.** Die fertige Canvas danach als gemeinsamen Bezugspunkt verwenden.
   Frage: *»Wo hängt die Canvas künftig, und bei welchen Anlässen holt ihr sie wieder hervor?«*

## Worauf du achten musst

- **Sich in der perfekten Formulierung verlieren.** Klarheit darüber, was ihr erreichen wollt, zählt mehr als der Wortlaut. Der lässt sich später schärfen.
- **Die Reihenfolge umdrehen.** Supports und Challenges vor Vision, Themes und Steps ergeben keinen Sinn. Steps ohne Themen hängen in der Luft.
- **Die falschen Menschen am Tisch.** Fehlen die, die entscheiden, oder die, die die Vision tragen, bleibt die Canvas folgenlos.
- **Nur reden statt visuell arbeiten.** Ohne Klebezettel bleibt die Gruppe statisch, und Unterschiede werden nicht sichtbar.
- **Die Canvas nach der Session ablegen.** Ihr Wert liegt darin, danach der gemeinsame Bezugspunkt zu sein.

## Ergebnis

Die ausgefüllte Canvas auf einer Seite. Vorlage: `templates/5-bold-steps-canvas.md`.

```markdown
# 5 Bold Steps Vision: [Organisation / Bereich / Team]
Stand: [Datum] · Beteiligte: [Namen oder Rollen]

**Vision Statement:** …

**Themes:** [Thema 1] · [Thema 2] · [Thema 3] · [Thema 4] · [Thema 5]

| # | Bold Step | Thema |
|---|---|---|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |

| Supports | Challenges |
|---|---|
| … | … |

**Offen:** …
```

## Mini-Check

Aus der Drive Checklist (Target Picture):
- Hast du ein klares Zielbild für deinen Verantwortungsbereich?
- Ist das Zielbild dokumentiert und zugänglich?
- Kennt dein Team das Zielbild und kann es wiedergeben?

(abgeleitet aus den typischen Fehlern)
- Ist jeder Bold Step einem Thema zugeordnet?
- Beziehen sich Supports und Challenges auf die konkreten Steps?
- Waren die Menschen beteiligt, die entscheiden, und die, die die Vision tragen?

## Im Flywheel

Modul DRIVE, Bereich D1 Target Picture. Eines der Formate, mit denen eine Vision ein Bild bekommt, das andere sehen und teilen können.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D1 Target Picture (Abb. 3.2). Originalquelle: David Sibbet, The Grove Consultants International. Bekannt auch aus »Design a Better Business« von Patrick van der Pijl, Justin Lokitz und Lisa Kay Solomon.

Original: David Sibbet, The Grove Consultants International: Five Bold Steps Vision Graphic Guide mit Leader's Guide. https://grovetools-inc.com/products/five-bold-steps
