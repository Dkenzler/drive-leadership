# 5 Bold Steps Vision® Canvas

Nach Abb. 3.2 im Drive Leadership Playbook, 5 Bold Steps von The Grove Consultants International (David Sibbet). 5 Bold Steps Vision® ist eine Marke von The Grove Consultants International.

Reihenfolge beim Ausfüllen: Vision Statement, Themes, 5 Bold Steps, Supports und Challenges.

**Organisation / Bereich / Team:**
**Stand:**
**Beteiligte:**

## Vision Statement
Wie sieht die Zukunft deines Geschäfts aus?

Was möchtest du langfristig erreichen?

## Themes
Die zentralen Stoßrichtungen, in ein oder zwei Worten (drei bis fünf):

| Theme | Theme | Theme | Theme | Theme |
|---|---|---|---|---|
| | | | | |

## 5 Bold Steps
Die großen Schritte auf dem Weg zu deiner Vision:

| # | Bold Step | Theme |
|---|---|---|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |

## Supports und Challenges

| Supports | Challenges |
|---|---|
| Was stärkt dich auf dem Weg zu deiner Vision? | Welche Herausforderungen hindern dich auf dem Weg zu deiner Vision? |
| | |
| | |
| | |
