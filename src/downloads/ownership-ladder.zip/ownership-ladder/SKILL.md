---
name: ownership-ladder
description: Verantwortungsübernahme einschätzen und entwickeln mit der Ownership Ladder, aus dem Drive Leadership Playbook, inklusive Barrels und Ammunition nach Keith Rabois. Nutze diesen Skill, wenn jemand einschätzen will, wie viel Ownership eine Person im Team typischerweise übernimmt, ein Entwicklungsgespräch über Verantwortung und Wachstum vorbereiten, Mitarbeitende von Kritik und Beschwerden hin zu eigener Initiative entwickeln oder die Barrels im Team erkennen und fördern will. Führt durch die sieben Stufen von Urteilen bis Ownen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L5 Grow Your People
  origin: Managementliteratur, im Buch ohne namentliche Urheber:in; Barrels und Ammunition nach Keith Rabois
  deep_dive: false
  version: "1.0"
---

# Ownership Ladder

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode aus der Managementliteratur, von verschiedenen Autor:innen weiterentwickelt. Exkurs Barrels und Ammunition nach Keith Rabois.

## Worum es geht

Die Ownership Ladder beschreibt die verschiedenen Grade, mit denen Menschen Verantwortung übernehmen. Sie hat sieben Stufen, von passivem Urteilen bis zu aktiver, vollständiger Ownership:

| Stufe | Name | Beschreibung |
|---|---|---|
| 1 | Urteilen | Die Person kritisiert intern, handelt aber nicht. »Das wird sowieso nicht funktionieren.« |
| 2 | Tratschen | Die Kritik wird nach außen getragen, aber nicht an die relevante Person. Beschwerden ohne Konsequenz. |
| 3 | Feedback geben | Die Person spricht Themen direkt an, macht aber keine Vorschläge zur Lösung. |
| 4 | Tiefes Feedback | Die Person analysiert ein Problem konstruktiv und bringt konkrete Verbesserungsvorschläge. |
| 5 | Kollaborieren | Die Person bietet aktiv Hilfe an und arbeitet mit anderen zusammen, um Themen voranzubringen. |
| 6 | Vorantreiben | Die Person übernimmt Initiative und setzt Dinge um, ohne auf Erlaubnis zu warten. |
| 7 | Ownen | Die Person übernimmt vollständige Verantwortung für Ergebnisse, auch wenn es schwierig wird. |

Ownership ist der Kern des Führungsmodells im Buch: Du kannst nicht führen ohne Ownership.

**Barrels und Ammunition.** Keith Rabois, ehemaliger COO bei Square und Executive Vice President bei PayPal, heute Managing Director bei Khosla Ventures, nennt Menschen, die konsequent auf Stufe 7 operieren, Barrels. Ein Barrel trägt eine Initiative von der Idee bis zur Umsetzung eigenständig: motiviert Mitarbeitende, beschafft Ressourcen, wenn sie gebraucht werden, weiß, wie die wichtigsten Kennzahlen gemessen und kommuniziert werden, und liefert am Ende das Ergebnis. Ammunition sind alle anderen, die den Barrels zuarbeiten und sie unterstützen. Beides wird gebraucht, aber das Verhältnis entscheidet, wie viel eine Organisation gleichzeitig voranbringen kann. Die Anzahl der Barrels bestimmt, wie viele wichtige Initiativen parallel verfolgt werden können. Mehr Menschen einzustellen, ohne die Anzahl der Barrels zu erhöhen, erzeugt nur mehr Koordinationsaufwand und Reibungsverluste.

## Wann du sie einsetzt

- **Als Diagnosetool:** Auf welcher Stufe bewegt sich eine Person typischerweise? Ist jemand auf Stufe 2 oder 3, aber selten auf Stufe 6 oder 7? Das gibt dir einen konkreten Ansatzpunkt für ein Entwicklungsgespräch.
- **Als Gesprächsrahmen:** Du besprichst das Modell direkt mit deinen Mitarbeitenden. Das öffnet Gespräche über Verantwortung und Wachstum, ohne dass es wie Kritik wirkt.
- Um Barrels im Team zu erkennen, zu fördern und zu halten, und Mitarbeitende mit Potenzial sukzessive dorthin zu entwickeln.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welche Person oder welches Team geht es, und in welcher Rolle? Willst du einschätzen (Diagnose) oder ein Gespräch vorbereiten (Gesprächsrahmen)? Gibt es einen konkreten Anlass? Frag nichts, was die Person schon gesagt hat.
- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Verlange für jede Einstufung beobachtetes Verhalten als Beleg. Eine Stufe ohne Beispiel ist eine Vermutung und wird als offen markiert.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz. Kein Lob als Füllmaterial.
- Erfinde keine Eigenschaften oder Verhaltensweisen der eingeschätzten Person.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Rolle und Anspruch klären.** Höhere Stufen sind nicht für jede Rolle in jeder Situation das Ziel. Es gibt Aufgaben, bei denen klare Anweisungen sinnvoller sind als volles Ownership.
   Frage: *»Welche Stufe braucht diese Rolle bei ihren wichtigsten Aufgaben?«* Gut ist die Antwort, wenn sie je Aufgabe unterscheidet statt pauschal »Stufe 7« zu fordern.

2. **Typische Stufe einschätzen.** Auf welcher Stufe bewegt sich die Person typischerweise, und wo selten?
   Frage: *»Welche konkreten Situationen der letzten Wochen zeigen, auf welcher Stufe die Person operiert?«* Gut ist die Antwort, wenn jede Einschätzung an einer beobachteten Situation hängt.

3. **Gespräch vorbereiten.** Das Modell direkt mit der Person besprechen. Die Fragen aus dem Buch:
   - Wo siehst du dich selbst?
   - Wo möchtest du hin?
   - Was hält dich auf einer niedrigeren Stufe?

   Frage an die Führungskraft: *»Wie führst du das Modell ein, damit es als gemeinsame Sprache und nicht als Urteil ankommt?«*

4. **Nächste Stufe festlegen.** In der Entwicklungsarbeit geht es darum, Menschen sukzessive zu höheren Stufen zu befähigen, wo es Sinn macht.
   Frage: *»Welche nächste Stufe ist realistisch, und bei welcher Aufgabe kann die Person sie zeigen?«* Gut ist die Antwort, wenn der Schritt sukzessive ist und an eine konkrete Aufgabe gebunden.

5. **Barrels im Team erkennen (optional, für das ganze Team).** Wer trägt heute Initiativen eigenständig von der Idee bis zum Ergebnis? Wer hat das Potenzial, sich dorthin zu entwickeln?
   Frage: *»Wie viele Barrels hast du, und wie viele wichtige Initiativen laufen parallel?«* Gut ist die Antwort, wenn sie zeigt, ob mehr Initiativen als Barrels im Spiel sind.

6. **Fortgesetztes Gespräch.** Die Ownership Ladder macht sichtbar, auf welcher Stufe jemand heute operiert, und bietet eine gemeinsame Sprache für ein fortgesetztes Gespräch über Wachstum. Vereinbare, wann ihr wieder darauf schaut.

## Worauf du achten musst

- **Stufe 7 für alles fordern.** Nicht jede Rolle braucht in jeder Situation volles Ownership. Manchmal sind klare Anweisungen sinnvoller.
- **Das Modell als Kritik einsetzen.** Richtig genutzt öffnet es Gespräche über Verantwortung und Wachstum, ohne dass es wie Kritik wirkt. Eine Einstufung ohne Gespräch mit der Person verfehlt den zweiten Zweck.
- **Einmal einstufen und liegen lassen.** Das Modell ist eine gemeinsame Sprache für ein fortgesetztes Gespräch, keine einmalige Bewertung.
- **Wachstum über Einstellungen lösen.** Mehr Menschen einzustellen, ohne die Anzahl der Barrels zu erhöhen, erzeugt nur mehr Koordinationsaufwand und Reibungsverluste.

## Ergebnis

```markdown
# Ownership Ladder: [Name / Rolle]
Stand: [Datum]

**Benötigte Stufe je Aufgabe:**
| Aufgabe | Benötigte Stufe | Beobachtete Stufe | Beleg (Situation) |
|---|---|---|---|
| … | … | … | … |

**Typische Stufe heute:** … · **Selten erreicht:** …
**Nächste Stufe und Aufgabe, an der sie sich zeigt:** …

**Gesprächsfragen:**
- Wo siehst du dich selbst?
- Wo möchtest du hin?
- Was hält dich auf einer niedrigeren Stufe?

**Nächstes Gespräch:** [Datum]
**Offen:** …
```

Für das ganze Team (optional):

```markdown
**Barrels heute:** …
**Mögliche künftige Barrels:** …
**Wichtige Initiativen parallel:** …
```

## Mini-Check

Aus der LEAD Checklist des Buchs:
- Weißt du, auf welcher Stufe der Ownership Ladder jede Person operiert?

Abgeleitet aus den typischen Fehlern:
- Hast du für jede Aufgabe geklärt, welche Stufe die Rolle wirklich braucht?
- Stützt sich jede Einstufung auf eine beobachtete Situation?
- Hast du das Modell mit der Person besprochen, statt sie nur einzustufen?
- Ist ein nächster Termin vereinbart, an dem ihr wieder darauf schaut?

## Im Flywheel

Modul LEAD, Bereich L5 Grow Your People.

Hinweis zur Abbildung: Abb. 4.13 im Buch zeigt eine andere Darstellung mit acht Stufen zwischen Victim und Owner (von »Ich bin nicht bewusst« über »Ich schiebe die Schuld« und »Ich finde Ausreden« bis »Ich mache es möglich«). Das ist ein eigenständiges Modell, verbreitet als Accountability Ladder. Dieser Skill arbeitet mit den sieben Stufen aus dem Fließtext.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L5 Grow Your People, Ownership Ladder (Abb. 4.13) mit Exkurs Barrels und Ammunition, LEAD Checklist. Das Buch nennt keine Originalquelle, sondern verweist auf die Managementliteratur. Barrels und Ammunition nach Keith Rabois.

Original: Julie Zhuo: The Ladder of Ownership, The Looking Glass, 2021, https://lg.substack.com/p/the-looking-glass-if-someones-gonna (die sieben Stufen Judging, Gossiping, Giving feedback, Giving deep feedback, Collaborating, Driving, Owning). Barrels und Ammunition: Keith Rabois: How to Operate, Vorlesung 14 in How to Start a Startup, Stanford und Y Combinator, 2014, https://startupclass.samaltman.com/courses/lec14/
