# Daily Checklist: Start-up und Shutdown

Nach Abb. 6.6 im Drive Leadership Playbook. Das Format ist ein Vorschlag, den du an deine Bedürfnisse anpasst.

**Datum:**

## Start-up-Ritual
Morgens, 20 bis 30 Minuten

- [ ] Datum der Seite aktualisieren (wenn du ein Journal nutzt).
- [ ] Morning Brain Dump.
- [ ] Kalender für heute checken.
- [ ] Meetings vorbereiten.
- [ ] Erst dann Slack und E-Mail.

**Brain Dump:**

**Meetings heute und Kernfragen (Was will ich erreichen? Was muss ich kommunizieren?):**

| Meeting | Kernfragen |
|---|---|
| | |

## Shutdown-Ritual
Abends, zum Tagesabschluss

- [ ] Einen Win festhalten.
- [ ] Kalender der Woche checken.
- [ ] Tasks für morgen planen.
- [ ] Laptop zuklappen.

**Win des Tages:**

**Tasks für morgen (drei bis fünf):**
1.
2.
3.
