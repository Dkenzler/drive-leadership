---
name: shutdown-ritual
description: Den Arbeitstag bewusst beginnen und beenden mit Start-up-Ritual, Shutdown-Ritual und Daily Checklist, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand morgens direkt in Inbox und Slack rutscht, abends nicht abschalten kann, die Arbeit in den Abend trägt, eine persönliche Tagesroutine oder Daily Checklist aufbauen oder eine bestehende Routine wieder aufnehmen will. Führt durch beide Rituale (Brain Dump, Kalender, Meetings vorbereiten, Win festhalten, Tasks für morgen, Laptop zuklappen) und passt sie an die Person an.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 2 Dich im Alltag steuern
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Shutdown Ritual und Daily Checklist

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Leadership ist eine der wenigen Tätigkeiten, bei denen die Arbeit nie wirklich fertig ist. Es gibt immer ein weiteres Problem, eine Nachricht, eine Entscheidung. Wer keinen bewussten Abschluss des Tages schafft, trägt die Arbeit in den Abend, die Nacht und in die Erholungsphase.

Start-up-Ritual und Shutdown-Ritual sind zwei kurze, klare Momente pro Tag, in denen du bewusst in die Arbeit einsteigst und bewusst aus ihr aussteigst. Das Start-up-Ritual stellt Klarheit über den Tag her, bevor der Tag dich übernimmt. Das Shutdown-Ritual signalisiert dem Gehirn, dass die Arbeit für heute abgeschlossen ist. Das ist notwendig für echte Erholung.

Beide sind kein Produktivitätssystem, sondern Selbstführungswerkzeuge. Sie schaffen zwei Momente der Selbststeuerung in einem Tag, der von außen bestimmt wird. Wer diese Momente hat, kommt häufiger an die Dinge, die wichtig sind, auch wenn kein Meeting daran erinnert.

## Wann du sie einsetzt

- Wenn du morgens direkt in die Inbox springst und ab dem ersten Moment reagierst.
- Wenn du abends nicht abschalten kannst.
- Wenn du eine persönliche Daily Checklist aufbauen oder an deinen Alltag anpassen willst.
- Wenn eine Routine eingeschlafen ist und du den Einstieg wiederfinden willst.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wie beginnt und endet der Arbeitstag heute? Was ist das größere Problem, der Einstieg oder der Ausstieg? Gibt es schon eine Routine oder ein Journal? Frag nichts, was die Person schon gesagt hat.
- Das Format aus dem Buch ist ein Vorschlag, den die Person an ihre Bedürfnisse anpasst. Geh Punkt für Punkt durch und frag, ob er passt, fehlt oder anders aussehen soll.
- Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge Antworten gegen »Worauf du achten musst«. Benenne direkt, wenn die Liste zu lang wird oder zum Produktivitätssystem ausufert.
- Schließe mit einer fertigen Daily Checklist im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Start-up-Ritual (morgens, 20 bis 30 Minuten)**

1. **Datum der Seite aktualisieren** (wenn du ein Journal nutzt). Trivial, aber es signalisiert den Beginn des Tages.
2. **Morning Brain Dump.** Drei bis fünf Minuten aufschreiben, was im Kopf ist: Sorgen, offene Punkte, Ideen, alles. Das leert den Arbeitsspeicher und schafft zentrale Kapazität für den Tag.
3. **Kalender für heute checken.** Welche Meetings kommen? Welche Vorbereitung brauche ich? Gibt es Konflikte oder Dinge, die ich klären muss?
4. **Meetings vorbereiten.** Für jedes wichtige Meeting Kernfragen notieren: Was will ich im Meeting erreichen? Was muss ich kommunizieren?
5. **Erst dann Slack und E-Mail** checken und antworten. Nicht davor.

Frage: *»Was machst du heute in den ersten 30 Minuten, und welcher dieser Schritte fehlt dir am meisten?«* Gut ist eine Antwort, die ehrlich sagt, wann die Inbox heute geöffnet wird.

**Shutdown-Ritual (abends, zum Tagesabschluss)**

6. **Einen Win festhalten.** Was ist heute wirklich gut gelaufen? Ein großes Ergebnis oder eine kleine Interaktion, die sich richtig angefühlt hat. Das trainiert den Blick für das Positive und verhindert, dass der Tag als Liste unerledigter Aufgaben wahrgenommen wird.
7. **Kalender für den Rest der Woche checken.** Gibt es etwas, das ich morgen oder übermorgen vorbereiten muss? Gibt es Konflikte, die ich jetzt klären kann?
8. **Tasks für morgen planen.** Welche drei bis fünf Dinge sind morgen wichtig? Nicht alles, was möglicherweise getan werden könnte, sondern das, was wirklich bewegt werden muss.
9. **Laptop zuklappen.** Kein Symbol, sondern eine Handlung, die das Ende markiert.

Frage: *»Woran merkst du heute, dass dein Arbeitstag zu Ende ist?«* Gut ist eine Antwort mit einer klaren Handlung, nicht mit einer Uhrzeit, die ständig verschoben wird.

**Anpassen.** Frage: *»Welches der beiden Rituale hilft dir mehr?«* Dominik Kenzler arbeitet vor allem mit dem Start-up-Ritual, viele Leader nehmen sich abends die Zeit für einen Shutdown. Wichtig ist, das zu machen, was am meisten hilft.

## Beispiel

Wann immer Dominik Kenzler das Start-up-Ritual in seinen Tag einbaut, merkt er, wie viel Klarheit es gibt und wie viel besser er vorbereitet ist. Es gibt aber auch Phasen, in denen er es nicht schafft: weil das Kind krank ist, weil zu viel zu tun ist oder weil er das Gefühl hat, direkt an die Aufgaben vom Vortag gehen zu müssen. Dann denkt er an das Mantra von Tomo Fujita, Gitarrist und langjähriger Professor am Berklee College of Music: »Don't worry! Don't compare! Don't expect too fast! Be kind to yourself!«

## Worauf du achten musst

- **Direkt in die Inbox springen.** Wer morgens mit Slack und E-Mail startet, reagiert ab dem ersten Moment.
- **Rituale als Produktivitätssystem missverstehen.** Es geht um Selbststeuerung, nicht darum, mehr abzuarbeiten.
- **Zu viele Tasks für morgen.** Drei bis fünf Dinge, die wirklich bewegt werden müssen, nicht alles, was möglich wäre.
- **Den Win auslassen.** Ohne ihn bleibt der Tag eine Liste unerledigter Aufgaben.
- **Kein klares Ende.** Ohne die Handlung »Laptop zuklappen« zieht sich die Arbeit in den Abend.
- **Perfektionismus bei der Routine.** Eine Routine muss nicht jeden Tag stattfinden. Sei sanft mit dir und finde den Einstieg einfach wieder.

## Ergebnis

Vorlage: `templates/daily-checklist.md`.

```markdown
# Daily Checklist: [Name]
Stand: [Datum]

## Start-up-Ritual (morgens, [Dauer])
- [ ] …
- [ ] …
- [ ] Erst dann Slack und E-Mail.

## Shutdown-Ritual (abends, zum Tagesabschluss)
- [ ] Einen Win festhalten.
- [ ] …
- [ ] Laptop zuklappen.

**Schwerpunkt:** Start-up / Shutdown / beide
**Wenn ich rausfalle, steige ich so wieder ein:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Öffnest du Slack und E-Mail erst nach Brain Dump, Kalender und Meeting-Vorbereitung?
- Hältst du jeden Abend einen Win fest?
- Stehen für morgen höchstens drei bis fünf Tasks auf der Liste?
- Gibt es eine klare Handlung, die deinen Arbeitstag beendet?
- Weißt du, wie du wieder einsteigst, wenn die Routine ein paar Tage ausfällt?

## Im Flywheel

Modul YOURSELF, Teil 2 Dich im Alltag steuern.

Verwandte Skills:
- `checklist`: Im SHIP-Kapitel (S5 Ensure Quality) zeigt das Buch eine erweiterte Fassung als persönliche Leadership-Checkliste (Abb. 5.14), unter anderem mit »Offene Punkte dokumentieren«, »Wichtige Entscheidungen in Decision Log« und einem Block Gesundheit.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Methode Shutdown Ritual und Daily Checklist (Abb. 6.6). Erweiterte Fassung im Kapitel SHIP, S5 Ensure Quality, Checklist (Abb. 5.14).
