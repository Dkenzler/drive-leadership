# Team-Roadmap

Nach Abb. 5.8 (Beispielhafte Roadmap, sevdesk Invoice Team, fiktiv) im Drive Leadership Playbook.

**[TEAM] ROADMAP**
Stand: [Quartal] · Subject to Change

**Zielgruppe dieser Sicht:** Leadership und Stakeholder / Team

| CURRENT | NEAR TERM | FUTURE |
|---|---|---|
| **THEMA:** <br> Beschreibung: <br> Status: | **THEMA:** <br> Beschreibung: <br> Status: | **THEMA:** <br> Beschreibung: <br> Status: |
| **THEMA:** <br> Beschreibung: <br> Status: | **THEMA:** <br> Beschreibung: <br> Status: | **THEMA:** <br> Beschreibung: <br> Status: |
| **THEMA:** <br> Beschreibung: <br> Status: | **THEMA:** <br> Beschreibung: <br> Status: | **THEMA:** <br> Beschreibung: <br> Status: |

**Status je Eintrag:** IDEE · DISCOVERY · TESTING · IN ENTWICKLUNG

## Pflege

- Nächster Review (Operating Rhythm, mindestens einmal pro Quartal):
- Änderungen seit der letzten Version:
- Aktiv kommuniziert an / über:
