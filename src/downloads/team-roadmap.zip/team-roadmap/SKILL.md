---
name: team-roadmap
description: "Team-Roadmap im Alltag führen, aus dem Drive Leadership Playbook von Dominik Kenzler: die operative Seite der Roadmap. Was wird wann geliefert und warum, wie hältst du die Roadmap aktuell, machst Confidence je Eintrag sichtbar und zeigst Leadership und Team die jeweils passende Sicht. Nutze diesen Skill, wenn jemand eine Roadmap für ein Produkt-, Marketing-, People- oder Finance-Team erstellen, aktualisieren oder kommunizieren, Änderungen an Stakeholder vermitteln, Status und Unsicherheit je Thema kennzeichnen oder verhindern will, dass die Roadmap als Versprechen gelesen wird. Für Aufbau und Formate strategischer Roadmaps gibt es eigene Skills (roadmap-anatomy, now-next-later, go-product-roadmap)."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S2 Plan & Prioritize
  origin: Dominik Kenzler (Confidence-Konzept aus Product Roadmaps Relaunched)
  deep_dive: false
  version: "1.0"
---

# Roadmap (Team-Roadmap)

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, mit dem Confidence-Konzept aus »Product Roadmaps Relaunched«.

## Worum es geht

Eine Roadmap ist die visuelle Darstellung des Plans: Was wird wann geliefert und warum? Sie ist das zentrale Kommunikationsinstrument zwischen Team, Stakeholdern und Leadership. Das gilt für Produktteams genauso wie für Marketing-, People- oder Finance-Teams, die ihre Initiativen strukturiert kommunizieren wollen.

Ihr größter Wert: Stakeholder und der Rest der Organisation können sich daran orientieren. Sie ist eine Sequenz von Prioritäten. Eine gute Roadmap bietet Self-Service für Stakeholder und spart dir und deinem Team viele Meetings.

Eine Roadmap ist kein Versprechen, sondern die Kommunikation des aktuellen Plans auf Basis der aktuellen Informationen. Das muss explizit gesagt werden, sonst entsteht die Erwartung, dass alles genau so eintritt wie geplant.

**Abgrenzung:** In DRIVE geht es um strategische Roadmaps, ihre Anatomie und Formate wie Now, Next, Later oder die GO Product Roadmap. Dieser Skill behandelt die operative Seite: wie du eine Roadmap im Alltag führst, kommunizierst und lebendig hältst.

## Wann du sie einsetzt

- Wenn ein Team seinen Plan für Stakeholder und Leadership sichtbar machen will.
- Im Operating Rhythm, mindestens einmal pro Quartal, und nach größeren Erkenntnissen.
- Wenn Stakeholder jeden Eintrag als Zusage lesen oder ständig nach dem Stand fragen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Team ist die Roadmap? Für wen ist diese Sicht gedacht (Leadership und Stakeholder oder das Team)? Gibt es eine bestehende Roadmap, die aktualisiert werden soll? Frag nichts, was die Person schon gesagt hat.
- Gibt es eine bestehende Roadmap, beginne mit der Prüfung: Was ist veraltet, was hat sich geändert, und wie wird es kommuniziert?
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge gegen »Worauf du achten musst«. Vor allem: Ist der Detailgrad für die Zielgruppe richtig? Hat jeder Eintrag einen Status?
- Erfinde keine Themen, Termine oder Status. Fehlende Angaben markierst du als offen.
- Soll die Roadmap nach einer Änderung kommuniziert werden, biete an, eine kurze Änderungsnotiz für Stakeholder zu formulieren.
- Schließe mit der Roadmap im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Zielgruppe und Sicht festlegen.** Leadership und Stakeholder brauchen eine andere Sicht als das Team. Leadership will strategische Richtung und Zeitrahmen. Das Team will Klarheit über Prioritäten und Sequenz.
   Frage: *»Wer liest diese Roadmap, und was muss diese Person daraus ablesen können?«* Gut ist die Antwort, wenn eine konkrete Zielgruppe genannt ist, nicht »alle«.

2. **Themen in eine Sequenz bringen.** Was wird wann geliefert und warum? Die Roadmap ist eine Sequenz von Prioritäten.
   Frage: *»Welche Themen stehen an, in welcher Reihenfolge, und warum in dieser?«*

3. **Confidence sichtbar machen.** Statt nur eines »Subject to change«-Vermerks am Ende macht ein Confidence-Level den Unsicherheitsgrad für jeden Eintrag sichtbar. Wie sicher bist du, dass ein Thema so kommt wie geplant? Was ist bereits in der Umsetzung, was noch in der Discovery? Themen in der Discovery bekommen einen anderen Status als Themen in der Entwicklung. Das verhindert, dass Stakeholder jedes Item als Versprechen interpretieren.
   Frage je Thema: *»In welchem Status ist das Thema: Idee, Discovery, Testing oder in Entwicklung?«*

4. **Kein-Versprechen explizit machen.** Die Roadmap sagt ausdrücklich, dass sie den aktuellen Plan auf Basis der aktuellen Informationen zeigt.

5. **Review-Rhythmus festlegen.** Reviewe die Roadmap im Einklang mit dem Operating Rhythm, mindestens einmal pro Quartal oder nach größeren Erkenntnissen.
   Frage: *»Wann wird die Roadmap das nächste Mal überprüft, und wer macht das?«*

6. **Änderungen aktiv kommunizieren.** Nicht darauf warten, dass jemand fragt, was sich geändert hat.
   Frage: *»Was hat sich seit der letzten Version geändert, und über welchen Kanal erfahren es die Stakeholder?«*

## Beispiel

Abb. 5.8 im Buch zeigt eine fiktive Roadmap des sevdesk Invoice Teams, »Stand Q2 · Subject to Change«, mit den Spalten Current, Near Term und Future. Jeder Eintrag hat einen Titel, eine Kurzbeschreibung und einen Status:

| Thema | Beschreibung | Status |
|---|---|---|
| E-Invoice-Funktionalität | XRechnung und ZUGFeRD gesetzeskonform versenden | In Entwicklung |
| Rabatte | Positionsrabatte und Gesamtrabatte auf Rechnungen | In Entwicklung |
| Wiederkehrende Rechnungen | Automatische Erstellung für Abonnement-Modelle | Testing |
| Realtime Preview | Split-View-Editor mit Livevorschau | Discovery |
| WYSIWYG Editor | Direktbearbeitung des Rechnungslayouts | Discovery |
| AI Price Suggestions | Preisempfehlungen und Markt-Benchmarks | Idee |
| AI Enhanced Writing | KI-gestützte Texthilfe für Rechnungstexte | Idee |

## Worauf du achten musst

- **Veraltete Roadmap.** Neue Erkenntnisse, verschobene Prioritäten, ungeplante Arbeit: Wer die Roadmap nicht regelmäßig aktualisiert, kommuniziert einen veralteten Plan. Das ist oft schlimmer als gar keine Roadmap, weil es falsche Erwartungen erzeugt.
- **Änderungen passiv kommunizieren.** Warten, bis jemand fragt.
- **Nur ein »Subject to change« am Ende.** Ohne Confidence je Eintrag liest die Organisation jedes Item als Versprechen.
- **Zu detailliert für Leadership.** Erzeugt sofort Fragen zu konkreten Features.
- **Zu abstrakt für das Team.** Bietet keine Orientierung.
- **Roadmap als Versprechen.** Wenn nicht explizit gesagt wird, dass sie den aktuellen Plan zeigt, entsteht die Erwartung, dass alles genau so eintritt.

## Ergebnis

Vorlage: `templates/team-roadmap.md`.

```markdown
# [Team] Roadmap
Stand: [Quartal / Datum] · Zielgruppe: Leadership und Stakeholder / Team
Hinweis: Diese Roadmap zeigt den aktuellen Plan auf Basis der aktuellen Informationen. Sie ist kein Versprechen.

| Current | Near Term | Future |
|---|---|---|
| **[Thema]** · [Kurzbeschreibung] · Status: … | **[Thema]** · … · Status: … | **[Thema]** · … · Status: … |

Status: Idee · Discovery · Testing · In Entwicklung

**Änderungen seit der letzten Version:** …
**Kommuniziert an / über:** …
**Nächster Review:** … · **Verantwortlich:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hat jeder Eintrag einen Status oder ein Confidence-Level, nicht nur einen Sammelhinweis am Ende?
- Passt der Detailgrad zur Zielgruppe: Richtung und Zeitrahmen für Leadership, Prioritäten und Sequenz für das Team?
- Ist ausdrücklich gesagt, dass die Roadmap kein Versprechen ist?
- Ist der nächste Review im Operating Rhythm terminiert?
- Habt ihr die letzten Änderungen aktiv kommuniziert?

## Im Flywheel

Modul SHIP, Bereich S2 Plan & Prioritize.

Verwandte Skills:
- `roadmap-anatomy`: die strategische Grundstruktur einer Roadmap aus DRIVE (Vision, Business Objectives, Timeframes, Themes, Disclaimer), auf die dieser Skill operativ aufsetzt.
- `now-next-later`: das in DRIVE eingeführte Format, auf das sich das Kapitel bezieht.
- `go-product-roadmap`: im Buch als ausführliche Methodenbeschreibung zur Roadmap genannt.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S2 Plan & Prioritize, Abschnitt Roadmap (Abb. 5.8). Confidence-Konzept aus: C. Todd Lombardo, Bruce McCarthy, Evan Ryan, Michael Connors: Product Roadmaps Relaunched (Autorenangabe laut Abb. 3.14 im Kapitel DRIVE).
