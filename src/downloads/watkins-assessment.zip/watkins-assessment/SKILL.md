---
name: watkins-assessment
description: Teammitglieder bewerten und die nächste Handlung pro Person ableiten mit dem Watkins Assessment Framework nach Michael Watkins (The First 90 Days), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand nach einem Teamwechsel oder einer Teamübernahme jede Person einordnen, Bewertungskriterien (Competence, Judgment, Energy, Focus, Relationships, Trust) gewichten, mit 100 Punkten Prioritäten setzen und über den Entscheidungsbaum zu Keep in Place, Keep and Develop, Move to Another Position, Replace (Low oder High Priority) oder Observe for a While kommen will. Ergebnis ist ein Arbeitsdokument für das Gespräch mit der vorgesetzten Person.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L2 Know Your Team
  origin: Michael Watkins
  deep_dive: false
  version: "1.0"
---

# Watkins Assessment Framework

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Michael Watkins.

## Worum es geht

Michael Watkins hat in »The First 90 Days« ein Assessment-Framework entwickelt, das Dominik Kenzler bei jedem Teamwechsel nutzt. Es ist eines der wenigen Frameworks, die Bewertung und Entscheidung strukturieren. Die meisten Tools helfen beim Messen, Watkins hilft beim Entscheiden.

Das Framework hat zwei Teile:

- **Bewertungskriterien:** sechs Kriterien, nach denen jede Person bewertet wird: Competence, Judgment, Energy, Focus, Relationships und Trust. Jedes Kriterium wird auf einer Skala bewertet. In der Praxis mit Gewichtung: 100 Punkte werden auf die Kriterien verteilt, je nachdem, was im eigenen Kontext am wichtigsten ist.
- **Entscheidungsbaum:** sechs Kategorien, in die jede Person eingeordnet wird, und die daraus folgende Handlung.

Der Entscheidungsbaum zwingt dazu, aus der Analyse in die Handlung zu kommen. Das Ergebnis ist ein klarer Plan, was als Nächstes passieren muss, und ein essenzielles Dokument, um die Pläne mit der direkten vorgesetzten Person zu besprechen.

## Wann du sie einsetzt

- Bei jedem Teamwechsel, nach dem Assessment-Prozess, um für jede Person eine klare Einordnung zu treffen.
- Als privates Arbeitsdokument einer neuen Führungskraft, mit Blick auf die richtige nächste Handlung pro Person.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: In welcher Phase steht die Organisation (etwa Transformation oder stabile Phase)? Wie eng arbeitet das Team mit Stakeholdern? Liegt ein Assessment mit Datenpunkten pro Person vor? Frag nichts, was die Person schon gesagt hat.
- Fehlen Datenpunkte, empfiehl zuerst den `assessment-prozess`. Ohne Beobachtungen, 1:1s und Peer-Sicht ist die Einordnung eine Vermutung.
- Geh den Ablauf Schritt für Schritt durch, Person für Person. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Frag bei jeder Einordnung nach den Datenpunkten dahinter. Schlag »Observe« aktiv vor, wenn die Belege dünn sind, und frag dann nach einer Frist.
- Erfinde keine Einschätzungen über Personen. Du ordnest nur ein, was die Führungskraft beschreibt, und markierst Lücken als offen.
- Behandle das Ergebnis als vertrauliches Arbeitsdokument. Keine Zuschreibungen von Charakter oder Motiven, die nicht beobachtet wurden.
- Schließe mit der Übersicht im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Kriterien festlegen.** Start mit den sechs Kriterien Competence, Judgment, Energy, Focus, Relationships, Trust. Die Kriterien lassen sich anpassen: In manchen Kontexten ergänzt das Buch Kriterien wie Coachability oder Strategic Thinking und reduziert dafür andere. Entscheidend ist, dass sie zur Situation passen.
   Frage: *»Passen die sechs Kriterien zu deiner Situation, oder fehlt eines, etwa Coachability oder Strategic Thinking?«*

2. **Gewichten.** 100 Punkte auf die Kriterien verteilen. Die Gewichtung ist der entscheidende Schritt und macht das Framework zum eigenen. Vor einer Transformation zählen Energy und Focus mehr als in einer stabilen Phase. In einem Team, das eng mit Stakeholdern arbeitet, sind Relationships und Trust besonders relevant.
   Frage: *»Wie verteilst du 100 Punkte, und warum?«* Gut ist die Antwort, wenn die Gewichtung aus der Situation begründet ist und nicht gleichmäßig verteilt.

3. **Bewerten.** Jede Person auf jedem Kriterium auf einer Skala bewerten. Die Skala legt die Führungskraft fest.
   Frage pro Person: *»Wie bewertest du die Person auf jedem Kriterium, und auf welche Beobachtungen stützt du das?«*

4. **Einordnen im Entscheidungsbaum.** Abb. 4.4 führt über diese Fragen:
   1. Genug Datenpunkte für ein klares Urteil? Wenn nein: Observe.
   2. Stimmen Fähigkeiten und Kompetenz für die Rolle?
   3. Stimmen Haltung, Energie und Veränderungsbereitschaft?
   4. Passen die Stärken besser zu einer anderen Rolle?
   5. Besteht dringender Handlungsbedarf?

   Die Antworten führen zu einer der sechs Kategorien:

   | Kategorie | Bedeutung laut Buch |
   |---|---|
   | Keep in Place | Richtige Rolle, richtiges Level, richtige Fähigkeiten. Keine Veränderung nötig. |
   | Keep and Develop | Die Grundlage stimmt, aber es gibt klare Entwicklungsfelder. Potenzial und Bereitschaft sind da, gezielte Unterstützung nötig. |
   | Move to Another Position | Starke Person, falsche Rolle. Die Fähigkeiten passen besser an einer anderen Stelle. |
   | Replace (Low Priority) | Passt nicht zur Rolle, aber kein akuter Handlungsdruck. Zeit für eine gute Lösung. |
   | Replace (High Priority) | Dringender Handlungsbedarf. Die Person blockiert Fortschritt oder schadet dem Team. Je schneller gehandelt wird, desto besser. |
   | Observe for a While | Noch nicht genug Datenpunkte. Legitim, besonders in den ersten Wochen, aber mit klarer Frist. |

   Frage pro Person: *»Wie beantwortest du die fünf Fragen, und in welcher Kategorie landet die Person?«* Gut ist die Antwort, wenn die Kategorie aus den Antworten und den Definitionen folgt und bei Observe eine Frist steht.

5. **Plan ableiten und besprechen.** Für jede Person festhalten, was als Nächstes passiert, und das Dokument mit der direkten vorgesetzten Person besprechen.
   Frage: *»Was ist pro Person der nächste Schritt, bis wann, und wann besprichst du den Plan mit deiner vorgesetzten Person?«*

## Beispiel

Beim Start bei sevdesk gewichtete Dominik Kenzler Competence und Energy am höchsten. Competence, weil die fachliche Qualität angehoben werden musste. Energy, weil eine Phase mit hoher Veränderungsbereitschaft bevorstand.

## Worauf du achten musst

- **Zu schnell urteilen.** Das Framework verführt dazu. Watkins betont, dass erste Eindrücke oft nur Hypothesen sind. Es ist keine Schwäche, noch kein Urteil zu haben. Es ist eine Schwäche, trotzdem eines zu fällen.
- **Observe unterschätzen.** Die Kategorie ist wertvoller, als viele Leader zugeben.
- **Observe als Ausrede.** Beobachten darf nicht zur Vermeidung von Entscheidungen werden. Immer mit klarer Frist.
- **Ungewichtet bewerten.** Ohne Gewichtung spiegeln die Kriterien nicht die eigenen Prioritäten.
- **Bei der Bewertung stehen bleiben.** Die Bewertung allein hilft wenig, wenn nicht klar ist, was daraus folgt.

## Ergebnis

```markdown
# Watkins Assessment: [Team]
Stand: [Datum] · Vertraulich · Zur Besprechung mit: [vorgesetzte Person]
Kontext: [Transformation / stabile Phase / …]

## Gewichtung (Summe 100)
| Kriterium | Punkte | Begründung |
|---|---|---|
| Competence | … | … |
| Judgment | … | … |
| Energy | … | … |
| Focus | … | … |
| Relationships | … | … |
| Trust | … | … |
| [angepasstes Kriterium] | … | … |

Skala: …

## Einordnung pro Person
| Person | Bewertung je Kriterium | Gewichteter Wert | Kategorie | Datenpunkte | Nächster Schritt | Frist |
|---|---|---|---|---|---|---|
| … | … | … | Keep in Place / Keep and Develop / Move / Replace (Low) / Replace (High) / Observe | … | … | … |

## Offen
- …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hast du die Kriterien an deine Situation angepasst und 100 Punkte begründet verteilt?
- Stützt sich jede Einordnung auf mehrere Datenpunkte und nicht auf den ersten Eindruck?
- Hat jede Person in »Observe« eine klare Frist?
- Steht für jede Person ein konkreter nächster Schritt fest?
- Hast du den Plan mit deiner vorgesetzten Person besprochen?

## Im Flywheel

Modul LEAD, Bereich L2 Know Your Team.

Verwandte Skills:
- `assessment-prozess`: liefert die Datenpunkte, auf deren Basis du nach dem Assessment jede Person einordnest.
- `9-box-grid`: Abgrenzung laut Buch. Der Watkins-Baum ist die individuelle Einordnung beim Übernehmen eines Teams, mit Blick auf die nächste Handlung pro Person, dein privates Arbeitsdokument. Das 9-Box Grid ist die organisationsweite Kalibrierung von Performance und Potenzial im Leadership-Team. Beide ergänzen sich.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L2 Know Your Team (Abb. 4.4) und Abgrenzung im Deep Dive 9-Box Grid. Originalquelle: Michael Watkins: The First 90 Days.

Original: Michael D. Watkins: The First 90 Days, Harvard Business School Press, 2003 (erweiterte Neuausgabe 2013).
