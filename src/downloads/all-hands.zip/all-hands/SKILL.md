---
name: all-hands
description: All-Hands, Onsites und Offsites planen und als Führungsinstrument nutzen, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn eine Führungskraft ein All-Hands für den eigenen Bereich aufsetzen oder vorbereiten, den Beitrag des Teams im Company All-Hands sichtbar machen, Teammitglieder auf die Bühne holen, ein Onsite am eigenen Standort oder ein Offsite an einem neuen Ort planen oder klären will, welches Ziel so ein Format haben soll. Führt durch die drei Teile eines All-Hands (Richtung und Kontext, Fortschritt und Erfolge, offene Fragen), Rhythmus und Dauer sowie Zielklärung, Umfang und Organisation von Onsite und Offsite.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L4 Set the Stage
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# All-Hands, Onsite, Offsite

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

All-Hands gibt es auf zwei Ebenen: auf Unternehmensebene, geführt von Geschäftsführung oder Senior Leadership, und auf Department- oder Teamebene, wo du das Format selbst gestaltest. Beide aktiv zu bespielen und als wesentlichen Teil deiner Führungsarbeit zu sehen, nicht als Pflichttermin am Rande, ist eine der unterschätzten Aufgaben als Lead.

Das All-Hands ist kein Statusbericht, sondern ein Führungsinstrument. Ein gutes All-Hands schafft Verbindung, gibt Energie und macht Richtung und Fortschritt spürbar. Im eigenen All-Hands kommunizierst du in die Breite, an alle Personen in deinem Verantwortungsbereich: Richtung, Fortschritt, wichtige Entscheidungen.

Meetings und Rituale strukturieren die Arbeit, aber ein echtes Team entsteht nicht allein durch gute Formate. Es braucht gemeinsame Zeit jenseits des Arbeitsalltags. Team Time gibt es in zwei Formaten: **Onsites** am eigenen Standort und **Offsites** an einem bewusst neuen Ort.

## Wann du sie einsetzt

- **Company All-Hands:** um den Beitrag deines Teams sichtbar zu machen und High Performer und Leads zu platzieren.
- **Eigenes All-Hands:** monatlich, für alle in deinem Verantwortungsbereich.
- **Onsite:** für Formate, bei denen Austausch quer durch die Organisation wichtig ist: gemeinsames Quartals-Planning, Teambuilding, Weiterbildungen, Hackathons, Zeit miteinander.
- **Offsite:** für intensive Strategie- und Denkarbeit, zwei bis fünf Tage, weg vom Alltag.
- Gerade in hybriden oder remote Settings, wo Präsenzzeit knapp ist.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welches Format (Company All-Hands, eigenes All-Hands, Onsite, Offsite)? Für wie viele Personen? Was ist der Anlass? Frag nichts, was die Person schon gesagt hat.
- Geh den passenden Teil des Ablaufs Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Gibt es genug Raum für Fragen? Hat das Onsite oder Offsite ein klares Ziel?
- Biete an, Agenda, Redepunkte für den State of the Union oder Leitfragen für die Teammitglieder zu entwerfen, die vortragen.
- Erfinde keine Zahlen, Erfolge oder Entscheidungen. Was fehlt, markierst du als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

### A. Company All-Hands

**1. Beitrag sichtbar machen.** Deine Aufgabe ist, den Beitrag deines Teams sichtbar zu machen, nicht als Selbstdarstellung, sondern als Führungsarbeit. Shreyas Doshi nennt das Optics: die kontinuierliche Kommunikation des Werts und Fortschritts deines Teams nach innen. Gerade in längeren Projekten passiert viel, bevor ein Produkt releast oder ein kommerzieller Wert sichtbar wird.
Frage: *»Was hat dein Team seit dem letzten All-Hands erreicht, das die Organisation kennen sollte?«*

**2. Leute auf die Bühne holen.** High Performer und Leads aus deinem Team ihre Arbeit selbst präsentieren lassen. Das schafft Sichtbarkeit, stärkt ihre Reputation und zeigt dem Team, dass gute Arbeit wahrgenommen wird.
Frage: *»Wer aus deinem Team präsentiert?«*

### B. Eigenes All-Hands

**3. Rhythmus und Dauer.** Monatlich hat sich am stärksten bewährt, 45 bis 60 Minuten.

**4. Die drei Teile.**
- **Richtung und Kontext:** Was beschäftigt das Unternehmen? Was hat sich verändert? Was sind die wichtigsten Prioritäten? Wo steht das Business, werden die Ziele erreicht? Was läuft gut, was nicht? Dein State of the Union, ehrlich und direkt.
- **Fortschritt und Erfolge:** Was hat das Team in den letzten Wochen erreicht? Arbeit sichtbar machen, Anerkennung geben.
- **Offene Fragen:** Raum für Fragen aus dem Team. Der wichtigste Teil, der am häufigsten zu kurz kommt.

Frage: *»Was ist deine ehrliche Antwort auf ›Wo stehen wir, was läuft gut, was nicht?‹«* Gut ist die Antwort, wenn sie auch Misserfolge benennt und sagt, wie ihr sie korrigiert.

**5. Teammitglieder reinholen.** Nicht alles muss von dir kommen. Teammitglieder berichten über ihre Projekte. Das macht das Format lebendiger und zeigt, dass ihre Arbeit Bühne bekommt.

### C. Onsite und Offsite

**6. Ziel klären.** Onsites und Offsites sind teuer. Ohne klares Ziel werden sie zur Routine ohne Wirkung.
Frage: *»Was soll am Ende erreicht sein, und was soll das Team danach anders machen oder verstehen?«*

**7. Format wählen.**
- **Onsite:** Das Team kommt für einen längeren Zeitraum am eigenen Standort oder Headquarter zusammen. Logistik überschaubar, Ort vertraut.
- **Offsite:** Ausbrechen aus dem Bestehenden, ein ganz neuer Ort. Zwei bis fünf Tage, voll fokussiert. Besonders gut in Gruppen von fünf bis zehn Personen, auch größere Departments können profitieren. Was wie Urlaub aussieht, ist meist intensive Arbeit, selbst abends und beim Frühstück. Ein Offsite ist kein Belohnungsausflug, sondern ein Arbeitsmodus.

**8. Rhythmus, Organisation, Budget.** Alle drei bis sechs Monate kann ein solches Format sehr wertvoll sein, aber nicht inflationär. Die Organisation ist mehr Arbeit, als es aussieht: Unterstützung aus dem Team oder anderen Teilen der Organisation holen, Budgets rechtzeitig einplanen.
Frage: *»Wer organisiert mit, und ist das Budget eingeplant?«*

## Beispiel

**Redesign bei sevdesk.** Nach drei Monaten startete Dominik Kenzler ein firmenweites Redesign von Marke und Produkt. Ursprüngliche Schätzung: 500 000 Euro, externe Agentur, zwei Jahre. Er war überzeugt, es intern in zwölf Monaten mit einem Zehntel des Budgets zu schaffen. Weil das Projekt jeden Bereich betraf, galt: in jedem monatlichen All-Hands ein Update zum Fortschritt, in jeder Townhall ein größeres. Ergebnis: Die gesamte Firma glaubte daran, alle wurden zu Unterstützenden, die den Release kaum erwarten konnten.

**SevWeek.** Bei sevdesk kam jedes Quartal die ganze Firma für drei bis vier Tage im Headquarter zusammen. Mitarbeitende organisierten Workshops und Weiterbildungen für andere, es gab Hackathons, die Woche wurde mit einer Townhall eröffnet. Kein Ausflug, sondern fokussierte Arbeit in einem anderen Rhythmus.

## Worauf du achten musst

- **All-Hands als Statusbericht.** Wer es nur als Informationskanal nutzt, verschenkt das Potenzial.
- **Keine Zeit für Fragen.** Wenn niemand Fragen stellt, ist das kein Zeichen, dass alles klar ist, sondern dass die psychologische Sicherheit fehlt.
- **Optics übertreiben.** Wer aus kleinen Themen riesige Erfolge macht, wird schnell entlarvt. Doshi warnt davor, Optics-Aktivitäten selbst zu feiern: Das signalisiert, dass Sichtbarkeit wichtiger ist als Wirkung. Erfolg und Misserfolg gleichermaßen kommunizieren, bei Misserfolg mit Plan zur Korrektur.
- **Den Erfolg für dich beanspruchen.** Es ist der Erfolg deines Teams, nicht deiner.
- **Alles selbst vortragen.** Teammitglieder reinholen.
- **Onsite oder Offsite ohne Ziel.** Wird schnell zur Routine ohne Wirkung.
- **Offsite als Belohnungsausflug.** Es ist ein Arbeitsmodus.
- **Zu häufig, zu spät geplant.** Nicht inflationär nutzen, Budget rechtzeitig einplanen.

## Ergebnis

```markdown
# [All-Hands / Onsite / Offsite]: [Bereich] · [Datum]
Teilnehmende: … · Dauer: …

## All-Hands
**1. Richtung und Kontext (State of the Union):**
- Was beschäftigt das Unternehmen, was hat sich verändert: …
- Wichtigste Prioritäten: …
- Wo steht das Business, Zielerreichung: …
- Was läuft gut, was nicht (und wie wir korrigieren): …

**2. Fortschritt und Erfolge:**
| Projekt | Wer präsentiert | Kernaussage |
|---|---|---|
| | | |

**3. Offene Fragen:** … Min reserviert · Wie Fragen gesammelt werden: …

## Onsite / Offsite
Ziel: Was am Ende erreicht sein soll: …
Was das Team danach anders macht oder versteht: …
Format: Onsite (eigener Standort) / Offsite (neuer Ort) · Dauer: … · Gruppengröße: …
Programm: …
Organisation (wer unterstützt): … · Budget eingeplant: ja / nein
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)
- Hat das All-Hands alle drei Teile, und ist genug Zeit für offene Fragen reserviert?
- Benennst du auch, was nicht läuft, und wie ihr es korrigiert?
- Präsentieren Teammitglieder ihre Arbeit selbst?
- Hat das Onsite oder Offsite ein klares Ziel und eine Antwort darauf, was das Team danach anders macht?
- Ist die Organisation verteilt und das Budget rechtzeitig eingeplant?

## Im Flywheel

Modul LEAD, Bereich L4 Set the Stage.

Verwandte Skills:
- `progress-optics`: Optics nach Shreyas Doshi, die kontinuierliche Kommunikation des Werts und Fortschritts deines Teams.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L4 Set the Stage. Optics nach Shreyas Doshi.
