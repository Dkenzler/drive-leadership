---
name: star-moment
description: Einen einprägsamen Höhepunkt für eine Präsentation gestalten mit der S.T.A.R. Moment Methode (Something They'll Always Remember) von Nancy Duarte (»Resonate«), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Strategie-Präsentation, ein Kick-off, eine Keynote oder einen externen Pitch vorbereitet und will, dass die Botschaft hängen bleibt, wenn eine Präsentation austauschbar wirkt oder keinen Höhepunkt hat. Führt von der Kernbotschaft über die Wahl eines der fünf Typen (Dramatisierung, wiederholbare Soundbites, evokative Visuals, emotionales Storytelling, überraschende Statistiken) bis zum Üben des Moments. Nicht zu verwechseln mit der S.T.A.R.-Methode für Interviews.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D5 Communicate Direction
  origin: Nancy Duarte
  deep_dive: false
  version: "1.0"
---

# S.T.A.R. Moment

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Nancy Duarte.

## Worum es geht

Die meisten Präsentationen werden vergessen, vor allem weil sie keine einprägsamen Momente enthalten: viele gleichwertige Slides, kein Höhepunkt, nichts, was hängen bleibt. Nancy Duarte, Gründerin der Präsentationsagentur Duarte und Autorin von »Resonate«, hat dafür die S.T.A.R.-Moment-Methode entwickelt. S.T.A.R. steht für **Something They'll Always Remember**.

Ein S.T.A.R. Moment ist ein einzelner, bewusst gestalteter Moment in einer Präsentation, der eine emotionale Reaktion auslösen soll. Das Publikum soll sich noch Tage später daran erinnern, wenn es gefragt wird, worum es in der Präsentation ging.

Duarte erklärt die Wirkung mit vier Faktoren:

- **Emotionale Resonanz:** Starke Gefühle, ob Überraschung, Freude oder Betroffenheit. Emotionen spielen eine zentrale Rolle bei der Gedächtnisbildung.
- **Überraschung:** Der Moment bricht mit der Erwartung und reißt das Publikum aus seinem Denkmuster.
- **Einfachheit:** Der Moment verdichtet die Kernbotschaft in einen einzigen, klaren Moment. Keine Komplexität, keine Erklärung nötig.
- **Sensorische Wirkung:** Ein starkes Bild, eine dramatische Pause oder ein unerwartetes Objekt spricht die Sinne an und verankert sich dadurch.

## Wann du sie einsetzt

Bei wichtigen Präsentationen, bei denen eine Botschaft wirklich ankommen muss: Strategie-Präsentationen, Kick-offs oder externe Pitches.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Worum geht es in der Präsentation? Wer ist das Publikum? Wie viel Zeit und welcher Rahmen (Bühne, Raum, remote)? Frag nichts, was die Person schon gesagt hat.
- Ohne Kernbotschaft kein S.T.A.R. Moment. Fehlt sie, kläre sie zuerst.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Schlage zwei bis drei Ideen für Momente vor, aber nur auf Basis dessen, was die Person über Thema, Publikum und verfügbares Material sagt. Erfinde keine Statistiken, Zitate oder Fakten. Braucht ein Moment eine Zahl, markiere sie als »von der Person zu belegen«.
- Challenge jede Idee gegen »Worauf du achten musst«. Vor allem: Zahlt der Moment direkt auf die Kernbotschaft ein?
- Die S.T.A.R.-Methode für Interviews (Situation, Task, Action, Result), die im Buch im LEAD-Kapitel vorkommt, ist etwas anderes. Verwechselt die Person beides, kläre es kurz.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Mit der Kernbotschaft starten.** Was ist die eine Sache, die das Publikum mitnehmen soll? Der Moment muss direkt darauf einzahlen. Ein Spektakel ohne Verbindung zur Kernbotschaft ist Ablenkung, kein S.T.A.R. Moment.
   Frage: *»Was ist die eine Botschaft, an die sich dein Publikum in einer Woche erinnern soll?«* Gut ist die Antwort, wenn sie ein Satz ist.

2. **Das Publikum kennen.** Welcher Typ von Moment wird bei dieser Gruppe resonieren?
   Frage: *»Was würde dein Publikum überraschen? Was würde es berühren?«* Gut ist die Antwort, wenn sie konkret auf diese Gruppe zugeschnitten ist, nicht auf Publikum im Allgemeinen.

3. **Typ wählen.** Einer der fünf Typen nach Duarte:
   - **Dramatisierung:** Eine Live-Demonstration oder Inszenierung, die die Botschaft erlebbar macht.
   - **Wiederholbare Soundbites:** Ein kurzer, rhythmischer Satz, den andere zitieren, wenn sie die Präsentation beschreiben. Er kann als Refrain wiederkehren.
   - **Evokative Visuals:** Ein Bild oder eine visuelle Darstellung, die eine emotionale Reaktion auslöst.
   - **Emotionales Storytelling:** Eine Geschichte, die berührt und die Botschaft menschlich macht. Fakten informieren, Geschichten berühren.
   - **Überraschende Statistiken:** Eine Zahl, die Erwartungen erschüttert. Die stärksten funktionieren über Vergleich oder Kontrast. Die nackte Zahl reicht selten, erst Bezug und Kontext machen sie greifbar.

   Frage: *»Welcher Typ passt zu deiner Botschaft und zu deinem Publikum, und wie sähe der Moment konkret aus?«* Gut ist die Antwort, wenn sich der Moment in ein bis zwei Sätzen beschreiben lässt und mindestens einen der vier Wirkfaktoren trifft.

4. **Einfach halten.** Je direkter und klarer der Moment, desto einprägsamer. Duarte nennt das »Murder your Darlings«: Alles, was die Wirkung verwässert, muss raus.
   Frage: *»Was kannst du am Moment und drumherum weglassen?«* Gut ist die Antwort, wenn der Moment ohne Erklärung funktioniert.

5. **Platzieren und üben.** S.T.A.R. Moments passieren nicht zufällig. Sie brauchen Timing, Pausen und Präzision. Proben, bis es sich natürlich anfühlt.
   Frage: *»An welcher Stelle der Präsentation sitzt der Moment, und wann probst du ihn?«* Gut ist die Antwort, wenn Stelle und Probentermin feststehen.

## Beispiel

Steve Jobs begann die iPhone-Keynote 2007 nicht mit dem iPhone, sondern kündigte drei revolutionäre Produkte an: einen Widescreen-iPod mit Touch-Steuerung, ein revolutionäres Mobiltelefon und ein bahnbrechendes Internetgerät. Er wiederholte die drei Produkte, und noch einmal. Das Publikum begann zu ahnen, was kommt. Als Jobs sagte, dass es sich um ein einziges Gerät handelt, brach der Saal in Jubel aus. Der Moment war kein Zufall, er war akribisch geplant.

Weitere Beispiele aus dem Buch, je Typ: Bill Gates ließ in einer Präsentation über Malaria Moskitos frei (Dramatisierung). Martin Luther Kings »I have a dream« wurde durch Wiederholung zum Refrain (Soundbite). Al Gore fuhr in »An Inconvenient Truth« mit einer Hebebühne an die Spitze seiner CO2-Grafik (Visual). Brené Brown begann ihren zweiten TED Talk mit dem Eingeständnis eines Nervenzusammenbruchs nach ihrer ersten Rede (Storytelling). »Bis 2050 wird es mehr Plastik als Fische in den Ozeanen geben« (Statistik).

## Worauf du achten musst

- **Keine Verbindung zur Kernbotschaft.** Der Moment unterhält, verstärkt aber nichts.
- **Zu viele S.T.A.R. Moments.** Mehrere Höhepunkte in einer Präsentation verwässern die Wirkung. Einer reicht.
- **Nicht geübt.** Ohne Probe fehlt das Timing, und der Moment verpufft.

## Ergebnis

```markdown
# S.T.A.R. Moment: [Präsentation]
Anlass: … · Publikum: …

**Kernbotschaft (ein Satz):** …
**Was das Publikum überrascht oder berührt:** …

**Typ:** Dramatisierung / Soundbite / Evokatives Visual / Emotionales Storytelling / Überraschende Statistik
**Der Moment (1 bis 2 Sätze):** …
**Wirkfaktoren:** Emotionale Resonanz / Überraschung / Einfachheit / Sensorische Wirkung
**Verbindung zur Kernbotschaft:** …

**Platzierung in der Präsentation:** …
**Was rausfliegt (Murder your Darlings):** …
**Probe:** wann, wie oft: …
**Offen / zu belegen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Zahlt der Moment direkt auf die eine Kernbotschaft ein?
- Gibt es genau einen S.T.A.R. Moment in der Präsentation?
- Funktioniert der Moment ohne Erklärung?
- Ist der Moment auf dieses Publikum zugeschnitten?
- Hast du den Moment geprobt, mit Timing und Pausen?

## Im Flywheel

Modul DRIVE, Bereich D5 Communicate Direction.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D5 Communicate Direction. Originalquelle: Nancy Duarte: Resonate.
Original: Nancy Duarte: Resonate. Present Visual Stories that Transform Audiences, Wiley, 2010, Kapitel 7 »Deliver Something They'll Always Remember«. https://www.resonatebook.com/chapter-7/
