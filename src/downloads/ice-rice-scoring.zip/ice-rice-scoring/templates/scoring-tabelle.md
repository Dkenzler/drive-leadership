# ICE/RICE Scoring-Tabelle

Nach Abb. 5.3 und 5.4 im Drive Leadership Playbook. ICE nach Sean Ellis, RICE nach Sean McBride (Intercom).

**Team / Vorhaben:**
**Ziel, auf das die Initiativen einzahlen:**
**Datum:**
**Skala (für alle Faktoren gleich):**

## Variante ICE

Impact × Confidence × Ease = ICE Score

| Projekt-Idee | Impact | Confidence | Ease | ICE Score |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

## Variante RICE

(Reach × Impact × Confidence) ÷ Effort = RICE Score

| Projekt-Idee | Reach (Nutzende) | Impact | Confidence | Effort (Personentage oder -wochen) | RICE Score |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

## Dialog

- Wo weichen unsere Einschätzungen am stärksten ab, und warum?
- Was könnten wir weglassen, um einen ähnlichen Impact bei 50 Prozent weniger Effort zu erzielen?
- Für welche weiteren Segmente wäre die Initiative relevant (Reach)?
