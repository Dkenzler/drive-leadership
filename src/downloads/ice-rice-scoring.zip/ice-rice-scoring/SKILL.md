---
name: ice-rice-scoring
description: Priorisieren mit ICE und RICE Scoring aus dem Drive Leadership Playbook. ICE (Impact, Confidence, Ease) nach Sean Ellis, RICE (Reach, Impact, Confidence, Effort) nach Sean McBride bei Intercom. Nutze diesen Skill, wenn jemand Ideen, Features oder Initiativen strukturiert bewerten und ordnen, einen Backlog priorisieren, eine Priorisierungsrunde mit dem Team vorbereiten, Bauchgefühl und politischen Druck durch eine gemeinsame Sprache ersetzen oder Scores als Ausgangspunkt für ein Gespräch über Annahmen nutzen will.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S2 Plan & Prioritize
  origin: ICE nach Sean Ellis, RICE nach Sean McBride (Intercom)
  deep_dive: false
  version: "1.0"
---

# ICE/RICE Scoring

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Sean Ellis (ICE) und Sean McBride, Intercom (RICE).

## Worum es geht

ICE und RICE sind Priorisierungsframeworks, die Ideen, Features oder Initiativen anhand einer strukturierten Bewertung ordnen. Statt nach Bauchgefühl oder politischem Druck zu priorisieren, werden Faktoren bewertet und zu einem Score kombiniert.

- **ICE** (geprägt von Sean Ellis, dem Pionier des Growth Hacking): **Impact**, wie stark eine Initiative auf das Ziel einzahlt. **Confidence**, wie sicher du dir mit deiner Einschätzung bist. **Ease**, wie einfach die Umsetzung ist. Score: Impact × Confidence × Ease.
- **RICE** (bei Intercom entwickelt) erweitert ICE um eine vierte Dimension. **Reach**, wie viele Nutzende eine Initiative betrifft. **Impact**, wie stark sie wirkt. **Confidence**. **Effort**, der Aufwand in Personentagen oder Personenwochen. Score: (Reach × Impact × Confidence) ÷ Effort.

Beide machen implizite Annahmen explizit. Wenn ein Team diskutiert, was wichtiger ist, reden die meisten aneinander vorbei, weil jede Person andere Faktoren gewichtet. ICE und RICE zwingen alle in dieselbe Sprache. Sie ersetzen kein tiefes Assessment und sind oft grobe Einschätzungen und Meinungen. Aber sie erzeugen einen wichtigen Diskurs und helfen bei einer ersten Priorisierung. Der Prozess des Scorings ist oft wertvoller als das Ergebnis.

## Wann du sie einsetzt

- Für eine erste Priorisierung der wichtigsten Initiativen, allein oder gemeinsam mit Mitarbeitenden und Teams.
- Wenn Priorisierung nach Lautstärke oder Reihenfolge der Anfragen passiert.
- Wenn ein Team aneinander vorbeiredet, weil jede Person anders gewichtet.

Abgrenzung: Die Impact/Effort-Matrix ist weniger präzise, aber schneller. ICE/RICE ist ein Scoring-System.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Initiativen stehen zur Auswahl? Auf welches Ziel sollen sie einzahlen? Bewertet die Person allein oder mit dem Team? Frag nichts, was die Person schon gesagt hat.
- Lass die Person zwischen ICE und RICE wählen. RICE, wenn Reichweite und Aufwand in Personentagen sinnvoll schätzbar sind, sonst ICE.
- Lege vor dem Scoring die Skala fest und halte sie für alle Initiativen gleich.
- Geh Initiative für Initiative vor. Frag je Faktor nach Wert und Begründung.
- Challenge gegen »Worauf du achten musst«. Vor allem: Scoring-Inflation. Wenn alles hohe Werte bekommt, benenne es.
- Nutze das Framework als Mittel zum Dialog, nicht nur als Rechenhilfe. Stell nach dem Scoring die Dialogfragen aus Schritt 5.
- Bewertet ein Team, biete an, die Scoring-Runde vorzubereiten: Initiativenliste, Skala, getrennte Einzelbewertung, dann Abgleich der Abweichungen.
- Erfinde keine Werte für Reach, Aufwand oder Wirkung. Fehlen Daten, markiere die Einschätzung als Annahme und senke die Confidence.
- Rechne die Scores korrekt aus und zeig die Rechnung. Schließe mit der Tabelle im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Ziel und Initiativen festlegen.** Frage: *»Auf welches Ziel sollen die Initiativen einzahlen, und welche stehen zur Auswahl?«* Gut ist die Antwort, wenn das Ziel konkret genug ist, um Impact daran zu messen.

2. **ICE oder RICE wählen und Skala festlegen.** Frage: *»Könnt ihr abschätzen, wie viele Nutzende jede Initiative erreicht und wie viele Personentage sie kostet?«* Wenn ja, RICE. Wenn nein, ICE.

3. **Faktoren je Initiative bewerten.** Für ICE: Impact, Confidence, Ease. Für RICE: Reach, Impact, Confidence, Effort. Bewertet ein Team, zuerst einzeln, dann abgleichen.
   Frage je Faktor: *»Welchen Wert gibst du, und worauf stützt du ihn?«* Gut ist die Antwort, wenn die Begründung eine Annahme offenlegt, die sich prüfen lässt.

4. **Abweichungen besprechen.** Bewerten Teammitglieder denselben Vorschlag sehr unterschiedlich, ist das der Ausgangspunkt für das wichtigste Gespräch: *»Warum siehst du das so und ich so?«*

5. **Die Faktoren als Dialog nutzen.** Nicht nur fragen »Was hat den höchsten Score?«, sondern in die Faktoren eintauchen, zum Beispiel:
   - *»Was könnten wir weglassen, um einen ähnlichen Impact bei 50 Prozent weniger Effort zu erzielen?«*
   - *»Wäre das Feature nicht auch für Segment X und Y relevant, was die Reach deutlich erhöhen würde?«*

6. **Scores berechnen, sortieren, Annahmen prüfen.** Den höchsten Score nicht automatisch umsetzen. Frage: *»Welche Annahme hinter dem Spitzenreiter müsste stimmen, damit er wirklich vorne liegt?«*

## Beispiel

Abb. 5.4 im Buch zeigt ein ICE-Scoring mit drei Projektideen:

| Projekt-Idee | Impact | Confidence | Ease | ICE Score |
|---|---|---|---|---|
| Rechnungssystem | 7 | 1 | 5 | 35 |
| Community Tab | 7 | 2 | 8 | 112 |
| Neues Rechnungs-Layout | 5 | 5 | 3 | 75 |

Bei sevdesk fiel Dominik auf, dass das Framework oft zu eindimensional genutzt wird, als reine Entscheidungshilfe zwischen Optionen. Er nutzt es eher als Mittel zum Dialog, um tief in die einzelnen Faktoren einzutauchen.

## Worauf du achten musst

- **Score als objektive Wahrheit.** Der Score ist eine strukturierte Meinungssammlung. Wer den höchsten Score automatisch umsetzt, ohne die Annahmen zu hinterfragen, nutzt das Framework falsch.
- **Scoring-Inflation.** Alle Vorschläge bekommen hohe Werte, weil niemand Nein sagen will. Das macht das Framework wertlos. Konsequent differenzieren.
- **Nur rechnen, nicht reden.** Der Wert liegt im Gespräch über abweichende Einschätzungen und über die Faktoren, nicht in der Zahl.

## Ergebnis

Vorlage: `templates/scoring-tabelle.md`.

```markdown
# ICE/RICE Scoring: [Team / Vorhaben]
Stand: [Datum] · Ziel: … · Framework: ICE / RICE · Skala: …

| Initiative | (Reach) | Impact | Confidence | Ease / Effort | Score | Wichtigste Annahme |
|---|---|---|---|---|---|---|
| … | | | | | | |

**Reihenfolge:** 1. … 2. … 3. …
**Größte Abweichungen in der Bewertung und was wir daraus gelernt haben:** …
**Ideen aus dem Dialog (weniger Effort, mehr Reach):** …
**Annahmen, die vor der Entscheidung geprüft werden:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Sind die Werte differenziert, oder haben fast alle Initiativen hohe Scores?
- Kennst du für den Spitzenreiter die Annahme, die stimmen muss?
- Habt ihr über die größten Abweichungen in der Bewertung gesprochen?

## Im Flywheel

Modul SHIP, Bereich S2 Plan & Prioritize.

Verwandte Skills:
- `impact-effort-matrix`: weniger präzise, aber schneller. Kein Scoring-System, sondern ein Gesprächswerkzeug. Beide haben je nach Kontext ihre Berechtigung.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S2 Plan & Prioritize und Abschnitt ICE/RICE Scoring (Abb. 5.3, 5.4). Originalquelle: ICE nach Sean Ellis, RICE nach Sean McBride (Intercom).
Original: ICE: Sean Ellis, Morgan Brown: Hacking Growth, 2017. RICE: Sean McBride: RICE. Simple prioritization for product managers, Intercom Blog. https://www.intercom.com/blog/rice-simple-prioritization-for-product-managers/
