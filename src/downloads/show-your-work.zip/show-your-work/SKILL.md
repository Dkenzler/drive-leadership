---
name: show-your-work
description: "Best Practice Sharing und Show Your Work, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand die Qualitätsbar im Team sichtbar machen und kontinuierlich erhöhen will, indem gute Beispiele von außen und aus dem eigenen Team regelmäßig geteilt und eingeordnet werden. Typische Auslöser: gemeinsames Qualitätsverständnis aufbauen, Inspirations- oder Slack-Kanal aufsetzen, Lightning Demos durchführen (Format aus dem Design Sprint von Jake Knapp, John Zeratsky, Braden Kowitz), Book Club starten, Lernkultur stärken, Fehler und Learnings teilen."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S5 Ensure Quality
  origin: Dominik Kenzler (Lightning Demos nach Jake Knapp, John Zeratsky und Braden Kowitz)
  deep_dive: false
  version: "1.0"
---

# Show Your Work

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, Lightning Demos nach Jake Knapp, John Zeratsky und Braden Kowitz.

## Worum es geht

Die Qualitätsbar steht nicht still. Was heute als exzellent gilt, ist morgen Standard. Einer der wirkungsvollsten Wege, sie kontinuierlich zu erhöhen, ist das regelmäßige Teilen von Best Practices, intern und extern. Artikel, Talks, Produkte anderer Unternehmen, Moodboards: All das schafft eine gemeinsame Referenzgrundlage, auf die sich ein Team beziehen kann. Es geht nicht ums Kopieren, sondern um ein geteiltes Bild davon, was exzellent aussieht und sich so anfühlt.

Der Grundsatz: nicht kommentarlos teilen. Was du zeigst, braucht Einordnung. Was findest du besonders gut? Warum ist das ein starkes Beispiel? Erst durch diesen Dialog entsteht ein gemeinsames Verständnis, was »gut« bedeutet. Du musst das Vorbild nicht selbst erschaffen. Es reicht, wenn du es zeigen und benennen kannst, so wie gute Professoren Beispiele zeigen, Fragen stellen und ein geteiltes Qualitätsgefühl im Raum schaffen.

## Wann du sie einsetzt

- Wenn die Qualitätsbar im Team diffus ist und abstrakt bleibt (»Das muss hochwertiger wirken«).
- Wenn das Team einen gemeinsamen Referenzraum braucht, auf den es sich später beziehen kann.
- Als fester, wiederkehrender Bestandteil des Teamalltags, nicht als einmalige Aktion.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wie groß ist das Team und in welcher Disziplin arbeitet es? Was wird heute schon geteilt, und wo? Wo ist die Qualitätsbar gerade unklar? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann einzelne Formate auswählen und andere überspringen.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Teilt nur die Führungskraft? Werden nur Erfolge gezeigt? Fehlt die Einordnung? Benenne Schwächen direkt und kurz.
- Hilf bei der Einordnung konkreter Beispiele: Bringt die Person ein Beispiel mit, frag, was genau daran gut ist und warum. Bewerte das Beispiel nicht an ihrer Stelle.
- Erfinde keine Beispiele, Produkte oder Referenzen für die Person. Fehlt etwas, markiere es als offen.
- Für eine Lightning-Demo-Session biete an, Einladung, Ablauf und die Vorlage `templates/lightning-demo.md` vorzubereiten.
- Schließe mit dem Plan im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Einordnen lernen.** Jedes geteilte Beispiel bekommt eine Einordnung: Was ist daran besonders gut? Warum ist es ein starkes Beispiel? Du kannst auch aktiv fragen, wie andere dazu stehen.
   Frage: *»Nimm ein Beispiel, das du zuletzt geteilt hast oder teilen willst: Was genau ist daran gut, und warum?«*
   Gut ist die Antwort, wenn sie konkret benennt, woran die Qualität festzumachen ist, statt »gefällt mir«.

2. **Externe Referenzen und interne Highlights teilen.** Einen festen Ort wählen, etwa einen Slack-Kanal. Dort regelmäßig starke Beispiele von außen teilen und genauso hervorheben, wenn im eigenen Team etwas besonders gut gelungen ist. Externe Referenzen zeigen, was möglich ist. Interne Highlights machen sichtbar, dass das Team auf diesem Level arbeiten kann.
   Frage: *»Wo teilt ihr, und wann habt ihr zuletzt etwas aus dem eigenen Team hervorgehoben?«*

3. **Lightning Demos durchführen.** Das Format stammt aus dem Design Sprint, entwickelt bei Google Ventures, und ist hier aus dem Sprintkontext in den regulären Teamalltag übertragen. Jede Person hat fünf Minuten. Sie zeigt ein Produkt, ein Feature, eine Kampagne oder eine Idee aus der Welt da draußen, die sie beeindruckt oder inspiriert hat, und erklärt in wenigen Sätzen, was sie daran besonders gut findet. Kein langer Vortrag, keine Präsentation, nur ein konkretes Beispiel mit klarer Einordnung. Die Vorlage in Abb. 5.15 hält pro Beispiel Strengths, Weaknesses und Opportunities fest.
   Frage: *»Wer bringt zur nächsten Session ein Beispiel mit, und aus welchen Bereichen oder Branchen?«*
   Gut ist die Planung, wenn Beispiele aus verschiedenen Bereichen kommen. Das erzeugt oft die interessantesten Querverbindungen.

4. **Book Clubs und andere Formate.** Eine kleine Gruppe liest dasselbe Buch zu Leadership, Product Management, Design oder Marketing und tauscht sich aus: Was ist überzeugend, was ist auf die eigene Arbeit übertragbar? Podcasts und Videos funktionieren genauso.

5. **Alle beitragen lassen und Fehler zeigen.** Das Team teilt regelmäßig selbst, nicht nur die Führungskraft. Und neben Erfolgen werden auch Fehler geteilt, mit dem, was man daraus gelernt hat.
   Frage: *»Wer außer dir hat im letzten Monat etwas geteilt, und wann wurde zuletzt ein Fehler mit Learning gezeigt?«*

## Beispiel

Dominik Kenzler teilt im Slack-Kanal regelmäßig starke Beispiele von außen und hebt hervor, wenn im eigenen Team etwas besonders gut gelungen ist. Nach einer Session mit sieben oder acht Lightning Demos hat das Team nicht nur neue Ideen gesehen, sondern einen gemeinsamen Referenzraum geschaffen, auf den es sich in der Folge beziehen kann. Die Demos sind kurz genug, dass alle dabei bleiben, und sie zwingen dazu, konkret zu benennen, was gut ist und warum. Abb. 5.15 zeigt eine Lightning-Demo-Vorlage mit Beispielen wie eBay, Deliveroo, Amazon und Nike.

## Worauf du achten musst

- **Kommentarlos teilen.** Ein Link ohne Einordnung baut kein gemeinsames Verständnis von »gut« auf.
- **Einbahnstraße.** Die Führungskraft teilt, die anderen konsumieren. Wirkungsvoller ist es, wenn alle im Team regelmäßig etwas beitragen.
- **Nur Erfolge zeigen.** Wer nur Erfolge zeigt, verschenkt die Hälfte des Lernpotenzials. Fehler zu teilen und zu erklären, was man daraus gelernt hat, trägt mehr zur Lernkultur bei als jedes perfekte Beispiel.
- **Kopieren statt verstehen.** Ziel ist ein geteiltes Bild von Exzellenz, nicht die Übernahme fremder Lösungen.

## Ergebnis

Vorlage für eine Session: `templates/lightning-demo.md`.

```markdown
# Show Your Work: [Team]
Stand: [Datum]

**Wo wir teilen:** [Kanal / Ort]
**Regel:** Nichts ohne Einordnung (Was ist gut? Warum?)

| Format | Rhythmus | Wer trägt bei | Nächster Termin |
|---|---|---|---|
| Externe Referenzen und interne Highlights | … | alle | laufend |
| Lightning Demos (5 Min pro Person) | … | … | … |
| Book Club / Podcasts / Videos | … | … | … |
| Fehler und Learnings teilen | … | … | … |

**Wo die Qualitätsbar gerade unklar ist:** …
**Offen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Wird jedes geteilte Beispiel eingeordnet: Was ist gut, und warum?
- Tragen alle im Team regelmäßig etwas bei, nicht nur die Führungskraft?
- Teilt ihr neben Erfolgen auch Fehler und was ihr daraus gelernt habt?
- Hebt ihr neben externen Referenzen auch gute Arbeit aus dem eigenen Team hervor?

## Im Flywheel

Modul SHIP, Bereich S5 Ensure Quality. Show Your Work dient dem Ziel aus der SHIP Checklist: die Qualitätsbar für das Team klar definieren und sichtbar machen, durch Beispiele, Reviews oder Referenzprodukte.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S5 Ensure Quality, Einleitung »Die Bar definieren« und »Inspiration von außen«, Best Practice Sharing und Show Your Work, Abb. 5.15, SHIP Checklist. Lightning Demos aus dem Design Sprint von Jake Knapp, John Zeratsky und Braden Kowitz (Google Ventures).
