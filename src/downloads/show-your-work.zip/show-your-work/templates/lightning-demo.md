# Lightning Demo

Nach Abb. 5.15 im Drive Leadership Playbook, Lightning Demo nach Jake Knapp.

**Team:**
**Datum:**
**Regel:** Jede Person hat fünf Minuten. Ein konkretes Beispiel von außen (Produkt, Feature, Kampagne, Idee) und in wenigen Sätzen, was daran besonders gut ist. Kein langer Vortrag, keine Präsentation.

## Beispiel 1: [Name]
Vorgestellt von:

**Strengths:**

**Weaknesses:**

**Opportunities:**

## Beispiel 2: [Name]
Vorgestellt von:

**Strengths:**

**Weaknesses:**

**Opportunities:**

## Beispiel 3: [Name]
Vorgestellt von:

**Strengths:**

**Weaknesses:**

**Opportunities:**

## Beispiel 4: [Name]
Vorgestellt von:

**Strengths:**

**Weaknesses:**

**Opportunities:**

## Gemeinsamer Referenzraum
Worauf wir uns ab jetzt beziehen können:
