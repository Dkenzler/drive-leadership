---
name: hedgehog-concept
description: "Prüfen, ob eine Strategie wirklich zur eigenen Organisation passt, mit dem Hedgehog Concept von Jim Collins (Good to Great), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Strategie fokussieren, eine generische Strategie auf die eigenen Stärken zurückführen, Optionen auf ihren Bezug zur eigenen DNA prüfen oder in der Strategiearbeit eine zusätzliche Perspektive einnehmen will. Führt durch die drei Fragen: Was können wir am besten? Wofür brennen wir? Was treibt unseren wirtschaftlichen Motor?"
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D2 Strategy
  origin: Jim Collins
  deep_dive: false
  version: "1.0"
---

# Hedgehog Concept

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Jim Collins.

## Worum es geht

Das Hedgehog Concept stammt von Jim Collins aus dem Buch »Good to Great«. Es basiert auf drei Fragen:

- Was können wir am besten?
- Wofür brennen wir?
- Was treibt unseren wirtschaftlichen Motor?

Strategie entsteht in der Schnittmenge dieser drei Kreise. Das Konzept zwingt zur Fokussierung: Nicht alles, was möglich ist, ist richtig. Nur, was alle drei Fragen beantwortet, gehört ins Zentrum der Strategie.

Dominik Kenzler nutzt das Hedgehog Concept als zusätzliche Perspektive, nicht als abgeschlossenes Framework. Es prüft, ob eine Strategie wirklich zur Organisation passt und ihre Stärken ausspielt. Es verhindert, dass Strategien generisch werden, weil es den Bezug zur eigenen DNA herstellt.

## Wann du sie einsetzt

- Prüfen, ob eine Strategie wirklich zu euch passt und eure Stärken ausspielt.
- Eine Strategie fokussieren, wenn zu vieles möglich scheint.
- Als zusätzliche Perspektive neben einem anderen Strategie-Framework.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Organisation oder welchen Bereich? Gibt es eine Strategie oder Optionen, die geprüft werden sollen? Arbeitet die Person allein oder mit einem Team? Frag nichts, was sie schon gesagt hat.
- Geh die drei Fragen nacheinander durch. Eine Frage, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist das wirklich das, was ihr am besten könnt, oder nur etwas, das ihr gut könnt?
- Erfinde keine Fakten über die Organisation. Was die Person nicht belegen kann, markierst du als Einschätzung.
- Arbeitet die Person mit einem Team, biete an, Moderationsfragen für die drei Kreise zu erstellen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Was können wir am besten?**
   Frage: *»Was kann eure Organisation besser als andere?«*
   Gut ist die Antwort, wenn sie spezifisch ist und nicht auf jedes Unternehmen der Branche passen würde.

2. **Wofür brennen wir?**
   Frage: *»Wofür brennt ihr als Organisation wirklich?«*
   Gut ist die Antwort, wenn sie erkennbar zu dieser Organisation gehört.

3. **Was treibt unseren wirtschaftlichen Motor?**
   Frage: *»Womit verdient ihr euer Geld, und was treibt es an?«*
   Gut ist die Antwort, wenn sie den wirtschaftlichen Kern benennt, nicht das gesamte Angebot.

4. **Die Schnittmenge bestimmen.** Was beantwortet alle drei Fragen? Nur das gehört ins Zentrum der Strategie.
   Frage: *»Was liegt in allen drei Kreisen zugleich?«*

5. **Die Strategie prüfen.** Die bestehende Strategie oder die Optionen gegen die Schnittmenge legen.
   Frage: *»Welche Teile eurer Strategie liegen in der Schnittmenge, und welche nicht?«*
   Gut ist die Antwort, wenn sie benennt, was nicht ins Zentrum gehört, auch wenn es möglich wäre.

## Worauf du achten musst

Das Buch nennt keine typischen Fehler. Die Punkte folgen aus der Beschreibung.

- **Alles Mögliche ins Zentrum nehmen.** Nicht alles, was möglich ist, ist richtig. Nur die Schnittmenge aller drei Kreise gehört ins Zentrum.
- **Generische Antworten.** Passt eine Antwort auf jede Organisation, fehlt der Bezug zur eigenen DNA.
- **Als vollständige Strategie behandeln.** Das Hedgehog Concept ist eine zusätzliche Perspektive, kein abgeschlossenes Framework.

## Ergebnis

```markdown
# Hedgehog Concept: [Organisation / Bereich]
Stand: [Datum]

| Kreis | Antwort |
|---|---|
| Was können wir am besten? | … |
| Wofür brennen wir? | … |
| Was treibt unseren wirtschaftlichen Motor? | … |

**Schnittmenge (Zentrum der Strategie):** …

**Strategie-Check:**
- Liegt in der Schnittmenge: …
- Liegt außerhalb, obwohl möglich: …

**Offen / Einschätzungen:** …
```

## Mini-Check

Aus der Drive Checklist (Strategy):
- Beschreibt die Strategie, was euch unterscheidet, und nicht nur, was ihr besser machen wollt?

(abgeleitet aus den typischen Fehlern)
- Beantwortet das Zentrum eurer Strategie alle drei Fragen?
- Würden eure Antworten auch auf einen Wettbewerber passen?
- Habt ihr benannt, was außerhalb der Schnittmenge liegt?

## Im Flywheel

Modul DRIVE, Bereich D2 Strategy. Das Hedgehog Concept taucht auch in Jim Collins' Flywheel auf, das das Buch im Kapitel Leadership Flywheel zeigt: Schritte nach vorn, im Einklang mit dem Hedgehog Concept (Abb. 2.1).

Verwandte Skills:
- `ikigai`: stellt ähnliche Fragen wie das Hedgehog Concept, aus einer persönlicheren Perspektive.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D2 Strategy (Abb. 3.8), Leadership Flywheel (Abb. 2.1), YOURSELF, Ikigai. Originalquelle: Jim Collins: Good to Great.
Original: Jim Collins: Good to Great, HarperBusiness, 2001. https://www.jimcollins.com/concepts/the-hedgehog-concept.html
