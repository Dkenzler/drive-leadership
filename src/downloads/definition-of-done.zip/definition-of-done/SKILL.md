---
name: definition-of-done
description: "Eine Definition of Done festlegen, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn ein Team klären muss, wann eine Arbeit wirklich abgeschlossen ist, und was im Scope ist und was nicht. Typische Auslöser: ein Projekt oder Redesign mit ambitionierter Timeline starten, V1 abgrenzen, unterschiedliche Vorstellungen von »fertig« im Team oder mit Stakeholdern, Streit kurz vor dem Launch, Scope schützen, Definition nach geänderten Rahmenbedingungen anpassen. Grundgedanke nach Sead Goedecke: Fertig ist kein technischer, sondern ein sozialer Zustand."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S5 Ensure Quality
  origin: Dominik Kenzler (Gedanke zu »fertig« nach Sead Goedecke)
  deep_dive: false
  version: "1.0"
---

# Definition of Done

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, mit einem Gedanken von Sead Goedecke.

## Worum es geht

Was bedeutet »fertig«? Die Antwort ist weniger selbstverständlich, als sie klingt. Sead Goedecke, Staff Software Engineer bei GitHub, formuliert es so: Fertig ist kein technischer Zustand, sondern ein sozialer. Eine Arbeit gilt als abgeschlossen, wenn die wichtigen Menschen im Unternehmen es so sehen. Wer etwas deployt, aber VP oder CEO sind nicht zufrieden, hat etwas in die Welt gebracht, ist aber nicht fertig.

Das gilt für jede Art von Arbeit. Ein Redesign ist nicht fertig, wenn die Files übergeben wurden. Eine Kampagne ist nicht fertig, wenn sie live ist. Ein Prozess ist nicht fertig, wenn er dokumentiert ist. Fertig bedeutet: Die Menschen, die es beurteilen, sind zufrieden.

Eine Definition of Done ist eine explizit vereinbarte Antwort auf die Frage: Was muss erfüllt sein, damit wir sagen können, dass diese Arbeit wirklich abgeschlossen ist? Sie ist kontextabhängig und teamspezifisch. Gute Definitionen sind explizit vereinbart, nicht implizit erwartet, und sie schließen bewusst aus, was nicht im Scope ist, genauso wie sie einschließen, was sein muss.

## Wann du sie einsetzt

- Zu Beginn eines Projekts, vor allem bei ambitionierter Timeline: um sich überhaupt auf ein Datum committen zu können.
- Wenn im Team oder mit Stakeholdern unterschiedliche Vorstellungen von »fertig« bestehen.
- Wenn sich Rahmenbedingungen ändern und die bestehende Definition nicht mehr passt.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welche Arbeit geht es (Projekt, Feature, Kampagne, Prozess)? Welche Timeline oder welcher Termin steht? Wer beurteilt am Ende, ob das Ergebnis gut genug ist? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Enthält der Scope ein klares Nicht-dabei? Ist die Definition mit den Menschen abgestimmt, die das Ergebnis beurteilen? Benenne Schwächen direkt und kurz.
- Erfinde keine Kriterien, Stakeholder oder Termine. Die Beispielkriterien aus dem Buch sind Anregungen, keine Vorgabe. Fehlt etwas, markiere es als offen.
- Wird die Definition im Team vereinbart, biete an, eine kurze Abstimmungsrunde vorzubereiten: Entwurf, offene Scope-Fragen, wer zustimmen muss.
- Schließe mit der Definition im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Klären, wer über »fertig« urteilt.** Fertig ist ein sozialer Zustand. Die Frage, wer entscheidet, ob das Ergebnis gut genug ist, gehört an den Anfang, nicht ans Ende.
   Frage: *»Wer muss am Ende zufrieden sein, damit diese Arbeit als abgeschlossen gilt?«*
   Gut ist die Antwort, wenn konkrete Personen oder Rollen genannt sind, nicht »das Management«.

2. **V1 und Scope festlegen.** Was ist V1? Was kommt danach? Der schwierigste Teil ist nicht die Liste, sondern die Entscheidung, was nicht dazugehört. Projekte scheitern oft nicht, weil etwas Wichtiges fehlt, sondern weil zu viel gleichzeitig versucht wird und nichts davon wirklich fertig wird.
   Frage: *»Was ist im ersten Paket, was kommt bewusst später, und warum?«*
   Gut ist die Antwort, wenn sie ein klares Nicht-dabei enthält und die Begründung nennt.

3. **Kriterien formulieren.** Was muss erfüllt sein? Das Buch nennt Beispiele je nach Team:
   - **Produktteam:** Tests grün, Monitoring eingerichtet, Rollback-Plan vorhanden.
   - **Marketing-Team:** Kampagne live, Reporting eingerichtet, Stakeholder informiert.
   - **People-Team:** Prozess dokumentiert, kommuniziert, erstes Feedback eingeholt.

   Frage: *»Was muss konkret erfüllt sein, damit ihr sagt: Das ist wirklich abgeschlossen?«*

4. **Explizit vereinbaren.** Die Definition wird mit den Menschen abgestimmt, die in Schritt 1 genannt wurden, und im Team ausgesprochen. Implizit erwartete Kriterien zählen nicht.
   Frage: *»Mit wem müsst ihr die Definition abstimmen, bevor ihr euch auf die Timeline committet?«*

5. **Anpassen, wenn sich etwas ändert.** Ändern sich die Rahmenbedingungen, wird die Definition angepasst, mit expliziter Kommunikation, was sich geändert hat und warum.
   Frage: *»Woran merkt ihr, dass die Definition nicht mehr passt, und wer kommuniziert die Änderung?«*

## Beispiel

Beim zwölfmonatigen Redesign bei sevdesk sollten das gesamte Produkt und die gesamte Brand innerhalb von zwölf Monaten neu gestaltet werden. Um sich auf diese Timeline committen zu können, legte Dominik Kenzler von Anfang an fest, was nach zwölf Monaten im Scope ist: Der erste Release enthielt die wichtigsten Produkt-Screens nach Feature-Usage, einige Setting-Screens folgten in einer zweiten Phase. Die gesamte Website mit tausend Seiten war im Scope. Printmaterial und Offline-Themen bewusst nicht für V1, da das Unternehmen zu 90 Prozent digital unterwegs war. Die Gründer Marco und Fabi waren einverstanden. Das war keine Niederlage, sondern eine Entscheidung. Den Rest hat das Team im Nachgang erneuert.

## Worauf du achten musst

- **Zu spät definiert.** Der häufigste Fehler. Erst kurz vor dem Launch zeigt sich, dass verschiedene Personen unterschiedliche Vorstellungen von »fertig« haben. Das erzeugt Druck, schlechte Kompromisse und Frust.
- **Einmal erstellt, nie angepasst.** Ändern sich die Rahmenbedingungen, muss auch die Definition angepasst werden, mit expliziter Kommunikation, was sich geändert hat und warum.
- **Kein Nein im Scope.** Eine Definition, die nur einschließt und nichts ausschließt, schützt den Scope nicht.
- **Nur technisch gedacht.** Wer »deployt« mit »fertig« gleichsetzt, übersieht, dass die Menschen, die das Ergebnis beurteilen, zufrieden sein müssen.

## Ergebnis

```markdown
# Definition of Done: [Projekt / Arbeit]
Stand: [Datum] · Team: [Name] · Timeline: [Termin]

**Wer beurteilt, ob es fertig ist:** …

**V1 (im Scope):**
- …

**Bewusst nicht in V1 (kommt später / gar nicht):**
- … weil …

**Kriterien für »fertig«:**
- [ ] …
- [ ] …
- [ ] …

**Abgestimmt mit:** … am …
**Auslöser für Anpassung:** … · **Kommuniziert durch:** …
**Offen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Ist die Definition zu Beginn vereinbart, nicht erst kurz vor dem Launch?
- Sind die Menschen benannt, die am Ende zufrieden sein müssen, und haben sie zugestimmt?
- Enthält der Scope ein klares Nicht-dabei, mit Begründung?
- Ist geklärt, wie ihr die Definition anpasst und kommuniziert, wenn sich Rahmenbedingungen ändern?

## Im Flywheel

Modul SHIP, Bereich S5 Ensure Quality.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S5 Ensure Quality, Definition of Done. Der Gedanke »Fertig ist kein technischer Zustand, sondern ein sozialer.« stammt laut Buch von Sead Goedecke, Staff Software Engineer bei GitHub.
