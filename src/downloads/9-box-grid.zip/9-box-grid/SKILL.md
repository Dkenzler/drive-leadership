---
name: 9-box-grid
description: Mitarbeitende nach Performance und Potenzial einordnen und im Leadership-Team kalibrieren, mit dem 9-Box Grid nach McKinsey und General Electric, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn HR, Geschäftsführung oder die vorgesetzte Person ein 9-Grid verlangt, eine Kalibrierungsrunde mit anderen Führungskräften ansteht, Nachfolgeplanung, Performance Management, eine Reorg oder Restrukturierung vorbereitet wird. Führt in zwei Stufen durch das Grid (allein erstellen und gegen dich selbst kalibrieren, dann im Leadership-Team besprechen und challengen), mit Fokus auf den Bias der Potenzialachse.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L2 Know Your Team
  origin: McKinsey und General Electric
  deep_dive: true
  version: "1.0"
---

# 9-Box Grid

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach McKinsey und General Electric.

## Worum es geht

Das 9-Box Grid ordnet jede Person auf zwei Achsen ein, Performance und Potenzial, und ergibt neun Felder. Die Neun-Felder-Form stammt von der Matrix, die McKinsey Anfang der 1970er für General Electric entwickelt hat, dort zur Bewertung von Geschäftsbereichen. Im Talent Management ist sie seitdem ein Industriestandard, den viele kennen und erwarten. In größeren Organisationen ist es wahrscheinlich das bekannteste Talent-Management-Tool.

Richtig genutzt leistet es drei Dinge:

- **Ein gemeinsames Bild über Teams hinweg.** Der Wert entsteht in der Kalibrierungsrunde, in der mehrere Führungskräfte ihre Einordnungen nebeneinanderlegen. Erst dann wird vergleichbar, wer in der Organisation heraussticht.
- **Muster sichtbar machen.** Habt ihr genug High Performer? Sitzen zu viele Menschen unten links? Das Grid beantwortet diese Fragen nicht, aber es stellt sie sichtbar.
- **Grundlage für Nachfolge und Gespräche.** Früh sehen, wer für welche Rollen infrage kommt. Gegenüber HR und Geschäftsführung ein Format, das Alignment schafft.

Die **Performance-Achse** ist der klare Teil: messbare Ergebnisse, Zielerreichung, Qualität der Arbeit, Impact, idealerweise gestützt auf ein Performance-Modell aus Impact und Verhalten. Die **Potenzial-Achse** ist der problematische Teil: Ist Potenzial die Fähigkeit, eine größere Rolle zu übernehmen, schnelle Lernfähigkeit, Ambition? In der Praxis wird sie oft subjektiv eingeschätzt und ist stark von Bias beeinflusst.

Das 9-Grid ist eine Gesprächsgrundlage, kein Urteil. Es liefert einen Ausschnitt, der sich mit anderen Frameworks zu einem vollständigen Bild zusammensetzt.

## Wann du sie einsetzt

- In Kalibrierungsrunden mit anderen Führungskräften, um ein gemeinsames Bild des Teams zu entwickeln.
- In der Nachfolgeplanung, um früh zu erkennen, wer für welche Rollen infrage kommt.
- In Gesprächen mit HR und Geschäftsführung, weil das Format Alignment schafft.
- Bei Reorgs oder Restrukturierungen und im Performance Management.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Anlass (Kalibrierung, Nachfolge, Reorg, Performance Management)? Für welche Organisation oder welches Department und wie viele Personen? Gibt es im Leadership-Team einen gemeinsamen Standard für die Achsen? Frag nichts, was die Person schon gesagt hat.
- Arbeite in zwei Stufen. Stufe 1 machst du mit der Person allein. Für Stufe 2 bereitest du die Leadership-Runde vor (Ablauf, Fragen zum Challengen), statt sie zu ersetzen.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen, wenn sie schon Material hat.
- Ersetze in Stufe 1 die fehlende Außensicht: Frag bei jeder Einordnung oben rechts oder auffällig hoch nach der Begründung, die ein Peer hören würde. Benenne den Bias zugunsten der Lauten aktiv.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz.
- Erfinde keine Einschätzungen über Personen. Fehlende Informationen markierst du als offen.
- Das Grid kann vertraulich sein, etwa bei einer noch nicht kommunizierten Reorg. Behandle es entsprechend.
- Schließe mit dem Grid im Format aus »Ergebnis« (Vorlage: `templates/9-box-grid.md`) und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Set-up.** Das Grid entsteht in zwei Stufen, die zusammengehören: Das Allein-Erstellen ist die Arbeit, die gemeinsame Runde ist der Standard. Allein erstellst du es für deine Organisation oder dein Department, etwa bei einer noch vertraulichen Reorg, bei der du das nächste Level nicht einweihen kannst. Besprochen wird es im Leadership-Team. Material: das Raster, für alle sichtbar, und die Liste der Personen. Gemessen wird das Ergebnis nicht am ausgefüllten Formular, sondern am gemeinsamen Verständnis und den abgeleiteten Maßnahmen.

**Stufe 1: Das Grid für deine Organisation erstellen**

1. **Beide Achsen definieren.** Der wichtigste und meist übersprungene Schritt. Festlegen, was Performance und Potenzial im eigenen Kontext konkret heißen, bevor jemand eingeordnet wird. Potenzial braucht die meiste Definitionsarbeit, sonst misst jede Führungskraft etwas anderes. Gibt es einen gemeinsamen Standard im Leadership-Team, diesen nehmen, damit das Grid vergleichbar bleibt.
   Frage: *»Was heißt bei euch Performance, und was genau heißt Potenzial?«* Gut ist die Antwort, wenn Potenzial so definiert ist, dass eine andere Führungskraft zur selben Einordnung käme.

2. **Einordnen.** Jede Person auf beiden Achsen einordnen. Die Liste vollständig durchgehen, nicht nur die offensichtlichen Fälle an den Rändern.
   Frage pro Person: *»Wo steht die Person auf Performance und Potenzial, und worauf stützt du das?«*

3. **Gegen dich selbst kalibrieren.** Die Einordnungen ein zweites Mal durchgehen: Differenzierst du wirklich oder sortierst du wohlwollend ein? Kontrollfrage: *»Würdest du diese Einordnung auch begründen können, wenn ein Peer sie anzweifelt?«* Wer das überspringt, landet schnell dabei, dass die halbe Organisation oben rechts steht.

4. **Muster lesen.** Einen Schritt zurücktreten und die Verteilung als Ganzes ansehen. Wo häufen sich Menschen, wo sind Lücken? Ein großes Cluster in der Mitte kann auf fehlendes Coaching hindeuten, zu viele unten links auf ein größeres Problem. Diese Muster sind die eigentliche Erkenntnis.
   Frage: *»Was fällt dir an der Verteilung auf?«*

5. **Vorläufige Maßnahmen festhalten.** Wer braucht gezielte Entwicklung, wer kommt für eine größere Rolle infrage? Vorläufig, weil die gemeinsame Runde das Bild noch verschieben kann.
   Frage: *»Welche Maßnahmen leitest du aus der Einordnung ab?«*

**Stufe 2: Im Leadership-Team besprechen**

Jede Führungskraft bringt ihr Grid mit, ihr legt sie nebeneinander. Die Runde leistet zwei Dinge, die der Alleingang nicht kann:

6. **Gemeinsames Verständnis herstellen.** Wer sind über die Organisation hinweg die High Performer? Erst im Vergleich quer durch die Bereiche entsteht ein gemeinsamer Standard.
7. **Gegenseitig challengen.** Ordnet eine Führungskraft jemanden auffällig hoch ein, fragen die anderen nach. Es geht nicht ums Sammeln, sondern ums Prüfen. Oft zeigt sich, dass jemand kein differenziertes Bild seiner Organisation hat, oder dass Peers nicht nachvollziehen können, warum eine Person ganz oben rechts steht.
8. **Maßnahmen anpassen.** Mit dem kalibrierten Bild die vorläufigen Maßnahmen aus Stufe 1 anpassen.
   Frage nach der Runde: *»Was hat sich in der Runde an deinem Bild verschoben, und welche Maßnahmen ändern sich dadurch?«*

## Beispiel

Dominik Kenzler war mehrfach in der Situation, dass ein Senior Leadership Team ein gemeinsames 9-Grid erstellen sollte und es Führungskräfte gab, bei denen 90 Prozent der eigenen Leute oben rechts standen, als High Performer und High Potenzial. Das ist fast immer ein Zeichen, dass jemand kein differenziertes Bild seiner Organisation hat. Häufig wunderten sich die Peers, warum Person A oder B ganz oben rechts gelistet war. Ob ein 9-Grid etwas wert ist, entscheidet sich nicht im Ausfüllen, sondern in der gemeinsamen Kalibrierung.

## Worauf du achten musst

- **Die Scheinobjektivität der Potenzialachse.** Die größte Schwäche des Grids. Die Achse suggeriert Messbarkeit, wo keine ist. Die Definition explizit machen, statt sie jeder Person zu überlassen.
- **Der Bias zugunsten der Lauten.** Extrovertierte und sichtbare Menschen, die sich gut verkaufen, werden häufiger als High Potenzial eingestuft, ruhige, solide Leistungsträger unterschätzt. Den Effekt aktiv benennen, allein wie in der Runde.
- **Alle stehen oben rechts.** Dann fehlt das differenzierte Bild. Allein passiert das besonders leicht, deshalb der Selbstcheck in Stufe 1. Ohne gemeinsamen Standard ist die Einordnung über Teams und Funktionen hinweg nicht aussagekräftig.
- **Das Grid als alleiniges Urteil.** Als einzige Grundlage für Beförderungsentscheidungen oder als objektive Wahrheit wird es missbraucht.
- **Einmal im Jahr und dann vergessen.** Der Wert liegt im Gespräch und in den abgeleiteten Maßnahmen, nicht im Artefakt.
- **Potenzialachse nicht definiert.** Dann misst jede Führungskraft etwas anderes.

## Ergebnis

Vorlage: `templates/9-box-grid.md`.

```markdown
# 9-Box Grid: [Organisation / Department]
Stand: [Datum] · Stufe: 1 (allein) / 2 (nach Kalibrierung) · Vertraulich

Performance heißt bei uns: …
Potenzial heißt bei uns: …

| Potenzial \ Performance | Low | Moderate | High |
|---|---|---|---|
| High | … | … | … |
| Moderate | … | … | … |
| Low | … | … | … |

## Muster
- Häufungen / Lücken: …

## Maßnahmen
| Person | Maßnahme | vorläufig / kalibriert |
|---|---|---|
| … | … | … |

## Aus der Leadership-Runde
- Was sich verschoben hat: …
```

## Mini-Check

- Hast du beide Achsen definiert, bevor du jemanden eingeordnet hast?
- Hast du dein Grid in Stufe 1 ehrlich gegen dich selbst kalibriert, statt wohlwollend einzusortieren?
- Wurde das Grid in der Leadership-Runde besprochen und dort auch gechallengt?
- Folgt die Einordnung einem gemeinsamen Standard, der über Teams und Funktionen hinweg trägt?
- Habt ihr die Verteilung als Ganzes gelesen, nicht nur einzelne Personen?
- Sind aus dem Grid konkrete Maßnahmen entstanden, oder verschwindet es in der Schublade?

## Im Flywheel

Modul LEAD, Bereich L2 Know Your Team.

Verwandte Skills:
- `watkins-assessment`: Abgrenzung laut Buch. Der Watkins-Baum ist die individuelle Einordnung beim Übernehmen eines Teams, mit Blick auf die nächste Handlung pro Person, das private Arbeitsdokument einer neuen Führungskraft. Das 9-Grid ist die organisationsweite Kalibrierung über mehrere Bereiche, mit Blick auf Performance und Potenzial im Vergleich, ein gemeinsamer Standard im Leadership-Team. Beide ergänzen sich.

Die beiden Achsen verdienen unterschiedlich viel Vertrauen: Die Performance-Achse ist belastbar, wenn sie auf einem klaren Modell steht. Die Potenzial-Achse bleibt eine begründete Einschätzung, kein Messwert.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L2 Know Your Team (Abb. 4.6) und Deep Dive 9-Box Grid (Abb. 4.17). Originalquelle: McKinsey für General Electric.

Original: GE-McKinsey Nine-Box Matrix, McKinsey & Company, Anfang der 1970er (als Portfolio-Instrument für Geschäftsbereiche), beschrieben in »Enduring Ideas: The GE-McKinsey nine-box matrix«, McKinsey Quarterly, 2008, https://www.mckinsey.com/capabilities/strategy-and-corporate-finance/our-insights/enduring-ideas-the-ge-and-mckinsey-nine-box-matrix
