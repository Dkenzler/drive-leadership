# 9-Box Grid

Nach Abb. 4.6 und 4.17 im Drive Leadership Playbook, nach McKinsey und General Electric.

**Organisation / Department:**
**Erstellt von:**
**Stand:**
**Stufe:** 1 (allein erstellt) / 2 (im Leadership-Team kalibriert)

## Achsen

**Performance** (messbare Ergebnisse, Zielerreichung, Qualität, Impact) heißt bei uns:

**Potenzial** heißt bei uns:

Gemeinsamer Standard des Leadership-Teams genutzt: ja / nein

## Grid

| Potential \ Performance | Low Performance | Moderate Performance | High Performance |
|---|---|---|---|
| **High Potential** | High Potential / Low Performance: | High Potential / Moderate Performance: | High Potential / High Performance: |
| **Moderate Potential** | Moderate Potential / Low Performance: | Moderate Potential / Moderate Performance: | Moderate Potential / High Performance: |
| **Low Potential** | Low Potential / Low Performance: | Low Potential / Moderate Performance: | Low Potential / High Performance: |

## Selbstkalibrierung (Stufe 1)

| Person | Feld | Würde ich das auch begründen können, wenn ein Peer es anzweifelt? |
|---|---|---|
| | | |

## Muster

- Wo häufen sich Menschen?
- Wo sind Lücken?
- Cluster in der Mitte (Hinweis auf fehlendes Coaching)?
- Viele unten links?

## Maßnahmen

| Person | Gezielte Entwicklung / größere Rolle / andere Maßnahme | Status: vorläufig oder kalibriert |
|---|---|---|
| | | |

## Leadership-Runde (Stufe 2)

**Termin:**
**Beteiligte Führungskräfte:**
**Gechallengte Einordnungen:**
**Was sich verschoben hat:**
