# Presentation Strategy Worksheet

Nach Ole Tillmann, »Beyond the Obvious«, wie im Drive Leadership Playbook beschrieben.

**Präsentation:**
**Termin und Rahmen:**

## 1. Warum präsentierst du?


## 2. Wer ist dein Publikum, und was ist sein Profil?


## 3. Welchen Nutzen hat das Publikum von deiner Botschaft?


## 4. Welche Gegenargumente könnten kommen?


## 5. Was ist dein konkretes Ziel?

