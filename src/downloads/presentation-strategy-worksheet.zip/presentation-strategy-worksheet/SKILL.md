---
name: presentation-strategy-worksheet
description: "Die Grundlagen einer Präsentation klären mit dem Presentation Strategy Worksheet von Ole Tillmann (»Beyond the Obvious«), aus dem Drive Leadership Playbook. Nutze diesen Skill, bevor jemand mit der Vorbereitung einer Präsentation, Rede, Strategie-Kommunikation oder eines Pitches beginnt, wenn unklar ist, warum und vor wem präsentiert wird und was am Ende erreicht werden soll, oder als Struktur für die Denkzeit der 50-25-25 Rule. Führt durch die fünf Felder: Warum präsentierst du? Wer ist dein Publikum? Welchen Nutzen hat es? Welche Gegenargumente könnten kommen? Was ist dein konkretes Ziel?"
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D5 Communicate Direction
  origin: Ole Tillmann
  deep_dive: false
  version: "1.0"
---

# Presentation Strategy Worksheet

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Ole Tillmann.

## Worum es geht

Bevor du mit der Vorbereitung einer Präsentation beginnst, brauchst du Klarheit über die Grundlagen. Ole Tillmann hat dafür ein einfaches Worksheet entwickelt. Er war Schauspieler und Moderator, hat über 350 Speaker für TEDx-Events gecoacht, an der D-School des Hasso-Plattner-Instituts gelehrt und im Axel Springer Plug and Play Accelerator Gründer:innen auf ihre Pitches vorbereitet. Seinen Ansatz beschreibt er in »Beyond the Obvious«.

Das Worksheet hat fünf Felder:

1. Warum präsentierst du?
2. Wer ist dein Publikum, und was ist sein Profil?
3. Welchen Nutzen hat das Publikum von deiner Botschaft?
4. Welche Gegenargumente könnten kommen?
5. Was ist dein konkretes Ziel?

Statt unstrukturiert nachzudenken, arbeitest du dich durch diese fünf Fragen. Am Ende weißt du, was du sagen willst und warum.

## Wann du sie einsetzt

- Am Anfang jeder Präsentationsvorbereitung, bevor Text oder Slides entstehen.
- Besonders als Struktur für die Denkzeit, die Terry Szuplat in seiner 50-25-25 Rule beschreibt.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Worum geht es in der Präsentation? Wann und in welchem Rahmen findet sie statt? Gibt es schon Material? Frag nichts, was die Person schon gesagt hat.
- Geh die fünf Felder in der Reihenfolge des Worksheets durch. Eine Frage pro Feld, dann auf die Antwort warten. Hat die Person ein Feld schon beantwortet, übernimm es und prüfe es nur.
- Benenne vage Antworten direkt und kurz, etwa ein Publikum, das »alle« ist, oder ein Ziel, das »informieren« heißt. Kein Lob als Füllmaterial.
- Erfinde nichts über Publikum, Organisation oder mögliche Einwände. Fehlt Wissen über das Publikum, markiere es als offen und frage, wer es schließen kann.
- Schließe mit dem ausgefüllten Worksheet (`templates/presentation-strategy-worksheet.md`) und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Warum präsentierst du?**
   Frage: *»Warum hältst du diese Präsentation, und warum gerade jetzt?«* Gut ist die Antwort, wenn sie einen Anlass und einen Grund nennt, nicht nur einen Termin im Kalender.

2. **Wer ist dein Publikum, und was ist sein Profil?**
   Frage: *»Wer sitzt vor dir? Was wissen diese Menschen schon, was beschäftigt sie?«* Gut ist die Antwort, wenn das Publikum konkret beschrieben ist, nicht als »alle« oder »die Organisation«.

3. **Welchen Nutzen hat das Publikum von deiner Botschaft?**
   Frage: *»Was hat dein Publikum davon, dir zuzuhören?«* Gut ist die Antwort, wenn sie aus Sicht des Publikums formuliert ist, nicht aus deiner.

4. **Welche Gegenargumente könnten kommen?**
   Frage: *»Welche Einwände, Zweifel oder Gegenargumente erwartest du?«* Gut ist die Antwort, wenn sie die unbequemen Einwände enthält, nicht nur die leicht zu entkräftenden.

5. **Was ist dein konkretes Ziel?**
   Frage: *»Was soll nach der Präsentation konkret anders sein?«* Gut ist die Antwort, wenn sich am Ende überprüfen lässt, ob das Ziel erreicht wurde.

## Ergebnis

Das ausgefüllte Worksheet. Vorlage: `templates/presentation-strategy-worksheet.md`.

```markdown
# Presentation Strategy Worksheet: [Präsentation]
Termin: … · Rahmen: …

1. **Warum präsentierst du?** …
2. **Wer ist dein Publikum, und was ist sein Profil?** …
3. **Welchen Nutzen hat das Publikum von deiner Botschaft?** …
4. **Welche Gegenargumente könnten kommen?** …
5. **Was ist dein konkretes Ziel?** …

**Offen:** …
```

## Mini-Check

(abgeleitet aus den fünf Feldern des Worksheets; das Buch nennt keine typischen Fehler)

- Kannst du in einem Satz sagen, warum du präsentierst?
- Ist dein Publikum konkret beschrieben, mit Profil?
- Ist der Nutzen aus Sicht des Publikums formuliert?
- Hast du die unbequemsten Gegenargumente benannt?
- Lässt sich nach der Präsentation überprüfen, ob du dein Ziel erreicht hast?

## Im Flywheel

Modul DRIVE, Bereich D5 Communicate Direction.

Verwandte Skills:
- `50-25-25-rule`: Das Worksheet dient laut Buch als Struktur für die Denkzeit der 50-25-25 Rule.
- `core-message-future-scenario`: Zwei weitere Worksheets von Ole Tillmann, im Buch als Deep Dive beschrieben.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D5 Communicate Direction. Originalquelle: Ole Tillmann: Beyond the Obvious.
Original: Ole Tillmann: Beyond the Obvious. Agile Presentation Design, an innovator's guide to more impactful presentations, 2019. https://www.tillmann.com/book
