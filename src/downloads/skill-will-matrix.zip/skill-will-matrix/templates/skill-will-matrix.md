# Skill-Will-Matrix

Nach Abb. 4.5 im Drive Leadership Playbook, nach Max Landsberg.

**Team:**
**Stand:**
**Anlass:** Teamübernahme / Vorbereitung Performance-Gespräche

**Skill** (Fähigkeiten und handwerkliches Verhalten: Craft, Communication & Collaboration, Customer Focus & Business Acumen) heißt bei uns:

**Will** (Haltung, Bereitschaft, Coachability: Ownership & Agency, Execution & Urgency, Builder Mindset) heißt bei uns:

## Matrix

| | Niedriger Skill | Hoher Skill |
|---|---|---|
| **Hoher Will** | **Low Skill / High Will: ANLEITEN** | **High Skill / High Will: DELEGIEREN** |
| | | |
| **Niedriger Will** | **Low Skill / Low Will: ANWEISEN** | **High Skill / Low Will: BEGEISTERN** |
| | | |

## Pro Person

| Person | Skill (hoch/niedrig) | Will (hoch/niedrig) | Beobachtetes Verhalten | Quadrant | Nächster Schritt |
|---|---|---|---|---|---|
| | | | | | |
