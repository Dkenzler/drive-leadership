---
name: skill-will-matrix
description: Teammitglieder nach Skill und Will einordnen und daraus den Führungsstil pro Person ableiten, mit der Skill-Will-Matrix nach Max Landsberg in der angepassten Fassung aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand ein neues Team übernimmt und einen schnellen Überblick braucht, Performance-Gespräche vorbereitet, prüfen will, ob der Mix aus Erfahrung und Fähigkeiten im Team stimmt, oder überlegt, ob jemand anleiten, delegieren, begeistern oder anweisen braucht. Skill umfasst Fähigkeiten und handwerkliches Verhalten, Will umfasst Haltung, Bereitschaft und Coachability.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L2 Know Your Team
  origin: Max Landsberg
  deep_dive: false
  version: "1.0"
---

# Skill-Will-Matrix

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Max Landsberg.

## Worum es geht

Die Skill-Will-Matrix ist ein sehr populäres Assessment-Tool. Jede Person im Team wird auf zwei Achsen eingeordnet, Skill und Will. Daraus ergeben sich vier Quadranten, jeder mit einer anderen Handlungsempfehlung.

In der klassischen Form ist Skill das fachliche Können und Will die Motivation. Das Buch arbeitet mit einer genaueren Definition:

- **Skill** umfasst Fähigkeiten und handwerkliches Verhalten: die fachliche Craft, aber auch Kompetenzen wie Communication & Collaboration und Customer Focus & Business Acumen. Alles, was sich beobachten, messen und gezielt entwickeln lässt.
- **Will** umfasst Haltung, Bereitschaft und Coachability: Ownership & Agency, Execution & Urgency, Builder Mindset. Die innere Einstellung, die entscheidet, ob jemand Veränderung mitträgt oder bremst.

Die Unterscheidung schärft die Handlungsoptionen: Fehlende Fähigkeiten lassen sich entwickeln, fehlende Haltung ist deutlich schwieriger zu verändern. Coachability gehört zu Will, weil eine Person, die coachable ist, neue Themen schnell lernt, und eine Person, die es nicht ist, sich auch mit guter Begleitung kaum entwickelt.

Die Matrix ist kein Präzisionsinstrument, sondern ein Denkmodell, um das Team als Ganzes einzuordnen und die richtigen Gespräche zu führen. Sie hilft zu erkennen, ob der Mix an Erfahrung und Fähigkeiten im Team stimmt.

## Wann du sie einsetzt

- Wenn du ein neues Team übernimmst und einen schnellen Überblick brauchst.
- In Vorbereitung auf Performance-Gespräche, um die eigene Einschätzung zu strukturieren.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Anlass (Teamübernahme oder Vorbereitung auf Performance-Gespräche)? Wie viele Personen sollen eingeordnet werden? Gibt es eine Fähigkeitenmatrix oder Verhaltenserwartungen, an denen sich Skill und Will festmachen lassen? Frag nichts, was die Person schon gesagt hat.
- Kläre zuerst, was Skill und Will im Team konkret heißen. Danach Person für Person. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Einordnung gegen »Worauf du achten musst«. Frag nach beobachtetem Verhalten statt nach Eindrücken. Benenne Schwächen direkt und kurz.
- Bei hohem Skill und niedrigem Will: Unterstelle keinen Grund. Hilf, das offene Gespräch vorzubereiten, in dem die Führungskraft den Grund erfragt.
- Erfinde keine Einschätzungen über Personen. Fehlende Informationen markierst du als offen.
- Behandle das Ergebnis als vertrauliches Arbeitsdokument.
- Schließe mit der Matrix im Format aus »Ergebnis« (Vorlage: `templates/skill-will-matrix.md`) und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Achsen definieren.** Festlegen, was Skill und Will im eigenen Kontext umfassen. Skill: Craft plus Kompetenzen wie Communication & Collaboration, Customer Focus & Business Acumen. Will: Ownership & Agency, Execution & Urgency, Builder Mindset, Coachability.
   Frage: *»Woran machst du Skill und Will in deinem Team fest?«* Gut ist die Antwort, wenn beides an beobachtbarem Verhalten hängt und nicht an Sympathie.

2. **Einordnen.** Jede Person auf beiden Achsen einordnen, hoch oder niedrig.
   Frage pro Person: *»Wie schätzt du Skill und Will ein, und welches Verhalten hast du dafür beobachtet?«*

3. **Handlung pro Quadrant ableiten.**
   - **Hoher Skill, hoher Will (Delegieren).** Die stärksten Leute. Genug Raum, Verantwortung und anspruchsvolle Aufgaben geben.
   - **Niedriger Skill, hoher Will (Anleiten).** Motiviert, aber Fähigkeiten fehlen noch. Investition in Entwicklung lohnt sich: klare Anleitung, gutes Coaching, Zeit zum Wachsen. Tipp aus dem Buch: eine der stärksten Personen als Coach oder Mentor einsetzen. Das gibt den einen mehr Verantwortung und den anderen ein gutes Set-up zum Lernen.
   - **Hoher Skill, niedriger Will (Begeistern).** Fachlich stark, aber die Haltung stimmt nicht. Oft die schwierigsten Fälle, weil fachliche Qualität über fehlende Bereitschaft hinwegtäuschen kann. Es braucht ein offenes Gespräch: Liegt es an der Rolle, an der Richtung, an einem persönlichen Thema? Manchmal lässt sich der Will wiederherstellen, manchmal nicht. Die Haltung kann auf andere abfärben, deshalb im Auge behalten.
   - **Niedriger Skill, niedriger Will (Anweisen).** Weder Fähigkeiten noch Haltung passen. In den meisten Fällen ist eine Trennung die richtige Entscheidung, auch wenn sie schwerfällt. Je länger gewartet wird, desto größer der Schaden für das restliche Team.
   Frage pro Person: *»Was ist in diesem Quadranten dein nächster Schritt mit der Person?«*

4. **Das Team als Ganzes lesen.** Stimmt der Mix an Erfahrung und Fähigkeiten?
   Frage: *»Wie verteilt sich dein Team auf die vier Quadranten, und was sagt das über den Mix aus?«*

## Beispiel

Viele der besten Leute, mit denen Dominik Kenzler gearbeitet hat, waren anfangs im Quadranten niedriger Skill, hoher Will.

## Worauf du achten musst

- **Klassische, zu ungenaue Definition.** Skill nur als fachliches Können und Will nur als Motivation zu lesen, verwischt den Unterschied zwischen Entwickelbarem und Haltung.
- **Sich von fachlicher Qualität täuschen lassen.** Bei hohem Skill und niedrigem Will verdeckt die Leistung oft die fehlende Bereitschaft.
- **Negative Haltung laufen lassen.** Sie kann auf andere Teammitglieder abfärben.
- **Bei niedrigem Skill und niedrigem Will nicht oder zu spät handeln.** Einer der größten Fehler. Das restliche Team muss härter arbeiten, um es auszugleichen, die Standards sinken peu à peu, und es führt zu Lower the Bar statt Raise the Bar. Wer schlechte Leistung toleriert, verliert außerdem das Vertrauen der Leute, die ihren Job gut machen.
- **Die Matrix als Präzisionsinstrument behandeln.** Sie ist ein Denkmodell für Überblick und Gespräche.

## Ergebnis

Vorlage: `templates/skill-will-matrix.md`.

```markdown
# Skill-Will-Matrix: [Team]
Stand: [Datum] · Anlass: [Teamübernahme / Performance-Gespräche] · Vertraulich

Skill heißt bei uns: …
Will heißt bei uns: …

| Quadrant | Personen | Nächster Schritt |
|---|---|---|
| Hoher Skill, hoher Will: Delegieren | … | … |
| Niedriger Skill, hoher Will: Anleiten | … | … |
| Hoher Skill, niedriger Will: Begeistern | … | … |
| Niedriger Skill, niedriger Will: Anweisen | … | … |

Beobachtetes Verhalten pro Person: …
Mix im Team: …
Offen: …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hast du Skill und Will an beobachtbarem Verhalten festgemacht, nicht nur an Können und Motivation?
- Hast du bei hohem Skill und niedrigem Will ein offenes Gespräch über den Grund geplant?
- Hast du im Blick, ob eine negative Haltung auf andere abfärbt?
- Handelst du bei niedrigem Skill und niedrigem Will, statt abzuwarten?
- Nutzt du die Matrix als Gesprächsgrundlage und nicht als präzises Urteil?

## Im Flywheel

Modul LEAD, Bereich L2 Know Your Team.

Verwandte Skills:
- `assessment-prozess`: liefert die Beobachtungen, auf denen die Einordnung beruht.
- `letting-go`: Das Buch verweist bei Letting Go auf den Quadranten niedriger Skill, niedriger Will.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L2 Know Your Team (Abb. 4.5), L3 Hire & Let Go und L5 Grow Your People zu Coachability. Originalquelle: Max Landsberg.

Original: Max Landsberg: The Tao of Coaching, HarperCollins, 1996.
