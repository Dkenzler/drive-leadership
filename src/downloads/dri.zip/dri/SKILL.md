---
name: dri
description: DRI (Directly Responsible Individual), ursprünglich von Apple, bekannt geworden durch »Scaling People« von Claire Hughes Johnson, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn Verantwortung kollektiv verteilt ist und Dinge liegen bleiben, wenn Co-Leads oder ganze Teams als verantwortlich eingetragen sind, wenn niemand weiß, an wen man sich wenden soll, oder wenn für Initiativen, Workstreams, Projekte oder Entscheidungen klare Verantwortliche festgelegt werden sollen. Führt dazu, pro Vorhaben genau einen Namen festzulegen, mit Autorität auszustatten und sichtbar zu machen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S3 Create Execution Clarity
  origin: Apple, verbreitet durch Claire Hughes Johnson
  deep_dive: false
  version: "1.0"
---

# DRI (Directly Responsible Individual)

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Apple, als Führungsprinzip verbreitet durch Claire Hughes Johnson.

## Worum es geht

DRI steht für Directly Responsible Individual. Das Konzept kommt ursprünglich von Apple und wurde durch »Scaling People« von Claire Hughes Johnson als Führungsprinzip breiter bekannt. Die Idee ist einfach: Für jede Initiative, jede Entscheidung und jedes Projekt gibt es genau eine Person, die verantwortlich ist. Nicht ein Team. Nicht zwei Co-Leads. Eine Person.

Das klingt nicht neu, ist es aber. In vielen Organisationen ist Verantwortung kollektiv verteilt. Alle sind ein bisschen verantwortlich, folglich ist niemand wirklich verantwortlich. Das ist einer der häufigsten Gründe, warum Dinge liegen bleiben.

Der DRI ist nicht unbedingt die Person, die alles selbst umsetzt. Er oder sie stellt sicher, dass es vorangeht. Funktioniert etwas nicht, ist es seine oder ihre Aufgabe, es zu lösen, Blockaden zu eskalieren und Entscheidungen herbeizuführen. DRI ist kein Mikromanagement: Der DRI hat den Überblick, delegiert, koordiniert und eskaliert, ist aber der Single Point of Accountability.

## Wann du sie einsetzt

- Eine neue Initiative, ein Projekt oder ein Workstream startet.
- Dinge bleiben liegen, und niemand fühlt sich zuständig.
- Als verantwortlich stehen ein Team, eine Abteilung oder mehrere Co-Leads.
- Eine Entscheidung steht an, und unklar ist, wer sie herbeiführt.
- Ein Dokument oder Prozess braucht jemanden, der es aktuell hält, etwa ein Decision Log.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welche Initiativen, Workstreams oder Entscheidungen geht es? Wer ist heute als verantwortlich benannt? Wo werden Verantwortlichkeiten sichtbar gemacht (Canonical Document, Roadmap, Weekly Meeting)? Frag nichts, was die Person schon gesagt hat.
- Geh die Vorhaben einzeln durch. Pro Vorhaben eine Frage, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Steht ein Team oder stehen zwei Namen da, frag nach der einen Person. Fehlt die Entscheidungsbefugnis, benenne das direkt.
- Du schlägst keine Personen vor und bewertest niemanden. Welche Person DRI wird, entscheidet die Führungskraft.
- Erfinde keine Namen oder Zuständigkeiten. Was fehlt, markierst du als offen.
- Schließe mit der DRI-Übersicht im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Vorhaben auflisten.** Alle Initiativen, Workstreams, Projekte und anstehenden Entscheidungen, für die Verantwortung geklärt werden soll.
   Frage: *»Für welche Vorhaben willst du die Verantwortung klären?«*

2. **Genau einen Namen festlegen.** Für jedes Vorhaben steht ein Name. Nicht eine Abteilung, nicht ein Team, nicht zwei Co-Leads.
   Frage: *»Wer ist für [Vorhaben] die eine Person, die sicherstellt, dass es vorangeht?«* Gut ist die Antwort, wenn dort genau ein Name steht.

3. **Rolle klären.** Der DRI setzt nicht alles selbst um. Er oder sie hat den Überblick, delegiert, koordiniert, löst Probleme, eskaliert Blockaden und führt Entscheidungen herbei.
   Frage: *»Weiß [Name], dass er oder sie nicht alles selbst machen muss, aber dafür geradesteht, dass es vorangeht?«*

4. **Mit Autorität ausstatten.** Ownership ohne Entscheidungsbefugnis ist keine echte Ownership.
   Frage: *»Was darf [Name] ohne Rückfrage entscheiden, und wohin eskaliert er oder sie, wenn es klemmt?«* Gut ist die Antwort, wenn Entscheidungsbefugnis und Eskalationsweg konkret benannt sind.

5. **Sichtbar machen.** Der Name ist sichtbar, im Canonical Document, in der Roadmap oder im Weekly Meeting, und wird aktiv kommuniziert.
   Frage: *»Wo steht der Name, und wie erfahren alle Beteiligten, wer DRI ist?«*

## Beispiel

Das Buch zeigt das Prinzip als Abbildung (Abb. 5.11, Directly Responsible Individual (DRI) nach Apple). Im fiktiven Decision Log des Buchs (Abb. 5.13) hat jede Entscheidung einen namentlichen DRI, und das Buch empfiehlt, die Pflege des Decision Logs einem DRI zu übertragen.

## Worauf du achten musst

- **DRI zugewiesen, aber nicht kommuniziert.** Der häufigste Fehler. Niemand weiß, wer es ist, und alle wenden sich weiterhin an verschiedene Personen.
- **DRI ohne Autorität.** Ein DRI wird ernannt, aber nicht mit der nötigen Entscheidungsbefugnis ausgestattet. Ownership ohne Entscheidungsbefugnis ist keine echte Ownership.
- **Kollektive Verantwortung.** Ein Team, eine Abteilung oder zwei Co-Leads als Verantwortliche. Alle sind ein bisschen verantwortlich, also niemand.
- **DRI als Mikromanagement verstehen.** Der DRI macht nicht alles allein und kontrolliert nicht alle Details. Er oder sie sorgt dafür, dass das Richtige passiert.

## Ergebnis

Eine DRI-Übersicht, die ins Canonical Document, die Roadmap oder das Weekly Meeting übernommen werden kann.

```markdown
# DRI-Übersicht: [Team / Bereich]
Stand: [Datum]

| Vorhaben | DRI (ein Name) | Darf entscheiden | Eskaliert an | Sichtbar in | Kommuniziert am |
|---|---|---|---|---|---|
| … | … | … | … | Canonical Document / Roadmap / Weekly | … |

**Offen:** Vorhaben ohne DRI oder ohne geklärte Befugnis: …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Steht bei jedem Vorhaben genau ein Name, kein Team und keine Co-Leads?
- Wissen alle Beteiligten, wer DRI ist, weil es kommuniziert wurde?
- Hat jeder DRI die Entscheidungsbefugnis, die er oder sie für die Aufgabe braucht?
- Ist der Name dort sichtbar, wo das Team arbeitet: Canonical Document, Roadmap oder Weekly Meeting?

## Im Flywheel

Modul SHIP, Bereich S3 Create Execution Clarity.

Verwandte Skills:
- `canonical-document`: Der Name des DRI ist dort sichtbar.
- `decision-log`: Das Decision Log braucht eine verantwortliche Person, die es aktuell hält. Laut Buch eine gute Aufgabe für einen DRI.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S3 Create Execution Clarity und S4 Make Fast Decisions, Decision Log (Abb. 5.13). Originalquelle: Apple, als Führungsprinzip verbreitet durch Claire Hughes Johnson: Scaling People.

Original: Claire Hughes Johnson: Scaling People. Tactics for Management and Company Building, Stripe Press, 2023. Dort wird der Begriff DRI auf Apple zurückgeführt.
