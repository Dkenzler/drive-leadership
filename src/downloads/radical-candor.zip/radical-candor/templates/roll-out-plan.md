# Radical Candor: Roll-out in sechs Schritten

Nach Abb. 4.22 im Drive Leadership Playbook, nach Kim Scott, Radical Candor. Reihenfolge einhalten: erst Vertrauen und Kultur, dann Kritik.

**Team:**
**Start:**

| # | Schritt | Was ich konkret tue | Stand |
|---|---|---|---|
| 1 | Eigene Geschichten teilen | Welche Feedbackerfahrung erzähle ich, wann? | |
| 2 | Feedback erbitten, bevor du es gibst | Meine Go-to-Frage: | |
| 3 | Career Conversations führen | Mit wem bis wann? | |
| 4 | 1:1s verbessern | Was ändere ich an meinen 1:1s? | |
| 5 | Lob und Kritik geben und auf Wirkung achten | Lob mindestens so häufig wie Kritik. Wie prüfe ich die Wirkung? | |
| 6 | Innehalten und prüfen | Woran erkenne ich, dass das Fundament trägt? | |

## Teamnorm
- [ ] Clean Escalation vereinbart: nicht übereinander reden, sondern zu dritt miteinander.

## Prüfpunkt vor Schritt 5 und vor allem Neuen
- [ ] Ich erbitte regelmäßig Feedback und reagiere gut darauf.
- [ ] Ich kenne meine Leute durch Career Conversations besser.
- [ ] Meine 1:1s tragen.
