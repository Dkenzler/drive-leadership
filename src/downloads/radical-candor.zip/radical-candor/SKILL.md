---
name: radical-candor
description: Feedback geben und eine Feedbackkultur aufbauen mit Radical Candor von Kim Scott, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand einschätzen will, wo ein Feedback landet (Radical Candor, Ruinous Empathy, Obnoxious Aggression, Manipulative Insincerity), sich vor unangenehmer Kritik drückt, Feedback im Team einführen, Feedback von Mitarbeitenden erbitten oder eine offene Feedbackkultur ohne Flurfunk etablieren will. Führt durch die zwei Dimensionen Care personally und Challenge directly und durch den Roll-out in sechs Schritten.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L5 Grow Your People
  origin: Kim Scott
  deep_dive: true
  version: "1.0"
---

# Radical Candor

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Kim Scott.

## Worum es geht

Radical Candor ist ein Führungs- und Feedback-Framework von Kim Scott, entwickelt aus ihrer Erfahrung bei Google, Apple und anderen Technologieunternehmen. Der Kern lässt sich in zwei Dimensionen beschreiben: Care personally (persönlich nahe sein) und Challenge directly (direkt herausfordern). Gutes Feedback und gute Führung entstehen nur im Schnittpunkt beider Dimensionen. Deine Mitarbeitenden müssen spüren, dass dir die Menschen hinter der Arbeit wichtig sind, dass es dein Ziel ist, sie besser zu machen, und dass der Weg dorthin das offene, klare Gespräch über die Qualität ihrer Arbeit ist.

Aus dem Zusammenspiel beider Dimensionen ergeben sich vier Führungsmuster (Abb. 4.12):

| Muster | Care personally | Challenge directly | Beschreibung |
|---|---|---|---|
| **Radical Candor** | hoch | hoch | Der Zielzustand. Du kümmerst dich um die Person und gibst trotzdem direkt und klar Feedback. Du sagst, was du denkst, weil dir ihre Entwicklung wichtig ist, nicht, um recht zu haben. |
| **Ruinous Empathy** (ruinöse Empathie) | hoch | niedrig | Das häufigste Problem in der Praxis. Du vermeidest unangenehme Wahrheiten, um niemanden zu verletzen. Kurzfristig freundlich, langfristig schädlich, weil die Person nicht bekommt, was sie für ihre Entwicklung braucht. |
| **Obnoxious Aggression** (aggressive Direktheit) | niedrig | hoch | Direktes, aber gleichgültiges Feedback. Inhaltlich vielleicht richtig, aber die Art zerstört Vertrauen. |
| **Manipulative Insincerity** (manipulative Unehrlichkeit) | niedrig | niedrig | Die gefährlichste Kombination: weder ehrlich noch fürsorglich. Feedback wird aus politischen Gründen zurückgehalten oder verzerrt. |

Brené Browns »Clear is kind. Unclear is unkind.« und Kim Scotts Radical Candor sagen dasselbe auf zwei Arten: Klarheit ist ein Akt der Fürsorge, kein Akt der Härte.

Der Deep Dive geht einen Schritt weiter: Radical Candor nicht nur selbst leben, sondern in ein Team bringen, sodass eine Feedbackkultur entsteht, in der Feedback in beide Richtungen und zwischen allen fließt. Ein bewusster Roll-out leistet drei Dinge:
- **Du nimmst die Last von deinen Schultern.** Solange nur du Feedback gibst, bist du der Flaschenhals. Eine funktionierende Feedbackkultur verteilt die Verantwortung aufs Team, viele Probleme sind gelöst, bevor sie bei dir landen.
- **Du baust auf Vertrauen, nicht auf Technik.** Der Roll-out ist eine Beziehung, die man aufbaut. Deshalb steht das Erbitten von Feedback am Anfang: Es zeigt Demut, macht dich angreifbar und signalisiert, dass Offenheit sicher ist.
- **Du machst Feedback alltäglich, nicht zum Ereignis.** Radical Candor passiert in ein, zwei Minuten zwischendurch, nicht in eigens angesetzten Terminen.

## Wann du sie einsetzt

- Um zu verstehen, wo ein Feedback gerade landet (Diagnose mit den Quadranten).
- Wenn du ein unangenehmes Thema vor dir herschiebst und hoffst, dass es sich von selbst löst. Es löst sich nicht, und das Gespräch wird mit der Zeit schwerer.
- Um eine Feedbackkultur im Team aufzubauen (Roll-out in sechs Schritten).
- In den ersten Meetings mit einem Team, um einen klaren Rahmen zu setzen: vertrauensvoll zusammenarbeiten und sich fachlich direkt und ehrlich challengen. Kim Scott schlägt vor, das Framework dort direkt vorzustellen, damit eine gemeinsame Sprache entsteht.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Geht es um ein konkretes Feedback oder um die Feedbackkultur im Team? Wie groß ist das Team, und wie läuft Feedback heute? Wo steht die Person selbst: bittet sie schon um Feedback? Frag nichts, was sie schon gesagt hat.
- Unterscheide zwei Werkzeuge. Die Quadranten sind das Diagnosewerkzeug: Wo landet ein Feedback? Die Order of Operations (erbitten, geben, gaugen, ermutigen) ist das Handlungswerkzeug: In welcher Reihenfolge gehst du vor? Der Roll-out in sechs Schritten ist die Anwendung dieser Reihenfolge auf ein Team über Zeit.
- Geht es um ein konkretes Feedback, nutze Teil A des Ablaufs. Geht es um das Team, nutze Teil B. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Will die Person mit Kritik starten, bevor sie selbst um Feedback gebeten hat? Benenne Schwächen direkt und kurz. Kein Lob als Füllmaterial.
- Erfinde keine Reaktionen oder Einschätzungen von Teammitgliedern. Was die Person nicht weiß, markiere als offen.
- Für die Formulierung eines einzelnen Feedbacks kannst du auf `sbi-feedback` verweisen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

### Teil A: Ein konkretes Feedback einordnen und geben

1. **Einordnen.** Wo landet das geplante oder bereits gegebene Feedback in den Quadranten?
   Frage: *»Was willst du sagen, und wie würdest du es heute sagen?«* Gut ist die Einordnung, wenn beide Achsen benannt sind: Wird die Person wirklich herausgefordert? Spürt sie, dass es dir um sie geht?
2. **Zeitpunkt.** Feedback so nahe wie möglich am Ereignis geben, nach Tagen oder Stunden, nicht nach Wochen. Zwei bis drei Minuten direkt nach einem Meeting wirken mehr als ein ausführliches Gespräch einen Monat später. Das gilt für Kritik und Lob.
   Frage: *»Wann ist der nächste Moment, in dem du es kurz ansprechen kannst?«*
3. **Wirkung prüfen (Gauging).** Feedback wird nicht am Mund der sprechenden Person gemessen, sondern am Ohr der zuhörenden. Wirkt die Person traurig, geh hoch auf der Achse »persönlich nahe sein«. Wirkt sie wütend, werde neugierig, nicht selbst wütend. Wehrt sie ab, fordere klarer heraus.
   Frage: *»Wie kennst du die Person: Wie könnte sie reagieren, und wie justierst du dann nach?«*

### Teil B: Roll-out im Team in sechs Schritten

Radical Candor, LLC beschreibt den Roll-out in sechs Schritten (Abb. 4.22). Die Reihenfolge ist Absicht: erst Vertrauen und Kultur, dann Kritik. Starte nichts Neues, bevor das Fundament steht.

1. **Teile deine eigenen Geschichten.** Führe Radical Candor ein, indem du von eigenen Feedbackerfahrungen erzählst, guten wie schlechten. Geschichten schaffen eine gemeinsame Sprache und machen das Konzept greifbar, ohne dass es nach Schulung klingt.
   Frage: *»Welche eigene Feedbackerfahrung, gut oder schlecht, kannst du deinem Team erzählen?«*
2. **Erbitte Feedback, bevor du es gibst.** Der entscheidende erste eigene Schritt. Leg dir eine ehrliche Go-to-Frage zurecht, die sich nicht mit Ja oder Nein beantworten lässt. Kim Scotts eigene Frage: »Was könnte ich tun oder lassen, um dir die Zusammenarbeit mit mir zu erleichtern?« Dann halte die unangenehme Stille aus, statt die Person vom Haken zu lassen, und belohne Offenheit, indem du gut reagierst, auch wenn du widersprichst.
   Frage: *»Wie lautet deine Go-to-Frage?«* Gut ist sie, wenn sie offen ist und die Person sie ehrlich meint.
3. **Führe Career Conversations.** Verstehe, was jede Person antreibt und wie ihre Arbeit in ihre langfristigen Lebensziele passt. Ohne dieses Verständnis bleibt jedes Feedback an der Oberfläche.
   Frage: *»Weißt du für jede Person in deinem Team, was sie antreibt?«*
4. **Verbessere deine 1:1s.** Die 1:1s sind das Gefäß, in dem die Beziehung zu den direkten Reports wächst. Erst wenn sie tragen, hat spontanes Feedback einen Resonanzboden.
   Frage: *»Wie laufen deine 1:1s heute, und was fehlt?«*
5. **Gib Lob und Kritik und achte auf die Wirkung.** Erst jetzt beginnst du mit spontanem Lob und spontaner Kritik, in kurzen Gesprächen von ein bis zwei Minuten. Lob sollte mindestens so häufig sein wie Kritik. Für die Formulierung hilft die CORE-Methode (Context, Observation, Result, next stEps). Prüfe die Wirkung wie in Teil A, Schritt 3.
   Frage: *»Wie ist dein Verhältnis von Lob zu Kritik in den letzten zwei Wochen?«*
6. **Halte inne und prüfe.** Starte nichts Neues, bis du auf dem Fundament wirklich Fortschritt siehst: dass du gut darin wirst, Feedback zu erbitten und zu geben, dass du deine Leute durch Career Conversations besser kennst und dass deine 1:1s tragen. Das Erbitten von Feedback hört nie auf, es wird zur täglichen Gewohnheit wie Zähneputzen.
   Frage: *»Woran erkennst du, dass das Fundament trägt?«*

Vorlage für den Roll-out: `templates/roll-out-plan.md`.

## Beispiel

Dominik Kenzler beschreibt, wie seine besten Führungskräfte ihm gesagt haben, woran er arbeiten muss, auch wenn es kein einfacher Moment war. Mate Galic sagte ihm nach sechs Monaten bei Native Instruments: »Dominik, dein Englisch ist leider zu schwach. Du hast gute Inhalte, aber sie kommen nicht gut rüber. Daran musst du arbeiten. Ich helfe dir, einen Coach zu finden, aber in sechs Monaten muss es besser sein.« Es dauerte oft ein bis zwei Wochen, bis er solches Feedback einordnen konnte. Rückblickend waren es genau diese Momente, die ihn weitergebracht haben.

Umgekehrt der Anfang seiner Führungslaufbahn: Aus Sorge, als Micromanager zu wirken, gab er wenig Richtung und vages Feedback. Das Ergebnis war regelmäßige Unzufriedenheit mit Ergebnissen, weil er seine Erwartungen nicht klar kommuniziert hatte.

## Worauf du achten musst

- **Mit Kritik beginnen.** Der häufigste und folgenreichste Fehler. Radical Candor beginnt nicht mit Kritik an Mitarbeitenden, sondern damit, dass du um Feedback bittest und das Aussprechen unbequemer Wahrheiten belohnst statt bestrafst. Wer mit Kritik beginnt, verbrennt das Vertrauen, das die Voraussetzung für alles Weitere ist.
- **Radical Candor mit Brutal Honesty verwechseln.** Direkt herausfordern ohne persönliche Nähe ist Obnoxious Aggression. Die persönliche Nähe ist keine Verzierung, sie ist die halbe Definition.
- **Ruinous Empathy.** Die häufigste Falle für Führungskräfte, die es gut meinen: nichts sagen, um niemanden zu verletzen, und hoffen, dass sich das Problem von selbst löst.
- **Backstabbing zulassen.** Etabliere die Norm der Clean Escalation (nach Fred Kofman): nicht schlecht über jemanden hinter dessen Rücken reden. Kommen zwei Personen nicht weiter, sprechen sie zu dritt, nicht übereinander. Ohne diese Norm zerfällt jede Feedbackkultur im Flurfunk.
- **Feedback nach eigener Absicht bewerten.** Die eine Person hört keine Kritik heraus, die nächste empfindet sie als verletzend, die dritte als Angriff. Du musst für jede Person und jeden Kontext nachjustieren.
- **Das Feedback-Sandwich benutzen.** Lob als Verpackung für Kritik entwertet beides. Gib echtes Lob und echte Kritik, beide spezifisch und aufrichtig, aber nicht ineinander versteckt.
- **Feedback aufsparen.** Gesammelt fürs Jahresgespräch oder ein formales Review verliert Feedback seine Wirkung. Die Person ist überrascht und hatte keine Chance, früher zu reagieren.

## Ergebnis

Für ein konkretes Feedback:

```markdown
# Radical Candor: Feedback an [Name / Rolle]

**Worum es geht:** …
**Einordnung heute:** Radical Candor / Ruinous Empathy / Obnoxious Aggression / Manipulative Insincerity, weil …
**Care personally:** Woran die Person merkt, dass es dir um sie geht: …
**Challenge directly:** Was du klar sagst: »…«
**Wann:** [nächster Moment, möglichst zeitnah]
**Gauging:** Mögliche Reaktion: … · Wie du nachjustierst: …
```

Für den Roll-out im Team: `templates/roll-out-plan.md`.

## Mini-Check

- Beginnst du damit, Feedback zu erbitten, bevor du es gibst?
- Hast du eine ehrliche Go-to-Frage, die sich nicht mit Ja oder Nein beantworten lässt?
- Achtest du beim Geben darauf, wie das Feedback ankommt, und justierst nach?
- Gibt es im Team eine Norm gegen Backstabbing (Clean Escalation)?
- Widerstehst du der Versuchung, mehr Neues zu starten, bevor Erbitten, 1:1s und Career Conversations tragen?

## Im Flywheel

Modul LEAD, Bereich L5 Grow Your People.

Du führst am stärksten durch Vorbild. Wenn im Team offen Feedback fließen soll, musst du selbst psychologische Sicherheit schaffen: Fehler offen zugeben, Offenheit belohnen, fürsorglich und klar Feedback geben.

Verwandte Skills:
- `sbi-feedback`: Im selben Kapitel, für die Form des einzelnen Feedbacks.
- `one-on-one-skip-level`: Schritt 4 des Roll-outs. Das Buch zitiert Kim Scott auch im 1:1-Kapitel mit der Go-to-Frage.
- `letting-go`: Das Buch nutzt Kim Scotts vier Lügen, die sich Manager erzählen, um eine Trennung aufzuschieben.
- `feedback-einholen`: Die Gegenrichtung. Eine Führungskraft, die Feedback einfordert, schafft eine Kultur, in der Feedback in alle Richtungen fließt.
- `leadership-flywheel`: Das Buch nennt Radical Candor als Beispiel dafür, wie ein Framework eine gemeinsame Sprache schafft.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Grundlagen, Gemeinsame Sprache (Abb. 2.5), Kapitel LEAD, L5 Grow Your People (Abb. 4.12) und Deep Dive Radical Candor (Abb. 4.22). Originalquelle: Kim Scott: Radical Candor. Roll-out nach Radical Candor, LLC. Clean Escalation nach Fred Kofman.

Original: Kim Scott: Radical Candor, St. Martin's Press, 2017. Roll-out: Kim Scott, 6 Ways to Roll Out Radical Candor, 2020, https://www.radicalcandor.com/blog/rolling-out-radical-candor-part-one
