---
name: timely-decisions
description: Timely Decisions mit Multitracking und Tripwires aus »Decisive« von Chip und Dan Heath (WRAP), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn eine Entscheidung stockt oder immer wieder vertagt wird, ein Team in einer Entweder-oder-Frage feststeckt, alle auf mehr Daten warten, Entscheidungen ständig wieder aufgemacht werden oder jemand für eine riskante Entscheidung vorab festlegen will, wann nachjustiert wird. Führt durch Optionen weiten (Vanishing-Options-Test, Opportunitätskosten, Leiter), zwei bis drei echte Optionen, Entscheidung bei rund 70 Prozent Information und Tripwires, Bookending und Premortem.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S4 Make Fast Decisions
  origin: Chip Heath und Dan Heath
  deep_dive: true
  version: "1.0"
---

# Timely Decisions

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Chip Heath und Dan Heath.

## Worum es geht

In fast jeder Organisation gibt es dasselbe Muster: Teams warten auf mehr Daten, Führungskräfte wollen noch eine Runde Abstimmung, Entscheidungen werden vertagt, bis der richtige Zeitpunkt kommt. Das Ergebnis sind nicht schlechte, sondern zu späte Entscheidungen. Es gibt weit mehr Entscheidungen, die zu langsam getroffen werden, als solche, die durch längeres Warten besser werden. Mehr Zeit bedeutet meistens nur mehr Meetings.

Chip und Dan Heath bringen es in »Decisive« auf den Punkt: Meistens ist es besser, eine Entscheidung zu treffen, zu handeln und falschzuliegen, als zu zögern und zu verzögern. Sie beschreiben vier Fallen, die Entscheidungen verlangsamen oder verschlechtern:

1. **Zu enge Rahmung:** Wir denken in Entweder-oder und übersehen andere Möglichkeiten.
2. **Bestätigungsfehler:** Wir suchen Informationen, die unsere Meinung bestätigen, statt sie herauszufordern.
3. **Kurzfristige Emotionen:** Unsicherheit oder Angst vor Konsequenzen lähmen die Entscheidung.
4. **Übergewissheit:** Wir sind zu sicher, wie die Zukunft aussehen wird.

Dagegen setzen sie einen Prozess mit vier Schritten, kurz WRAP: Widen Your Options (Optionen weiten), Reality-Test Your Assumptions (Annahmen an der Realität testen), Attain Distance Before Deciding (Abstand gewinnen), Prepare to Be Wrong (sich auf den Irrtum vorbereiten). Timely Decisions konzentriert sich auf zwei Werkzeuge daraus, weil sie das meiste eigene Handwerk mitbringen: **Multitracking** am Anfang, um bessere Optionen zu erzeugen, und **Tripwires** am Ende, um den Zeitpunkt zum Nachjustieren festzulegen. Mehr Optionen klingt nach mehr Aufwand, ist aber oft schneller: Wer nur eine Option entwickelt, hängt sein Ego daran und kämpft um sie. Wer von Anfang an zwei oder drei verfolgt, diskutiert sachlicher und hat einen eingebauten Rückfallplan, falls eine Option scheitert. Zwischen Multitracking und Tripwires liegt die Entscheidung selbst, getroffen bei rund 70 Prozent der gewünschten Information.

Bei folgenreichen Entscheidungen schlägt der Prozess die Analyse. Ein strukturierter Ablauf führt zuverlässiger zu guten Ergebnissen als mehr Nachdenken ohne Rahmen. Nicht weniger nachdenken, sondern besser.

## Wann du sie einsetzt

- Eine Entscheidung wird seit Wochen vertagt, oder alle warten auf mehr Daten.
- Ein Team steckt in einer Entweder-oder-Frage fest (»Sollen wir das tun oder nicht?«).
- Eine Person oder ein Team hängt an der einen Lösung, die es entwickelt hat.
- Entscheidungen werden durch Flurgespräche oder starke Einzelmeinungen immer wieder gekippt, bevor sie wirken konnten.
- Du triffst eine riskante Entscheidung und willst vorab festlegen, wann sie neu bewertet wird.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Entscheidung steht an, und wie ist sie heute formuliert? Seit wann ist sie offen, und woran hängt sie? Wer entscheidet? Frag nichts, was die Person schon gesagt hat.
- Prüf früh, ob es eine Two-way Door ist. Ist die Entscheidung umkehrbar, soll sie schnell fallen. Dann reichen die Schritte 1, 6 und 10. Für irreversible Entscheidungen geh den ganzen Ablauf durch.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Sind die Optionen echte Alternativen oder Scheinoptionen? Ist der Grund für die Verzögerung analytisch oder emotional? Benenne Schwächen direkt und kurz.
- Wenn »mehr Daten« als Grund genannt wird, frag nach: welche Daten genau, bis wann, und wer beschafft sie?
- Du entwickelst keine Optionen über die Organisation der Person aus eigenem Wissen. Du stellst die Fragen, die Person liefert die Inhalte. Was fehlt, markierst du als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Diagnose**

1. **Grund der Verzögerung klären.** Nach Matt Mochary: Ist der Grund analytisch oder emotional? Fehlen echte Daten, ist das legitim, aber dann muss klar sein: welche Daten, bis wann, durch wen? Ist die Verzögerung emotional, ist das ein Signal, jetzt zu entscheiden.
   Frage: *»Was fehlt dir konkret, um heute zu entscheiden? Sind das Daten, oder ist es ein ungutes Gefühl?«* Gut ist die Antwort, wenn sie entweder konkrete Daten mit Termin und Person nennt oder ehrlich benennt, dass es Unsicherheit ist.

**Multitracking: mehr als eine Option entwickeln**

2. **Vanishing-Options-Test.** Steckt ihr in einer Entweder-oder-Frage fest, stellt die Frage um: Angenommen, keine eurer aktuellen Optionen wäre erlaubt, was würdet ihr tun? Das zwingt aus dem engen Rahmen und bringt fast immer Möglichkeiten zum Vorschein, die vorher unsichtbar waren.
   Frage: *»Angenommen, keine eurer aktuellen Optionen wäre erlaubt: Was würdet ihr dann tun?«*

3. **Nach Opportunitätskosten fragen.** Was gebt ihr auf, wenn ihr euch so entscheidet? Was könntet ihr mit derselben Zeit und demselben Geld sonst tun?
   Frage: *»Was könntet ihr mit derselben Zeit und demselben Geld sonst tun?«*

4. **Optionen über die Leiter suchen.** Fehlen Alternativen, geh in Stufen vor: zuerst die eigenen hellen Flecken (wo in der Organisation funktioniert etwas Ähnliches bereits gut?), dann interne Best Practices und etablierte Lösungen, schließlich Analogien aus anderen Bereichen, in denen ein verwandtes Problem gelöst wurde.
   Frage: *»Wo bei euch funktioniert etwas Ähnliches schon gut? Und wo außerhalb wurde ein verwandtes Problem gelöst?«*

5. **Zwei bis drei echte Optionen parallel entwickeln.** Mehrere deutlich verschiedene Optionen gleichzeitig ausarbeiten, nicht nacheinander. Es müssen echte Alternativen sein, keine Scheinoptionen, die nur die Lieblingsoption gut aussehen lassen. Zwei bis drei, nicht zehn.
   Frage: *»Welche zwei oder drei Optionen verfolgt ihr ernsthaft, und wäre jede davon wirklich umsetzbar?«* Gut ist die Antwort, wenn die Optionen deutlich verschieden und jede realistisch ist. Sind alle Alternativen offensichtlich schwächer, gibt es nur eine Option und etwas Theater drum herum.

**Der Entscheidungszeitpunkt**

6. **Bei genug entscheiden, nicht bei voller Information.** Als Faustregel nach Jeff Bezos reichen für die meisten wichtigen Entscheidungen rund 70 Prozent der Informationen, die du dir wünschen würdest. Die letzten 20 oder 30 Prozent kosten unverhältnismäßig viel Zeit und verbessern die Entscheidung selten. Multitracking und Tripwires geben dir die Sicherheit, früher zu entscheiden.
   Frage: *»Wie viel von dem, was du gerne wüsstest, weißt du schon? Was würde die fehlende Information an der Entscheidung ändern?«*

**Tripwires: den Korrekturzeitpunkt vorab setzen**

7. **Tripwires setzen, bevor du sie brauchst.** Ein Tripwire ist ein im Voraus definierter Auslöser, der eine Entscheidung erzwingt. Leg ihn fest, solange die Lage ruhig ist. Drei Formen sind üblich:
   - eine Metrik-Schwelle: »Wenn die Adoption nach drei Monaten unter zehn Prozent liegt, überprüfen wir die Initiative.«
   - ein Datum: ein fester Review-Punkt.
   - eine Bedingung: »Wenn ein Projekt nach sechs Wochen kein klares Signal zeigt, stoppen wir.«

   Frage: *»Bei welcher Zahl, an welchem Datum oder unter welcher Bedingung schaut ihr euch die Entscheidung neu an?«* Gut ist die Antwort, wenn der Auslöser eindeutig prüfbar ist und feststeht, was dann passiert.

8. **Bookending.** Plane bewusst beide Enden. Unteres Ende: Was tun wir, wenn es schlechter läuft als gedacht? Oberes Ende: Sind wir vorbereitet, wenn es besser läuft als erwartet?
   Frage: *»Was tut ihr, wenn es deutlich schlechter läuft, und was, wenn es deutlich besser läuft?«*

9. **Premortem.** Stellt euch vor, die Entscheidung sei in einem Jahr gescheitert, und sucht nach den Gründen. Das deckt Risiken auf, bevor sie eintreten.
   Frage: *»Es ist ein Jahr später, und die Entscheidung ist gescheitert. Was ist passiert?«*

10. **Entscheiden und kommunizieren.** Eine getroffene Entscheidung, die nicht kommuniziert wird, ist keine Entscheidung.
    Frage: *»Wer muss von der Entscheidung wissen, und bis wann erfährt er oder sie es?«*

## Beispiel

Bei sevdesk entschied Dominik Kenzler mit dem Product Director, die alte mobile App zu sunsetten und durch die neu gebaute zu ersetzen, um maximalen Fokus zu behalten. Der neuen App fehlten wichtige Funktionen, aber die Daten zeigten, dass die aktiven Nutzer:innen der alten App überschaubar waren und die fehlenden Funktionen kaum genutzt wurden. Kurz danach brach der NPS ein, mit vielen negativen Reviews: Die App war für die Nutzer:innen emotional wichtiger als gedacht. Gedacht hatten beide nur in »alte App laufen lassen« oder »alte App sunsetten«. Eine dritte Option hätte es gegeben: einen Teil der alten Funktionen als Überbrückung in die neue App zu integrieren, Aufwand zwei Wochen. Seitdem stellt er sich vor jeder Entweder-oder-Entscheidung die Frage: Welche Option sehen wir noch nicht?

## Worauf du achten musst

- **Entscheidungsaufschub durch den Prozess.** Noch ein Meeting, noch eine Abstimmungsrunde, noch ein Alignment. Die meisten Entscheidungen tragen ein Risiko, das sich verstehen und manchmal verringern, aber selten vollständig vermeiden lässt. Der Versuch, jedes Risiko zu eliminieren, ist selbst eine Entscheidung und oft die schlechtere. Irgendwann ist der Moment vergangen, oder jemand anderes hat entschieden.
- **Entscheidungen nicht kommunizieren.** Das Team wartet weiter, weil niemand weiß, dass es eine Entscheidung gibt.
- **Entscheidungen ständig wieder aufmachen.** Ohne klare Kriterien kippen Flurgespräche und Einzelmeinungen Entscheidungen, bevor sie wirken können. Wer sie vorher ändert, erfährt nie, ob sie richtig gewesen wären. Tripwires definieren, wann tatsächlich neu bewertet wird, und schützen die Entscheidung bis dahin.
- **Scheinoptionen entwickeln.** Wer zwei schwache Alternativen neben die Lieblingslösung stellt, sucht nur Bestätigung.
- **Multitracking in Optionenflut kippen lassen.** Zu viele Möglichkeiten lähmen genauso wie zu wenige. Zwei bis drei.
- **Tripwires erst im Krisenmoment suchen.** Ein Tripwire wirkt nur, wenn er vorher gesetzt wurde.
- **Anti-Patterns, die Entscheidungen systematisch verlangsamen:**
  - »Lass uns das nächste Woche noch mal aufgreifen.« Ohne konkreten Grund ist das keine Sorgfalt, sondern Aufschub.
  - »Wir brauchen noch mehr Daten.« Kann legitim sein. Nachbohren: welche Daten, bis wann, wer beschafft sie?
  - Nachträgliche Deadline-Verlängerungen. Die erste grundlose Verschiebung signalisiert der ganzen Organisation, dass Deadlines verhandelbar sind.
  - Status-Meetings zur Beschleunigung. Status ist asynchron, Meetings sind für Diskussion und Entscheidung.
  - »Wir müssen noch alle abholen.« Konsens ist manchmal wichtig, aber kein Ersatz für eine Entscheidung.

## Ergebnis

```markdown
# Entscheidung: [Titel]
Datum: [Datum] · Entscheidet: [Name]

**Ursprüngliche Frage:** …
**Grund der Verzögerung:** analytisch (Daten: …, bis …, durch …) / emotional

## Optionen (2 bis 3, echt und verschieden)
1. …
2. …
3. …
Aus Vanishing-Options-Test / Leiter / Opportunitätskosten: …

**Informationsstand:** rund … Prozent · Was noch fehlt und warum es die Entscheidung kaum ändert: …
**Entscheidung:** Option …, weil …

## Tripwires
| Art | Auslöser | Was dann passiert |
|---|---|---|
| Metrik | … | … |
| Datum | … | … |
| Bedingung | … | … |

**Bookending:** schlechter als gedacht: … · besser als gedacht: …
**Premortem, wichtigste Risiken:** …
**Kommuniziert an / bis:** …
```

## Mini-Check

- Habt ihr bei der letzten wichtigen Entscheidung mehrere Optionen entwickelt oder nur eine geprüft?
- Sind eure Alternativen echte Optionen oder nur Scheinoptionen, die die Lieblingslösung stützen sollen?
- Nutzt ihr eine systematische Suche nach Optionen, von eigenen hellen Flecken bis zu Analogien von außen?
- Habt ihr für riskante Entscheidungen Tripwires gesetzt, also klare Auslöser zum Nachjustieren?
- Entscheidet ihr bei rund 70 Prozent Informationen, oder wartet ihr auf eine Sicherheit, die nicht kommt?

## Im Flywheel

Modul SHIP, Bereich S4 Make Fast Decisions. Das Buch versteht Entscheidungsgeschwindigkeit als Kultur: Ohne Leader, die das Tempo aktiv setzen, verfällt jede Organisation in ihre träge Eigengeschwindigkeit (Frank Slootman). Als Leader ermöglichst du Entscheidungen, statt sie zu verwalten: Blocker aus dem Weg räumen, klar benennen, wer entscheidet, Freigaben schnell geben. »Wenn du nicht sicher bist, wer entscheidet, dann bist du es. Handle so.« (Claire Hughes Johnson)

Verwandte Skills:
- `one-way-two-way-door`: Das Buch verweist für den Unterschied zwischen umkehrbaren und irreversiblen Entscheidungen auf diese Methode.
- `mut-zu-entscheidungen`: Greift die 70-Prozent-Regel und die Two-way Doors aus Make Fast Decisions für die eigene Entscheidungspraxis auf.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S4 Make Fast Decisions und Deep Dive Timely Decisions, Kapitel YOURSELF, Mut zu Entscheidungen. Originalquelle: Chip Heath, Dan Heath: Decisive. Weitere im Kapitel genannte Quellen: Frank Slootman: Amp It Up, Matt Mochary.

Original: Chip Heath, Dan Heath: Decisive. How to Make Better Choices in Life and Work, 2013. 70-Prozent-Regel: Jeff Bezos: 2016 Letter to Shareholders, 2017, https://www.aboutamazon.com/news/company-news/2016-letter-to-shareholders
