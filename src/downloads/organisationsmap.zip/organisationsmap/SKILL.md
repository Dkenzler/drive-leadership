---
name: organisationsmap
description: Die fachliche Zusammensetzung einer Organisation sichtbar machen mit der Organisationsmap aus dem Drive Leadership Playbook, auf Basis der drei Ebenen Funktionen, Fachrichtungen und Spezialisierungen nach Peter Merholz (Org Design for Design Orgs). Nutze diesen Skill, wenn jemand eine neue Organisation oder ein neues Team aufbaut, skaliert und aus einer Funktion mehrere Fachrichtungen werden, unklar ist, welche Rolle als Nächstes besetzt werden soll, eine Restrukturierung vorbereitet oder die eigene Aufstellung gegen Strategie und Markt prüfen will. Startet bei Disziplinen, nicht bei Personen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L1 Design Your Organisation
  origin: Peter Merholz
  deep_dive: false
  version: "1.0"
---

# Organisationsmap

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Peter Merholz (Unterscheidung von Functions, Practices und Specializations aus »Org Design for Design Orgs«).

## Worum es geht

Die Organisationsmap ist ein Denkmodell, das die fachliche Zusammensetzung einer Organisation sichtbar macht. Sie besteht aus drei Ebenen:

1. **Funktionen:** die großen Disziplinen, etwa Engineering, Design, Sales, Marketing oder Operations.
2. **Fachrichtungen:** die Bereiche innerhalb einer Funktion, jeweils mit eigenen Methoden und eigenem Fachwissen. In Design etwa UX Research, Product Design oder Content Design. Im Engineering Backend, Frontend oder Data Engineering. Im Vertrieb Inbound Sales oder Key Account Management.
3. **Spezialisierungen:** konkrete Profile mit unterschiedlichem Schwerpunkt innerhalb einer Fachrichtung. Ein Product Designer kann sich stärker als UX Architect oder als UI-Spezialist positionieren.

Das Ziel ist Klarheit darüber, welche fachlichen Disziplinen eine Organisation braucht. Die Map startet bewusst bei Disziplinen und Fachrichtungen, nicht bei Personen und Profilen. Wer zuerst an Personen denkt, baut Organisationen um einzelne Menschen herum. Das funktioniert kurzfristig, aber selten langfristig. Die Map stellt eine Frage ins Zentrum: Was genau brauchen wir, um unsere Strategie umzusetzen?

Die Unterscheidung hilft, präziser über das Team nachzudenken. Die Frage ist nicht nur: Brauche ich einen Designer oder Engineer? Sondern: Welche Fachrichtung brauche ich, und welche Spezialisierung passt zu unserer aktuellen Herausforderung?

## Wann du sie einsetzt

- Beim Aufbau einer neuen Organisation oder eines neuen Teams.
- Bei der Skalierung, wenn aus einer Funktion mehrere Fachrichtungen werden.
- Wenn unklar ist, welche Rolle als Nächstes besetzt werden soll.
- Bei einer Restrukturierung, um die bestehende Aufstellung kritisch zu prüfen und vorzubereiten.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Organisation oder welchen Bereich gilt die Map? Wie lautet die Strategie oder das Zielbild, aus dem sich die Aufstellung ableiten soll? Anlass (Aufbau, Skalierung, nächste Besetzung, Restrukturierung)? Frag nichts, was die Person schon gesagt hat.
- Fehlt eine Strategie, sag das deutlich. Ohne sie lässt sich nicht beurteilen, welche Fachrichtungen gebraucht werden. Arbeite dann mit dem, was als Ziel bekannt ist, und markiere es als Annahme.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen, wenn sie schon Material hat.
- Nennt die Person Namen oder beschreibt sie Funktionen entlang einzelner Menschen, lenke zurück auf Disziplinen und Fachrichtungen.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz.
- Erfinde keine Fakten über die Organisation der Person. Fehlende Informationen markierst du als offen.
- Schritt 2 kann in einem Workshop mit den betreffenden Stakeholdern stattfinden. Biete dann an, Fragen und Ablauf für diese Runde vorzubereiten.
- Schließe mit der Map im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Funktionen definieren.** Welche Disziplinen braucht die Organisation? Nicht welche sie hat, sondern welche die Strategie verlangt. Das erfordert, von der Vision her zu denken und nicht vom Organigramm.
   Frage: *»Welche Disziplinen verlangt eure Strategie, unabhängig davon, wie euer Organigramm heute aussieht?«* Gut ist die Antwort, wenn jede Funktion mit der Strategie begründet ist und nicht mit der bestehenden Struktur.

2. **Fachrichtungen identifizieren.** Innerhalb jeder Funktion: Welche Fachrichtungen braucht ihr? Entscheidend ist, dass jede Fachrichtung eigene Methoden, eigenes Fachwissen und eigene Wirkungsbereiche mitbringt. Das geht in Einzelarbeit oder in einem Workshop mit den betreffenden Stakeholdern. Oft entstehen neue Fachrichtungen innerhalb einer Disziplin, die wiederum die Zusammenarbeit mit anderen Disziplinen verändern. Sitzt eine Rolle an der Schnittstelle zweier Disziplinen, lohnt die gemeinsame Auseinandersetzung, weil es meist um neue Arbeitsweisen und Kollaboration geht.
   Frage: *»Welche Fachrichtungen braucht ihr in jeder Funktion, und was bringt jede an eigenen Methoden, Fachwissen und Wirkungsbereich mit?«* Gut ist die Antwort, wenn sich jede Fachrichtung klar von den anderen abgrenzt.

3. **Spezialisierungen klären.** Innerhalb einer Fachrichtung gibt es unterschiedliche Profile. Diese Ebene wird erst ab einer gewissen Größe relevant. Bei kleinen Teams reicht meist die Ebene der Fachrichtungen.
   Frage: *»Ist eure Organisation groß genug, dass innerhalb einer Fachrichtung unterschiedliche Profile nötig sind? Wenn ja, welche?«* Bei kleinen Teams ist »nicht relevant« eine gute Antwort.

4. **Abgleich mit der Strategie.** Passt die Aufstellung zu dem, was ihr erreichen wollt? Fehlt eine Fachrichtung, die ihr aufbauen müsst? Gibt es Fachrichtungen, die heute besetzt sind, aber strategisch keine Priorität mehr haben?
   Frage: *»Welche Fachrichtung fehlt, und welche ist besetzt, hat aber keine strategische Priorität mehr?«* Gut ist die Antwort, wenn sie beide Richtungen benennt: Lücke und Überhang.

5. **Den Markt beobachten.** Fachrichtungen und Spezialisierungen verändern sich mit Technologien, Märkten und Arbeitsweisen. In den letzten Jahren sind Rollen wie AI Product Manager, Design Engineer oder Prompt Engineer entstanden. Bestehende Profile verschieben sich: Der Product Owner wird in vielen Unternehmen durch den Product Manager mit breiterem strategischem Mandat ersetzt. Prüfe die Aufstellung deshalb regelmäßig gegen den Markt.
   Frage: *»Welche neuen Fachrichtungen oder Spezialisierungen entstehen gerade, die für eure Strategie relevant werden können? Und gibt es Rollen im Team, deren Profil sich so verändert hat, dass ihr sie neu definieren müsst?«*

## Beispiel

Das Buch nutzt den Fußball als Bild. Jürgen Klopp und Pep Guardiola haben unterschiedliche Visionen vom perfekten Spiel: Guardiola setzt auf Ballbesitz, Klopp auf Gegenpressing. Beide brauchen dafür eine passende Aufstellung, und erst aus der Struktur ergibt sich, welche Fähigkeiten jede Position verlangt. In der Arbeitswelt entspricht die Aufstellung der Teamstruktur. In der Produktentwicklung arbeiten viele Organisationen mit einem Product Trio aus Engineering, Product und Design als strategischem Kern, ergänzt durch weitere Engineers für die Umsetzung. Das Prinzip bleibt: Die Vision bestimmt, welche Funktionen ein Team braucht und wie sie zusammenspielen.

Ein aktuelles Beispiel für Schritt 2 ist der AI Design Engineer, eine Rolle an der Schnittstelle von zwei Disziplinen.

## Worauf du achten musst

- **Von Personen statt von Disziplinen ausgehen.** Wer zuerst an Menschen denkt, baut die Organisation um Einzelne herum. Das trägt selten langfristig.
- **Vom Organigramm statt von der Vision her denken.** Die Frage ist, welche Disziplinen die Strategie verlangt, nicht welche es heute gibt.
- **Fachrichtungen aus der Historie ableiten.** Besetzte Fachrichtungen ohne strategische Priorität bleiben sonst unbemerkt bestehen.
- **Spezialisierungen zu früh anlegen.** In kleinen Teams reicht die Ebene der Fachrichtungen.
- **Den Markt nicht beobachten.** Wer das nicht tut, baut Organisationen für den Markt von gestern.

## Ergebnis

```markdown
# Organisationsmap: [Organisation / Bereich]
Stand: [Datum] · Erstellt von: [Rolle]
Strategie / Zielbild (Kurzfassung): …

| Funktion | Fachrichtung | Eigene Methoden, Fachwissen, Wirkungsbereich | Spezialisierungen (falls relevant) | Beitrag zur Wertschöpfung |
|---|---|---|---|---|
| … | … | … | … | … |

## Abgleich mit der Strategie
- Fehlende Fachrichtungen, die wir aufbauen müssen: …
- Besetzte Fachrichtungen ohne strategische Priorität: …
- Als Nächstes aufbauen oder stärken: …

## Marktbeobachtung
- Neue Fachrichtungen / Spezialisierungen mit Relevanz für uns: …
- Rollen, deren Profil wir neu definieren müssen: …

## Offen
- …
```

## Mini-Check

- Kannst du die Funktionen und Fachrichtungen deiner Organisation in einem Satz erklären?
- Leiten sich deine Fachrichtungen aus der Strategie oder aus der Historie ab?
- Weißt du, welche Fachrichtung du als Nächstes aufbauen oder stärken musst?
- Ist für jede Fachrichtung klar, welchen Beitrag sie zur Wertschöpfung leistet?
- Wann hast du zuletzt geprüft, ob deine Fachrichtungen noch dem Markt entsprechen?

## Im Flywheel

Modul LEAD, Bereich L1 Design Your Organisation.

Verwandte Skills:
- `faehigkeitenmatrix`: Steht fest, welche Funktionen und Fachrichtungen die Organisation braucht, folgt die Frage, welche Fähigkeiten jede Fachrichtung mitbringen muss.
- `rollen`: Eine Rolle ergibt sich aus Fachrichtung, Fähigkeiten und Level.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L1 Design Your Organisation (Abb. 4.1). Originalquelle der drei Ebenen: Peter Merholz: Org Design for Design Orgs.

Original: Peter Merholz und Kristin Skinner: Org Design for Design Orgs, O'Reilly, 2016.
