# GO Product Roadmap

Nach der Abbildung zur GO Product Roadmap im Drive Leadership Playbook, nach Roman Pichler.

**Produkt / Team / Bereich:**
**Stand:**

Spalten: Zeithorizonte (Jahre oder Quartale). Zeilen: Ziele, Initiativen, Details.

| | Zeithorizont 1 | Zeithorizont 2 | Zeithorizont 3 | Zeithorizont 4 |
|---|---|---|---|---|
| **Datum** | | | | |
| **Name** | | | | |
| **Ziel** | | | | |
| **Metrik** | | | | |
| **Feature** | | | | |

## Das machen wir nicht, und warum
