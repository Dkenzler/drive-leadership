---
name: go-product-roadmap
description: Eine zielorientierte Roadmap mit der GO Product Roadmap (Goal-Oriented) nach Roman Pichler erstellen, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand eine Produkt-, Team- oder Bereichs-Roadmap bauen will, die Ergebnisse (Outcomes) statt Features zeigt, Ziele und Initiativen über Zeithorizonte kommunizieren, Tradeoffs sichtbar machen oder eine Feature-Liste in eine stabile, zielorientierte Roadmap mit Datum, Name, Ziel, Metrik und Features umbauen will.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D4 Guiding Principles (Strategic Planning)
  origin: Roman Pichler
  deep_dive: false
  version: "1.0"
---

# GO Product Roadmap

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Roman Pichler.

## Worum es geht

GO steht für »Goal-Oriented«. Statt Features und Funktionen aufzulisten, zeigt die GO Product Roadmap, welche Ergebnisse (Outcomes) erreicht werden sollen. Ursprünglich für Product Roadmaps entwickelt, eignet sich das Format genauso für Team- oder Bereichs-Roadmaps, überall dort, wo Ziele und Initiativen über Zeithorizonte kommuniziert werden sollen.

**Struktur:** Die Spalten sind Zeithorizonte, zum Beispiel Jahre oder Quartale. Die Zeilen beschreiben Ziele, Initiativen und Details. Das Ziel gibt den strategischen Kontext vor, Features oder Details sind Mittel zum Zweck. Die Abbildung im Buch zeigt pro Spalte die Felder Datum, Name, Ziel, Metrik und Feature.

**Kernprinzip:** Ergebnisse (Outcomes) vor Maßnahmen (Outputs). Die Roadmap bleibt stabil, auch wenn sich konkrete Maßnahmen ändern. Sie macht Tradeoffs sichtbar, den Punkt, den Geoff Charles (CPO bei Ramp) betont: »Das machen wir, das machen wir nicht, und warum.«

## Wann du sie einsetzt

- Eine Product Roadmap aufbauen, die Ziele statt Features zeigt.
- Team- oder Bereichs-Roadmaps, wenn Ziele und Initiativen über Zeithorizonte kommuniziert werden sollen.
- Wenn sich eine Roadmap ständig ändert, weil sie an konkreten Maßnahmen hängt.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Produkt, Team oder welchen Bereich? Welche Zeithorizonte (Jahre, Quartale)? Gibt es übergeordnete Ziele oder eine bestehende Roadmap? Frag nichts, was die Person schon gesagt hat.
- Bringt die Person eine Feature-Liste mit, frag bei jedem Feature nach dem Ziel, dem es dient. Features ohne Ziel sind Kandidaten für »machen wir nicht«.
- Geh den Ablauf Schritt für Schritt durch, Spalte für Spalte. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz.
- Erfinde keine Ziele, Metriken oder Features. Fehlt etwas, markiere es als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Das Buch beschreibt keinen festen Ablauf. Die Schritte folgen den Feldern der Abbildung, pro Zeithorizont.

1. **Zeithorizonte festlegen (Datum).** Frage: *»In welchen Zeithorizonten plant ihr, Jahre oder Quartale, und wie viele Spalten braucht ihr?«*

2. **Ziel pro Zeithorizont.** Frage: *»Welches Ergebnis wollt ihr in diesem Zeitraum erreichen?«* Gut ist die Antwort, wenn sie ein Outcome beschreibt, keinen Output.

3. **Name.** Frage: *»Wie heißt dieser Abschnitt kurz, sodass man ihn sich merken kann?«*

4. **Metrik.** Frage: *»Woran messt ihr, dass das Ziel erreicht ist?«* Gut ist die Antwort, wenn die Metrik das Ziel misst und nicht die Lieferung eines Features.

5. **Features oder Details.** Frage: *»Welche Features oder Initiativen sind Mittel zum Zweck für dieses Ziel?«* Gut ist die Antwort, wenn jedes Feature erkennbar dem Ziel der Spalte dient.

6. **Tradeoffs benennen.** Frage: *»Was macht ihr bewusst nicht, und warum?«*

## Worauf du achten musst

(abgeleitet aus dem Text des Buchs)

- **Features statt Outcomes.** Das Ziel gibt den Kontext vor, Features sind Mittel zum Zweck. Stehen Features oben, ist es eine Feature-Liste mit Datum.
- **Roadmap an Maßnahmen gekoppelt.** Ändert sich die Roadmap bei jeder geänderten Maßnahme, hängt sie an Outputs statt Outcomes.
- **Tradeoffs verschwiegen.** Die Roadmap soll sichtbar machen, was ihr macht, was nicht, und warum.
- **Als Commitment gelesen.** Ein strategischer Plan ist kein Vertrag, sondern eine fundierte Einschätzung, die sich ändern wird.

## Ergebnis

Vorlage: `templates/go-roadmap.md`.

```markdown
# GO Product Roadmap: [Produkt / Team / Bereich]
Stand: [Datum]

| | [Zeithorizont 1] | [Zeithorizont 2] | [Zeithorizont 3] |
|---|---|---|---|
| Datum | … | … | … |
| Name | … | … | … |
| Ziel (Outcome) | … | … | … |
| Metrik | … | … | … |
| Features (Mittel zum Zweck) | … | … | … |

**Das machen wir nicht, und warum:** …
**Offene Punkte:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hat jede Spalte ein Ziel, das ein Outcome beschreibt?
- Hat jedes Ziel eine Metrik?
- Dient jedes Feature erkennbar einem Ziel?
- Bliebe die Roadmap stabil, wenn sich ein Feature ändert?
- Ist sichtbar, was ihr bewusst nicht macht?

## Im Flywheel

Modul DRIVE, Bereich D4 (im Buch »Guiding Principles«, inhaltlich Strategic Planning).

Verwandte Skills:
- `now-next-later`: Das Buch setzt Now, Next, Later auch ergänzend zur GO Product Roadmap für Stakeholder ein.
- `team-roadmap`: Im Kapitel SHIP verweist die Team-Roadmap für die ausführliche Methodenbeschreibung auf die GO Product Roadmap.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D4 Guiding Principles, Frameworks für Strategic Planning. Originalquelle: Roman Pichler.

Original: Roman Pichler: The GO Product Roadmap. https://www.romanpichler.com/blog/goal-oriented-agile-product-roadmap/
