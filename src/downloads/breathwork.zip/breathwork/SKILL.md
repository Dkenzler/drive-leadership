---
name: breathwork
description: Stress regulieren mit Breathwork und einem Stressmanagement-System aus drei Ebenen (Prävention, Regulation im Moment, Verarbeitung danach), aus dem Drive Leadership Playbook, angeregt durch Alan Watkins (Complete Coherence). Nutze diesen Skill, wenn jemand vor einem schwierigen Gespräch, einer Präsentation oder einer Entscheidung unter Druck ruhiger werden will, unter Anspannung den Faden verliert, eine tägliche Atempraxis aufbauen oder den eigenen Umgang mit Stress als Führungskraft systematisch prüfen will. Enthält die 4-7-8-Atmung für den akuten Moment und die kohärente Atmung als tägliche Praxis.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 2 Dich im Alltag steuern
  origin: Dominik Kenzler, angeregt durch Alan Watkins (Complete Coherence)
  deep_dive: false
  version: "1.0"
---

# Breathwork und Stressmanagement

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, angeregt durch Alan Watkins (Complete Coherence).

## Worum es geht

Leadership ist stressreich. Das ist die Natur der Rolle: komplexe Entscheidungen, hohe Erwartungen, ständige Unterbrechungen und Verantwortung für Menschen. Was zählt, ist nicht, ob du Stress hast, sondern wie du damit umgehst. Wer keinen aktiven Umgang mit Stress entwickelt, trägt ihn ins Team. Körperliche und mentale Belastbarkeit sind Führungskompetenzen.

Unter Stress aktiviert der Körper das sympathische Nervensystem, Cortisol und Adrenalin steigen, die Herzrate beschleunigt sich. Das Gehirn wechselt in einen Modus, der kurzfristig überleben soll, aber nicht für komplexes Denken und klare Kommunikation gemacht ist. Deshalb verlierst du in stressigen Momenten Zugang zu Teilen deines Wissens. Nicht weil das Wissen weg ist, sondern weil das Nervensystem nicht im richtigen Zustand ist, es abzurufen. Die Lösung: den Körper regulieren, bevor du in die schwierige Situation gehst.

Breathwork ist ein Werkzeug für den Moment. Nachhaltiges Stressmanagement braucht ein System mit drei Ebenen: Prävention, Regulation im Moment, Verarbeitung danach.

## Wann du sie einsetzt

- Vor schwierigen Gesprächen, bei denen du vorher weißt, dass sie wahrscheinlich emotional werden, etwa ein Entlassungsgespräch.
- Vor dem Sprechen vor größerem Publikum, etwa fünf Minuten vor dem Auftritt.
- Bevor du eine emotionale E-Mail beantwortest oder eine Entscheidung unter Zeitdruck triffst.
- Als tägliche Praxis, um über Wochen die eigene Belastbarkeit zu erhöhen.
- In stressigen Phasen, um das eigene Stressmanagement als Ganzes zu prüfen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Geht es um einen konkreten Moment, der bevorsteht, oder um den Umgang mit Stress insgesamt? Was genau steht an? Wie viel Zeit bleibt bis dahin? Frag nichts, was die Person schon gesagt hat.
- Steht ein Moment unmittelbar bevor, geh direkt zur 4-7-8-Atmung und leite sie knapp an. Keine lange Analyse.
- Geht es um das System, geh die drei Ebenen nacheinander durch. Eine Frage pro Ebene, dann auf die Antwort warten.
- Challenge Antworten gegen »Worauf du achten musst«. Benenne direkt, wenn eine Ebene fehlt.
- Du ersetzt keine medizinische oder therapeutische Beratung. Beschreibt die Person anhaltende Erschöpfung, körperliche Beschwerden oder Belastung, die über den Arbeitsalltag hinausgeht, empfiehl ärztliche oder therapeutische Unterstützung.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Teil A: Zwei Atemtechniken mit unterschiedlichem Zweck**

1. **4-7-8-Atmung (für den Moment).** Vier Sekunden einatmen, sieben Sekunden halten, acht Sekunden ausatmen. Drei bis vier Runden. Das bringt das Nervensystem schnell in einen ruhigeren Zustand. Entscheidend ist die lange Ausatmung mit der kurzen Pause davor, die den Ruhemodus des Körpers aktiviert. Deshalb wirkt sie in den wenigen Minuten, bevor du in eine angespannte Situation gehst.
   Frage: *»In welchen zwei, drei Situationen willst du die 4-7-8-Atmung gezielt einsetzen?«* Gut ist eine Antwort mit konkreten, wiederkehrenden Anlässen.

2. **Kohärente Atmung (als tägliche Praxis).** Gleichmäßig fünf Sekunden einatmen, fünf Sekunden ausatmen, über etwa zehn Minuten. Hier geht es nicht darum, einen Moment zu überstehen, sondern das System zu trainieren. Der Rhythmus erzeugt Herzratenvariabilität, ein Maß für die Flexibilität des Nervensystems, das mit Resilienz und kognitiver Leistungsfähigkeit zusammenhängt. Über Wochen praktiziert, hebt das die Belastbarkeit, nicht nur den Zustand im Augenblick.
   Frage: *»Wann am Tag hast du zehn Minuten, die du dafür fest einplanen kannst?«* Gut ist ein fester Zeitpunkt, kein »wenn Zeit ist«.

**Teil B: Stressmanagement als System**

3. **Prävention.** Ausreichend Schlaf, regelmäßige Bewegung, Zeiten ohne Bildschirm, soziale Verbindungen außerhalb der Arbeit. Das klingt banal, trotzdem sind es die ersten Dinge, die unter Druck wegfallen.
   Frage: *»Welche dieser vier Dinge sind gerade unter Druck weggefallen?«*

4. **Regulation im Moment.** Atemtechniken, kurze Pausen, bewusstes Verlangsamen, bevor du reagierst: bevor du eine emotionale E-Mail beantwortest, bevor du in ein schwieriges Gespräch gehst, bevor du eine Entscheidung unter Zeitdruck triffst.
   Frage: *»Woran merkst du, dass du gerade reagierst statt zu steuern, und was tust du dann?«*

5. **Verarbeitung danach.** Work Journal, Gespräche mit einem Mentor oder Coach, sportliche Aktivität, Schlaf. Stress, der nicht verarbeitet wird, akkumuliert.
   Frage: *»Wo verarbeitest du, was dich belastet hat?«* Gut ist eine Antwort mit einer festen Gewohnheit.

6. **Kontrollfrage.** Frage: *»Was würdest du einem Mitarbeitenden sagen, der so mit sich umgeht wie du gerade mit dir?«* Die Antwort ist meistens erhellend.

## Beispiel

Bei Native Instruments präsentierte Dominik Kenzler eine Produktstrategie, an der er wochenlang gearbeitet hatte. In der Fragerunde kamen unerwartete Fragen, der Puls ging hoch, die Stimme schwankte, die Souveränität war weg. Wenige Wochen später zeigte Alan Watkins, Gründer von Complete Coherence, in einem Leadership Training live am Pulsmessgerät, wie mit steigendem Stress die Qualität der Antworten massiv sinkt und wie bewusste Atmung den Puls reguliert. Heute nutzt Dominik die 4-7-8-Atmung gezielt vor emotionalen Gesprächen und vor Auftritten, die kohärente Atmung ist Teil seiner Meditationspraxis.

## Worauf du achten musst

- **Breathwork mit Stressmanagement verwechseln.** Atmung hilft im Moment. Ohne Prävention und Verarbeitung fehlt das System.
- **Techniken vermischen.** Die 4-7-8-Atmung ist für den akuten Moment, die kohärente Atmung ein Training über Wochen.
- **Erst im Raum regulieren.** Den Körper regulieren, bevor du in die schwierige Situation gehst.
- **Prävention als banal abtun.** Schlaf, Bewegung, Bildschirmpausen und soziale Kontakte fallen unter Druck als Erstes weg.
- **Stress nicht verarbeiten.** Unverarbeiteter Stress akkumuliert und landet im Team.

## Ergebnis

```markdown
# Mein Stressmanagement: [Name]
Stand: [Datum]

**4-7-8-Atmung (4 ein, 7 halten, 8 aus, 3 bis 4 Runden) setze ich ein vor:**
- …
- …

**Kohärente Atmung (5 ein, 5 aus, ca. 10 Min):** täglich um/bei …

| Ebene | Was ich konkret tue | Was gerade fehlt |
|---|---|---|
| Prävention (Schlaf, Bewegung, Bildschirmpausen, soziale Verbindungen) | | |
| Regulation im Moment (Atmung, Pausen, Verlangsamen) | | |
| Verarbeitung danach (Work Journal, Mentor oder Coach, Sport, Schlaf) | | |

**Was ich einem Mitarbeitenden in meiner Lage sagen würde:** …
**Nächster Schritt:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Weißt du, vor welchen konkreten Situationen du die 4-7-8-Atmung einsetzt?
- Hat die kohärente Atmung einen festen Platz in deinem Tag?
- Deckst du alle drei Ebenen ab: Prävention, Regulation im Moment, Verarbeitung danach?
- Welche Präventionsgewohnheit ist unter Druck zuletzt weggefallen, und holst du sie zurück?

## Im Flywheel

Modul YOURSELF, Teil 2 Dich im Alltag steuern.

Verwandte Skills:
- `executive-presence`: Laut Buch helfen die Atemtechniken direkt, in unangenehmen Momenten ruhig zu bleiben. Gravitas beginnt im Nervensystem.
- `work-journal`: im Buch als Weg genannt, Stress nach einer Belastung zu verarbeiten.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Einleitung und Methode Breathwork und Stressmanagement. Bezug: Leadership Training von Complete Coherence mit Alan Watkins.
