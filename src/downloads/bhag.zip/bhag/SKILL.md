---
name: bhag
description: Ein BHAG (Big Hairy Audacious Goal) nach Jim Collins formulieren, aus dem Drive Leadership Playbook von Dominik Kenzler. Ein großes, langfristiges Ziel auf zehn bis 25 Jahre. Nutze diesen Skill, wenn jemand ein ambitioniertes Langfristziel für eine Organisation finden will, nur noch Hindernisse und Blockaden sieht und für einen Moment die Machbarkeit ausblenden möchte, zwischen den vier BHAG-Typen (Target, Common Enemy, Role Model, Internal Transformation) wählen oder prüfen will, ob ein großes Ziel die Menschen wirklich begeistert.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D3 Set Strategic Goals
  origin: Jim Collins
  deep_dive: false
  version: "1.0"
---

# BHAG

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Jim Collins.

## Worum es geht

BHAG steht für Big Hairy Audacious Goal: ein großes, langfristiges Ziel auf zehn bis 25 Jahre. Das Konzept stammt von Jim Collins und Jerry I. Porras aus »Built to Last«.

Ein BHAG ist ambitioniert, klar und motivierend. Es klingt fast unmöglich, und genau das trifft den Punkt. Es soll die Organisation über Jahrzehnte antreiben und eine Richtung geben, die größer ist als jedes Quartalsziel. Es ignoriert für einen kurzen Moment die Frage der Machbarkeit in der Gegenwart und formuliert das Ziel, das in der fernen Zukunft erreichbar sein könnte.

Das Buch unterscheidet vier Typen (Abb. 3.11):

- **Target / Ziel:** Ein klares, messbares Ziel. Quantitativ oder qualitativ, mit eindeutiger Ziellinie.
- **Common Enemy / Gegner:** Den führenden Wettbewerber einholen oder schlagen. Der Vergleich gibt die Richtung vor.
- **Role Model / Vorbild:** Das X der eigenen Branche werden. Ein etabliertes Vorbild als Orientierung.
- **Internal Transformation:** Sich als Organisation grundlegend wandeln, um neue Fähigkeiten aufzubauen.

## Wann du sie einsetzt

- Wenn man nur Hindernisse und Blockaden erkennt und viele Ideen sich nicht umsetzen lassen. Dann hilft es, die Machbarkeit für einen Moment auszublenden.
- Wenn eine Organisation eine Richtung über Jahrzehnte braucht, die größer ist als jedes Quartalsziel.

Nicht jede Organisation braucht ein BHAG. Aber wenn es passt, kann es enorme Energie freisetzen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Organisation? Gibt es bereits eine Vision oder ein Zielbild? Was blockiert gerade? Frag nichts, was die Person schon gesagt hat.
- Prüfe früh, ob ein BHAG überhaupt passt. Nicht jede Organisation braucht eines. Sag es, wenn es nicht passt.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Im Entwurf gilt: Machbarkeit bewusst ausblenden. Bremse die Person nicht mit Realitätschecks, solange sie formuliert. Den Test auf Begeisterung machst du am Ende.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz.
- Erfinde keine Fakten über die Organisation, ihre Wettbewerber oder Vorbilder. Fehlt etwas, markiere es als offen.
- Soll das BHAG im Team entstehen, biete Moderationsfragen für die Schritte an.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Das Buch beschreibt keinen festen Ablauf. Die Schritte ordnen die Elemente aus Text und Abb. 3.11.

1. **Zeithorizont setzen.** Zehn bis 25 Jahre.
   Frage: *»Wo könnte eure Organisation in zehn bis 25 Jahren stehen, wenn ihr die Machbarkeit heute ausblendet?«* Gut ist die Antwort, wenn sie deutlich über jedes Jahres- oder Quartalsziel hinausgeht.

2. **Typ wählen.** Target, Common Enemy, Role Model oder Internal Transformation.
   Frage: *»Was treibt euch am stärksten an: eine klare Ziellinie, ein Gegner, ein Vorbild oder der eigene Wandel?«*

3. **Formulieren.** Ambitioniert, klar, motivierend, in einem Satz.
   Frage: *»Wie klingt das in einem Satz, den jede Person in der Organisation versteht?«* Gut ist der Satz, wenn er fast unmöglich klingt und trotzdem klar ist.

4. **Begeisterung testen.** Der Test aus dem Buch: Begeistert das Ziel die Menschen? Würden sie dafür morgens aufstehen?
   Frage: *»Würden eure Leute dafür morgens aufstehen?«* Wenn ja, ist es ein echtes BHAG. Wenn nicht, ist es nur ein großes Ziel. Dann zurück zu Schritt 2 oder 3.

## Beispiel

- Microsoft (in den 1980ern): »A computer on every desk and in every home.«
- Amazon: »Earth's most customer-centric company.«
- SpaceX: »Make humanity a multi-planetary species.«

## Worauf du achten musst

- **Nur ein großes Ziel.** Begeistert es die Menschen nicht, ist es kein BHAG, sondern nur ein großes Ziel.
- **Zu kurzer Horizont.** Ein BHAG treibt über Jahrzehnte, nicht über ein Geschäftsjahr.
- **Zu früh an der Machbarkeit messen.** Der Wert liegt darin, die Machbarkeit in der Gegenwart für einen Moment zu ignorieren.
- **Unklar.** Ambitioniert heißt nicht vage. Ein BHAG ist ambitioniert, klar und motivierend zugleich.
- **Aus Pflicht.** Nicht jede Organisation braucht ein BHAG.

## Ergebnis

```markdown
# BHAG: [Organisation]
Stand: [Datum] · Horizont: [Jahr, 10 bis 25 Jahre entfernt]

**Typ:** Target / Common Enemy / Role Model / Internal Transformation
**BHAG (ein Satz):** …

**Warum dieser Typ:** …
**Begeisterungs-Test:** Würden die Menschen dafür morgens aufstehen? ja / nein, weil …
**Offene Punkte:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Reicht der Horizont zehn bis 25 Jahre in die Zukunft?
- Ist das BHAG ambitioniert, klar und motivierend zugleich?
- Ist klar, welcher der vier Typen es ist?
- Würden die Menschen dafür morgens aufstehen?
- Braucht eure Organisation überhaupt ein BHAG?

## Im Flywheel

Modul DRIVE, Bereich D3 Set Strategic Goals.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D3 Set Strategic Goals, Frameworks für strategische Ziele, Abb. 3.11 BHAG: die vier Typen nach Jim Collins. Originalquelle: Jim Collins: Built to Last.
Original: Jim Collins, Jerry I. Porras: Built to Last, HarperBusiness, 1994. https://www.jimcollins.com/concepts/bhag.html
