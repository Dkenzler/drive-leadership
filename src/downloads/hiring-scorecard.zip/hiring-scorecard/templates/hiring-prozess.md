# Hiring-Prozess

Nach Abb. 4.8 und 4.10 im Drive Leadership Playbook. Kernprozess, wird je nach Unternehmen und Rolle ergänzt oder erweitert.

**Rolle / Level:**
**Hiring Manager:**
**Hiring-Team (bleibt für diese Rolle gleich):**

## Vorab: intern oder extern?

Entscheidungsbaum Internal vs. External Hire, nach Claire Hughes Johnson.

| # | Prüffrage | Ja | Nein |
|---|---|---|---|
| 1 | Verfüge ich über internes Talent in meiner Organisation? Können diese Personen den Anforderungen der Position im Laufe des nächsten Jahres gerecht werden? | Intern besetzen | weiter zu 2 |
| 2 | Gibt es jemanden in der gesamten Organisation, der die Fähigkeiten und das Potenzial hat, alles Nötige für den Job zu lernen und in den nächsten sechs Monaten mit den Anforderungen zu wachsen? | weiter zu 3 | |
| 3 | Kann ich oder können andere diese Person innerhalb von sechs Monaten für die Rolle entwickeln? | Intern besetzen | |
| 4 | Finden wir die benötigten Fähigkeiten in unserem Unternehmen? Wären sie für jemanden außerhalb schwer zu erlernen? | Übergangslösung: Aufgaben auf mehrere Personen verteilen, bis intern oder extern besetzt werden kann | |
| 5 | Kann ich derzeit die richtigen externen Talente für diese Rolle gewinnen? | Extern besetzen | |

Antworten und Begründung:

## Kernprozess

| # | Schritt | Wer | Inhalt | Termin |
|---|---|---|---|---|
| 1 | Screening (30 Min) | Talent Acquisition oder Hiring Manager (bei selbst gesourcten Talenten) | Motivation, Erfahrung, Compensation, Verfügbarkeit. Gehaltsrahmen hier klären. | |
| 2 | Fachliches + Cultural Fit (60 Min) | Hiring Manager | Fachliches Level prüfen. Haltung und Arbeitsweise. Verhaltensbasierte Fragen (Wie, nicht Was). | |
| 3 | Fachlicher Deep Dive (90 Min, bei Probearbeit 4 bis 8 Std) | | Portfolio-Review, Case Study oder Probearbeit mit Team. Core Capabilities in der Tiefe prüfen. | |
| 4 | Collaboration-Interview (60 Min) | Team und Peers | Zusammenarbeit, Kommunikation, Team-Fit. Ergänzt die Person das Team? | |
| 5 | Referenz-Checks | | Das stärkste Signal im gesamten Prozess. Fester Schritt, nicht optional. | |
| 6 | Closing Call | | Offene Fragen auf beiden Seiten. Wertschätzung zeigen. Zeige, dass du die Person willst. | |

**Entscheidung anhand von Scorecard.**
**Bar Raising:** Jede Einstellung sollte das Niveau des Teams anheben, nicht verwässern.

## Referenz-Checks: Fragen

- Wo siehst du diese Person in drei Jahren?
- Wann seid ihr zuletzt unterschiedlicher Meinung gewesen, und wie ist die Person damit umgegangen?
- Wie hat die Person anderen im Team geholfen? Erzähl mir von einer Situation, in der du die Person gecoacht hast.
- Wie würdest du die Person auf einer Skala von 1 bis 10 bewerten, wobei 7 nicht gilt?

Gesprächspartner (Mix, lange Zusammenarbeit):
