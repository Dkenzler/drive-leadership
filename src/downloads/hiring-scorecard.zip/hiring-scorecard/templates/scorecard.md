# Scorecard

Nach Abb. 4.9 im Drive Leadership Playbook.

**Ausgangspunkt:** Fähigkeiten-Rubrics und Verhaltenserwartungen aus Design Your Organisation.
**Warum eine Scorecard?** Alle im Hiring-Team bewerten anhand derselben Kriterien. Die Bewertung wird definiert, bevor die erste Person interviewt wird. Das macht Interviews vergleichbar und reduziert den Einfluss von Bias und Bauchgefühl.

**Rolle / Level:**
**Hiring Manager:**
**Interviewrunde:**

Der Hiring Manager definiert vor dem ersten Interview für jede Frage, wie eine schwache, gute und starke Antwort inhaltlich aussieht.

| Fragen | Schwach | Gut | Stark |
|---|---|---|---|
| Frage 1 (Core Capability): | Beschreibung einer inhaltlich schwachen Antwort | Beschreibung einer inhaltlich guten Antwort | Beschreibung einer inhaltlich starken Antwort |
| Frage 2 (Core Capability): | | | |
| Frage 3 (Verhalten): | | | |
| … | | | |

## Auswertung

| Bewerbende Person | Frage 1 | Frage 2 | Frage 3 | … |
|---|---|---|---|---|
| | schwach / gut / stark | | | |

- Stärken:
- Lücken:
- Liegen die Lücken in Bereichen, die sich entwickeln lassen, oder in Core Capabilities, die ab Tag eins gebraucht werden?
- Hebt diese Einstellung das Niveau des Teams an (Bar Raising)?
- Sicher? Wenn nicht: weitersuchen.
