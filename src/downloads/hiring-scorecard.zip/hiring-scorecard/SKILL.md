---
name: hiring-scorecard
description: Einen standardisierten Hiring-Prozess mit Scorecard aufsetzen, aus dem Drive Leadership Playbook (Dominik Kenzler, Entscheidungsbaum Internal vs. External Hire nach Claire Hughes Johnson). Nutze diesen Skill, wenn jemand eine Stelle besetzen will und prüfen muss, ob intern oder extern gesucht wird, einen Interviewprozess plant, das Hiring-Team briefen will, eine Scorecard mit schwachen, guten und starken Antworten erstellen, Referenz-Checks vorbereiten oder nach den Interviews eine Einstellungsentscheidung strukturieren will. Führt durch Internal Moves, Prozess in sechs Schritten (Screening, Fachliches und Cultural Fit, Fachlicher Deep Dive, Collaboration-Interview, Referenz-Checks, Closing Call) und die Entscheidung anhand der Scorecard.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L3 Hire & Let Go
  origin: Dominik Kenzler; Entscheidungsbaum nach Claire Hughes Johnson
  deep_dive: false
  version: "1.0"
---

# Hiring-Prozess und Scorecard

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, Entscheidungsbaum Internal vs. External Hire nach Claire Hughes Johnson.

## Worum es geht

Ob du die richtige Person findest, entscheidet sich nicht im Interview, sondern davor. Bevor du die ersten Interviews führst, brauchst du zwei Dinge: einen klaren Prozess und eine Scorecard. Der Prozess definiert, wer wann welche Themen prüft. Die Scorecard definiert, wonach du bewertest, bevor du die Bewerbenden kennenlernst. Sie baut direkt auf den Fähigkeiten-Rubrics und den Verhaltenserwartungen aus Design Your Organisation auf.

Je standardisierter der Prozess, desto vergleichbarer die Ergebnisse und desto geringer der Einfluss von Bias und Tagesform. Dahinter steht das Urgency-Dilemma: Geschwindigkeit ist entscheidend, Mis-Hires sind extrem teuer (drei bis sechs Monate bis zum Start, dann drei bis sechs Monate Probezeit, plus die Zeit aller Beteiligten). Die Regel des Buchs: Beschleunige alles rund um das Hiring, aber mache keine Kompromisse bei der Entscheidung. Im Zweifel: nicht einstellen.

Headcount ist kein Ziel. Definiere zuerst, was in diesem Kontext, zu diesem Zeitpunkt, außergewöhnlich für diese Rolle bedeutet. Erst dann öffne die Stelle.

## Wann du sie einsetzt

- Eine Stelle wird frei oder neu geschaffen.
- Du willst einen Hiring-Prozess standardisieren, weil Ergebnisse nicht vergleichbar sind.
- Du bereitest ein Hiring-Team, Interviews oder Referenz-Checks vor.
- Nach den Interviews, um die Entscheidung anhand der Scorecard zu treffen.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Rolle auf welchem Level? Gibt es Job Description, Fähigkeiten-Rubrics und Verhaltenserwartungen? Wo im Prozess steht die Person gerade (vor der Ausschreibung, mitten in Interviews, vor der Entscheidung)? Frag nichts, was die Person schon gesagt hat.
- Setz dort ein, wo die Person steht. Wer schon Bewerbende im Prozess hat, braucht vielleicht nur Scorecard und Entscheidung.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Wird der Headcount wichtiger als die Qualität? Wird eine unsichere Entscheidung schöngeredet?
- Bewerte keine konkreten Bewerbenden. Hilf, Kriterien, Fragen und Signale festzulegen und die Einschätzungen des Hiring-Teams zu strukturieren.
- Erfinde keine Fakten über die Organisation. Was fehlt, markierst du als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**1. Zuerst nach innen schauen (Internal Moves).** Bevor du extern suchst: Habe ich intern, was ich brauche? Der Entscheidungsbaum des Buchs:
- Gibt es jemanden im Team, der die Anforderungen des nächsten Levels bereits konstant erfüllt und bereit für eine Beförderung ist? Dann Beförderung oder Rollenerweiterung prüfen.
- Gibt es eine starke Person in der falschen Rolle, die in der offenen Stelle besser aufgehen würde? Dann Rollenwechsel prüfen, als bessere Passung geframt, nicht als Abstufung.
- Gibt es jemanden in einer anderen Abteilung oder einem anderen Team mit den gesuchten Fähigkeiten? Das erfordert Alignment mit den anderen Führungskräften und eine ehrliche Einschätzung, ob der Wechsel das Problem löst oder nur verschiebt.

Erst wenn keines dieser Szenarien passt, öffnest du die Stelle extern. Granularer ist der Entscheidungsbaum nach Claire Hughes Johnson (Abb. 4.10) mit fünf Prüffragen:
1. Verfüge ich über internes Talent? Können diese Personen den Anforderungen im Laufe des nächsten Jahres gerecht werden? Ja: intern besetzen. Nein: weiter zu 2.
2. Gibt es jemanden in der gesamten Organisation, der die Fähigkeiten und das Potenzial hat, alles Nötige zu lernen und in den nächsten sechs Monaten mit den Anforderungen zu wachsen? Ja: weiter zu 3.
3. Kann ich oder können andere diese Person innerhalb von sechs Monaten für die Rolle entwickeln? Ja: intern besetzen.
4. Finden wir die benötigten Fähigkeiten in unserem Unternehmen, und wären sie für jemanden von außen schwer zu erlernen? Ja: Übergangslösung, zum Beispiel die Aufgaben auf mehrere Personen verteilen, bis intern oder extern besetzt werden kann.
5. Kann ich derzeit die richtigen externen Talente für diese Rolle gewinnen? Ja: extern besetzen.

Ein Nein bei den internen Fragen führt weiter im Baum. Erst wenn alle internen Optionen erschöpft sind, geht er zur externen Suche über.

Grundsatz bei Beförderungen: Befördert wird nur, wer die Anforderungen des nächsten Levels bereits konstant erfüllt, nicht, wer die Erwartungen des aktuellen Levels gut erfüllt.
Frage: *»Hast du geprüft, ob jemand im Team, in der falschen Rolle oder in einem anderen Team die Stelle ausfüllen könnte?«*

**2. Definieren, was außergewöhnlich bedeutet.** Bevor die Stelle öffnet: Was heißt in diesem Kontext, zu diesem Zeitpunkt, außergewöhnlich für diese Rolle? Erst dann die Stelle öffnen und das Hiring starten.
Frage: *»Was bedeutet in eurem Kontext, zu diesem Zeitpunkt, außergewöhnlich für diese Rolle?«*

**3. Scorecard bauen.** Für jede Core Capability und jede Verhaltenserwartung festlegen, welches Level du erwartest und welche Signale du im Gespräch suchst. Der Hiring Manager definiert vor dem ersten Interview für jede Frage, wie eine inhaltlich schwache, gute und starke Antwort aussieht. Alle im Hiring-Team bewerten anhand derselben Kriterien. Fragen verhaltensbasiert stellen: nach konkreten Situationen und Entscheidungen, nicht nach abstrakten Selbsteinschätzungen.
Frage: *»Welche Frage prüft diese Fähigkeit, und wie klingt eine schwache, eine gute, eine starke Antwort?«* Gut ist die Antwort, wenn die drei Stufen inhaltlich unterscheidbar sind.

**4. Prozess festlegen.** Der Kern, der je nach Unternehmen und Rolle ergänzt wird (bei Leadership-Rollen etwa um ein spezielles Leadership-Interview):

| Schritt | Dauer | Wer | Fokus |
|---|---|---|---|
| 1 Screening | 30 Min | Talent Acquisition, bei selbst gesourcten Talenten der Hiring Manager | Motivation, Erfahrung, Gehaltsrahmen, Verfügbarkeit. Gehalt hier klären. |
| 2 Fachliches und Cultural Fit | 60 Min | Hiring Manager | Fachliches Level, Haltung und Arbeitsweise, verhaltensbasierte Fragen (Wie, nicht Was) |
| 3 Fachlicher Deep Dive | 90 Min, bei Probearbeit 4 bis 8 Std | je nach Rolle | Portfolio-Review, Case Study oder Probearbeit mit Team. Core Capabilities in der Tiefe. |
| 4 Collaboration-Interview | 60 Min | Team und Peers | Zusammenarbeit, Kommunikation. Ergänzt die Person das Team? |
| 5 Referenz-Checks | | | Das stärkste Signal im Prozess. Fester Schritt, nicht optional. |
| 6 Closing Call | | | Offene Fragen auf beiden Seiten, zeigen, dass du die Person willst |

Idealerweise bleiben die gleichen Interviewenden für eine Rolle im Prozess, sonst geht die Vergleichbarkeit verloren. Frage: *»Wer prüft in welcher Runde was?«*

**5. Hiring-Team briefen.** Hiring ist ein Teamsport. Jede Person im Hiring-Team braucht Klarheit, welche Rolle sie hat und welche Themen sie prüft. Gemeinsam die Job Description durchgehen, das Team Fragen stellen lassen. Beispiel aus dem Buch: Wer ein Challenger-Profil sucht und das Team nicht brieft, riskiert, dass eine Kandidatin rausgevotet wird, weil sie als fordernd empfunden wird, obwohl genau das gewünscht ist.

**6. Interviews: das Wie, nicht das Was.** Bewerbende zählen gern auf, was sie gemacht haben. Die S.T.A.R.-Methode (Situation, Task, Action, Result) ist ein guter Startpunkt, driftet aber oft ins Was ab. In die Action hineinzoomen: Was war das für ein Workshop? Wie lange? Welche Methoden? Welche Herausforderungen? Allein oder mit anderen vorbereitet? Remote oder vor Ort? Was waren die Learnings? Würdest du es heute noch mal so machen? Ist ein Thema zu kurz gekommen, lieber eine kurze zusätzliche Session einplanen als eine offene Frage bei der Entscheidung.

**7. Referenz-Checks.** Auf einen guten Mix der Gesprächspartner achten, die wirklich längere Zeit mit der Person gearbeitet haben. Fragen nach Claire Hughes Johnson, die über Stärken und Schwächen hinausgehen:
- Wo siehst du diese Person in drei Jahren?
- Wann seid ihr zuletzt unterschiedlicher Meinung gewesen, und wie ist die Person damit umgegangen?
- Wie hat die Person anderen im Team geholfen? Erzähl mir von einer Situation, in der du die Person gecoacht hast.
- Wie würdest du die Person auf einer Skala von 1 bis 10 bewerten, wobei 7 nicht gilt? Das zwingt zu einer klaren Einordnung: Eine 6 ist knapp über dem Durchschnitt, eine 8 oder höher ein starkes Signal.

**8. Closing Call und Angebot.** Das letzte Gespräch vor der Entscheidung. Die meisten Bewerbenden sind auch in anderen Prozessen, also Herausforderung und Unternehmen pitchen. Das Angebot darf nie eine Überraschung sein: Recruiter oder Hiring Manager bespricht es vorher mündlich.

**9. Entscheidung anhand der Scorecard.** Am Ende jedes Prozessschritts steht eine Entscheidung. Hier zählt die Scorecard, nicht das Bauchgefühl. Auf die konkreten Bewertungen schauen: Wo sind Stärken, wo Lücken? Liegen die Lücken in Bereichen, die sich entwickeln lassen, oder in Core Capabilities, die die Person ab Tag eins braucht? Bar Raising: Jede Einstellung soll das Niveau des Teams anheben, nicht verwässern.
Frage: *»Bist du dir nach den Interviews sicher?«* Wenn nicht, ist das meistens ein Signal, weiterzusuchen.

Zwei Situationen, in denen du vom Standard abweichen darfst: ein zusätzliches kurzes Interview, wenn ein Thema zu kurz kam, und Beschleunigung, wenn ein Talent andere Angebote hat. Beschleunigen heißt alle Beteiligten mobilisieren, nicht Schritte überspringen.

## Beispiel

Dominik Kenzler hatte früh in seiner Karriere unter Zeitdruck den Rat befolgt, sich eine Deadline zu setzen und die beste Person im Funnel einzustellen. Er stellte jemanden ein, der viele, aber nicht alle Boxen tickte, und musste die Person in der Probezeit entlassen. Sein Learning: alles rund um das Hiring beschleunigen, bei der Entscheidung keine Kompromisse.

Bei sevdesk suchte er extern einen Product Director und führte rund zehn Interviews mit erfahrenen Profilen, bis ihm klar wurde, dass er alle mit seinem Lead PM verglich. Er beförderte ihn intern. Sein Fehler: zu schnell nach außen geschaut, statt zuerst systematisch intern zu prüfen.

## Worauf du achten musst

- **Headcount als Ziel.** Wenn offene Stellen, Recruiting-KPIs und müde Interview-Panels zusammenkommen, werden Lücken schöngeredet. Niemand entscheidet bewusst, die Anforderungen zu senken, und genau das passiert.
- **Zu schnell nach außen schauen.** Internal Moves sind eines der wirksamsten und unterschätztesten Werkzeuge.
- **Beförderung als Belohnung.** Befördert wird, wer das nächste Level bereits konstant erfüllt, nicht wer das aktuelle gut erfüllt.
- **Das Was statt des Wie abfragen.** Ohne Nachfragen in die Action bleiben es Lehrbuchantworten.
- **Wechselndes Interview-Panel.** Dann geht die Vergleichbarkeit verloren.
- **Referenz-Checks als Formalität.** Sie sind das stärkste Signal, nicht ein optionaler Anhang.
- **Gehalt zu spät klären.** Nichts ist ärgerlicher, als am Ende festzustellen, dass Budget und Erwartung nicht zusammenpassen.
- **Recruiter-Druck nachgeben.** Recruiter stehen unter dem Druck eigener KPIs und neigen dazu, spät im Prozess für einen Hire zu pushen.
- **Bauchgefühl statt Scorecard.** Unsicherheit nach den Interviews ist ein Signal, weiterzusuchen.
- **Sich als Leader raushalten.** Auch bei Hires, die nicht deine direkten Reports betreffen, kannst du bei Verhalten und Mindset mitsteuern. Und du solltest immer selbst sourcen.

## Ergebnis

Ein Hiring-Plan mit Internal-Moves-Prüfung, Prozess und Scorecard. Vorlagen: `templates/hiring-prozess.md` und `templates/scorecard.md`.

```markdown
# Hiring-Plan: [Rolle, Level]
Hiring Manager: … · Stand: …

**Internal Moves geprüft:** Beförderung: … · Rollenwechsel: … · andere Teams: …
**Entscheidung:** intern / Übergangslösung / extern, weil …
**Was außergewöhnlich für diese Rolle bedeutet:** …

| Schritt | Wer | Prüft | Scorecard-Fragen |
|---|---|---|---|
| Screening | | | |
| Fachliches + Cultural Fit | | | |
| Fachlicher Deep Dive | | | |
| Collaboration-Interview | | | |
| Referenz-Checks | | | |
| Closing Call | | | |

## Scorecard
| Frage | Kriterium | Schwach | Gut | Stark |
|---|---|---|---|---|
| … | Core Capability | … | … | … |
| … | Verhalten | … | … | … |

**Offen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)
- Hast du Beförderung, Rollenwechsel und andere Teams geprüft, bevor du extern ausschreibst?
- Ist für jede Frage vor dem ersten Interview definiert, wie eine schwache, gute und starke Antwort aussieht?
- Bleibt das Interview-Panel über alle Bewerbenden gleich, und weiß jede Person, was sie prüft?
- Sind Referenz-Checks ein fester Schritt mit Gesprächspartnern, die lange mit der Person gearbeitet haben?
- Fällt die Entscheidung anhand der Scorecard, und würde diese Einstellung das Niveau des Teams anheben?

## Im Flywheel

Modul LEAD, Bereich L3 Hire & Let Go. Wie du hirest, zeigt, wie du führst: Jared Spool zufolge stößt ein schlecht gestalteter Prozess genau die qualifiziertesten Bewerbenden ab.

Verwandte Skills:
- `job-description`: Grundlage für Briefing und Scorecard.
- `faehigkeitenmatrix`: Die Fähigkeiten-Rubrics sind Ausgangspunkt der Scorecard.
- `werte-workshop`: Die Verhaltenserwartungen sind Ausgangspunkt der Scorecard.
- `watkins-assessment`: Die Kategorie »Move to Another Position« speist die Prüfung auf Rollenwechsel.
- `work-trial`: Probearbeit als Variante des Fachlichen Deep Dive.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L3 Hire & Let Go (Abb. 4.8 Hiring-Prozess, 4.9 Scorecard, 4.10 Entscheidungsbaum Internal vs. External Hire). Entscheidungsbaum und Referenzfragen nach Claire Hughes Johnson: Scaling People.
