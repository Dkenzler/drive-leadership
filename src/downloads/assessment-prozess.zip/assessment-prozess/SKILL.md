---
name: assessment-prozess
description: Ein ehrliches Bild vom eigenen Team gewinnen mit dem Assessment-Prozess aus dem Drive Leadership Playbook von Dominik Kenzler, mit Bezug auf Michael Watkins (The First 90 Days). Nutze diesen Skill, wenn jemand ein neues Team übernimmt, in einem Unternehmen startet, vor einer strategischen Neuausrichtung steht oder regelmäßig prüfen will, ob das Team zu den Anforderungen passt. Führt vom Zielbild (Set-up for Success, Ist gegen Soll) über Beobachten und Shadowing, 1:1-Gespräche, Peer-Interviews und Selbsteinschätzung bis zum Abgleich mit Fähigkeitenmatrix und Zielbild, pro Person, mit dem Ziel, das Team-Assessment in den ersten 30 Tagen abzuschließen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L2 Know Your Team
  origin: Dominik Kenzler, mit Bezug auf Michael Watkins
  deep_dive: false
  version: "1.0"
---

# Assessment-Prozess

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, mit Bezug auf Michael Watkins.

## Worum es geht

Bevor du Strategien umsetzt, Prozesse veränderst oder neue Ziele setzt, musst du verstehen, mit wem du arbeitest. Welche Fähigkeiten sind im Team vorhanden? Wo liegen Stärken, wo Lücken? Sind die Mitarbeitenden auf den richtigen Positionen? Und was braucht das Team, um die Strategie umzusetzen?

Im Kern geht es um Bar Raising, also Erwartungsmanagement: sichtbar und verständlich machen, wie gut und großartig aussehen, damit das Team die Erwartungen versteht und darauf hinarbeiten kann.

Die Leitfrage ist das Set-up for Success: Habe ich das richtige Team, um die gesetzten Ziele zu erreichen? Das Assessment führt in der Regel zu diesen Fragen:

1. Welche Fähigkeiten fehlen im jetzigen Set-up, und lassen sie sich innerhalb des Unternehmens finden?
2. Sind die Mitarbeitenden auf dem richtigen Level und in der richtigen Rolle? Das gilt in alle Richtungen: Talente, die unter ihrem Level arbeiten, Menschen, deren Stärken in der jetzigen Rolle nicht zur Geltung kommen, und solche, denen die nötigen Fähigkeiten für ihre Position fehlen.
3. Sind die Mitarbeitenden bereit für die anstehenden Veränderungen, oder versuchen sie, diese zu verlangsamen? Gibt es Mitarbeitende mit Fähigkeiten, die künftig nicht mehr gebraucht werden, und lassen sie sich in eine neue Richtung entwickeln?

Ein Assessment ist keine einmalige Aktion, sondern ein Prozess: in den ersten Wochen einer neuen Rolle intensiv, danach als regelmäßiger Rhythmus. Michael Watkins empfiehlt in »The First 90 Days«, das Team-Assessment in den ersten 30 Tagen abzuschließen. Nicht jedes Detail wird in 30 Tagen sichtbar, aber wer dem Prozess folgt, bekommt ein sehr aussagekräftiges Bild.

## Wann du sie einsetzt

- Wenn du ein neues Team übernimmst oder in einem Unternehmen startest.
- Wenn eine strategische Neuausrichtung ansteht.
- Als mitschwingender Rhythmus, um zu prüfen, ob dein Team noch zu den Anforderungen passt: mindestens einmal im Jahr umfassend.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Anlass (neues Team, neue Firma, Neuausrichtung, Regel-Assessment)? Wie groß ist das Team, und seit wann führt die Person es? Gibt es klare Ziele und eine Fähigkeitenmatrix? Frag nichts, was die Person schon gesagt hat.
- Bestehe auf dem Zielbild als erstem Schritt. Ohne Maßstab wird jedes Assessment beliebig.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen, wenn sie schon Material hat.
- In den Schritten 1 bis 3 hilfst du beim Vorbereiten (Beobachtungsfragen, Gesprächsleitfäden) und beim Sammeln. Urteile entstehen erst im Abgleich in Schritt 4.
- Challenge jede Antwort gegen »Worauf du achten musst«. Unterscheide streng zwischen Beobachtung, Hypothese und Urteil. Benenne Schwächen direkt und kurz.
- Erfinde keine Einschätzungen über Personen. Was die Person nicht belegen kann, markierst du als offene Frage.
- Behandle Aussagen über Mitarbeitende vertraulich und sachlich. Keine Zuschreibungen von Charakter oder Motiven, die die Person nicht beobachtet hat.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Schritt 0: Zielbild und Set-up for Success.** Vor der Bewertung braucht es einen Maßstab. Das Zielbild beantwortet: Wo steht das Team heute, und wo muss es hin, um die Strategie umzusetzen? Voraussetzung sind klare Ziele. Ziele gibt es immer, manchmal nur implizit. Es ist Aufgabe der Führungskraft, sie mit Manager oder CEO klar zu definieren, sonst arbeitet sie ohne Kompass. Drei Perspektiven schärfen das Zielbild:

- **Fähigkeiten:** Welche Fähigkeiten braucht das Team, um die Strategie umzusetzen? Nicht welche es hat, sondern welche es braucht.
- **Rollen und Levels:** Passen Rollen und Levels zu den Anforderungen? Genug Seniority an den richtigen Stellen? Rollen, die nicht mehr zur Strategie passen?
- **Haltung und Verhalten:** Passt die Arbeitsweise zu dem, was vor euch liegt? Veränderung erfordert Veränderungsbereitschaft.

Das Zielbild muss nicht perfekt sein, nur klar genug, um Lücken zu identifizieren und Prioritäten zu setzen. Aufschreiben als einfache Gegenüberstellung: Was brauchen wir? Was haben wir? Wo ist das Delta?

Frage: *»Welche Ziele gelten für dein Team, und welche Fähigkeiten, Rollen und Haltung braucht es, um sie zu erreichen?«* Gut ist die Antwort, wenn sie beschreibt, was gebraucht wird, nicht was da ist.

**Schritt 1: Beobachten und Shadowing.** In Meetings sitzen, zuschauen, wie das Team arbeitet. Wer treibt Diskussionen voran, wer hält sich zurück? Wie wird mit Problemen umgegangen? Wie ist die Qualität der Arbeitsergebnisse? Prozesse verstehen und mit den eigenen Erwartungen abgleichen. Nicht als stiller Bewerter, sondern als jemand, der das System verstehen will. Drei Fragen dabei: Was fällt mir auf? Was überrascht mich? Wo hätte ich eine andere Erwartung gehabt? Das liefert Hypothesen, noch keine Urteile.

Frage: *»Was ist dir aufgefallen, was hat dich überrascht, und wo hättest du etwas anderes erwartet?«*

**Schritt 2: 1:1-Gespräche mit Teammitgliedern.** Die wichtigste Datenquelle sind die Menschen selbst. Mit jeder Person ein ausführliches 1:1, kein Status-Update, sondern ein offenes Kennenlernen: Sicht auf die Organisation, die eigene Rolle, Stärken, Herausforderungen. Was läuft gut? Was nicht? Was würdest du ändern? Zwei Regeln: zuhören, nicht bewerten. Und Muster erkennen: Wenn drei von fünf Personen dasselbe Problem benennen, ist das ein Signal. In Schritt 4 fließen neben Beobachtungen und Peer-Perspektiven auch Selbsteinschätzungen ein. Wie sie erhoben werden, lässt das Buch offen. Frag die Person, woher sie ihre hat.

Frage: *»Welche Themen tauchen in mehreren Gesprächen auf?«* Biete an, einen Gesprächsleitfaden aus den Fragen des Buchs zu erstellen.

**Schritt 3: Peer-Interviews.** Gespräche mit den wichtigsten Stakeholdern und Peers, etwa Product Manager, Engineering Leads, andere Führungskräfte. Ähnliche Fragen: Wie erlebst du die Zusammenarbeit? Wo siehst du Stärken, wo Lücken? Die Außensicht ist oft aufschlussreicher als die Selbsteinschätzung und deckt blinde Flecken auf. Ein Team kann sich als gut funktionierend wahrnehmen, während die Umgebung eine ganz andere Erfahrung macht.

Frage: *»Wo weicht das Bild der Peers von der Selbsteinschätzung des Teams ab?«*

**Schritt 4: Abgleich mit dem Framework.** Beobachtungen, Selbsteinschätzungen und Peer-Perspektiven über das Zielbild und die Fähigkeitenmatrix legen. Für jede Person: Wo sind ihre relevanten Fähigkeiten? Stimmt das Level? Passt die Haltung? Kein mechanisches Ausfüllen einer Tabelle, sondern eine Einschätzung auf Basis mehrerer Datenpunkte. Fähigkeitenmatrix und Rubrics strukturieren sie und machen sie nachvollziehbar.

Frage pro Person: *»Welche relevanten Fähigkeiten siehst du, stimmt das Level, passt die Haltung, und auf welche Datenpunkte stützt du das?«* Gut ist die Antwort, wenn jede Einschätzung auf mehr als einer Quelle beruht.

**Rhythmus.** In den ersten 90 Tagen intensiv. Danach mindestens einmal im Jahr umfassend, ergänzt durch die Signale aus 1:1s, Projekt-Reviews und Performance-Zyklen.

## Beispiel

Bei CLARK war das Zielbild der erste Schritt. Aus Produktvision und strategischen Zielen ergab sich, was die Design-Organisation brauchte: UX Research, um Entscheidungen datenbasiert zu treffen. Content Design, weil das Versicherungsthema komplex ist und klare, einfache Sprache für eine intuitive Product Experience essenziell ist. Und Senior Product Designer mit starken visuellen Fähigkeiten und ausgeprägtem Product Thinking, die im Product Trio auf Augenhöhe mitarbeiten. Daran ließ sich ablesen, was vorhanden war und was fehlte.

Bei sevdesk nahm Dominik Kenzler in den ersten zwei bis drei Wochen an so vielen Meetings wie möglich teil, ohne selbst viel zu sagen, und stellte sich dabei die drei Beobachtungsfragen aus Schritt 1.

## Worauf du achten musst

- **Ohne Zielbild bewerten.** Dann stellst du fest, was da ist, weißt aber nicht, was fehlt.
- **Zu lange warten.** Sechs Monate Beobachtung klingen sicher, gehen aber oft nach hinten los: Die Suche nach den richtigen Personen dauert drei bis sechs Monate, das Onboarding weitere drei. Das richtige Set-up steht dann frühestens nach 12 bis 15 Monaten, und die Organisation verliert Vertrauen, weil zu wenig Impact entsteht. Watkins beschreibt den Break-even Point: den Punkt, an dem man mehr Wert beigetragen als verbraucht hat. Urgency ist essenziell.
- **Früh urteilen statt Hypothesen bilden.** Beobachtung liefert Hypothesen, keine Urteile.
- **In 1:1s bewerten statt zuhören.** Du willst verstehen, nicht urteilen.
- **Nur auf die Selbsteinschätzung hören.** Peer-Interviews decken blinde Flecken auf.
- **Den Abgleich mechanisch ausfüllen.** Jede Einschätzung braucht mehrere Datenpunkte.
- **Das Team betreuen, aber nicht entwickeln.** Bestehende Teams als gegeben nehmen und erst bei einer Vakanz über Besetzung nachdenken, ist der Fehler, den das Buch aus der eigenen ersten Managementrolle beschreibt.

## Ergebnis

```markdown
# Team-Assessment: [Team]
Stand: [Datum] · Phase: erste 30 Tage / Regel-Assessment

## Zielbild
| Perspektive | Was brauchen wir? | Was haben wir? | Delta |
|---|---|---|---|
| Fähigkeiten | … | … | … |
| Rollen und Levels | … | … | … |
| Haltung und Verhalten | … | … | … |

## Muster aus Beobachtung, 1:1s und Peer-Interviews
- …

## Einschätzung pro Person
| Person | Relevante Fähigkeiten | Level passend? | Haltung | Potenzial | Datenpunkte (Beobachtung / 1:1 / Peers / Selbsteinschätzung) | Offene Fragen |
|---|---|---|---|---|---|---|
| … | … | … | … | … | … | … |

## Antworten auf die Leitfragen
1. Fehlende Fähigkeiten, intern zu finden? …
2. Richtiges Level, richtige Rolle? …
3. Bereitschaft für Veränderung? …

Nächster Schritt: Einordnung mit Watkins-Entscheidungsbaum / Skill-Will-Matrix / 9-Box Grid
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hast du ein aufgeschriebenes Zielbild mit Delta zwischen Ist und Soll, bevor du Personen einschätzt?
- Liegt dein Assessment im Zeitrahmen von etwa 30 Tagen, oder schiebst du Entscheidungen auf?
- Hast du mit jeder Person im Team ein ausführliches 1:1 geführt und die Peers befragt?
- Beruht jede Einschätzung auf mehreren Datenpunkten, getrennt nach Beobachtung, Selbsteinschätzung und Peer-Sicht?
- Ist festgelegt, wann das nächste umfassende Assessment stattfindet?

## Im Flywheel

Modul LEAD, Bereich L2 Know Your Team.

Verwandte Skills:
- `faehigkeitenmatrix`: Fähigkeitenmatrix und Rubrics strukturieren den Abgleich in Schritt 4.
- `watkins-assessment`: Nach dem Assessment-Prozess ordnest du jede Person im Entscheidungsbaum ein.
- `skill-will-matrix`: schneller Überblick beim Übernehmen eines Teams.
- `9-box-grid`: organisationsweite Kalibrierung von Performance und Potenzial.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L2 Know Your Team: Einleitung, Zielbild / Set-up for Success und Assessment-Prozess (Abb. 4.3). Originalquelle für 30-Tage-Empfehlung und Break-even Point: Michael Watkins: The First 90 Days.
