---
name: impact-effort-matrix
description: "Impact/Effort-Matrix (auch Effort/Value-Matrix) aus dem Drive Leadership Playbook von Dominik Kenzler: das einfachste Priorisierungswerkzeug. Initiativen werden nach erwartetem Impact und benötigtem Aufwand in vier Quadranten sortiert (Quick Wins, Big Bets, Incremental, Money Pit). Nutze diesen Skill, wenn jemand viele Ideen schnell sortieren, einen Team-Workshop zur ersten Priorisierung vorbereiten, einen Backlog ausdünnen, Quick Wins finden oder Initiativen identifizieren will, die gestrichen werden sollten."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S2 Plan & Prioritize
  origin: Dominik Kenzler (das Buch nennt keine Urheber:in)
  deep_dive: false
  version: "1.0"
---

# Impact/Effort-Matrix

Aus dem Drive Leadership Playbook von Dominik Kenzler. Das Buch nennt für die Matrix keine Urheber:in.

## Worum es geht

Die Impact/Effort-Matrix, auch bekannt als Effort/Value-Matrix, ist das einfachste Priorisierungswerkzeug im Kapitel SHIP. Sie teilt Initiativen in vier Quadranten ein, basierend auf zwei Achsen: dem erwarteten Impact und dem benötigten Aufwand.

| | Geringer Aufwand | Hoher Aufwand |
|---|---|---|
| **Hoher Impact** | **Quadrant 1: Quick Wins.** Zuerst angehen. | **Quadrant 2: Big Bets.** Strategische Projekte. Planen und angehen, aber mit realistischer Ressourcenplanung. |
| **Geringer Impact** | **Quadrant 3: Incremental.** Fill-ins. Nur angehen, wenn Zeit übrig ist. | **Quadrant 4: Money Pit.** Vermeiden. Wenn möglich aus dem Backlog streichen. |

Die Stärke liegt in der Einfachheit. Sie ist weniger präzise als ICE/RICE, aber schneller. Sie ist kein Scoring-System, sondern ein Gesprächswerkzeug.

## Wann du sie einsetzt

- In schnellen Team-Workshops, in denen viele Ideen auf den Tisch kommen und eine erste Sortierung gebraucht wird. Mit Post-its auf einer 2×2-Matrix kann ein Team in 30 Minuten eine Diskussion strukturieren, die sonst stundenlang dauern würde.
- Wenn Geschwindigkeit wichtiger ist als Präzision. Braucht es eine genauere Bewertung, ist ICE/RICE die Alternative.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Initiativen oder Ideen sollen sortiert werden? Auf welches Ziel bezieht sich der Impact? Sortiert die Person allein oder im Team-Workshop? Frag nichts, was die Person schon gesagt hat.
- Für einen Workshop: Biete an, Ablauf und Moderation für 30 Minuten vorzubereiten (Ideen sammeln, auf Post-its, einsortieren, Quadranten besprechen). Vorlage: `templates/impact-effort-matrix.md`.
- Geh Initiative für Initiative vor und frag nach Impact und Aufwand, jeweils hoch oder gering, mit kurzer Begründung.
- Challenge gegen »Worauf du achten musst«. Vor allem: Landen fast alle Initiativen in Quadrant 2? Dann nach dem relativen Vergleich fragen und neu sortieren lassen.
- Erfinde keine Einschätzungen zu Impact oder Aufwand. Wo die Person unsicher ist, markiere die Einordnung als vorläufig.
- Schließe mit der gefüllten Matrix im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Bezugsziel klären.** Impact heißt: Wirkung auf ein bestimmtes Ziel.
   Frage: *»Auf welches Ziel bezieht sich der Impact?«*

2. **Initiativen sammeln.** Frage: *»Welche Ideen oder Initiativen liegen auf dem Tisch?«*

3. **Einordnen.** Jede Initiative auf die zwei Achsen: erwarteter Impact (hoch/gering) und benötigter Aufwand (hoch/gering).
   Frage je Initiative: *»Wie hoch ist der erwartete Impact auf das Ziel, und wie hoch der Aufwand, im Vergleich zu den anderen Initiativen?«* Gut ist die Antwort, wenn sie relativ zu den anderen Initiativen begründet ist.

4. **Differenzierung prüfen.** Bevor Schlüsse gezogen werden: Sind die Quadranten ausgewogen besetzt, oder ballt sich alles in Quadrant 2?
   Frage: *»Welche dieser Initiativen hat im Vergleich den geringsten Impact?«*

5. **Konsequenzen je Quadrant ziehen.** Quick Wins zuerst. Big Bets planen und mit realistischer Ressourcenplanung angehen. Incremental nur bei übriger Zeit. Money Pit vermeiden und wenn möglich aus dem Backlog streichen.
   Frage: *»Was davon streicht ihr jetzt aus dem Backlog?«*

## Worauf du achten musst

- **Alles landet in Quadrant 2.** Der häufigste Fehler: Niemand will sagen, dass etwas geringen Impact hat. Ohne echte Differenzierung verliert das Tool seinen Wert.
- **Als Scoring-System missverstehen.** Die Matrix ist ein Gesprächswerkzeug für eine erste Sortierung, keine präzise Bewertung. Wer mehr Präzision braucht, nimmt ICE/RICE.

## Ergebnis

Vorlage: `templates/impact-effort-matrix.md`.

```markdown
# Impact/Effort-Matrix: [Team / Vorhaben]
Stand: [Datum] · Bezugsziel: …

| | Geringer Aufwand | Hoher Aufwand |
|---|---|---|
| **Hoher Impact** | Quick Wins: … | Big Bets: … |
| **Geringer Impact** | Incremental: … | Money Pit: … |

**Als Nächstes (Quick Wins):** …
**Einplanen mit Ressourcenplanung (Big Bets):** …
**Nur bei übriger Zeit (Incremental):** …
**Aus dem Backlog gestrichen (Money Pit):** …
**Vorläufige Einordnungen, die geprüft werden:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Sind alle vier Quadranten besetzt, oder ballt sich fast alles in Quadrant 2?
- Habt ihr mindestens eine Initiative bewusst als geringen Impact eingeordnet?
- Ist entschieden, was aus dem Backlog gestrichen wird?
- Ist klar, ob die Sortierung reicht oder eine genauere Bewertung mit ICE/RICE folgen soll?

## Im Flywheel

Modul SHIP, Bereich S2 Plan & Prioritize.

Verwandte Skills:
- `ice-rice-scoring`: präziser, aber langsamer. Beide haben je nach Kontext ihre Berechtigung.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S2 Plan & Prioritize, Abschnitt Impact/Effort-Matrix (Abb. 5.7).
