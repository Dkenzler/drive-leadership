# Impact/Effort-Matrix

Nach Abb. 5.7 im Drive Leadership Playbook.

**Team / Vorhaben:**
**Bezugsziel für Impact:**
**Datum:**
**Format:** Post-its auf einer 2×2-Matrix, ca. 30 Minuten

Achsen: IMPACT (Low bis High) · EFFORT (Low bis High)

| | EFFORT Low | EFFORT High |
|---|---|---|
| **IMPACT High** | **QUICK WINS** (Quadrant 1: zuerst) | **BIG BETS** (Quadrant 2: strategische Projekte, mit realistischer Ressourcenplanung) |
| | | |
| **IMPACT Low** | **INCREMENTAL** (Quadrant 3: Fill-ins, nur wenn Zeit übrig ist) | **MONEY PIT** (Quadrant 4: vermeiden, wenn möglich aus dem Backlog streichen) |
| | | |

## Entscheidungen

- Zuerst:
- Einplanen:
- Nur bei übriger Zeit:
- Gestrichen:
