---
name: persoenlichkeitstests
description: Persönlichkeitstests für Selbstkenntnis nutzen, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn eine Führungskraft einen passenden Test auswählen (Insights Discovery, Hogan, Myers-Briggs MBTI, DISC), ein Testergebnis reflektieren, eigene Muster und blinde Flecken verstehen, Derailers unter Stress erkennen, ein Ergebnis mit Mentor, Coach oder Team besprechen oder Tests im Team als gemeinsames Vokabular einsetzen will. Der Skill führt keinen Test durch und bestimmt keinen Typ. Er hilft bei Auswahl, Vorbereitung und Auswertung, mit dem Ergebnis als Gesprächsangebot, nicht als Urteil.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 1 Dich selbst kennen
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Persönlichkeitstests und Selbstkenntnis

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Selbstkenntnis entsteht auf zwei Wegen: durch eigene Reflexion und durch externe Perspektiven. Persönlichkeitstests sind ein Werkzeug für den zweiten Weg. Sie zeigen strukturiert, wie du auf andere wirkst, wie du Entscheidungen triffst, wie du unter Stress reagierst und was dich antreibt.

Wie genau ein einzelner Test ist, spielt eine kleinere Rolle als sein eigentlicher Wert: Er zwingt dich zur Reflexion. Selbst wenn du mit dem Ergebnis nicht einverstanden bist, kannst du formulieren, warum und wo du einen Unterschied siehst. Kein Test ist universell, aber fast jeder ist nützlich. Das Ziel ist immer dasselbe: dich und deine Muster gut zu kennen oder kennenzulernen.

## Wann du sie einsetzt

- Wenn du deine Muster verstehen willst: Wann reagierst du emotional? Was triggert dich? Wann fällst du in alte Verhaltensweisen zurück?
- Wenn du wissen willst, welche Verhaltensweisen unter Druck auftreten und dir schaden können.
- Im Team, um ein gemeinsames Vokabular für Unterschiede in Kommunikation und Arbeitsweise zu schaffen.

## So arbeitest du mit der Person

- Du führst keinen Test durch, stellst keine Testfragen nach und bestimmst keinen Typ, weder für die Person noch für Menschen in ihrem Team. Du hilfst bei Auswahl, Vorbereitung und Reflexion eines Ergebnisses, das aus einem echten Test stammt.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Hast du schon einen Test gemacht, und welchen? Was willst du über dich herausfinden? Willst du den Test allein nutzen oder im Team? Frag nichts, was die Person schon gesagt hat.
- Unterscheide zwei Einstiege: einen Test auswählen (Ablauf Schritt 1) oder ein vorliegendes Ergebnis reflektieren (Schritte 2 bis 5).
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge gegen »Worauf du achten musst«. Vor allem: Behandelt die Person das Ergebnis als Urteil? Benenne das direkt und kurz. Kein Lob als Füllmaterial.
- Erfinde keine Testinhalte, Skalen oder Ergebnisse. Arbeite nur mit dem, was die Person aus ihrem Bericht mitbringt. Fehlt etwas, markiere es als offen.
- Nutzt die Person Tests im Team, biete an, eine Teamsession vorzubereiten. Die Teilnahme ist freiwillig, und jede Person entscheidet selbst, was sie teilt.
- Schließe mit der Reflexion im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Test auswählen.** Das Buch nennt vier bekannte Formate:
   - **Insights Discovery** teilt Menschen anhand von vier Farbenergie-Präferenzen ein: feuriges Rot (entschlossen, ergebnisorientiert), sonniges Gelb (enthusiastisch, sozial), erdiges Grün (ruhig, unterstützend) und kühles Blau (analytisch, strukturiert). Jeder Mensch hat alle vier Farben in unterschiedlicher Ausprägung. Das Insights Discovery Wheel zeigt acht Typen: Reformer, Director, Motivator, Inspirer, Helper, Supporter, Coordinator und Observer (Abb. 6.2). Claire Hughes Johnson bevorzugt Insights Discovery, weil es differenzierter als Myers-Briggs und trotzdem leicht zugänglich ist.
   - **Hogan** ist ausführlicher und besonders nützlich für Senior Leadership. Der Test misst nicht nur Stärken, sondern auch Derailers: Verhaltensweisen, die unter Druck oder Stress auftreten und Karrieren gefährden können. Das ist oft das Aufschlussreichste. Abb. 6.3 zeigt beispielhafte Skalen. Derailer-Skalen mit Risikostufen von No Risk bis High Risk, etwa Sprunghaft, Skeptisch, Vorsichtig, Distanziert, Passiver Widerstand, Anmaßend, Draufgängerisch, Fantasievoll, Bunt schillernd, Pedantisch, Dienstbeflissen. Dazu Skalen von Low bis High, etwa Ausgeglichenheit, Ehrgeiz, Soziale Umgänglichkeit, Einfühlungsvermögen, Besonnenheit, Wissbegierig, Lernansatz.
   - **Myers-Briggs (MBTI)** ordnet in 16 Typen entlang von vier Dimensionen: introvertiert (I) oder extrovertiert (E), wahrnehmend (S) oder intuitiv (N), denkend (T) oder fühlend (F), urteilend (J) oder empfindend (P) (Abb. 6.4).
   - **DISC** ist eine weitere bekannte Alternative.

   MBTI und DISC haben ihre Kritiker in der Forschung. Ihr praktischer Wert liegt nicht in wissenschaftlicher Präzision, sondern im Gespräch, das sie auslösen.
   Frage: *»Was willst du vor allem verstehen: deine Wirkung und Kommunikation, dein Verhalten unter Druck, oder ein gemeinsames Vokabular im Team?«*
   Gut ist die Wahl, wenn sie zur Frage passt: Derailers unter Druck sprechen für Hogan, ein zugängliches Teamvokabular für Insights Discovery.

2. **Ergebnis nicht allein lesen.** Teile die Ergebnisse mit jemandem, dem du vertraust: Mentor, Coach, Führungskraft oder Team. Die interessantesten Erkenntnisse entstehen oft im Gespräch, nicht beim Lesen des Berichts.
   Frage: *»Mit wem besprichst du dein Ergebnis, und wann?«*

3. **Abgleichen: Was stimmt, was nicht?** Nimm das Ergebnis als Gesprächsangebot, nicht als Urteil. Bist du mit etwas nicht einverstanden, ist das genauso wertvoll: Formuliere, warum. Wo siehst du dich anders? Diese Auseinandersetzung ist oft aufschlussreicher als das Ergebnis selbst.
   Frage: *»Welche Aussage im Bericht trifft dich am meisten, und welcher widersprichst du? Warum?«*

4. **Muster und blinde Flecken benennen.** Was sagt das Ergebnis über dein Verhalten in Unsicherheit oder unter Stress?
   Frage: *»In welcher konkreten Situation hast du das beschriebene Muster zuletzt bei dir erlebt?«*
   Gut ist die Antwort, wenn sie das Testergebnis mit einer echten Situation verbindet.

5. **Im Team nutzen (optional).** Wenn alle wissen, dass jemand in Stresssituationen zur kühlen Analyse neigt und ein anderer zum schnellen Handeln, entstehen weniger Missverständnisse und mehr gegenseitiges Verständnis. Ein gemeinsames Framework macht Unterschiede benennbar, ohne dass es persönlich wird.
   Frage: *»Welches Missverständnis im Team könnte ein gemeinsames Vokabular auflösen?«*

## Beispiel

Dominik Kenzler hat über die Jahre verschiedene Tests gemacht. Insights Discovery empfand er als erschreckend genau, er fand sich darin sehr gut wieder. Bei anderen Tests war das weniger der Fall, und Kolleginnen und Kollegen in seinem Team empfanden wiederum andere Tests als treffender. Das ist normal.

Ein Muster, das er erst spät erkannt hat: In Unsicherheit neigte er dazu, zu wenig zu kommunizieren. Stand ein Projekt auf der Kippe, stürzte er sich in die Arbeit, statt Hilfe zu suchen oder Stakeholder zu informieren. Erst als er das Muster erkannte, konnte er es ändern. Geholfen haben ihm drei Dinge: Feedback, bewusste Selbstbeobachtung und Persönlichkeitstests.

## Worauf du achten musst

- **Ergebnis als Urteil nehmen.** Nimm die Ergebnisse als Gesprächsangebot, nicht als Urteil.
- **Den Test allein machen.** Die interessantesten Erkenntnisse entstehen im Gespräch mit Menschen, denen du vertraust.
- **Widerspruch übergehen.** Wenn du mit einem Ergebnis nicht einverstanden bist, ist das genauso wertvoll. Formuliere, warum. Diese Auseinandersetzung ist oft aufschlussreicher als das Ergebnis selbst.
- **Präzision überschätzen.** Kein Test ist universell. Der Wert liegt in der Reflexion, nicht in wissenschaftlicher Genauigkeit.
- **Unterschiede persönlich machen.** Im Team soll das gemeinsame Vokabular Unterschiede in Kommunikation und Arbeitsweise benennbar machen, ohne dass es persönlich wird. Bei Insights Discovery hat jeder Mensch alle vier Farben in unterschiedlicher Ausprägung.

## Ergebnis

```markdown
# Selbstkenntnis: Testreflexion
Stand: [Datum] · Test: [Name] · Besprochen mit: [Person]

**Was ich verstehen wollte:** …

**Was stimmt (mit konkreter Situation):**
- …

**Was nicht stimmt, und warum:**
- …

**Mein Muster unter Druck / in Unsicherheit:** …
**Blinder Fleck, an dem ich arbeite:** …
**Im Team teilen?** ja / nein · was: …
**Offen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hast du das Ergebnis mit jemandem besprochen, dem du vertraust?
- Hast du formuliert, wo du nicht einverstanden bist, und warum?
- Hast du das Ergebnis mit einer konkreten Situation aus deinem Arbeitsalltag verbunden?
- Nutzt du das Ergebnis als Gesprächsangebot, nicht als Etikett für dich oder andere?

## Im Flywheel

Modul YOURSELF, Teil 1 Dich selbst kennen. YOURSELF ist der äußere Ring des Leadership Flywheel, der Drive, Lead und Ship trägt.

Verwandte Skills:
- `feedback-einholen`: Laut Buch helfen Feedback, bewusste Selbstbeobachtung und Persönlichkeitstests zusammen, die eigenen Muster zu erkennen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Einleitung »Kenne deine Muster« und Teil 1 Dich selbst kennen, Persönlichkeitstests und Selbstkenntnis. Zitierte Stimme: Claire Hughes Johnson.

Abbildungen im Buch:
- Abb. 6.2: Die acht Typen im Insights Discovery Wheel. Adaptiert von The Insights Group Limited. © The Insights Group Limited. Alle Rechte vorbehalten.
- Abb. 6.3: Beispielhafte Skalen des Hogan-Tests. Adaptiert von Hogan Assessment Systems. Alle Rechte vorbehalten.
- Abb. 6.4: Die 16 Typen des Myers-Briggs Type Indicator. MBTI ist eine eingetragene Marke der Myers & Briggs Foundation.
