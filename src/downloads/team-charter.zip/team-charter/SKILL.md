---
name: team-charter
description: Mit dem Team eine Team Charter erarbeiten, nach dem Workshop-Prozess von Peter Merholz, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn ein Team neu zusammengestellt wird, eine neue Führungskraft ein Team übernimmt, ein gewachsenes Team merkt, dass das gemeinsame Verständnis nicht mehr stimmt, oder wenn jemand Purpose, Capabilities, Werte, interne und externe Normen und Measures of Success eines Teams gemeinsam festhalten will. Führt durch vier moderierte Sessions (remote oder als Tagesworkshop), die Synthese zum fertigen Dokument und die nächsten Schritte, damit die Charter im Alltag wirkt.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L4 Set the Stage
  origin: Peter Merholz
  deep_dive: true
  version: "1.0"
---

# Team Charter

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Peter Merholz.

## Worum es geht

Eine Team Charter ist ein gemeinsam erarbeitetes, knappes Dokument (typischerweise rund sechs Folien), das beschreibt, wer das Team ist, wofür es steht und wie es arbeitet. Kein Organigramm, keine Rollenbeschreibung, sondern eine ehrliche Antwort auf die Fragen: Warum existiert dieses Team? Was sind unsere Werte? Wie arbeiten wir zusammen, und wie arbeiten wir mit anderen? Intern klärt sie, was Teammitglieder voneinander erwarten dürfen, extern, was der Rest der Organisation vom Team erwarten kann.

Ohne Charter existieren die Antworten trotzdem, nur nirgends festgehalten. Jede Person hat ein eigenes Bild, mit der Zeit entstehen Lücken und Reibungsverluste. Die Charter macht Annahmen sichtbar, nicht durch Regeln, sondern durch Klarheit.

Sie besteht aus sechs Bausteinen: Purpose, Capabilities, Werte, interne Normen, externe Normen, Measures of Success. Der Prozess leistet drei Dinge:
1. **Identität statt Zuschreibung.** Definieren andere von außen, wofür das Team da ist, bleibt es bei Produktion auf Zuruf. Mit der Charter übernimmt das Team die Deutungshoheit über die eigene Rolle.
2. **Verbindung.** Gerade in verteilten Teams schaffen die gemeinsamen Sessions, besonders die persönlichen Übungen, Vertrauen.
3. **Grundlage für Priorisierung und Hiring.** Besonders die Measures of Success helfen später zu entscheiden, woran gearbeitet, wer eingestellt und welche Initiativen verfolgt werden.

Eine Charter, die nur die Führungskraft schreibt, ist keine Charter, sondern ein Manifest. Sie entsteht gemeinsam mit dem Team.

## Wann du sie einsetzt

- Ein Team wird neu zusammengestellt, oder eine neue Führungskraft übernimmt.
- Ein Team ist gewachsen und merkt, dass das gemeinsame Verständnis nicht mehr mit der Realität übereinstimmt.
- In sehr großen Organisationen (150+) für einzelne Teilteams, die ihre eigene Charter formulieren.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wie groß ist das Team, und arbeitet es verteilt oder am selben Ort? Warum jetzt (neues Team, neue Führung, gewachsen)? Moderiert die Person selbst, oder gibt es eine Moderation? Frag nichts, was die Person schon gesagt hat.
- Die Charter entsteht im Team, nicht im Gespräch mit dir. Deine Aufgabe ist die Vorbereitung: Agenda, Teilnehmende, Board-Struktur, Thought Starters, Moderationsfragen. Vorlage: `templates/workshop-agenda.md`.
- Nach den Sessions hilfst du bei der Synthese: Die Person gibt dir das Rohmaterial, du verdichtest es zu Entwürfen für jeden Baustein. Entscheiden und formulieren tut das Team, du lieferst Varianten.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Nimmt die gesamte Führungsebene teil? Sind die Werte austauschbar?
- Erfinde keine Inhalte für Purpose, Werte oder Normen des Teams. Was nicht aus dem Material kommt, markierst du als offen.
- Schließe mit der Charter im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Set-up.** Die Sessions funktionieren für Gruppen bis etwa 20 Personen. Ist das Team kleiner, sind alle dabei. Ist es größer, eine repräsentative Gruppe, wobei die gesamte Führungsebene teilnehmen muss. Format: vier Sessions, je maximal zwei Stunden, um Ermüdung in Videokonferenzen zu vermeiden. Üblich ist eine Session pro Tag an vier Tagen, zwei an einem Tag gehen mit Pause auch. Nicht über eine Woche hinaus strecken. Remote über Video plus gemeinsames Board (Miro, FigJam), vor Ort als Tagesworkshop mit rund acht Stunden, Whiteboards und Stickies.
Frage: *»Wer nimmt teil, und an welchen Tagen innerhalb einer Woche finden die vier Sessions statt?«*

Durch fast alle Aktivitäten zieht sich dasselbe Muster: schreiben, vorlesen und clustern, abstimmen, dann diskutieren. Die Zeiten sind Merholz' Vorschlag.

**Session 1: Aufwärmen und Verbindung**
1. **Einführung und Ground Rules (10 Min).** Überblick über die vier Sessions. Regeln: Benachrichtigungen aus, größter verfügbarer Bildschirm, mitmachen und Spaß haben.
2. **What's Working, What's Not (30 Min).** Jede Person schreibt auf, was gut läuft und was aktuell Schmerz oder Chance ist, sortiert nach Themenfeldern (Menschen und Rollen, Arbeit und Prozesse, Beziehungen und Kommunikation, Kultur …). Abstimmen mit fünf Stimmen pro Person, auffälligste Muster besprechen.
3. **If The Team Was a Person (30 Min).** Bewusst kreativ: Welche reale oder fiktive Person verkörpert das beste Selbst des Teams? Bild suchen, Eigenschaften aufschreiben. Die Muster fließen später in Purpose und Werte ein.
4. **My Best Work Experience (45 Min).** Jede Person schildert ihre beste Arbeitserfahrung. Das feiert das Gute, zeigt, welche Bedingungen ihr optimieren wollt, und lässt die Teilnehmenden einander kennenlernen.

**Session 2: Purpose und Capabilities**
5. **Mission / Purpose Statement (60 Min).** Ohne Purpose kein Team, sondern eine Ansammlung von Individuen. Jede Person entwirft mithilfe von Thought Starters mehrere Purpose-Statements, ohne auf Formulierung zu achten. Vorlesen, clustern, in zwei Runden abstimmen (erst Themenfelder, dann konkrete Statements), diskutieren. Ein guter Purpose ist präzise und unterscheidbar: Was liefert dieses Team, was kein anderes liefern kann? Nicht »Wir gestalten großartige Nutzererlebnisse«.
6. **Capabilities, Skills und The Work We Do (35 Min).** Von außen wird ein Team meist über Ergebnisse und Fähigkeiten wahrgenommen. Vorgegebene Tätigkeiten und Artefakte sortieren (machen wir / sollten wir machen), Fehlendes ergänzen, per Dot-Voting bewerten: Was sollten wir lassen (Stop), was besser machen (Better), worin sind wir stark (Great)?

**Session 3: Werte und interne Normen**
7. **Values (35 Min).** Jede Person schreibt mindestens fünf Werte auf. Vorlesen, clustern, jedes Cluster mit einem Label versehen, auf das Label abstimmen (nicht auf den Zettel), diskutieren. Ziel: vier bis fünf Werte, hinter denen die Gruppe steht. Gute Werte sind konkret: »Wir gehen unbequemen Fragen nicht aus dem Weg« ist ein Wert. »Wir sind transparent« ist keiner.
8. **Internal Norms, Behaviors and Commitments (50 Min).** Für Themen wie Kommunikation, Zusammenarbeit, gegenseitige Verbindlichkeit und Konfliktlösung beantwortet die Gruppe: Was sollten wir beibehalten, anfangen, aufhören? Lesen, abstimmen (rund 20 Stimmen pro Person über das ganze Board), themenweise diskutieren. Der schwierigste und wirkungsvollste Abschnitt, weil er das Verhalten im Alltag beeinflusst.

**Session 4: Externe Normen und Measures**
9. **External Norms, How The Team Works With Others (50 Min).** Wie das Team gegenüber crossfunktionalen Partnern auftreten will. Aufbau wie bei den internen Normen, für Themen wie Erwartungsmanagement, Zusammenarbeit und Feedback, Beziehungen aufbauen, sichtbar machen, was das Team tut, und für eigene Bedürfnisse eintreten.
10. **Measures of Success (50 Min).** Erbt ein Team Erfolgskriterien von anderen, sind sie oft unreif oder zu weit von der Arbeit entfernt. Jede Person schreibt rund fünf Erfolgsmaße, möglichst im Impact-Frame und nach SMART, beginnend mit dem Zeitfaktor (»In sechs Monaten …«). Vorlesen, clustern, in zwei Runden abstimmen, diskutieren.
11. **Wrap-up (10 Min).** Wie fühlt sich das Ergebnis an, wofür brennen Einzelne, was fehlt noch?

**Danach: Synthese und Verfeinerung.** Die Sessions sind nur ein Drittel bis die Hälfte der Arbeit. Eine Person oder ein kleiner Kreis destilliert aus dem Rohmaterial die Charter:
- Erst alles sichten und Muster suchen.
- Dann Session für Session verdichten: für den Purpose drei bis fünf Varianten, für Werte Unterstützungssätze zu den Top-Begriffen, für Measures je Themenfeld ein bis zwei Kennzahlen.
- Die erste Fassung zeigt bewusst die Herleitung und wird mit der Führung des Teams in einem 90- bis 120-minütigen Review Abschnitt für Abschnitt durchgegangen.
- Danach der finale Schliff. Auf das knappe Purpose Statement folgt eine eigene Seite, die es Zeile für Zeile aufschlüsselt: Adressat, Leistung, Wirkung.

Frage: *»Wer übernimmt die Synthese, und wann ist das Review mit der Führung?«*

**Next Steps.** Die Charter in den Alltag übersetzen. Merholz' häufigster Vorschlag: Die Measures of Success werden zum Mandat einer Person, die dafür sorgt, dass sie in Agenden, Programme und Rituale einfließen.
Frage: *»Wer sorgt dafür, dass die Measures of Success in euren Ritualen auftauchen?«*

## Beispiel

Das Buch zeigt aus Merholz' Beispielcharter ein Detail: Auf das knappe Purpose Statement folgt eine eigene Folie, die es aufschlüsselt. Ein guter Purpose ist dicht gepackt, und die Aufschlüsselung macht Zeile für Zeile klar, was das Team konkret liefern will.

## Worauf du achten musst

- **Die Charter nach den Sessions liegen lassen.** Der häufigste Fehler. Die Sessions erzeugen das Material, nicht das Dokument. Ohne Synthese bleibt es ein netter Workshop.
- **Nicht operationalisieren.** Eine Charter, die nicht in den Alltag übersetzt wird, ist nutzlos. Explizite Next Steps planen.
- **Klischeewerte zulassen.** Werte, die auf jedes Team zutreffen, sind verschenkt.
- **Den Schwung verlieren.** Vier Sessions über mehr als eine Woche lassen die Energie versickern.
- **Die Führung außen vor lassen.** Die gesamte Führungsebene muss teilnehmen, sonst trägt das Ergebnis nicht. Keine Übung, die man delegiert.
- **Von oben schreiben.** Eine Charter nur von der Führungskraft ist ein Manifest.
- **Generischer Purpose.** Ein Purpose, der für jedes Team gelten könnte, grenzt nichts ab.

## Ergebnis

Eine Charter mit sechs Bausteinen und aufgeschlüsseltem Purpose, dazu Next Steps. Vorlage: `templates/team-charter.md`, Workshop: `templates/workshop-agenda.md`.

```markdown
# Team Charter: [Team]
Stand: … · Erarbeitet von: … · Synthese: …

| Baustein | Inhalt |
|---|---|
| Purpose | Wofür das Team da ist und welche Wirkung es anstrebt: … |
| Capabilities | Welche Arbeit es macht und welche Fähigkeiten es bündelt: … |
| Werte | 4 bis 5 Werte mit Unterstützungssatz: … |
| Interne Normen | Beibehalten / anfangen / aufhören: … |
| Externe Normen | Wie wir mit anderen Teams und Partnern arbeiten: … |
| Measures of Success | In sechs Monaten …: … |

**Purpose, Zeile für Zeile:** Statement: … · Adressat: … · Leistung: … · Wirkung: …

**Next Steps:** Mandat Measures of Success: … · Weitere: …
```

## Mini-Check

- Nimmt die gesamte Führungsebene des Teams teil?
- Folgen die Sessions eng aufeinander, innerhalb einer Woche?
- Habt ihr nach den Sessions eine Person oder einen Kreis, der das Material zur Charter verdichtet?
- Enthält die Charter alle Bestandteile (Purpose, Capabilities, Werte, interne und externe Normen, Measures)?
- Gibt es explizite Next Steps, die die Charter in den Alltag bringen?

## Im Flywheel

Modul LEAD, Bereich L4 Set the Stage.

Verwandte Skills:
- `werte-workshop`: Der Werte-Workshop ist das fokussierte Format und erarbeitet nur Werte und Verhaltenserwartungen in ein bis zwei Sitzungen. Die Team Charter ist das umfassende Format über vier Sessions. Hat ein Team eine vollständige Charter, hat es seine Werte damit definiert. Der Werte-Workshop lohnt sich, wenn du gezielt und schneller nur dieses Fundament setzen willst.

Der Ablauf stammt aus Design- und UX-Organisationen. Die Mechanik (schreiben, clustern, abstimmen, diskutieren, synthetisieren) passt für jedes Produkt- oder Designteam. Einige vorgegebene Capability- und Norm-Themen passt du an euren Kontext an.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L4 Set the Stage und Deep Dive Team Charter (Abb. 4.20 und 4.21). Originalquelle: Peter Merholz, Crafting A Design Team Charter. Peter Merholz ist Mitautor von »Org Design for Design Orgs«.

Original: Peter Merholz: Crafting A Design Team Charter, https://www.petermerholz.com/design-org-dimensions/dimension-1-definition/crafting-a-design-team-charter/
