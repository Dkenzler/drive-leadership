# Team Charter Workshop: Agenda

Nach Abb. 4.20 im Drive Leadership Playbook, Agenda nach Peter Merholz, Crafting A Design Team Charter.

**Teilnehmende:** bis etwa 20 Personen, gesamte Führungsebene des Teams.
**Format:** vier Sessions, je maximal zwei Stunden, innerhalb einer Woche. Remote mit Video und gemeinsamem Board (Miro, FigJam) oder vor Ort als Tagesworkshop (rund acht Stunden).
**Muster:** schreiben, vorlesen und clustern, abstimmen, diskutieren.

| Session | Thema | Zeit |
|---|---|---|
| 1 | Einführung & Ground Rules | 10 Min |
| 1 | What's Working, What's Not | 30 Min |
| 1 | If The Team Was a Person | 30 Min |
| 1 | My Best Work Experience | 45 Min |
| 2 | Mission / Purpose Statement | 60 Min |
| 2 | Capabilities & The Work We Do | 35 Min |
| 3 | Values | 35 Min |
| 3 | Internal Norms | 50 Min |
| 4 | External Norms | 50 Min |
| 4 | Measures of Success | 50 Min |
| 4 | Wrap-up und Next Steps | 10 Min |

## Termine

| Session | Datum | Uhrzeit | Moderation |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |

## Ground Rules

- Benachrichtigungen aus.
- Größter verfügbarer Bildschirm.
- Mitmachen und Spaß haben.

## Danach: Synthese

- [ ] Person oder kleiner Kreis für die Synthese: …
- [ ] Rohmaterial sichten, Muster suchen
- [ ] Purpose: drei bis fünf Varianten
- [ ] Werte: Unterstützungssätze zu den Top-Begriffen
- [ ] Measures: je Themenfeld ein bis zwei Kennzahlen
- [ ] Review mit der Führung des Teams (90 bis 120 Min), Abschnitt für Abschnitt: …
- [ ] Finaler Schliff
- [ ] Next Steps, Mandat für Measures of Success: …
