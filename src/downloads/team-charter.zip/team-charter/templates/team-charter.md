# Team Charter: Die sechs Bausteine

Nach Abb. 4.21 im Drive Leadership Playbook, nach Peter Merholz, Crafting A Design Team Charter.

**Team:**
**Stand:**
**Erarbeitet von:**

## Purpose
Wofür das Team da ist und welche Wirkung es anstrebt?

## Capabilities
Welche Arbeit es macht und welche Fähigkeiten es bündelt?

## Werte
Woran die Gruppe glaubt: vier bis fünf tragfähige Werte?

1.
2.
3.
4.
5.

## Interne Normen
Wie das Team intern zusammenarbeitet?

| Thema | Beibehalten | Anfangen | Aufhören |
|---|---|---|---|
| Kommunikation | | | |
| Zusammenarbeit | | | |
| Gegenseitige Verbindlichkeit | | | |
| Konfliktlösung | | | |

## Externe Normen
Wie es mit anderen Teams und Partnern arbeitet?

| Thema | Beibehalten | Anfangen | Aufhören |
|---|---|---|---|
| Erwartungsmanagement | | | |
| Zusammenarbeit und Feedback | | | |
| Beziehungen aufbauen | | | |
| Sichtbar machen, was das Team tut | | | |
| Für eigene Bedürfnisse eintreten | | | |

## Measures of Success
Woran das Team seine Wirkung misst? (im Impact-Frame, SMART, beginnend mit »In sechs Monaten …«)

-

---

## Der Purpose, Zeile für Zeile aufgeschlüsselt

| | |
|---|---|
| Purpose-Statement | Was das Team erreichen will, verdichtet auf einen Satz? |
| Adressat | Für wen ist das Team da? |
| Leistung | Was liefert es konkret? |
| Wirkung | Welches Ergebnis strebt es an? |

## Next Steps
- Mandat für die Measures of Success (Person):
- Wo die Charter in Agenden, Programme und Rituale einfließt:
