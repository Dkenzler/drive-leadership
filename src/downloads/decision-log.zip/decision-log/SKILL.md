---
name: decision-log
description: Decision Log aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn Entscheidungen in Meetings, Slack oder mündlich fallen und danach verschwinden, wenn sich nach einem Meeting alle unterschiedlich erinnern, wenn Entscheidungen ständig wieder aufgemacht werden oder wenn jemand ein einfaches Log für ein Team oder Projekt anlegen oder einen Eintrag formulieren will. Führt durch die vier Elemente jedes Eintrags (was, warum und welche Alternativen, wer, wann), ergänzt um DRI, Dokumente und Einordnung als One-way oder Two-way Door, und klärt, wer das Log pflegt.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S4 Make Fast Decisions
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Decision Log

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Entscheidungen verschwinden. In Meetings getroffen, in Slack-Nachrichten erwähnt, mündlich bestätigt und dann plötzlich weg von der Bildfläche. Zwei Monate später weiß niemand mehr, wer was entschieden hat und warum. Die Entscheidung wird wieder aufgemacht, der Prozess beginnt von vorne.

Das Decision Log löst dieses Problem. Es ist ein einfaches, lebendiges Dokument, das wichtige Entscheidungen festhält, dokumentiert und zugänglich macht. Jeder Eintrag braucht vier Elemente: Was wurde entschieden? Warum, und welche Alternativen wurden erwogen? Wer hat entschieden? Wann?

Der Kontext ist genauso wichtig wie die Entscheidung selbst. Eine Entscheidung, die sechs Monate später falsch erscheint, war vielleicht zum Zeitpunkt der Entscheidung absolut richtig, basierend auf den damaligen Informationen. Wer den Kontext kennt, kann fair urteilen. Wer ihn nicht kennt, missversteht die Entscheidung.

Ein Nebeneffekt, der oft unterschätzt wird: Das Decision Log schafft psychologische Sicherheit. Wenn Entscheidungen dokumentiert und nachvollziehbar sind, sinkt die Angst, an einer Entscheidung beteiligt gewesen zu sein, die sich später als falsch herausstellt. Der Kontext ist sichtbar, die Entscheidung war zu einem bestimmten Zeitpunkt die richtige Wahl.

## Wann du sie einsetzt

- Nach einem Meeting erinnert sich jede Person anders an das, was entschieden wurde.
- Bereits getroffene Entscheidungen werden immer wieder infrage gestellt.
- Ein Team oder Projekt startet und braucht einen festen Ort für Entscheidungen.
- Am Ende jedes wichtigen Meetings, um die Entscheidungen in Echtzeit festzuhalten.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Team oder Projekt ist das Log? Gibt es schon eines, und wo liegt es (Notion, Google Sheets)? Willst du ein Log aufsetzen oder konkrete Entscheidungen eintragen? Frag nichts, was die Person schon gesagt hat.
- Beim Aufsetzen geh die Schritte 1 bis 3 und 6 durch. Für einzelne Einträge die Schritte 4 und 5, pro Entscheidung.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Fehlen Begründung und Alternativen? Ist eine Person als Entscheider benannt oder nur ein Gremium? Benenne Schwächen direkt und kurz.
- Erfinde keine Entscheidungen, Begründungen, Namen oder Daten. Was fehlt, markierst du als offen.
- Liefert die Person Meetingnotizen oder einen Chatverlauf, schlag daraus Einträge vor und lass jede Zeile bestätigen.
- Schließe mit dem Log im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Ort festlegen.** Ein Decision Log muss nicht aufwendig sein. Eine einfache Tabelle in Notion oder Google Sheets reicht.
   Frage: *»Wo soll das Log liegen, damit alle Beteiligten es finden?«*

2. **Spalten festlegen.** Die vier Pflichtelemente plus die Spalten aus der Abbildung im Buch: Datum, Entscheidung, Begründung / Alternativen, DRI, Dokumente, dazu die Einordnung als One-way oder Two-way Door.
   Frage: *»Übernehmt ihr alle Spalten, oder reichen euch vorerst die vier Pflichtelemente?«*

3. **Verantwortliche Person benennen.** Das Log ist kein Selbstläufer. Es braucht eine Person, die sicherstellt, dass es aktuell bleibt. Laut Buch eine gute Aufgabe für einen DRI.
   Frage: *»Wer ist dafür verantwortlich, dass das Log aktuell bleibt?«* Gut ist die Antwort, wenn dort ein Name steht.

4. **Eintrag formulieren.** Pro Entscheidung: Was wurde entschieden? Warum, und welche Alternativen wurden erwogen? Wer hat entschieden? Wann?
   Frage: *»Was wurde entschieden, warum, welche Alternativen lagen auf dem Tisch, wer hat entschieden und wann?«* Gut ist ein Eintrag, wenn jemand ohne Vorwissen in sechs Monaten versteht, warum die Entscheidung damals richtig war.

5. **Einordnen und verlinken.** One-way oder Two-way Door markieren und die zugehörigen Dokumente oder Slack-Threads verlinken.
   Frage: *»Ist die Entscheidung umkehrbar, und wo liegen die Unterlagen dazu?«*

6. **Pflegerhythmus verankern.** Am besten direkt nach dem Meeting, in dem entschieden wurde. Hilfreiche Gewohnheit: Am Ende jedes wichtigen Meetings werden die Entscheidungen in Echtzeit ins Log übertragen.
   Frage: *»In welchen Meetings werden künftig am Ende die Entscheidungen ins Log übertragen, und wer macht das?«*

## Beispiel

Das Buch zeigt einen fiktiven Decision Log (Abb. 5.13) für ein Invoice Team im Q2 mit Spalten für Datum, Entscheidung, Begründung / Alternativen, DRI und Dokumente, jede Zeile als One-way oder Two-way Door markiert. Zwei Einträge daraus, gekürzt:

- E-Invoice Capability vor UX priorisieren. Begründung: regulatorische Deadline Q3, UX-first wäre 6 Wochen langsamer. Two-way Door.
- ZUGFeRD und XRechnung beide unterstützen. Begründung: maximale Marktabdeckung. Alternative: nur XRechnung wäre schneller gewesen. Two-way Door.

Im selben Log steht eine One-way Door rund um einen ungeklärten ZUGFeRD-Bug mit der Begründung: Bugfix 2 Wochen, ein Release mit Bug würde der Reputation schaden.

## Worauf du achten musst

- **Angelegt und nicht gepflegt.** Nach zwei Monaten stehen nur die ersten fünf Einträge drin, und niemand schaut mehr hinein. Ohne verantwortliche Person bleibt das Log nicht aktuell.
- **Entscheidung ohne Kontext.** Ohne Begründung und Alternativen wird die Entscheidung später missverstanden und unfair beurteilt.
- **Mündlich entscheiden, später nachtragen.** Entscheidungen, die nur mündlich fallen, werden unterschiedlich erinnert. Direkt nach dem Meeting oder in Echtzeit festhalten.

## Ergebnis

Ein Decision Log als Tabelle. Vorlage: `templates/decision-log.md`.

```markdown
# Decision Log: [Team] · [Organisation] · [Zeitraum]
Gepflegt von: [Name]

| Datum | Entscheidung | Begründung / Alternativen | Door | DRI | Dokumente |
|---|---|---|---|---|---|
| [TT.MM.] | … | Warum: … · Alternativen: … | One-way / Two-way | [Name] | [Link] |
```

## Mini-Check (abgeleitet aus den typischen Fehlern, ergänzt um die SHIP Checklist)

- Werden Entscheidungen explizit dokumentiert, damit niemand unterschiedliche Erinnerungen daran hat?
- Hat jeder Eintrag alle vier Elemente: was, warum und welche Alternativen, wer, wann?
- Gibt es eine Person, die das Log pflegt, und ist der letzte Eintrag aktuell?
- Werden Entscheidungen direkt im oder nach dem Meeting eingetragen?

## Im Flywheel

Modul SHIP, Bereich S4 Make Fast Decisions. Im Kapitel Create Execution Clarity nennt das Buch das Decision Log als Mittel, Entscheidungen sichtbar zu machen: mit Datum, Kontext und wer entschieden hat.

Verwandte Skills:
- `extreme-clarity`: Das Übertragen ins Log am Ende des Meetings passt direkt zum Real-time Editing aus Extreme Clarity.
- `dri`: Die Pflege des Logs ist laut Buch eine gute Aufgabe für einen DRI.
- `canonical-document`: Das Buch verweist beim Dokumentieren von Entscheidungen auf das Canonical Document.
- `one-way-two-way-door`: Im Beispiel-Log ist jede Entscheidung als One-way oder Two-way Door markiert.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S3 Create Execution Clarity, Entscheidungen sichtbar machen, S4 Make Fast Decisions, Decision Log, SHIP Checklist. Das Buch nennt keine externe Originalquelle.
