# Decision Log

Nach Abb. 5.13 im Drive Leadership Playbook: Fiktiver Decision Log.

**Team:**
**Organisation:**
**Zeitraum:**
**Gepflegt von:**

| Datum | Entscheidung | Begründung / Alternativen | One-way / Two-way Door | DRI | Dokumente |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

Jeder Eintrag beantwortet vier Fragen:
1. Was wurde entschieden?
2. Warum wurde es so entschieden, und welche Alternativen wurden erwogen?
3. Wer hat entschieden?
4. Wann?
