# Job Description Template

Nach Abb. 4.7 und 4.18 im Drive Leadership Playbook.

**Ausgangspunkt:** interne Rollenbeschreibung aus Design Your Organisation.
**Prinzip:** Balance zwischen allgemein und spezifisch (Merholz). Aktivitäten beschreiben, nicht Dokumentation. Fähigkeiten nachweisen, nicht Jahre zählen.

## Titel
Bildet Rolle und Level wirklich ab:

## Einleitung
- Company Vision und Mission:
- Team und Scope auf hohem Level:
- Warum existiert diese Rolle? Was wird möglich, wenn sie besetzt ist?

## Scope und Verantwortungsbereich
- Aktivitäten (nicht Deliverables):
- Produktbereich, Zusammenarbeit, strategischer vs. operativer Anteil:
- Konkretes Team (zum Beispiel Product Trio, crossfunktional):

## Fähigkeiten
Aus Fähigkeiten-Rubrics ableiten. Nachgewiesene Fähigkeiten, keine Jahre.
- Must-haves (Core Capabilities):
- Nice-to-haves (weitere Fähigkeiten):

## Arbeitsweise und Haltung
Aus Verhaltenserwartungen ableiten. Konkrete Arbeitsweise beschreiben (Ownership, Urgency, Collaboration), nicht als abstrakte Werte listen.
-

## Umfeld und Kontext
- Remote, hybrid oder vor Ort? Teamgröße, Reife der Prozesse:
- Aktuelle Herausforderungen, ehrlich beschrieben:
- Optional Anti-JD (Ambiguität, wechselnde Prioritäten, Prozesse, die erst entstehen):

## Was wir bieten
Nicht nur Benefits, sondern was die Rolle attraktiv macht.
- Wirkung:
- Wachstum:
- Herausforderung:
- Team:

---
**Länge:** grob 300 bis 660 Wörter.
