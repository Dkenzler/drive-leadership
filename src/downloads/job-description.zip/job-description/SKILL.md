---
name: job-description
description: Eine Job Description schreiben, die die richtigen Talente anzieht und unpassende sich selbst aussortieren lässt, aus dem Drive Leadership Playbook (Dominik Kenzler, Prinzipien nach Peter Merholz). Nutze diesen Skill, wenn jemand eine Stellenanzeige oder Rollenbeschreibung für externe Bewerbende formulieren, eine bestehende Job Description schärfen oder kürzen, eine Rolle vor dem Hiring klären oder prüfen will, ob eine Anzeige zu generisch, zu lang oder zu überladen ist. Führt durch Titel und sechs Bereiche (Einleitung, Scope und Verantwortungsbereich, Fähigkeiten und Qualifikationen, Arbeitsweise und Haltung, Umfeld und Kontext, Was wir bieten).
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L3 Hire & Let Go
  origin: Dominik Kenzler, Prinzipien nach Peter Merholz
  deep_dive: true
  version: "1.0"
---

# Job Description

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, mit Prinzipien von Peter Merholz.

## Worum es geht

Die Job Description übersetzt deine interne Rollenbeschreibung in ein externes Dokument. Was du in Design Your Organisation an Rollen, Fähigkeiten und Verhaltenserwartungen definiert hast, wird hier zum Werkzeug, um die richtigen Menschen anzusprechen. Sie erfindet die Rolle nicht neu.

Sie ist dein erstes Gespräch mit zukünftigen Teammitgliedern, bevor ihr euch je begegnet seid. Sie leistet drei Dinge:

1. **Die Richtigen ansprechen, die Falschen nicht anziehen.** Sie zieht Menschen an, die zur Rolle passen, und hilft Unpassenden, früh zu erkennen, dass sie es nicht sind.
2. **Von Anfang an die richtigen Erwartungen setzen.** Sie vermittelt Kultur, Werte und Realität der Rolle. Ehrlichkeit ist kein Soft Factor, sondern Selbstschutz.
3. **Den Talentpool erweitern statt verengen.** Studien zeigen, dass Männer sich oft schon bewerben, wenn sie etwa 60 Prozent der Anforderungen erfüllen, viele Frauen erst bei nahezu 100 Prozent. Eine überladene Anforderungsliste verkleinert den Pool systematisch und einseitig.

Die zentrale Herausforderung nach Peter Merholz ist die Balance zwischen allgemein und spezifisch. Zu allgemein: Bewerbende wissen nicht, was der Job wirklich ist, Qualifizierte erkennen sich nicht wieder, Unpassende bewerben sich. Zu spezifisch: Qualifizierte schrecken zurück, weil sie meinen, jeden Punkt perfekt erfüllen zu müssen.

## Wann du sie einsetzt

- Vor jeder externen Ausschreibung, nachdem geprüft ist, ob die Stelle intern besetzt werden kann.
- Zum Briefing des Hiring-Teams: gemeinsam die Job Description durchgehen und Fragen zur Rolle stellen lassen. Das schärft die Rolle und das gemeinsame Bild.
- Wenn eine bestehende Anzeige keine passenden Bewerbungen bringt oder zu generisch ist.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Rolle auf welchem Level, in welchem Team? Gibt es eine interne Rollenbeschreibung, Fähigkeiten-Rubrics und Verhaltenserwartungen? Gibt es schon einen Entwurf? Frag nichts, was die Person schon gesagt hat.
- Liegt Material vor (interne Rollenbeschreibung, alter Entwurf), lass es dir geben und arbeite daraus. Die Job Description übersetzt, sie erfindet nicht.
- Kann die Person die Rolle nicht klar beschreiben, sag das direkt. Laut Buch gilt: Wenn du die Rolle nicht klar definieren kannst, solltest du dafür nicht einstellen. Kläre dann zuerst die Rolle.
- Geh die Bereiche Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten. Formuliere aus den Antworten einen Textvorschlag für den Bereich und lass ihn bestätigen.
- Challenge jeden Satz gegen »Worauf du achten musst«. Vor allem die Frage: Könnte das genauso in der Anzeige eines beliebigen anderen Unternehmens stehen?
- Erfinde keine Fakten über Unternehmen, Team, Benefits oder Arbeitsmodell. Was fehlt, markierst du als offen.
- Schließe mit der fertigen Job Description im Format aus »Ergebnis«, nenne die ungefähre Wortzahl und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**0. Titel.** Das Erste, was Bewerbende sehen. Nicht einfach den Titel übernehmen, den andere benutzen, sondern einen wählen, der Rolle und Level wirklich abbildet.
Frage: *»Welcher Titel bildet Rolle und Level bei euch ab, und passt er zu dem, was die Person tatsächlich tut?«*

**1. Einleitung.** Wer seid ihr, wo wollt ihr hin? Unternehmensvision und Mission in zwei bis drei Sätzen. Das Team, in dem die Rolle angesiedelt ist, und der Scope auf hohem Level. Vor allem: warum diese Rolle existiert.
Frage: *»Welches Problem löst ihr mit dieser Rolle, und was wird möglich, wenn sie besetzt ist?«* Gut ist die Antwort, wenn sie spezifisch für diese Rolle ist. Diese Warum-Frage ist der Haken, an dem die besten Talente hängen bleiben.

**2. Scope und Verantwortungsbereich.** Was wird die Person konkret tun? Aktivitäten beschreiben, nicht Deliverables. Statt »erstellt Wireframes und Prototypen« lieber »gestaltet komplexe Interaktionen und testet sie mit Nutzenden«. Produktbereich, Zusammenarbeit (zum Beispiel Product Trio, crossfunktional), strategischer versus operativer Anteil. Aufgaben mit ihrer Wirkung verbinden: Wie zahlt die Rolle auf Produkt, Kundschaft und Unternehmenserfolg ein?
Frage: *»Was tut die Person in einer typischen Woche, mit wem, und wofür ist das wichtig?«* Gut ist die Antwort, wenn sie Tätigkeiten und Wirkung beschreibt, keine Liste von Artefakten.

**3. Fähigkeiten und Qualifikationen.** Direkt aus den Fähigkeiten-Rubrics ableiten. Zwei Dinge sind entscheidend: klar trennen zwischen Must-haves (Core Capabilities) und Nice-to-haves (weitere Fähigkeiten), die Must-have-Liste kurz halten. Wünschenswertes weicher formulieren (»Erfahrung mit …«, »ein Plus ist …«). In nachgewiesenen Fähigkeiten formulieren, nicht in Jahren: statt »5 bis 7 Jahre Erfahrung« lieber »nachgewiesene Erfahrung in der Führung von Designteams, die hochwertige Software ausgeliefert haben«.
Frage: *»Ohne welche Fähigkeiten kann die Person die Rolle ab Tag eins nicht ausfüllen?«* Alles andere wandert zu den Nice-to-haves.

**4. Arbeitsweise und Haltung.** Aus den Verhaltenserwartungen ableiten. Nicht als abstrakte Werte, sondern als konkrete Arbeitsweise (Ownership, Urgency, Collaboration). Nicht »Ownership« als Wort, sondern: »Wir erwarten, dass du Verantwortung übernimmst, Tempo machst und nicht auf Erlaubnis wartest.«
Frage: *»Welches Verhalten erwartest du im Alltag, beschrieben als etwas, das man beobachten kann?«*

**5. Umfeld und Kontext.** Wie sieht der Alltag aus? Remote, hybrid oder vor Ort? Teamgröße, Reife der Prozesse, Herausforderungen, die man kennen sollte. Oft weggelassen, für die besten Talente aber entscheidend. Auch das Unfertige ehrlich beschreiben. Optional die Anti-JD: ein kurzer, ehrlicher Abschnitt über die Realität, also Ambiguität, wechselnde Prioritäten, Prozesse, die erst entstehen. Das zieht belastbare Leute an und filtert die heraus, die feste Strukturen brauchen.
Frage: *»Was ist bei euch gerade unfertig oder schwierig, das eine neue Person wissen sollte?«*

**6. Was wir bieten.** Nicht nur Benefits, sondern was die Rolle attraktiv macht: Wirkung, Wachstum, Herausforderung, Team. Entwicklungsmöglichkeiten konkret machen. Gerade im Start-up zählt der Gesamtmix aus Gehalt, Equity und Entwicklung mehr als einzelne Vergünstigungen.
Frage: *»Was bekommt die Person hier, was sie anderswo nicht bekommt?«*

**7. Kürzen und prüfen.** Bewerbende überfliegen eine Anzeige oft in unter einer Minute. Recherche nennt grob 300 bis 660 Wörter als ideale Länge. Kürzen, Struktur statt Textwände, jeden Satz auf Austauschbarkeit prüfen.

## Beispiel

Das Buch zeigt als durchgängiges Beispiel die Anzeige von Linear für einen Senior Product Designer (gekürzt und übersetzt). Linear baut ein Tool für Projekt- und Issue-Tracking in der Produktentwicklung und ist bekannt für hohen Anspruch an Handwerk und Produktqualität. Die Anzeige zeigt, wie eine Job Description Werte, Arbeitsweise und Erwartung ohne Floskeln transportiert:

- **Einleitung:** Linear baut das Product-Development-System für Teams und Agents, über 25 000 Unternehmen nutzen es. Qualität ist der Wettbewerbsvorteil, jedes Mitglied des remote arbeitenden Teams ist im Kern ein Maker.
- **Erwartung:** Robuste Designfähigkeiten, scharfes Produktdenken, die Fähigkeit, in technische Diskussionen einzusteigen. Kleine, autonome Projektteams, die Person trägt Projekte von Anfang bis Ende.
- **Standort und Arbeitsweise:** Remote-first mit optionalen Co-Working-Offices, tiefe Konzentration, asynchrone Zusammenarbeit, bewusste Treffen bei Offsites.
- **Was du tun wirst:** Mit Engineering und Produkt Roadmap-Projekte ohne Hand-offs anstoßen und abschließen, zentrale Screens neu gestalten und kleine Qualitätsmängel beheben, Prototypen bauen, andere durch Kritik anleiten, das Designsystem weiterentwickeln, beim Hiring helfen.
- **Wonach wir suchen:** Unter anderem Mut, Fragen zu stellen und für das Richtige einzustehen, Demut, Feedback anzunehmen, starke schriftliche Kommunikation, weil vieles asynchron läuft.
- **Was wir bieten:** Gehalt und Equity mit mitarbeiterfreundlichen Bedingungen, fünf Wochen Urlaub, vier Monate bezahlte Elternzeit, ein bezahlter freier Monat nach vier Jahren.

Hinweis: Auch die Linear-Anzeige nennt unter »Wonach wir suchen« »7+ Jahre Erfahrung«. Das Buch empfiehlt, stattdessen nachgewiesene Fähigkeiten zu beschreiben.

## Worauf du achten musst

- **Generisch bleiben.** Der häufigste Fehler. Eine Beschreibung, die auf jede Rolle dieser Art passt, sortiert niemanden vor und zieht niemanden an. Bei jedem Satz fragen: Könnte das genauso bei einem beliebigen anderen Unternehmen stehen? Wenn ja, schärfen.
- **Die Anforderungsliste überladen.** Jede zusätzliche Pflichtanforderung verkleinert den Pool, überproportional bei genau den Gruppen, die du gewinnen willst. Hart trennen, bei Must-haves geizig sein.
- **Das Einhorn suchen.** Wer eine eierlegende Wollmilchsau verlangt, bekommt einen Pool von Generalisten, obwohl eine Spezialistin gebraucht wird. Entscheiden, was die Rolle im Kern verlangt.
- **Ausschließende Sprache.** Wörter wie »Rockstar«, »Ninja« oder »Digital Native« wirken codiert nach Geschlecht oder Alter. Über die tatsächlich benötigte Fähigkeit formulieren.
- **Unehrlich sein.** Passt die Realität nicht zur Beschreibung, gewinnst du vielleicht die Bewerbung, verlierst die Person danach aber umso schneller. Das Unfertige ehrlich beschreiben filtert nicht die Guten heraus, sondern die Falschen.
- **Zu lang werden.** Was über grob 660 Wörter hinausgeht, wird selten gelesen.
- **Deliverables und Jahre statt Aktivitäten und Fähigkeiten.** Siehe Schritte 2 und 3.

## Ergebnis

Eine fertige Job Description mit Titel und sechs Bereichen, dazu eine Liste offener Punkte. Vorlage: `templates/job-description.md`.

```markdown
# [Titel, der Rolle und Level abbildet]

## Einleitung
[Vision und Mission, 2 bis 3 Sätze] [Team und Scope] [Warum es die Rolle gibt, was möglich wird]

## Was du tun wirst
- [Aktivität + Wirkung]

## Was du mitbringst
**Must-haves:** [kurz, nachgewiesene Fähigkeiten]
**Ein Plus ist:** [Nice-to-haves]

## Wie wir arbeiten
[Verhaltenserwartungen als konkrete Arbeitsweise]

## Umfeld
[Arbeitsmodell, Teamgröße, Reife der Prozesse, ehrliche Herausforderungen]

## Was wir bieten
[Wirkung, Wachstum, Herausforderung, Team, Konditionen]

---
Wortzahl: [~ …] · Offen: [fehlende Angaben]
```

## Mini-Check

- Deckt die Beschreibung alle sechs Bereiche ab, inklusive des oft vergessenen Umfeld-Abschnitts?
- Beschreibst du Aktivitäten statt Deliverables, nachgewiesene Fähigkeiten statt Jahre?
- Ist klar getrennt, was Must-have und was Nice-to-have ist, und ist die Must-have-Liste wirklich kurz?
- Würde sich die Beschreibung von der eines beliebigen anderen Unternehmens unterscheiden?
- Ist sie ehrlich, auch in Bezug auf Herausforderungen und Unfertiges?

## Im Flywheel

Modul LEAD, Bereich L3 Hire & Let Go.

Die Job Description ist die externe Seite eines internen Artefakts. Sie steht und fällt mit der Rollenbeschreibung aus Design Your Organisation. Umgekehrt zwingt das Schreiben oft dazu, die interne Rolle erst richtig zu klären. Behandle sie als Marketingdokument, nicht als juristische Auflistung: Mehr als die Hälfte der Bewerbenden gibt an, dass die Qualität der Beschreibung ihre Entscheidung, sich zu bewerben, stark beeinflusst.

Verwandte Skills:
- `rollen`: Aus den Rollen lässt sich direkt eine Rollenbeschreibung oder Job Description ableiten.
- `faehigkeitenmatrix`: Die Fähigkeiten-Rubrics liefern Must-haves und Nice-to-haves.
- `werte-workshop`: Die Verhaltenserwartungen fließen in Arbeitsweise und Haltung ein.
- `hiring-scorecard`: Die Job Description ist Grundlage für das Briefing des Hiring-Teams.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L3 Hire & Let Go (Abb. 4.7) und Deep Dive Job Description (Abb. 4.18 und 4.19). Prinzipien nach Peter Merholz. Beispiel: Stellenanzeige von Linear Orbit, Inc., gekürzt und übersetzt.
