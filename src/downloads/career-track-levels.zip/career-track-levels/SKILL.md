---
name: career-track-levels
description: Karrierestufen und Karrierepfade definieren mit Career Track & Levels aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand ein Level-Framework oder Career Framework aufbaut, eine Dual Career Ladder mit Management-Pfad und Expert-Pfad (Individual Contributor) einführen, Levels über Funktionen hinweg vergleichbar machen, Levels mit Gehaltsbändern verknüpfen, Beförderungskriterien klären oder ein bestehendes Framework auf Wachstum prüfen will. Beschreibt Levels über fünf Dimensionen (Verantwortungsbereich, Wirkung, Eigenständigkeit, Komplexität, Fachtiefe).
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L1 Design Your Organisation
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Career Track & Levels

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Levels beschreiben die Karrierestufen einer Organisation, von Werkstudierenden bis zum Vorstand. Je nach Unternehmensgröße sind das sieben bis 13 Stufen. Levels werden über die gesamte Organisation definiert, nicht pro Team oder Funktion. So lassen sich die Stufen verschiedener Funktionen vergleichen: Ein Senior im Engineering und ein Senior im Vertrieb stehen auf demselben Level, auch wenn sich ihre fachlichen Anforderungen unterscheiden.

Die **Dual Career Ladder** beschreibt zwei parallele, gleichwertige Pfade. Der **Management-Pfad** führt über Team- und Bereichsleitung bis zur Geschäftsführung, mit Fokus auf strategischem Einfluss und der Führung von Menschen. Der **Expert-Pfad** (oft Individual Contributor genannt) führt über zunehmende fachliche Tiefe und Breite bis zur anerkannten Expertise, die Richtung und Standards für eine Fachrichtung setzt, mit Fokus auf direktem Einfluss durch Expertise. Karriere muss nicht über Personalführung laufen. Wer in den Expert-Pfad geht, macht nicht weniger Karriere, sondern eine andere.

Ein Level ist mehr als ein Titel. Es beschreibt Umfang und Wirkung der Arbeit, entlang von fünf Dimensionen:

1. **Verantwortungsbereich:** Wie breit ist der Bereich? Ein einzelnes Thema, ein Teilbereich, eine ganze Fachrichtung?
2. **Wirkung:** Wirkt die Arbeit im eigenen Team, über Teams hinweg oder auf das gesamte Unternehmen?
3. **Eigenständigkeit:** Braucht jemand Anleitung, oder gibt die Person die Richtung vor?
4. **Komplexität:** Klar definierte Aufgaben oder mehrdeutige, strategische Herausforderungen?
5. **Fachtiefe:** Wie ausgeprägt sind Wissen und Können in der eigenen Fachrichtung?

Diese Dimensionen machen den Unterschied zwischen den Levels greifbar: für die Führungskraft, die einschätzen muss, und für die Mitarbeitenden, die verstehen wollen, wo sie stehen und was der nächste Schritt ist.

## Wann du sie einsetzt

- Beim Aufbau eines Career Frameworks, in dem Erwartungen auf jeder Stufe beschrieben sind.
- Wenn Karriere bisher nur über Personalführung möglich ist und ein Expert-Pfad fehlt.
- Wenn Gehaltsgespräche ohne nachvollziehbare Grundlage laufen.
- Vor einer Wachstumsphase, damit das Framework nicht unter Zeitdruck umgebaut werden muss.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Wie groß ist die Organisation, und wie stark soll sie wachsen? Gibt es schon Levels oder Titel, und für welche Funktionen? Hat die Person das Mandat, Levels organisationsweit zu definieren, oder arbeitet sie für ihren Bereich zu? Frag nichts, was die Person schon gesagt hat.
- Levels werden organisationsweit definiert. Arbeitet die Person nur für ihren Bereich, weise darauf hin und markiere, was mit anderen Funktionen abgestimmt werden muss.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen, wenn sie schon Material hat.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz.
- Erfinde keine Gehaltsbänder, Titel oder Stufenzahlen für die Organisation der Person. Was fehlt, markierst du als offen.
- Schließe mit dem Framework im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Das Buch gibt keine feste Schrittfolge vor. Die Reihenfolge ordnet die Bausteine aus dem Buch.

1. **Anzahl der Stufen festlegen.** Sieben bis 13 Stufen, je nach Größe, von Werkstudierenden bis Vorstand, organisationsweit gültig.
   Frage: *»Wie viele Stufen braucht eure Organisation von der niedrigsten bis zur höchsten Ebene, und gelten sie für alle Funktionen gleich?«* Gut ist die Antwort, wenn ein Senior in einer Funktion auf demselben Level steht wie ein Senior in einer anderen.

2. **Zwei Pfade anlegen.** Management-Pfad und Expert-Pfad parallel, transparent, fair und gleichwertig.
   Frage: *»Wie weit reicht bei euch der Expert-Pfad, und auf welchem Level stehen Management- und Expert-Pfad nebeneinander?«* Gut ist die Antwort, wenn der Expert-Pfad bis in die oberen Stufen reicht.

3. **Levels über die fünf Dimensionen beschreiben.** Für jedes Level: Verantwortungsbereich, Wirkung, Eigenständigkeit, Komplexität, Fachtiefe.
   Frage: *»Was unterscheidet Level X von Level X+1 in Verantwortungsbereich, Wirkung, Eigenständigkeit, Komplexität und Fachtiefe?«* Gut ist die Antwort, wenn jede Dimension von Stufe zu Stufe erkennbar wächst.

4. **Levels mit Vergütung verknüpfen.** Jedes Level ist mit einem Gehaltsband verbunden. Wer aufsteigt, bewegt sich in ein neues Band. Das schafft Transparenz und nimmt Gehaltsgesprächen einen Teil der Willkür.
   Frage: *»Ist jedes Level mit einem Gehaltsband verbunden, oder hängt Vergütung heute am Titel?«*

5. **Wachstum einplanen.** Das Framework von Anfang an mit mehr Stufen anlegen, als aktuell gebraucht werden. Nicht benötigte Stufen sind angelegt und lassen sich bei Bedarf aktivieren.
   Frage: *»Welche Stufen braucht ihr heute noch nicht, solltet sie aber schon anlegen?«*

6. **Beförderungsgrundsatz festhalten.** Eine Person wird nur befördert, wenn sie die Anforderungen des nächsten Levels bereits konstant erfüllt, nicht, wenn sie die Erwartungen des aktuellen Levels gut erfüllt. Eine Beförderung bestätigt, dass jemand auf dem nächsten Level angekommen ist.
   Frage: *»Woran erkennt ihr, dass jemand die Anforderungen des nächsten Levels bereits konstant erfüllt?«*

## Beispiel

Abb. 4.2 im Buch zeigt Karrierestufen und Tracks für Finance und Engineering nebeneinander, mit Level-Codes von P1 bis P6, M1 bis M5 und E1 bis E3. Von M1/P3 bis M4/P6 stehen M- und P-Codes auf derselben Stufe nebeneinander.

- Engineering, Functional Track: Junior Engineer, Professional Engineer, Advanced Engineer, Senior Engineer, Staff Engineer, Principal Engineer, Senior Principal, Chief. Leadership Track: Eng Manager, Senior Eng Manager, Director, Senior Director, VP, SVP, C-Level.
- Finance, Functional Track: Specialist / Junior / Associate, Professional, Analyst / Accountant / Manager, Senior Analyst / Accountant / Manager, Expert, Principal. Leadership Track: Team Lead, Head of, Director, Senior Director, VP, SVP, C-Level.

Bei CLARK hatte sich die Zahl der Mitarbeitenden innerhalb von 18 Monaten verdreifacht. Das Level-Framework hatte von Anfang an mehr Stufen als benötigt. Ein Senior-Director-Level gab es zunächst nicht, es war aber angelegt und konnte bei Bedarf aktiviert werden.

Für den Expert-Pfad nennt das Buch Menschen im Marketing, deren Gespür für Sprache und Marke die gesamte Außenwahrnehmung eines Unternehmens prägt. Ihre Zeit wäre in der Personalführung nicht am besten genutzt.

## Worauf du achten musst

- **Levels pro Team oder Funktion definieren.** Dann sind Stufen nicht vergleichbar.
- **Expert-Pfad nur auf dem Papier.** Beide Pfade müssen tatsächlich gleichwertig sein, in Vergütung, Sichtbarkeit und Ansehen.
- **Level gleich Titel.** Ein Level beschreibt Umfang und Wirkung der Arbeit, nicht nur eine Bezeichnung.
- **Keine Verknüpfung mit Gehaltsbändern.** Dann bleiben Gehaltsgespräche willkürlich.
- **Erst unter Druck erweitern.** Wer ein Level-Framework erst erweitert, wenn Druck da ist, baut unter Zeitdruck. Und das merkt man.
- **Für gute Leistung auf dem aktuellen Level befördern.** Maßstab ist, ob jemand das nächste Level bereits konstant erfüllt.

## Ergebnis

```markdown
# Career Track & Levels: [Organisation]
Stand: [Datum] · Verantwortlich: [Rolle]
Anzahl Stufen: … · Davon aktuell aktiv: …

| Level | Management-Pfad (Titel) | Expert-Pfad (Titel) | Gehaltsband | Aktiv? |
|---|---|---|---|---|
| … | … | … | … | ja / angelegt |

## Level-Beschreibung
| Level | Verantwortungsbereich | Wirkung | Eigenständigkeit | Komplexität | Fachtiefe |
|---|---|---|---|---|---|
| … | … | … | … | … | … |

## Beförderungsgrundsatz
…

## Abstimmung mit anderen Funktionen / offen
- …
```

## Mini-Check

- Gibt es in deiner Organisation einen klar definierten Expert-Pfad neben dem Management-Pfad?
- Werden beide Pfade tatsächlich gleichwertig behandelt, in Vergütung, Sichtbarkeit und Ansehen?
- Sind die Dimensionen, die ein Level definieren, für deine Mitarbeitenden transparent und nachvollziehbar?
- Ist dein Level-Framework auf Wachstum angelegt, oder müsstest du es bei der nächsten Skalierung komplett umbauen?
- Wissen deine Mitarbeitenden, was konkret nötig ist, um das nächste Level zu erreichen?

## Im Flywheel

Modul LEAD, Bereich L1 Design Your Organisation.

Verwandte Skills:
- `faehigkeitenmatrix`: Rubrics beschreiben für jede Fähigkeit, was auf welchem Level erwartet wird.
- `rollen`: Eine Rolle kombiniert Fachrichtung, Level und Fähigkeiten.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L1 Design Your Organisation (Abb. 4.2) und L3 Hire & Let Go zum Beförderungsgrundsatz.
