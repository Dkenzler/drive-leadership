---
name: performance-reviews
description: "Performance Reviews vorbereiten und führen, aus dem Drive Leadership Playbook, mit Gedanken von Molly Graham, Sebastian Barrios und den fünf Tipps von Carol Gill (Melbourne Business School). Nutze diesen Skill, wenn eine Führungskraft ein Jahres- oder Halbjahresgespräch, ein Performance-Gespräch oder eine Leistungsbeurteilung vorbereitet, eine Selbsteinschätzung strukturieren will, unsicher ist, ob ein Performance-Problem eigentlich ein Klarheitsproblem ist, oder einen Entwicklungsplan ableiten will. Bewertet in zwei Dimensionen: Was wurde erreicht (zwei bis drei wichtigste Ziele) und wie (Unternehmenswerte)."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S5 Ensure Quality
  origin: Dominik Kenzler (Gesprächsführung nach Carol Gill)
  deep_dive: false
  version: "1.0"
---

# Performance Reviews

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, Tipps zur Gesprächsführung nach Carol Gill.

## Worum es geht

Ein Team kontinuierlich zu verbessern und Mitarbeitenden beim Wachsen zu helfen, geht nur über klar formulierte Erwartungen und Ziele. In der Praxis sind sie oft zu schwammig. Je weniger Erfahrung jemand mitbringt, desto wichtiger ist Klarheit. Sehr erfahrene Mitarbeitende brauchen einen Rahmen, der deutlich gröber sein kann.

Der Performance Review ist der regelmäßige Abgleich: Werden die Ziele erreicht? Und genauso wichtig: Stimmt die Art und Weise? Manche erreichen ihre Ziele auf Kosten anderer, machen ihr Team schlechter und erzeugen Unzufriedenheit. Deshalb zählt das »Wie«. Damit es nicht willkürlich bewertet wird, ist es durch Unternehmenskultur und Werte definiert. Im Kern geht es aber um Zielerreichung. Das »Wie« ist kein Ersatz für Ergebnisse.

Performance Reviews sind der formale Rahmen, der laufendes Feedback und Entwicklungsgespräche in regelmäßigen Abständen strukturiert zusammenfasst. Ein gutes Review endet nicht mit einer Bewertung, sondern mit einem konkreten Entwicklungsplan.

Das Ziel: von einer Kultur mit vagen Zielen, in der es normal ist, ein Ziel zu verschieben oder nicht zu erreichen, zu einem Set-up mit echter Klarheit. Das beginnt bei dir: Was erwartest du von dieser Person? Wie sieht gute Leistung in dieser Rolle aus? Und wie kommunizierst du das, nicht nur beim Einstieg, sondern regelmäßig, konkret und nachvollziehbar?

## Wann du sie einsetzt

- Formal alle sechs bis zwölf Monate, weil Performance sich nicht in einzelnen Wochen zeigt, sondern über längere Zeiträume.
- Wenn du bei einer Person ein Performance-Problem vermutest: zuerst prüfen, ob es ein Klarheitsproblem ist.
- Nicht als Ersatz für zeitnahes Feedback. Was verbessert werden müsste, gehört sofort in den Alltag, nicht in den Review-Termin.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welche Rolle und welchen Zeitraum geht es? Welche Ziele und Werte gelten als Maßstab? Bereitest du als Führungskraft vor oder deine eigene Selbsteinschätzung? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Gibt es Wachstumsfelder? Ist das Urteil durch konkrete Beobachtungen gedeckt? Benenne Schwächen direkt und kurz.
- Erfinde keine Beobachtungen, Ergebnisse oder Verhaltensweisen der bewerteten Person. Frag nach konkreten Situationen. Fehlt etwas, markiere es als offen.
- Arbeite nur mit den Informationen, die die Person für die Vorbereitung braucht. Formuliere Aussagen über die bewertete Person sachlich und respektvoll.
- Schließe mit der Vorbereitung im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Klarheit prüfen, bevor du bewertest.** Molly Graham: Performance-Probleme sind fast immer Klarheitsprobleme. Bevor du bei der Person landest, frag dich: Weiß sie, was du von ihr erwartest? Kennt sie ihre drei wichtigsten Ziele? Weiß sie, woran Erfolg gemessen wird? Wenn nicht, ist das kein Performance-Gespräch, sondern ein Clarity-Gespräch.
   Frage: *»Kennt die Person ihre drei wichtigsten Ziele und weiß sie, woran Erfolg gemessen wird? Woran machst du das fest?«*
   Gut ist die Antwort, wenn sie auf nachweislich kommunizierte Ziele verweist. Ist das unklar, empfiehl zuerst ein Clarity-Gespräch.

2. **Das Was einschätzen.** Was wurde erreicht, bezogen auf die zwei bis drei wichtigsten Ziele? Nicht 20 Indikatoren, sondern eine klare Einschätzung.
   Frage: *»Welche zwei bis drei Ziele waren die wichtigsten, und was wurde bei jedem konkret erreicht?«*

3. **Das Wie einschätzen.** Wie wurde es erreicht, bezogen auf die Unternehmenswerte? Wurde das Ziel auf Kosten anderer erreicht?
   Frage: *»Wie hat die Person gearbeitet, gemessen an euren Werten? Nenne konkrete Situationen.«*
   Gut ist die Antwort, wenn sie sich auf definierte Werte bezieht, nicht auf persönlichen Geschmack.

4. **Selbsteinschätzung einholen.** Führungskraft und Mitarbeitende schätzen beide ein. Die Selbsteinschätzung ist kein Formalismus: Sie zeigt, wie gut jemand sich selbst beurteilen kann, und ist eine wertvolle Information für die Entwicklung.
   Frage: *»Wo liegen deine Einschätzung und die Selbsteinschätzung auseinander, und was sagt das über die Selbstwahrnehmung?«*

5. **Über den ganzen Zeitraum schauen.** Performance zeigt sich über längere Zeiträume. Es kann schwierigere Phasen geben, durch private Themen oder externe Umstände. Der Review fasst zusammen, was du laufend beobachtet und kommuniziert hast.
   Frage: *»Gibt es in deiner Einschätzung etwas, das die Person heute zum ersten Mal hören würde?«*
   Gut ist die Antwort, wenn nichts Wesentliches überraschend ist. Sonst fehlt laufendes Feedback.

6. **Wachstumsfelder benennen.** Sebastian Barrios: Wenn alles positiv zurückkommt und nichts zu verbessern ist, war das Review nicht ernsthaft geführt. Ein Performance Review ohne Wachstumsfelder ist keine Führung, sondern nur Höflichkeit.
   Frage: *»Welches Wachstumsfeld benennst du, auch wenn die Person insgesamt stark ist?«*

7. **Das Gespräch vorbereiten.** Carol Gill (Melbourne Business School) beschreibt, warum Reviews oft als Konfrontation erlebt werden: Führungskräfte bereiten sich auf jedes »Was, wenn« vor, Mitarbeitende erwarten das Schlimmste. Ihre fünf Tipps (Abb. 5.16):
   - **Delivery is key.** Es geht um das Gespräch, nicht das Formular. Wer ausdruckslos vom Notizbuch abliest, wirkt unecht. Face-to-face ist das optimale Format.
   - **Sei transparent.** Vorab erklären, wie das Gespräch abläuft. Der Person die Wahl geben: zuerst Stärken oder zuerst Entwicklungsfelder?
   - **Führe häufige Gespräche.** Kontinuierliches Feedback macht das formale Review zur Zusammenfassung, nicht zur Überraschung.
   - **Sei authentisch.** »Say what you mean, mean what you say, but don’t say it meanly.« Positives Feedback aus Bequemlichkeit schadet beiden Seiten.
   - **Nimm Entwicklung ernst.** Das Review endet mit einem konkreten Entwicklungsplan.

   Frage: *»Wie eröffnest du das Gespräch, und welche Wahl lässt du der Person bei der Reihenfolge?«*

8. **Entwicklungsplan ableiten.** Was braucht diese Person, um besser zu werden? Welche Unterstützung kannst du geben? Bei High Performern gilt: Die Hebelwirkung pro investierter Stunde ist dort am höchsten. Wer die Besten in Ruhe lässt, weil sie gut sind, sollte sich nicht wundern, wenn sie kündigen. Low Performer brauchen Klarheit und gegebenenfalls eine klare Entscheidung, kein endloses Coaching ohne Wirkung.
   Frage: *»Was ist der eine nächste Entwicklungsschritt, und was trägst du konkret dazu bei?«*

## Worauf du achten musst

- **Klarheitsproblem als Performance-Problem behandeln.** Kennt die Person ihre Ziele und Erfolgskriterien nicht, ist zuerst ein Clarity-Gespräch fällig.
- **Nur das Wie bewerten.** Das Wie ist wichtig, aber kein Ersatz für Ergebnisse. Im Kern geht es um Zielerreichung.
- **Das Wie willkürlich bewerten.** Ohne Bezug zu Kultur und Werten wird das Wie zur Geschmacksfrage.
- **Zu viele Indikatoren.** Nicht 20 Kennzahlen, sondern zwei Dimensionen: Was und Wie.
- **Review ohne Wachstumsfelder.** Wenn nichts zu verbessern ist, war das Review nicht ernsthaft geführt.
- **Bis zum Termin warten.** Wer Beobachtungen für den Review aufspart, macht ihn zur Überraschung.
- **Führungsenergie nur in die Schwächsten.** Die Hebelwirkung liegt bei High Performern.
- **Performance Review und Quality Review vermischen.** Der Quality Review schaut auf die Arbeit, der Performance Review auf die Person und ihre Entwicklung.

## Ergebnis

```markdown
# Performance Review: [Name / Rolle]
Zeitraum: [von bis] · Gespräch am: [Datum] · Führungskraft: [Name]

**Klarheitscheck:** Ziele bekannt? ja / nein · Erfolgskriterien bekannt? ja / nein
(Bei nein: zuerst Clarity-Gespräch)

## Was (2 bis 3 wichtigste Ziele)
| Ziel | Ergebnis | Einschätzung Führungskraft | Selbsteinschätzung |
|---|---|---|---|
| | | | |

## Wie (Unternehmenswerte)
| Wert | Beobachtung (konkrete Situation) | Einschätzung Führungskraft | Selbsteinschätzung |
|---|---|---|---|
| | | | |

**Abweichungen Selbst- und Fremdbild:** …
**Stärken:** …
**Wachstumsfelder (mindestens eines):** …

## Gesprächsvorbereitung
- Ablauf, vorab erklärt: …
- Reihenfolge nach Wahl der Person: Stärken zuerst / Entwicklungsfelder zuerst
- Format: face-to-face

## Entwicklungsplan
| Entwicklungsschritt | Unterstützung durch Führungskraft | bis |
|---|---|---|
| | | |

**Offen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern und den fünf Tipps nach Carol Gill)

- Kennt die Person ihre zwei bis drei wichtigsten Ziele und weiß, woran Erfolg gemessen wird?
- Bewertest du Was und Wie, und ist das Wie an euren Werten festgemacht?
- Enthält der Review mindestens ein ernsthaftes Wachstumsfeld?
- Gibt es nichts Wesentliches, das die Person im Gespräch zum ersten Mal hört?
- Endet der Review mit einem konkreten Entwicklungsplan und deiner Unterstützung?

## Im Flywheel

Modul SHIP, Bereich S5 Ensure Quality.

Verwandte Skills:
- `braintrust`: Abgrenzung laut Buch. Der Quality Review schaut auf die Arbeit, der Performance Review auf die Person und ihre Entwicklung. Nicht vermischen.
- `skill-will-matrix`: Laut Buch hilfreich in der Vorbereitung auf Performance-Gespräche, um die eigene Einschätzung zu strukturieren.
- `work-journal`: Laut Buch eine Sammlung von Fieldnotes, auf die du zurückgreifen kannst, wenn du einen Performance Review vorbereitest.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S5 Ensure Quality, Performance Reviews, Abb. 5.16, Deep Dive Braintrust, Gut zu wissen. Kapitel LEAD, Skill-Will-Matrix, Kapitel YOURSELF, Work Journal. Zitierte Stimmen: Molly Graham, Sebastian Barrios, Carol Gill (Melbourne Business School).
