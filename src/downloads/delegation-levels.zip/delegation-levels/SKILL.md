---
name: delegation-levels
description: Bewusst delegieren mit den sieben Delegation Levels (Tell, Sell, Consult, Agree, Advise, Inquire, Delegate) nach Jurgen Appelo (Management 3.0), zurückgehend auf Paul Hersey und Ken Blanchard, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand Aufgaben oder Entscheidungen an Mitarbeitende oder ein Team übergeben, Missverständnisse darüber klären will, wer entscheidet, Micromanagement vermeiden oder je nach Seniorität und Aufgabe den passenden Grad an Freiheit festlegen will. Führt zur expliziten Benennung der Delegationsstufe pro Entscheidung.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L5 Grow Your People
  origin: Jurgen Appelo (Management 3.0), zurückgehend auf Paul Hersey und Ken Blanchard
  deep_dive: false
  version: "1.0"
---

# Delegation Levels

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Jurgen Appelo, zurückgehend auf Paul Hersey und Ken Blanchard.

## Worum es geht

»Sag den Leuten nicht, wie sie die Dinge tun sollen. Sag ihnen, was zu tun ist, und lasse sie dich mit ihren Ergebnissen überraschen.« Mit diesem Satz brachte General George S. Patton auf den Punkt, worum es bei Delegation geht: nicht Kontrolle aufgeben, sondern Verantwortung übertragen.

Delegation Levels beschreiben sieben Stufen, auf denen Entscheidungen getroffen werden können, von »Ich entscheide und teile dir meine Entscheidung mit« bis »Du entscheidest vollständig und informierst mich nicht einmal«. Die sieben Stufen stammen von Jurgen Appelo (Management 3.0). Er hat sie aus den vier Führungsstilen des Situational Leadership von Paul Hersey und Ken Blanchard weiterentwickelt, deshalb nennt das Buch das Modell auch Situational-Leadership-Modell.

| Stufe | Name | Was es heißt | So klingt es (Abb. 4.15) |
|---|---|---|---|
| 1 | Tell | Du entscheidest und informierst. Kein Spielraum. | »Ich verkünde meine Entscheidung.« |
| 2 | Sell | Du entscheidest, erklärst aber, warum, um Akzeptanz zu schaffen. | »Ich erkläre und begründe meine Entscheidung.« |
| 3 | Consult | Du holst Input ein, behältst aber die Entscheidung. | »Ich hole Input ein und entscheide dann.« |
| 4 | Agree | Du entscheidest gemeinsam mit der anderen Person oder dem Team. | »Wir entscheiden gemeinsam.« |
| 5 | Advise | Du teilst deine Meinung mit, aber die andere Person entscheidet. | »Ich berate, das Team entscheidet.« |
| 6 | Inquire | Die andere Person entscheidet und informiert dich danach. | »Ich frage nach, nachdem das Team entschieden hat.« |
| 7 | Delegate | Vollständige Übertragung. Du bist nicht mehr eingebunden. | »Ich delegiere vollständig.« |

## Wann du sie einsetzt

- Bei jeder Aufgabe oder Entscheidung, die du übergibst.
- Wenn es Missverständnisse darüber gibt, wer entscheidet. Eines der häufigsten Missverständnisse in der Führungsarbeit entsteht, wenn Führungskraft und Mitarbeitende unterschiedliche Annahmen über die Delegationsstufe haben.
- Wenn du den Führungsstil an Seniorität und Aufgabe anpassen willst. Nicht alle Mitarbeitenden sollten gleich gemanagt werden.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Aufgabe oder Entscheidung soll delegiert werden? An wen (Person oder Team, Erfahrung mit dieser Art Aufgabe)? Gibt es schon ein Missverständnis, das gelöst werden soll? Frag nichts, was die Person schon gesagt hat.
- Arbeite pro Entscheidung, nicht pro Person. Dieselbe Person kann bei verschiedenen Aufgaben auf verschiedenen Stufen stehen.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist die Stufe explizit benannt, oder nur gemeint? Benenne Schwächen direkt und kurz. Kein Lob als Füllmaterial.
- Erfinde nichts über die Fähigkeiten der Mitarbeitenden. Fehlt eine Einschätzung, markiere sie als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Entscheidung benennen.** Um welche konkrete Aufgabe oder Entscheidung geht es?
   Frage: *»Welche Entscheidung soll bei wem liegen?«* Gut ist die Antwort, wenn sie eine einzelne, abgrenzbare Entscheidung beschreibt, nicht einen ganzen Verantwortungsbereich.

2. **Stufe bewusst wählen.** Je nach Seniorität und Aufgabe wählst du bewusst eine andere Stufe. Seniorität bedeutet laut Buch, wie viel Unterstützung jemand braucht, um eine Aufgabe zur Zufriedenheit zu lösen.
   Frage: *»Wie viel Unterstützung braucht die Person bei genau dieser Aufgabe, und welche der sieben Stufen passt dazu?«* Gut ist die Antwort, wenn die Stufe aus Aufgabe und Erfahrung begründet ist, nicht aus Gewohnheit.

3. **Stufe in einem Satz formulieren.** Die Lösung ist simpel: explizit benennen, auf welcher Stufe ihr euch bewegt. »Ich möchte hier deine Meinung hören, aber die finale Entscheidung liegt bei mir« ist Stufe 3. »Das liegt komplett bei dir, informier mich einfach danach« ist Stufe 6.
   Frage: *»Mit welchem Satz sagst du der Person, auf welcher Stufe ihr seid?«* Gut ist der Satz, wenn die Person danach eindeutig weiß, wer entscheidet und ob und wann sie informieren soll.

4. **Abgleichen.** Prüfen, ob die andere Seite dieselbe Stufe verstanden hat.
   Frage: *»Wie stellst du sicher, dass ihr dieselbe Stufe meint?«*

## Beispiel

Typisches Missverständnis aus dem Buch: Die Führungskraft meint Stufe 3 (Consult), die Mitarbeitenden verstehen Stufe 6 (Inquire). Oder umgekehrt: Die Führungskraft meint Stufe 1 (Tell), die Mitarbeitenden interpretieren es als Einladung zur Diskussion.

Das Tischler-Beispiel aus der Einleitung des Kapitels: Ein Tischlermeister zeigt dem Lehrling Schritt für Schritt die Handgriffe, spricht über klare Erwartungen und begleitet ihn engmaschig. Das klingt nach Micromanagement, und genau das wird an dieser Stelle gebraucht. Mit zunehmender Seniorität braucht es einen anderen Führungsstil.

## Worauf du achten musst

- **Die Stufe nicht aussprechen.** Führungskraft und Mitarbeitende gehen von unterschiedlichen Stufen aus. Ein einziger Satz verhindert eine Menge Verwirrung.
- **Alle gleich managen.** Dieselbe Stufe für alle Personen und Aufgaben passt selten. Die Stufe richtet sich nach Seniorität und Aufgabe.
- **Niedrige Stufen für Misstrauen halten.** Eine bewusst gewählte niedrigere Stufe ist kein Zeichen von Micromanagement oder mangelndem Vertrauen, sondern situative Führungsklarheit. Micromanagement ist nichts Schlechtes per se, sondern ein Werkzeug, das je nach Person und Situation richtig oder falsch eingesetzt wird.
- **Delegation als Kontrollverlust verstehen.** Es geht nicht darum, Kontrolle aufzugeben, sondern Verantwortung zu übertragen.

## Ergebnis

```markdown
# Delegation Levels: [Team / Person]
Stand: [Datum]

| Entscheidung / Aufgabe | Bei wem | Stufe (1 bis 7) | Begründung (Aufgabe, Erfahrung) | Satz, mit dem ich die Stufe benenne |
|---|---|---|---|---|
| … | … | … | … | »…« |

**Abgeglichen mit der Person / dem Team am:** …
**Offen:** …
```

## Mini-Check

Aus der LEAD Checklist des Buchs:
- Delegierst du bewusst und nennst explizit, auf welcher Delegationsstufe ihr euch bewegt?

Abgeleitet aus den typischen Fehlern:
- Hast du für jede Entscheidung eine Stufe gewählt statt eine pauschale für die Person?
- Begründet sich die Stufe aus Aufgabe und Seniorität?
- Weiß die andere Seite nach deinem Satz eindeutig, wer entscheidet und ob sie dich informieren soll?

## Im Flywheel

Modul LEAD, Bereich L5 Grow Your People.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L5 Grow Your People, Delegation Levels (Abb. 4.15), LEAD Checklist. Originalquelle laut Buch: Paul Hersey und Ken Blanchard, weiterentwickelt von Jurgen Appelo (Management 3.0).

Original: Jurgen Appelo: Management 3.0. Leading Agile Developers, Developing Agile Leaders, Addison-Wesley, 2011 (Seven Levels of Authority), https://management30.com/practice/delegation-poker/
