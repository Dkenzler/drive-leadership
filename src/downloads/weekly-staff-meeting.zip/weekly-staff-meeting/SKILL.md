---
name: weekly-staff-meeting
description: Ein Weekly Staff Meeting mit den Direct Reports aufsetzen und führen, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn eine Führungskraft ein wöchentliches Führungsteam-Meeting einführen, ein bestehendes Staff Meeting straffen, eine Agenda mit Pre-Read vorbereiten, Aufgaben und Verantwortung klar verteilen oder ein Meeting reparieren will, das regelmäßig überläuft, bilaterale Themen verhandelt oder keinen klaren Output hat. Führt durch Timing, laufendes Themen-Dokument, Pre-Read, Ablauf, Delegation und Zusammenfassung mit Entscheidungen und Wer macht was bis wann.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L4 Set the Stage
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Weekly Staff Meeting

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Das Weekly Staff Meeting ist dein wichtigstes Format für den Rhythmus deiner Direct Reports. Es schafft Alignment, gibt der Woche eine klare Richtung und hält alle auf dem gleichen Stand. Anders als im 1:1 kommt ein Großteil der Agenda von dir.

Es ist ein Arbeitsmeeting mit klarem Output: kein Einzelgespräch in der Gruppe, kein Stimmungsbarometer, kein Format für emotionalen Austausch. 60 Minuten als Orientierung, nicht mehr. Das Meeting ist die Konsequenz der Vorbereitung, nicht ihr Ersatz.

## Wann du sie einsetzt

- Du führst ein Team von Direct Reports und brauchst einen gemeinsamen Wochenrhythmus.
- Das bestehende Staff Meeting läuft regelmäßig über, verliert sich in Status oder endet ohne klare Verantwortung.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wer sind die Direct Reports? Gibt es schon ein Staff Meeting, und was stört daran? Gibt es ein gemeinsames Dokument? Frag nichts, was die Person schon gesagt hat.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Gehört ein Thema wirklich in die Runde, oder ist es ein 1:1-Thema?
- Liefert die Person eine Themenliste, sortiere sie: Pre-Read, offene Fragen, Themen für die Runde, Themen fürs 1:1.
- Erfinde keine Themen oder Verantwortlichkeiten. Was fehlt, markierst du als offen.
- Schließe mit dem Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**1. Timing festlegen.** Dominik legt das Meeting bewusst auf Montag. Der Wochenanfang ist der richtige Moment, um Prioritäten zu setzen, nicht der Freitagabend oder kurz vor dem nächsten Termin. 60 Minuten als Orientierung.
Frage: *»Wann findet das Meeting statt, und passt der Zeitpunkt dazu, Prioritäten für die Woche zu setzen?«*

**2. Ein gemeinsames Dokument, die ganze Woche.** Themen, Aufgaben und offene Fragen werden die ganze Woche in einem gemeinsamen Dokument gesammelt, nicht erst kurz vorher. Dasselbe Dokument dient als Pre-Read und später für die Zusammenfassung.
Frage: *»Wo sammelst du die Themen unter der Woche, und haben alle Zugriff?«*

**3. Pre-Read vorbereiten.** Ein kurzer Statusabgleich muss vorher als Pre-Read fertig sein. Im Meeting werden nur die offenen Fragen dazu geklärt.

**4. Themen sortieren.** Der Rest der Zeit gehört den Themen, die du oder die Teilnehmenden mitbringen. Bilaterale Themen, die nur zwei Personen betreffen, gehören nicht hinein. Ist ein Thema nur für eine Person relevant, ist es ein 1:1-Thema.
Frage: *»Welche Themen auf deiner Liste betreffen wirklich die ganze Runde?«*

**5. Delegieren.** Das Staff Meeting ist der wichtigste Ort für Dominiks Prinzip: Ich delegiere so lange, bis Leute Stopp sagen. Aufgaben werden verteilt, Verantwortung klar zugeordnet. Das erzeugt Fluss und hält das Tempo.

**6. Zusammenfassen.** Am Ende jedes Meetings eine kurze Zusammenfassung im selben Dokument: Was wurde entschieden? Wer macht was bis wann? Ohne diesen Schritt verliert das Meeting seinen Drive.

**7. Nachhalten.** Aktiv nachfragen, wenn Dinge nicht in der vereinbarten Zeit fertig werden. Das gehört genauso zum Format wie die Vorbereitung.
Frage: *»Wo prüfst du nächste Woche, was aus den Zusagen geworden ist?«*

**8. Beim Format bleiben.** Claire Hughes Johnson beschreibt in »Scaling People«, dass der gefährlichste Fehler im Operating Rhythm nicht ein schlechtes Meetingformat ist, sondern das ständige Wechseln. Wenige Formate, konsequent umgesetzt, sind stärker als viele gut gemeinte Experimente.

## Worauf du achten musst

- **Vorbereitung erst kurz vorher.** Die Themen werden die ganze Woche gesammelt.
- **Status im Meeting.** Der Statusabgleich ist Pre-Read, im Meeting nur offene Fragen.
- **Bilaterale Themen.** Das Staff Meeting ist kein Einzelgespräch in der Gruppe.
- **Stimmungsrunde statt Arbeitsmeeting.** Das Format hat einen klaren Output.
- **Regelmäßiges Überlaufen.** Heißt: zu viele Themen oder die falschen Themen im falschen Format.
- **Keine Zusammenfassung.** Ohne Entscheidungen und Wer macht was bis wann verliert das Meeting seinen Drive.
- **Nicht nachfragen.** Aktiv nachfragen, wenn Dinge nicht in der vereinbarten Zeit fertig werden, gehört genauso zum Format wie die Vorbereitung.
- **Ständig das Format wechseln.** Konsequenz schlägt Experimente.

## Ergebnis

Ein laufendes Dokument, das zugleich Themenspeicher, Pre-Read und Protokoll ist.

```markdown
# Weekly Staff Meeting: [Team] · [Datum, Montag]
Teilnehmende: … · Dauer: 60 Min

## Themenspeicher (die ganze Woche gesammelt)
- …

## Pre-Read: Statusabgleich (vor dem Meeting fertig)
| Person | Status | Offene Frage fürs Meeting |
|---|---|---|
| | | |

## Themen für die Runde
1. … (eingebracht von …)

## Nicht hier, sondern im 1:1
- … (mit …)

## Zusammenfassung
**Entschieden:**
- …

**Wer macht was bis wann:**
| Wer | Was | Bis |
|---|---|---|
| | | |

**Nachhalten aus der Vorwoche:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)
- Liegt der Statusabgleich vor dem Meeting als Pre-Read vor?
- Betrifft jedes Thema auf der Agenda die ganze Runde?
- Endet das Meeting mit Entscheidungen und Wer macht was bis wann im selben Dokument?
- Fragst du nach, wenn Zusagen nicht eingehalten werden?
- Bleibt das Meeting in der Regel bei 60 Minuten?

## Im Flywheel

Modul LEAD, Bereich L4 Set the Stage.

Verwandte Skills:
- `one-on-one-skip-level`: Themen, die nur eine Person betreffen, gehören ins 1:1.
- `work-journal`: Aus den Weekly Notes ergeben sich Themen für das wöchentliche Staff Meeting.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L4 Set the Stage, Bezug zum Work Journal in YOURSELF. Operating Rhythm nach Claire Hughes Johnson: Scaling People.
