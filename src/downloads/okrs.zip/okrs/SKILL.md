---
name: okrs
description: Ziele setzen mit OKRs (Objectives and Key Results, Andy Grove bei Intel, durch John Doerr bei Google populär), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand Team- oder Bereichsziele formulieren, Company Objectives in Team-OKRs übersetzen (kaskadieren), bestehende OKRs prüfen, Key Results schärfen, den OKR-Zyklus mit Check-ins, Halbzeit und Scoring aufsetzen oder OKR-Theater beenden will. Führt vom Objective über outcome-basierte Key Results bis zum Betrieb im Operating Rhythm.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S1 Set Goals (auch DRIVE D3 Set Strategic Goals)
  origin: Andy Grove (Intel), populär gemacht durch John Doerr (Google)
  deep_dive: true
  version: "1.0"
---

# OKRs

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Andy Grove, populär gemacht durch John Doerr.

## Worum es geht

Objectives and Key Results sind das bekannteste Framework für Zielsetzung in der Tech-Welt. Ein **Objective** beschreibt, was erreicht werden soll: qualitativ, inspirierend, ambitioniert. **Key Results** zeigen, woran man misst, ob das Objective erreicht wurde: quantitativ, spezifisch, zeitgebunden.

OKRs leisten drei Dinge:

- **Ambition messbar machen.** Erst die Verbindung von Objective und Key Results verhindert, dass aus einem inspirierenden Ziel ein frommer Wunsch wird, den am Ende niemand einfordert.
- **Fokus durch Begrenzung.** Die eigentliche Kraft liegt im Weglassen. Ein OKR-Set, das alles enthält, ist kein Fokusinstrument, sondern eine bessere To-do-Liste.
- **Transparenz über Teams hinweg.** Wenn jedes Team seine OKRs sichtbar macht und sie nachvollziehbar auf das Company Objective einzahlen, sieht die ganze Organisation, woran gearbeitet wird und warum. Hier werden OKRs vom Zielformat zum Alignment-Werkzeug.

Viele Teams haben OKRs, wenige nutzen sie gut. Der Unterschied liegt selten am Framework, fast immer an der Ausführung: ob ein Key Result ein echtes Ergebnis beschreibt oder nur eine erledigte Aufgabe, ob die Ziele zwischen Teams zusammenpassen und ob zwischen Planung und Review überhaupt noch jemand hinschaut.

## Wann du sie einsetzt

- In der Planungsphase, je nach Operating Rhythm alle sechs Wochen oder einmal im Quartal.
- Wenn strategische Ziele in operative Team-Ziele übersetzt werden sollen.
- Wenn mehrere Teams auf dasselbe Company Objective ausgerichtet werden sollen.
- Wenn bestehende OKRs geprüft werden: Sind die Key Results Outcomes? Zahlt das Team Objective wirklich auf das Company Objective ein?

Auf Company-Level mit mehrjährigem Horizont sind Strategic Objectives das Dach. OKRs sind die quartalsweise Übersetzung darunter. Ob du deine Ziele OKRs, Strategic Objectives oder Jahresziele nennst, ist zweitrangig. Entscheidend ist, ob alle verstehen, worauf ihr hinarbeitet.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Team oder welche Ebene entstehen die OKRs? Welches Company Objective oder strategische Ziel liegt darüber? Wie lang ist der Zyklus (sechs Wochen, Quartal)? Frag nichts, was die Person schon gesagt hat.
- Wenn die Person bereits OKRs hat, prüfe sie gegen den Ablauf und »Worauf du achten musst«, statt bei null anzufangen.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jedes Key Result mit der Prüffrage: *»Würdest du es auch als erfüllt ansehen, wenn das Ergebnis ausbleibt, die Aufgabe aber erledigt ist?«* Benenne Aufgaben, die sich als Key Result tarnen, direkt.
- Halte die Formulierungsarbeit kurz. Eine grobe, gute Fassung, mit der das Team arbeitet, schlägt eine perfekte, an der es sich verschluckt. Wenn die Diskussion philosophisch wird, lenk zurück auf den Inhalt.
- Erfinde keine Kennzahlen, Baselines oder Zielwerte. Fehlen sie, markiere sie als offen und frag, woher die Daten kommen.
- Plant die Person die OKR-Runde mit Teams, biete an, die Commitment Ceremony oder den Zyklus (siehe `templates/okr-zyklus.md`) vorzubereiten.
- Schließe mit dem OKR-Set im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

### Teil 1: OKRs aufsetzen

1. **Beitrag klären.** Die Übersetzung von strategischen in operative Ziele folgt einer einfachen Logik: Was ist der Verantwortungsbereich des Teams? Welche strategischen Ziele sind für es relevant? Wie kann es konkret zur Wertschöpfung beitragen? Dieser Beitrag, der Outcome, ist das, was definiert wird. Dominik schreibt in der Planungsphase selbst auf, welche Objectives er für am relevantesten hält. Die Teams bekommen dieselbe Aufgabe: Sie kennen die strategischen Ziele und formulieren für ihren Bereich ihre eigenen Objectives.
   Frage: *»Wofür ist dein Team verantwortlich, und welches übergeordnete Ziel ist dafür am relevantesten?«* Gut ist die Antwort, wenn der Beitrag des Teams als Wirkung beschrieben ist, nicht als Projektliste.

2. **Objective schreiben, das eine Richtung gibt.** Kurz, einprägsam, qualitativ. Es beschreibt einen Zustand, den ihr erreichen wollt, keine Zahl. Enthält das Objective schon eine Metrik, steht wahrscheinlich ein Key Result an der falschen Stelle. Es soll motivieren und beantworten, warum diese Arbeit wichtig ist. Das Objective ist immer Outcome-fokussiert formuliert.
   Frage: *»Welchen Zustand wollt ihr am Ende des Zyklus erreicht haben?«* Gut ist die Antwort, wenn sie ohne Zahl auskommt und das Warum erkennbar ist.

3. **Key Results als Ergebnisse formulieren, nicht als Aufgaben.** Hier scheitern die meisten OKRs. Ein Key Result beschreibt einen messbaren Outcome, kein erledigtes Stück Arbeit. »Onboarding-Flow überarbeitet« ist eine Aufgabe. »Anteil der Nutzenden, die das Onboarding abschließen, von 40 auf 60 Prozent« ist ein Key Result. Wo ein echter Outcome noch nicht messbar ist, etwa bei einer ganz neuen Initiative oder bei weniger erfahrenen Teams, darf bewusst ein Output als bester verfügbarer Proxy stehen. Dann muss das explizit sein, damit niemand den Proxy mit dem eigentlichen Ziel verwechselt.
   Frage: *»Woran würdet ihr messen, dass das Objective erreicht ist? Von welchem Wert auf welchen?«* Gut ist die Antwort, wenn Ausgangswert, Zielwert und Messgröße genannt sind. Fehlen die Daten, frag, ob die Infrastruktur zum Messen existiert (Dashboards, Tracking).

4. **Erfolg vorab definieren.** Erfolg wird definiert, bevor die Arbeit beginnt, nicht während sie läuft. Ohne vorab festgelegten Zielwert wird jeder Fortschritt als Erfolg gewertet. Fortschritt ist nicht dasselbe wie Zielerreichung.
   Frage: *»Welcher Wert muss erreicht sein, damit es ein Erfolg ist, und warum genau dieser?«* Gut ist die Antwort, wenn der Zielwert aus dem übergeordneten Ziel abgeleitet ist, nicht aus dem, was bequem erreichbar scheint.

5. **Mengen klein halten.** Pro Ebene zwei bis maximal vier Objectives, je drei bis fünf Key Results. Mehr ist kein Zeichen von Ehrgeiz, sondern von fehlender Priorisierung.
   Frage: *»Wenn du ein Objective oder Key Result streichen müsstest, welches wäre es?«*

6. **Kaskadieren als Übersetzung, nicht als Weitergabe.** Das Company Objective gibt die Richtung vor. Das Team Objective beschreibt den konkreten Beitrag des Teams. Die Key Results messen, ob dieser Beitrag erbracht wurde. Prüffrage: *»Wenn dein Team sein Objective erreicht, zahlt das wirklich auf das Company Objective ein?«* Kannst du das nicht klar beantworten, stimmt die Kaskadierung nicht. Genauso wichtig ist die horizontale Abstimmung: Teams mit unterschiedlichen Objectives unter demselben Company Objective klären ihre Abhängigkeiten früh, nicht erst, wenn sie aufeinanderprallen.
   Frage: *»Welche anderen Teams zahlen auf dasselbe Company Objective ein, und wo hängt ihr voneinander ab?«*

7. **Ungeplante Arbeit einplanen und committen.** Ungeplante Arbeit kommt. Wer sie nicht antizipiert, hat einen Plan, der nach der ersten Woche nicht mehr stimmt. Am Ende der Planungsphase stehen echte Commitments, für die Teams accountable sind, und ein Austausch, in dem die schriftlichen Pläne im Detail durchgegangen werden. Die Ziele sollten so formuliert sein, dass die Führungskraft den Plan wirklich versteht (siehe `commitment-ceremony`).

### Teil 2: Im Zyklus betreiben

OKRs leben nicht im Planungsmeeting, sondern im Rhythmus danach. Der Takt richtet sich nach dem Operating Rhythm, sechs Wochen oder ein Quartal sind üblich. Vorlage: `templates/okr-zyklus.md`.

8. **Zyklus aufsetzen.** Vier Punkte: Setzen zu Beginn, ein kurzer Check-in pro Woche oder zweiwöchentlich, eine Halbzeitsicht in der Mitte (Stand prüfen, nachjustieren) und ein Scoring am Ende.
   Frage: *»Wann und in welchem Format finden Check-in, Halbzeit und Scoring statt, und wer ist dabei?«*

9. **Mit Confidence-Levels arbeiten.** Im Check-in geht es nicht um Aktivität, sondern um die Frage, wie sicher das Team ist, das Key Result noch zu erreichen. Eine einfache Einschätzung, etwa Confidence von eins bis zehn oder eine Ampel, macht früh sichtbar, wo es hakt.
   Frage: *»Welche Skala nutzt ihr, und was passiert, wenn ein Key Result auf Rot steht?«*

10. **Am Ende ehrlich bewerten.** Jedes Key Result wird bewertet, oft auf einer Skala von null bis eins. Bei bewusst ambitionierten OKRs ist ein Wert um 0,7 ein gutes Ergebnis. Wer durchgehend volle Punktzahl erreicht, hat sich zu kleine Ziele gesetzt. Unterscheide **committed** OKRs (sollen voll erreicht werden) und **aspirational** OKRs (absichtlich so hoch, dass volle Erreichung unwahrscheinlich ist). Wer beide verwechselt, bestraft Teams für Ehrgeiz oder belohnt sie für Bequemlichkeit.
    Frage: *»Welche eurer OKRs sind committed, welche aspirational?«*

## Beispiel

**Grundform (aus DRIVE).** Objective: Unsere Kunden lieben unser Produkt. Key Results: NPS steigt von 40 auf 55. Retention nach 90 Tagen steigt von 65 auf 75 Prozent. Support-Tickets pro User sinken um 30 Prozent.

**Kaskadierung bei sevdesk.** Anfang 2024 kamen die Gründer aus Italien zurück, wo die E-Rechnungspflicht starkes Wachstum für Cloud-Accounting ausgelöst hatte. Dieselbe Regulierung würde nach Deutschland kommen, die Strategie wurde umgebaut. Company Objective: *Winning the e-invoice wave*, wobei »Winning« klar definiert war: mehr neue Marktanteile gewinnen als der Wettbewerb. Team Objective des Invoice Teams: *Building the best invoice experience for small businesses.* Wichtigstes Key Result im ersten Quartal: 50 Prozent der Nutzenden können E-Rechnungen versenden, im Folgequartal 100 Prozent. Die Key Results zur Experience standen in der Priorität dahinter. Auch das Growth Team schwenkte um und wollte maximal viele neue Kund:innen auf das Invoice Feature onboarden. Verschiedene Teams, unterschiedliche Objectives, alle auf dasselbe Company Objective ausgerichtet.

**Vom strategischen zum Team-Objective bei CLARK.** Die Daten zeigten: Nutzende mit mehr als 50 Prozent digitalisierten Verträgen hatten 69 Prozent höheren Umsatz und 40 Prozent höhere Retention nach 26 Wochen. Das strategische Objective der Leadership: die Zeit bis zum ersten Mehrwert für neue Nutzende deutlich verkürzen und ihr Engagement steigern. Das Team Objective: neue Nutzende begeistern, indem sie vom ersten App-Öffnen an einen Überblick über ihre Versicherungssituation bekommen. Die A/B-Tests im Quartal liefen alle mit vorab definierten Uplift-Zielen.

## Worauf du achten musst

- **OKR-Theater.** Ziele, die so einfach sind, dass man sie an einem Nachmittag abhakt. »Drei Prototypen fertiggestellt« hat keine qualitative Komponente, keinen Anspruch, keine Spannung. Ein Key Result ohne Spannung ist eine Beschäftigungsnotiz.
- **Mehr Zeit ins Formulieren als ins Liefern.** Wenn die Formulierung philosophisch wird und mehrere Meetings verschlingt, ist der Fokus verloren. Geoff Charles, CPO bei Ramp: »Die gesamte OKR-Planung dauerte länger, als es uns gekostet hätte, einfach ein Ziel zu setzen und es umzusetzen.« Faustregel aus DRIVE: Planung sollte nicht mehr als zehn Prozent der Zeit einnehmen.
- **Key Results mit Aufgaben verwechseln.** Der häufigste handwerkliche Fehler. Eine Liste erledigter Aufgaben kann vollständig abgehakt sein, während das Ziel verfehlt wurde.
- **Proxy mit Ziel verwechseln.** Ein Output als Proxy ist erlaubt, wenn allen bewusst ist, dass es ein Proxy ist.
- **Erfolg im Nachhinein definieren.** Ein Team, das zehn Prozent Conversion-Verbesserung brauchte und fünf erreicht, hat eine Verbesserung erzeugt, aber das Ziel um 50 Prozent verfehlt. Fortschritt nicht als Erfolg verkaufen lassen.
- **Kaskadierung als Durchreichen.** Wenn nicht klar ist, wie das Team Objective auf das Company Objective einzahlt, stimmt die Kaskadierung nicht.
- **OKRs nach der Planung vergessen.** Ohne Check-ins werden OKRs zu einem Dokument, das einmal im Quartal hervorgeholt wird. Der Wert entsteht im wöchentlichen Blick darauf.
- **Vergütung an OKRs koppeln.** Sobald OKRs über Boni entscheiden, setzen Teams vorsichtige Ziele. Das zerstört die Ambition. Zielsetzung und Vergütung auseinanderhalten.
- **Framework über Kontext stellen.** Es gibt keine reine Lehre, die in jeder Organisation funktioniert. Nimm die Mechanik, die hilft, und lass den Rest.

## Ergebnis

Ein OKR-Set für einen Zyklus. Für den Betrieb im Zyklus: `templates/okr-zyklus.md`.

```markdown
# OKRs: [Team] · Zyklus [Zeitraum]
Stand: [Datum] · Owner: [Name oder Rolle]

**Übergeordnetes Ziel (Company Objective / Strategic Objective):** …
**Beitrag des Teams (Outcome):** …

## Objective 1: [qualitativ, ohne Zahl]
Warum wichtig: …
Typ: committed / aspirational

| Key Result | Ausgangswert | Zielwert | Messquelle | Outcome oder Proxy |
|---|---|---|---|---|
| KR 1.1 | … | … | … | … |
| KR 1.2 | … | … | … | … |
| KR 1.3 | … | … | … | … |

Einzahlung auf das Company Objective: …

## Objective 2: …
(max. 4 Objectives, je 3 bis 5 Key Results)

**Abhängigkeiten zu anderen Teams:** …
**Eingeplante ungeplante Arbeit:** …
**Offene Punkte (fehlende Daten, Baselines):** …
```

## Mini-Check

- Sind deine Key Results als messbare Outcomes formuliert, nicht als erledigte Aufgaben?
- Habt ihr pro Ebene nur wenige Objectives mit je wenigen Key Results, oder ist die Liste zu lang?
- Lässt sich für jedes Team Objective klar erklären, wie es auf das Company Objective einzahlt?
- Habt ihr einen festen Check-in-Rhythmus mit Confidence-Einschätzung, nicht nur ein Setzen und ein Scoring?
- Ist klar, welche OKRs committed und welche aspirational sind, und bewertet ihr sie entsprechend?

## Im Flywheel

Modul SHIP, Bereich S1 Set Goals. In DRIVE, D3 Set Strategic Goals, als Framework für strategische Ziele eingeführt.

Verwandte Skills:
- `strategic-objectives`: das mehrjährige Dach auf Company-Level ohne Key Results. OKRs, Quartals- und Teamziele sollen darauf einzahlen.
- `ogsm`: OGSM für die Jahresstrategie, OKR für die quartalsweise Umsetzung darin.
- `commitment-ceremony`: formaler Abschluss der Planungsphase, in dem Teams ihre OKRs vorstellen und explizit committen.
- `weekly-priorities`: das Bindeglied zwischen quartalsweisen OKRs und dem Alltag.
- `goal-review`: Abschluss des Zyklus, in dem Key Results und Commitments bewertet werden.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D3 Set Strategic Goals und Deep Dives Strategic Objectives und OGSM, Kapitel SHIP, S1 Set Goals und Deep Dive OKRs (Abb. 5.17 OKR Operating Rhythm). Originalquelle: Andy Grove (Intel), John Doerr (Google). Zitierte Stimmen im Buch: Tim Herbig, Geoff Charles.
Original: Andrew S. Grove: High Output Management, 1983. John Doerr: Measure What Matters, 2018. https://www.whatmatters.com/articles/the-origin-story
