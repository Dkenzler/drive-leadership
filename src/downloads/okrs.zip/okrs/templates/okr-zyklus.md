# Der OKR-Zyklus

Nach Abb. 5.17 (OKR Operating Rhythm) im Drive Leadership Playbook.

**Team:**
**Zyklus:** von … bis …
**Takt nach Operating Rhythm:** meist sechs Wochen oder ein Quartal

## 1. Setzen
Objectives und Key Results setzen.

| Objective | Key Result | Ausgangswert | Zielwert | committed / aspirational |
|---|---|---|---|---|
| | | | | |

## 2. Check-in (wöchentlich oder zweiwöchentlich)
Confidence prüfen. Nicht Aktivität, sondern: Wie sicher sind wir, das Key Result noch zu erreichen?

| Datum | Key Result | Confidence (1 bis 10 oder Ampel) | Was hakt? | Nächster Schritt |
|---|---|---|---|---|
| | | | | |

## 3. Halbzeit
Stand prüfen, nachjustieren.

- Stand je Key Result:
- Was justieren wir nach?

## 4. Check-in (wöchentlich)
Confidence prüfen (Tabelle wie oben fortführen).

## 5. Scoring
Jedes Key Result auf einer Skala von 0 bis 1 bewerten. Bei ambitionierten OKRs ist ein Wert um 0,7 ein gutes Ergebnis.

| Key Result | committed / aspirational | Score (0 bis 1) | Begründung |
|---|---|---|---|
| | | | |

**Übergabe in den nächsten Zyklus:**
