---
name: wigs
description: Wildly Important Goals (WIGs) formulieren, aus »The 4 Disciplines of Execution« von Chris McChesney, Sean Covey und Jim Huling, wie im Drive Leadership Playbook von Dominik Kenzler beschrieben. Nutze diesen Skill, wenn jemand die zwei bis drei Ziele finden will, die den größten Unterschied machen, Ziele ins Format »From X to Y by When« bringen will, bei Turnarounds, Ressourcenknappheit oder zu vielen parallelen Initiativen Fokus herstellen muss oder sicherstellen will, dass jede Person und jedes Team nur ein WIG verfolgt.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D3 Set Strategic Goals
  origin: Chris McChesney, Sean Covey und Jim Huling
  deep_dive: false
  version: "1.0"
---

# Wildly Important Goals

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Chris McChesney, Sean Covey und Jim Huling.

## Worum es geht

Wildly Important Goals (WIGs) stammen aus »The 4 Disciplines of Execution«. Die Idee: Identifiziere jene zwei bis drei Ziele, die wirklich den größten Unterschied machen würden. Die entscheidende Frage ist nicht »Was ist am wichtigsten?«, sondern »Wo wollen wir einen Durchbruch erzielen?«. Das fokussiert auf echte Veränderung, nicht auf das Verwalten des Status quo.

Jedes WIG braucht das Format **From X to Y by When**: Wo stehen wir heute, wo wollen wir hin, bis wann?

Die zentrale Regel: Kein Individuum fokussiert auf mehr als ein WIG gleichzeitig. In einer Organisation kann es Dutzende WIGs geben, aber jede Person, jedes Team hat nur eines. Das klingt radikal, ist aber der Mechanismus, der echten Fokus erzwingt.

## Wann du sie einsetzt

In Phasen, in denen der Fokus kritisch ist:
- bei Turnarounds,
- bei Ressourcenknappheit,
- wenn zu viele parallele Initiativen das Team lähmen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Organisation oder welches Team? Welche Ziele laufen gerade? Was ist die Lage (Turnaround, knappe Ressourcen, zu viele Initiativen)? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Fehlt X, Y oder When? Hat jemand mehr als ein WIG? Benenne Schwächen direkt und kurz.
- Erfinde keine Ausgangs- oder Zielwerte. Fehlt X, markiere es als offen und frag, wie es sich messen lässt.
- Soll die Auswahl im Team stattfinden, biete Moderationsfragen für die Schritte an.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Das Buch beschreibt keinen festen Ablauf. Die Schritte ordnen die Elemente aus dem Buch.

1. **Durchbruch statt Wichtigkeit.** Kandidaten sammeln mit der Frage aus dem Buch.
   Frage: *»Wo wollt ihr einen Durchbruch erzielen?«* Gut ist die Antwort, wenn sie echte Veränderung beschreibt und nicht den laufenden Betrieb.

2. **Auf zwei bis drei verdichten.** Die Ziele, die wirklich den größten Unterschied machen würden.
   Frage: *»Welche zwei oder drei davon würden den größten Unterschied machen?«*

3. **In From X to Y by When übersetzen.** Für jedes WIG: Ausgangswert, Zielwert, Termin.
   Frage: *»Wo steht ihr heute, wo wollt ihr hin, und bis wann?«* Gut ist das WIG, wenn es klar, messbar und unmissverständlich ist.

4. **Ein WIG pro Person und Team zuordnen.**
   Frage: *»Welches Team und welche Person verfolgt welches WIG, und hat jemand mehr als eines?«* Gut ist das Ergebnis, wenn niemand mehr als ein WIG gleichzeitig hat und jedes Team-WIG zum übergeordneten WIG der Organisation beiträgt.

## Beispiel

1958 hatte die NASA vage Ziele wie »The expansion of human knowledge of phenomena in the atmosphere and space«. 1961 formulierte Kennedy ein echtes WIG: »Land a man on the moon and return him safely to earth before this decade is out.« X ist auf der Erde, Y ist auf dem Mond und zurück, When ist Ende 1969.

»Kundenbeziehungen stärken« ist kein WIG. Den »Client-Relationship-Score von 40 auf 70 innerhalb von zwei Jahren steigern« ist eines.

## Worauf du achten musst

- **Vage statt From X to Y by When.** Ohne Ausgangswert, Zielwert und Termin ist es kein WIG. »Kundenbeziehungen stärken« fällt durch.
- **Nach Wichtigkeit statt nach Durchbruch fragen.** Das führt zum Verwalten des Status quo.
- **Mehr als ein WIG pro Person.** Das hebelt den Mechanismus aus, der Fokus erzwingt.
- **Zu viele WIGs auf einmal.** Die Methode ist simpel, aber die Disziplin, sich auf wenige Dinge zu beschränken, ist es nicht. Steve Jobs: »I'm as proud of what we don't do as I am of what we do.«

## Ergebnis

```markdown
# Wildly Important Goals: [Organisation / Team]
Stand: [Datum]

| WIG | From X | To Y | By When | Team / Person |
|---|---|---|---|---|
| … | … | … | … | … |
| … | … | … | … | … |

**Bewusst nicht verfolgt:** …
**Personen oder Teams mit mehr als einem WIG:** keine / … (auflösen)
**Offene Punkte:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Beantwortet jedes WIG die Frage, wo ihr einen Durchbruch wollt?
- Hat jedes WIG X, Y und When?
- Sind es zwei bis drei WIGs, nicht mehr?
- Hat jede Person und jedes Team genau ein WIG?
- Wisst ihr, was ihr dafür bewusst nicht tut?

## Im Flywheel

Modul DRIVE, Bereich D3 Set Strategic Goals.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D3 Set Strategic Goals, Frameworks für strategische Ziele. Originalquelle: Chris McChesney, Sean Covey, Jim Huling: The 4 Disciplines of Execution.
Original: Chris McChesney, Sean Covey, Jim Huling: The 4 Disciplines of Execution. Free Press, 2012.
