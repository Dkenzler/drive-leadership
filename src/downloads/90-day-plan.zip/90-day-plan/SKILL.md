---
name: 90-day-plan
description: "Den eigenen Übergang in eine neue Führungsrolle planen mit dem 90-Day-Plan nach Michael D. Watkins (The First 90 Days), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine neue Führungsrolle antritt, den Job wechselt, eine neue Verantwortung übernimmt, eine Restrukturierung oder neue Unternehmensphase vor sich hat oder die eigenen ersten 90 Tage strukturieren will. Ordnet zuerst die Situation nach STARS ein (Start-up, Turnaround, Accelerated Growth, Realignment, Sustaining Success) und führt dann durch drei Phasen: Verstehen, Einordnen, Ausrichten. Nicht für das Onboarding neuer Mitarbeitender, dafür gibt es den 30/60/90-Day-Plan."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 3 Dich weiterentwickeln und in Übergängen wachsen
  origin: Michael D. Watkins
  deep_dive: false
  version: "1.0"
---

# Der 90-Day-Plan

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Michael D. Watkins.

## Worum es geht

Die ersten 90 Tage in einer neuen Führungsrolle sind die wichtigste Phase, weil du sie nie wieder hast. Du kannst Fragen stellen, ohne als unwissend zu gelten. Du kannst beobachten, ohne sofort entscheiden zu müssen. Du hast einen natürlichen Vertrauensvorschuss, den du nutzt oder vergibst.

Der Grundgedanke aus Michael Watkins' »The First 90 Days«: Eine neue Führungsrolle ist kein Sprint, sondern ein strukturierter Übergang. Wer in den ersten Wochen sofort in den Umsetzungsmodus wechselt, überspringt die Lernphase und baut auf falschen Annahmen. Die Logik gilt immer: erst verstehen, dann gestalten.

Der Plan hat zwei Teile. Zuerst ordnest du die Situation nach STARS ein, denn der Situationstyp verändert den ganzen Plan. Dann planst du drei Phasen, jede mit derselben Struktur: Fokus, Schritte, Ergebnis, Check.

Abgrenzung: Der 30/60/90-Day-Plan im LEAD-Kapitel folgt derselben Logik, dient aber dem Onboarding neuer Teammitglieder. Hier geht es um deinen eigenen Übergang.

## Wann du sie einsetzt

- Beim Start in einer neuen Führungsrolle oder einem neuen Job, idealerweise schon vor dem ersten Tag.
- Wenn ein Unternehmen in eine neue Phase tritt.
- Wenn eine Restrukturierung ansteht.
- Wenn du eine neue Verantwortung übernimmst.
- Wenn sich der Kontext fundamental verändert.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Rolle übernimmt die Person, in welcher Organisation? Wann ist der Start, oder an welchem Tag steht sie gerade? Wer ist ihre Führungskraft, wer sind Direct Reports, Peers und wichtige Stakeholder? Frag nichts, was sie schon gesagt hat.
- Beginne immer mit der STARS-Einordnung. Frag nach der Hypothese der Person und prüf sie. Man hat vorher fast immer eine Einschätzung, aber stimmt sie?
- Geh danach die drei Phasen nacheinander durch. Eine Frage pro Schritt, dann auf die Antwort warten. Steht die Person schon mitten im Übergang, starte bei der aktuellen Phase.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Will die Person in den ersten 30 Tagen schon zu viel verändern?
- Erfinde keine Fakten über Organisation, Team oder Stakeholder. Was die Person noch nicht weiß, wird zur Lernfrage für die ersten 30 Tage.
- Biete an, die fünf Gespräche mit der Führungskraft vorzubereiten.
- Schließe mit dem Plan im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Schritt 0: Situation einordnen mit STARS**

Watkins unterscheidet fünf Grundtypen, deren Anfangsbuchstaben STARS ergeben. Jeder bringt eigene Herausforderungen und Chancen und verändert den ganzen Plan (Abb. 6.7, Vorlage `templates/stars-situation.md`):

| Situation | Worum es geht | Herausforderung | Chance |
|---|---|---|---|
| Start-up | Etwas Neues von Grund auf aufbauen, ohne klaren Rahmen, mit begrenzten Ressourcen. | Ohne Rahmen und mit wenigen Ressourcen starten. | (im Buch nicht eindeutig ausgewiesen) |
| Turnaround | Etwas übernehmen, das anerkanntermaßen in ernsten Schwierigkeiten steckt. | Harte Schritte und Entscheidungen unter Zeitdruck. | Alle wissen, dass Wandel nötig ist, externe Hilfe ist da. |
| Accelerated Growth | Ein schnell wachsendes Geschäft steuern. | Strukturen schaffen, die das Wachstum tragen, und viel Neues integrieren. | Wachstum motiviert, Menschen strecken sich. |
| Realignment | Eine früher erfolgreiche, träge gewordene Einheit führen, die das Problem oft selbst noch nicht sieht. | Überzeugen, dass Veränderung nötig ist. | Es gibt echte Stärken, auf denen man aufbaut. |
| Sustaining Success | Etwas Funktionierendes erben, nicht beschädigen, auf das nächste Niveau bringen. | Im Schatten des Vorgängers das Team führen. | Starkes Team und Fundament sind oft schon da. |

Im Turnaround sind frühe, sichtbare Entscheidungen überlebenswichtig. Im Realignment wäre genau das ein Fehler, weil du erst das Bewusstsein für den Handlungsbedarf schaffen musst. Oft ist es eine Mischung, weil verschiedene Teile der Organisation in unterschiedlichen Situationen stecken.

Frage: *»In welcher Situation startest du, und woran machst du das fest? Gilt das für alle Teile deines Bereichs?«* Gut ist eine Antwort mit Belegen und, wo nötig, einer Aufteilung nach Bereichen. Lies alle folgenden Phasen durch diese Brille.

**Phase 1: Tag 1 bis 30, Verstehen**

- **Fokus:** Zuhören, nicht antworten.
- **Schritte:** So viele strukturierte Gespräche wie möglich, in alle Richtungen: Direct Reports, Peers, Stakeholder, die eigene Führungskraft. Jedes Gespräch einfach vorbereiten: Was will ich über diese Person und ihre Arbeit verstehen? Was sind aus ihrer Sicht die größten Herausforderungen? Welche informellen Machtstrukturen und unausgesprochenen Erwartungen gibt es? Nach jedem Gespräch drei Dinge notieren: Was habe ich gelernt, was hat mich überrascht, welche Muster sehe ich?
- **Ergebnis:** Eine erste Diagnose der Situation und eine Liste der wiederkehrenden Themen.
- **Check:** Du erkennst Muster, die du am ersten Tag nicht gesehen hast, und kannst benennen, wo Konsens herrscht und wo es fundamentale Meinungsverschiedenheiten gibt.

Frage: *»Mit wem führst du in den ersten 30 Tagen Gespräche, und was sind deine Lernziele?«* Gut ist eine Liste, die alle Richtungen abdeckt, nicht nur Direct Reports.

**Phase 2: Tag 31 bis 60, Einordnen**

- **Fokus:** Erste Positionierung.
- **Schritte:** Die Ausgangshypothese mit dem Gelernten abgleichen. Ein erstes Zielbild formulieren, aber noch nicht offiziell teilen, sondern in Einzelgesprächen testen und informelles Feedback holen. Zwei bis drei Quick Wins identifizieren: Verbesserungen, die mit hoher Wahrscheinlichkeit schnell umsetzbar sind und sichtbaren Wert schaffen.
- **Ergebnis:** Ein erstes Zielbild und eine kurze Liste konkreter Quick Wins.
- **Check:** Quick Wins bauen Vertrauen auf, ohne die große Richtung vorwegzunehmen.

Frage: *»Was ist deine Quick-Win-Hypothese, und nimmt einer davon die große Richtung vorweg?«*

**Phase 3: Tag 61 bis 90, Ausrichten**

- **Fokus:** Kommunikation und Richtung.
- **Schritte:** Die Einschätzung breit kommunizieren: Was hast du gelernt, was sind aus deiner Sicht die wichtigsten Prioritäten, was gehst du in den nächsten Monaten an? Aktiv Feedback dazu holen.
- **Ergebnis:** Eine geteilte Standortbestimmung und ein priorisierter Plan für die nächsten Monate.
- **Check:** Die Richtung ist verstanden und trägt. Du wirst nicht alles richtig haben. Feedback einzuholen zeigt hier Stärke, nicht Schwäche.

Frage: *»Wem kommunizierst du deine Einschätzung, in welchem Format, und wie holst du Feedback ein?«*

**Plan aufschreiben und abstimmen**

1. Den Plan als Dokument aufschreiben, nicht als Präsentation, sondern als strukturierten Text in drei Abschnitten: Lernziele für die ersten 30 Tage inklusive der geplanten Gespräche, erste Einschätzungen und Quick-Win-Hypothesen für Tag 30 bis 60, erste Prioritäten und Kommunikationspläne für Tag 60 bis 90.
2. Den Plan früh mit der eigenen Führungskraft teilen. Das signalisiert strukturiertes Denken und schafft gegenseitige Erwartungsklarheit.
3. Die fünf Gespräche nach Watkins über die ersten Wochen verteilen, nicht in einen Termin pressen: Situation (wie schätzt ihr beide die Lage ein, auch im Sinne von STARS?), Erwartungen (was muss in den ersten Monaten erreicht sein?), Arbeitsstil (deiner und der deiner Führungskraft), Ressourcen (was brauchst du?), persönliche Entwicklung in der Rolle.
4. Den Plan an Tag 30 und Tag 60 überprüfen: Was hast du in den letzten Wochen gelernt, und welchen Einfluss hat das auf den Plan?

## Beispiel

Dominik Kenzler hat »The First 90 Days« fünf Mal gelesen und nutzt das Prinzip nicht nur bei Jobwechseln. Vor jedem Start versucht er, erste Insights oder Zugang zur Wissensbasis zu bekommen, eine Art Pre-Onboarding. Der 90-Day-Plan hilft ihm, bei den vielen neuen Eindrücken den Überblick zu behalten und sich mit seiner Führungskraft über Prioritäten und Arbeitsweise abzustimmen. Das STARS-Framework zwingt ihn, seine erste Einschätzung zu prüfen: Wer einen Hammer hat, für den sieht jedes Problem wie ein Nagel aus.

## Worauf du achten musst

- **Zu früh zu viel verändern.** Wer in den ersten 30 Tagen beweisen will, dass er Wirkung erzeugt, riskiert, wichtige Kontexte zu übersehen und das Vertrauen zu verspielen, das er gerade aufbaut. Erste Eindrücke und frühe Entscheidungen prägen oft über Jahre, wie andere dich wahrnehmen.
- **Nur mit Direct Reports sprechen.** Das zweithäufigste Muster. Peers, Stakeholder und das eigene Team werden übersehen. Ein vollständiges Bild entsteht nur, wenn du in alle Richtungen zuhörst.
- **Die eigene Hypothese nicht prüfen.** Die vorab angenommene Situation stimmt nicht immer. STARS zwingt zur Prüfung.
- **Situationstyp ignorieren.** Im Turnaround sind frühe, sichtbare Entscheidungen überlebenswichtig. Im Realignment wäre genau das ein Fehler.
- **Zielbild zu früh offiziell machen.** In Phase 2 wird es in Einzelgesprächen getestet, nicht verkündet.
- **Quick Wins, die die große Richtung vorwegnehmen.** Sie sollen Vertrauen aufbauen, ohne die große Richtung vorwegzunehmen.
- **Alles in ein Gespräch mit der Führungskraft pressen.** Die fünf Gespräche gehören über die ersten Wochen verteilt.

## Ergebnis

Vorlagen: `templates/stars-situation.md` und `templates/90-day-plan.md`.

```markdown
# 90-Day-Plan: [Name], [Rolle], [Organisation]
Start: [Datum] · Review: Tag 30 [Datum], Tag 60 [Datum]

**Situation (STARS):** … · Begründung: … · Teilbereiche in anderer Situation: …

| | Verstehen (Tag 1 bis 30) | Einordnen (Tag 31 bis 60) | Ausrichten (Tag 61 bis 90) |
|---|---|---|---|
| Fokus | Zuhören, nicht antworten | Erste Positionierung | Kommunikation und Richtung |
| Schritte | … | … | … |
| Ergebnis | … | … | … |
| Check | … | … | … |

**Gespräche Phase 1 (Person, Rolle, Lernziel):** …
**Quick-Win-Hypothesen:** …
**Fünf Gespräche mit der Führungskraft:** Situation [Datum] · Erwartungen [Datum] · Arbeitsstil [Datum] · Ressourcen [Datum] · Persönliche Entwicklung [Datum]
**Offene Lernfragen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hast du deine Situation nach STARS eingeordnet und deine erste Hypothese geprüft?
- Führst du in den ersten 30 Tagen Gespräche in alle Richtungen, nicht nur mit Direct Reports?
- Verzichtest du in den ersten 30 Tagen auf große Veränderungen?
- Bauen deine Quick Wins Vertrauen auf, ohne die große Richtung vorwegzunehmen?
- Hast du den Plan mit deiner Führungskraft geteilt und die fünf Gespräche über die ersten Wochen verteilt?

## Im Flywheel

Modul YOURSELF, Teil 3 Dich weiterentwickeln und in Übergängen wachsen.

Verwandte Skills:
- `30-60-90-day-plan`: dieselbe Logik im LEAD-Kapitel, dort für das Onboarding neuer Teammitglieder. Das Buch verweist von dort auf diese Methode.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Methode Der 90-Day-Plan (Abb. 6.7 und 6.8). Originalquelle: Michael D. Watkins: The First 90 Days.

Original: Michael D. Watkins: The First 90 Days. Proven Strategies for Getting Up to Speed Faster and Smarter, Updated and Expanded Edition, Harvard Business Review Press, 2013 (Erstausgabe 2003). STARS auch in: Michael D. Watkins: Picking the Right Transition Strategy, Harvard Business Review, 2009, https://hbr.org/2009/01/picking-the-right-transition-strategy
