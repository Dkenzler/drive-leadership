# 90-Day-Plan

Nach Abb. 6.8 im Drive Leadership Playbook, nach Michael D. Watkins, The First 90 Days. Drei Phasen mit je vier Zeilen: Fokus, Schritte, Ergebnis, Check.

**Name / Rolle:**
**Organisation:**
**Start:**
**Situation (STARS):**
**Review Tag 30:**
**Review Tag 60:**

## VERSTEHEN: Tag 1 bis 30

**Fokus:** Zuhören, nicht antworten.

**Schritte:** Strukturierte Gespräche in alle Richtungen.

| Person | Rolle (Direct Report / Peer / Stakeholder / Führungskraft) | Was will ich verstehen? | Termin |
|---|---|---|---|
| | | | |

Nach jedem Gespräch: Was habe ich gelernt? Was hat mich überrascht? Welche Muster sehe ich?

**Ergebnis:** Erste Diagnose der Situation.

**Check:** Du erkennst neue Muster.

## EINORDNEN: Tag 31 bis 60

**Fokus:** Erste Positionierung.

**Schritte:** Zielbild testen, Quick Wins identifizieren.

Erstes Zielbild (noch nicht offiziell, in Einzelgesprächen testen):

Quick-Win-Hypothesen (zwei bis drei):
1.
2.
3.

**Ergebnis:** Zielbild und Liste an Quick Wins.

**Check:** Quick Wins bauen Vertrauen auf.

## AUSRICHTEN: Tag 61 bis 90

**Fokus:** Kommunikation und Richtung.

**Schritte:** Einschätzung breit teilen, Feedback einholen.

Was ich gelernt habe:

Wichtigste Prioritäten aus meiner Sicht:

Was ich in den nächsten Monaten angehe:

Kommunikationsplan (wem, wie, wann):

**Ergebnis:** Geteilte Richtung, priorisierter Plan.

**Check:** Die Richtung trägt.

## Fünf Gespräche mit meiner Führungskraft

| Gespräch | Termin | Notizen |
|---|---|---|
| Situation (auch im Sinne von STARS) | | |
| Erwartungen (was muss in den ersten Monaten erreicht sein?) | | |
| Arbeitsstil (meiner und der meiner Führungskraft) | | |
| Ressourcen | | |
| Persönliche Entwicklung in der Rolle | | |
