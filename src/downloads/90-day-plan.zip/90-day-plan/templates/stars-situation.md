# STARS: In welcher Situation startest du?

Nach Abb. 6.7 im Drive Leadership Playbook, nach Michael D. Watkins, The First 90 Days.

**Name / Rolle:**
**Organisation / Bereich:**
**Datum:**

| | START-UP | TURNAROUND | ACC. GROWTH | REALIGNMENT | SUSTAINING |
|---|---|---|---|---|---|
| **Kurz** | Etwas Neues von Grund auf aufbauen. | Etwas in erster Krise retten. | Schnelles Wachstum steuern. | Träge gewordene Einheit aufwecken. | Erfolg sichern und weiterentwickeln. |
| **Herausforderung** | Ohne Rahmen und mit wenigen Ressourcen starten. | Harte Schritte und Entscheidungen unter Zeitdruck. | Strukturen schaffen und viel Neues integrieren. | Überzeugen, dass Veränderung nötig ist. | Im Schatten des Vorgängers das Team führen. |
| **Chance** | (in der Abbildung nicht eindeutig ausgewiesen) | Alle wissen, dass Wandel nötig ist, externe Hilfe da. | Wachstum motiviert, Menschen strecken sich. | Es gibt echte Stärken, auf denen man aufbaut. | Starkes Team und Fundament sind oft schon da. |
| **Trifft auf mich zu (ja/teilweise/nein)** | | | | | |

## Meine Einordnung

**Meine Hypothese vor dem Start:**

**Belege dafür:**

**Belege dagegen:**

**Teile meines Bereichs in einer anderen Situation:**

| Teilbereich | Situation | Woran ich das festmache |
|---|---|---|
| | | |

**Was das für meinen Plan bedeutet:**
