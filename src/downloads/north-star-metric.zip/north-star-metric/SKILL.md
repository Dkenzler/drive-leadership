---
name: north-star-metric
description: Eine North Star Metric finden und mit Input-Metriken unterlegen, aus dem Drive Leadership Playbook von Dominik Kenzler, mit dem North Star Metric Framework nach John Cutler. Nutze diesen Skill, wenn jemand die eine zentrale Value-Metrik für Unternehmen oder Produkt bestimmen, die Organisation auf eine strategische Größe fokussieren, Input-Metriken ableiten oder einen Kompass für Produktentscheidungen und Zielkonflikte schaffen will (»Welche Option verbessert unsere North Star Metric?«). Grenzt die North Star Metric von Revenue-Metriken und vom OMTM ab.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D3 Set Strategic Goals
  origin: John Cutler (Framework-Darstellung)
  deep_dive: false
  version: "1.0"
---

# North Star Metric

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach John Cutler (North Star Metric Framework, Abb. 3.9).

## Worum es geht

Die North Star Metric ist eine zentrale Metrik, die den Kernwert des Unternehmens für seine Nutzer misst. Sie fokussiert die gesamte Organisation auf eine einzige strategische Größe. Die Idee: Wenn diese eine Metrik steigt, geht es dem Unternehmen gut, weil sie den Wert misst, den Nutzer tatsächlich erhalten.

Die North Star Metric ist keine Revenue-Metrik, sondern eine Value-Metrik. Revenue folgt, wenn der Wert stimmt. Sie misst den Erfolg, die Input-Metriken sagen, woran man dafür arbeitet.

Das Framework nach John Cutler ordnet die Metriken in Ebenen:
- **Focus Metric:** die Metrik, die für dein Geschäft am wichtigsten ist.
- **Level 1 Metrics:** Metriken, die die Fokusmetrik ergänzen.
- **Level 2 Metrics:** Metriken, die die L1- und die Fokusmetrik antreiben.

Den Rahmen dafür bildet deine Wachstumsstrategie.

## Wann du sie einsetzt

- Als Kompass für Produktentscheidungen.
- Bei Zielkonflikten, mit der Frage: Welche Option verbessert unsere North Star Metric?
- Wenn Initiativen und Features eine gemeinsame Richtung brauchen, auf die sie einzahlen.

Sie ersetzt nicht die Strategic Objectives, gibt ihnen aber eine gemeinsame Richtung.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Unternehmen oder Produkt? Welchen Wert erhalten die Nutzer? Gibt es bereits eine zentrale Metrik oder Strategic Objectives? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist der Vorschlag in Wahrheit eine Revenue-Metrik? Benenne Schwächen direkt und kurz.
- Erfinde keine Zahlen oder Nutzungsdaten der Person. Fehlt etwas, markiere es als offen.
- Arbeitet die Person mit einem Team, biete Moderationsfragen für die Schritte an.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Das Buch beschreibt keinen festen Ablauf. Die Schritte ordnen die Elemente aus Text und Abbildungen 3.9 und 3.10.

1. **Kernwert benennen.** Welchen Wert erhalten die Nutzer tatsächlich?
   Frage: *»Was bekommen eure Nutzer von euch, wofür sie wiederkommen?«* Gut ist die Antwort, wenn sie aus Sicht der Nutzer formuliert ist, nicht aus Sicht des Umsatzes.

2. **Die eine Metrik festlegen (Focus Metric).** Eine Größe, die diesen Wert misst.
   Frage: *»Wenn nur eine Zahl steigen dürfte und es euch dann gut ginge, welche wäre es?«* Gut ist die Antwort, wenn es eine einzige Metrik ist und sie Value misst, nicht Revenue.

3. **Input-Metriken ableiten.** Welche Metriken ergänzen die Fokusmetrik (Level 1), welche treiben sie an (Level 2)?
   Frage: *»Woran arbeiten eure Teams konkret, damit die North Star Metric steigt?«* Gut ist die Antwort, wenn jede Input-Metrik erkennbar auf die Fokusmetrik wirkt.

4. **Initiativen zuordnen.** Features und Initiativen zahlen auf die North Star Metric ein.
   Frage: *»Welche eurer aktuellen Initiativen verbessert welche Input-Metrik?«*

5. **Als Entscheidungskompass testen.** An einem echten Zielkonflikt prüfen.
   Frage: *»Nenn mir eine aktuelle Entscheidung zwischen zwei Optionen. Welche verbessert eure North Star Metric?«* Gut ist das Ergebnis, wenn die Metrik die Entscheidung tatsächlich leichter macht.

## Beispiel

- Spotify: »Time spent listening.«
- Airbnb: »Nights booked.«
- Facebook: »Daily Active Users.«

Die North Star Metric von Spotify zielt auf die Zeit, die User mit Musikhören verbringen. Viele Initiativen richten sich an ihr aus. Ein neues Feature wie die Spotify-Playlists zahlt am Ende auf die North Star Metric ein.

Abb. 3.10 (nach Paul Johann Dollinger) zeigt das Framework an einer Musik-Streaming-App:
- North Star: Zeit, die User mit Musikhören verbringen.
- Input-Metriken (in zwei Ebenen): User hören wiederkehrend Musik, User hören länger Musik, Neue Songs entdecken, Empfehlungen, User erstellen Playlisten, Benachrichtigungen über neue Künstler.

## Worauf du achten musst

- **Revenue statt Value.** Die North Star Metric misst den Wert für die Nutzer. Revenue folgt, wenn der Wert stimmt.
- **Mehr als eine Metrik.** Sie fokussiert die Organisation auf eine einzige Größe.
- **Keine Input-Metriken.** Die North Star Metric misst den Erfolg. Ohne Input-Metriken wissen Teams nicht, woran sie dafür arbeiten.
- **Als Ersatz für Strategic Objectives.** Sie gibt den Objectives eine gemeinsame Richtung, ersetzt sie aber nicht.
- **Mit OMTM verwechseln.** Die North Star Metric ist langfristig und strategisch und verändert sich selten. OMTM ist kurzfristig und operativ, der Fokus für dieses Quartal.

## Ergebnis

```markdown
# North Star Metric: [Unternehmen / Produkt]
Stand: [Datum]

**Wachstumsstrategie (Rahmen):** …
**Kernwert für die Nutzer:** …

**North Star Metric (Focus Metric):** …

| Level 1 Metric (ergänzt die Fokusmetrik) | Level 2 Metrics (treiben L1 und Fokusmetrik an) |
|---|---|
| … | … |
| … | … |

**Initiativen und worauf sie einzahlen:**
- … → …

**Kompass-Test:** Entscheidung … · Option, die die North Star Metric verbessert: …
**Offene Punkte:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Misst eure North Star Metric den Wert für die Nutzer und nicht den Umsatz?
- Ist es genau eine Metrik?
- Habt ihr Input-Metriken, an denen Teams konkret arbeiten können?
- Hilft die Metrik bei einem echten Zielkonflikt, zu entscheiden?
- Ist klar, wie sie sich zu euren Strategic Objectives verhält?

## Im Flywheel

Modul DRIVE, Bereich D3 Set Strategic Goals.

Verwandte Skills:
- `strategic-objectives`: Die North Star Metric gibt den Strategic Objectives eine gemeinsame Richtung, ersetzt sie aber nicht.
- `omtm`: OMTM ist die kurzfristige, operative Fokusmetrik für eine Phase. Die North Star Metric ist langfristig und strategisch.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D3 Set Strategic Goals, Frameworks für strategische Ziele, Abb. 3.9 North Star Metric Framework nach John Cutler, Abb. 3.10 nach Paul Johann Dollinger. Abgrenzung zu OMTM im Kapitel SHIP, S1 Set Goals.

Original: John Cutler, Jason Scherschligt: The North Star Playbook, Amplitude, 2019. https://amplitude.com/books/north-star
