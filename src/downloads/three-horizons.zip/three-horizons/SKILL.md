---
name: three-horizons
description: Aktivitäten und Initiativen nach Zeithorizont sortieren und die Balance zwischen Gegenwart und Zukunft prüfen mit dem Drei-Horizonte-Modell (Three Horizons of Growth) nach McKinsey, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Strategie oder ein Portfolio auf den richtigen Mix aus Kerngeschäft, Wachstumsinitiativen und Zukunftswetten prüfen, Ressourcen zwischen kurz-, mittel- und langfristigen Themen verteilen oder erkennen will, ob eine Organisation zu stark im Heute feststeckt oder zu viel auf eine unsichere Zukunft setzt.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D2 Strategy
  origin: McKinsey
  deep_dive: false
  version: "1.0"
---

# Drei Horizonte

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach McKinsey.

## Worum es geht

Das Drei-Horizonte-Modell stammt ursprünglich von McKinsey und hilft, Aktivitäten nach dem Zeithorizont zu sortieren. Als Unternehmen, aber auch in jeder Führungsrolle, muss man parallel in kurz-, mittel- und langfristige Themen investieren. Manche Dinge muss man heute anstoßen, damit sie in ein paar Jahren Wirkung zeigen können.

| Horizont | Was | Stoßrichtung | Zeitraum |
|---|---|---|---|
| Horizont 1 | Kerngeschäft: was heute Geld verdient | Kerngeschäft verteidigen und ausbauen | 1 bis 2 Jahre |
| Horizont 2 | Wachstumsinitiativen: was morgen relevant wird | Neue Geschäftsfelder aufbauen | 3 bis 5 Jahre |
| Horizont 3 | Zukunftswetten: was übermorgen entscheidend sein könnte | Zukünftige Geschäftsfelder entwickeln | 5+ Jahre |

Das Modell macht sichtbar, wann strategische Optionen wirken und ob die Balance zwischen Gegenwart und Zukunft stimmt. Alle drei Horizonte brauchen Aufmerksamkeit, und das gleichzeitig. Die Verteilung ist eine Leadership-Entscheidung.

## Wann du sie einsetzt

- Strategien überprüfen: Zahlen zu viele Themen auf kurzfristige oder langfristige Ziele ein? Stimmt der Mix?
- Prüfen, ob die Ressourcenverteilung zum Mix passt.
- Erkennen, ob eine Organisation heute zu stark feststeckt oder zu viel auf eine unsichere Zukunft setzt.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Ebene gilt die Betrachtung (Unternehmen, Bereich, eigene Führungsrolle)? Gibt es eine Strategie oder eine Liste von Initiativen, die geprüft werden soll? Wie werden Ressourcen heute verteilt? Frag nichts, was die Person schon gesagt hat.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Zuordnung. Eine Initiative, die heute Geld verdient, ist kein Horizont 3, auch wenn sie sich neu anfühlt.
- Setz keine Zielverteilung als richtig. Die Zahlen verschieben sich je nach Situation. Die Verteilung entscheidet die Führungskraft.
- Erfinde keine Zahlen zu Budget, Umsatz oder Kapazität. Fehlt etwas, markiere es als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Themen sammeln.** Alle laufenden und geplanten Themen, Initiativen oder strategischen Optionen auflisten.
   Frage: *»Woran arbeitet ihr, und was ist geplant?«*

2. **Horizonte zuordnen.** Jedes Thema einem Horizont zuordnen: Kerngeschäft, Wachstumsinitiative oder Zukunftswette.
   Frage: *»Verdient dieses Thema heute Geld, wird es morgen relevant, oder könnte es übermorgen entscheidend sein?«*
   Gut ist die Zuordnung, wenn sie sich am Zeitpunkt der Wirkung orientiert, nicht am Neuigkeitsgefühl.

3. **Den Mix prüfen.** Zahlen zu viele Themen auf kurzfristige oder auf langfristige Ziele ein? Steckt die Organisation heute zu stark fest, oder setzt sie zu viel auf eine unsichere Zukunft?
   Frage: *»Wenn du auf die Verteilung schaust: Wo ist es zu viel, wo zu wenig?«*
   Gut ist die Antwort, wenn jeder der drei Horizonte bewusst besetzt ist oder bewusst nicht.

4. **Die Ressourcenverteilung prüfen.** Passt die Verteilung von Zeit, Menschen und Geld zum gewünschten Mix? Orientierung bietet die 70-20-10-Regel, aber die genauen Zahlen sind nicht das Entscheidende.
   Frage: *»Welche Verteilung passt zu eurer Situation, eurer Strategie und dem, was gerade im Markt passiert?«*
   Gut ist die Antwort, wenn sie eine bewusste Verteilung benennt und begründet.

## Beispiel

Google hat das Prinzip mit der 70-20-10-Regel bekannt gemacht: 70 Prozent der Ressourcen fürs Kerngeschäft, 20 Prozent für angrenzende Projekte, zehn Prozent für transformative Ideen.

Die Zahlen verschieben sich je nach Situation. Shreyas Doshi, ehemals Product Manager bei Google und Stripe, beschreibt es so:

»Angesichts unserer Situation, unserer Strategie und dessen, was gerade im Markt passiert, möchte ich, dass wir etwa 60 Prozent unserer Zeit auf inkrementelle Verbesserungen verwenden, 30 Prozent auf große neue Initiativen und zehn Prozent auf Stabilität und Infrastruktur.«

## Worauf du achten musst

Das Buch nennt keine typischen Fehler. Die Punkte folgen aus der Beschreibung.

- **Nur einen Horizont bedienen.** Alle drei brauchen Aufmerksamkeit, gleichzeitig.
- **Zu stark im Heute feststecken.** Was nicht heute angestoßen wird, wirkt in ein paar Jahren nicht.
- **Zu viel auf eine unsichere Zukunft setzen.** Das Gegenstück zum Feststecken im Heute.
- **Feste Prozentsätze übernehmen.** 70-20-10 ist Orientierung, keine Regel. Die Verteilung ist eine Führungsentscheidung.
- **Mix und Ressourcen trennen.** Ein guter Mix auf dem Papier nützt nichts, wenn die Ressourcen anders verteilt sind.

## Ergebnis

```markdown
# Drei Horizonte: [Organisation / Bereich]
Stand: [Datum]

| Horizont | Themen / Initiativen | Anteil Ressourcen heute | Anteil Ressourcen Ziel |
|---|---|---|---|
| H1 Kerngeschäft (1 bis 2 Jahre) | … | …% | …% |
| H2 Wachstumsinitiativen (3 bis 5 Jahre) | … | …% | …% |
| H3 Zukunftswetten (5+ Jahre) | … | …% | …% |

**Befund zum Mix:** …
**Entscheidung zur Verteilung und Begründung:** …
**Offen:** …
```

## Mini-Check

Aus der Drive Checklist (Strategic Planning):
- Gibt es einen Plan, der zeigt, was ihr wann angeht?

(abgeleitet aus den typischen Fehlern)
- Ist jeder der drei Horizonte bewusst besetzt?
- Orientiert sich die Zuordnung am Zeitpunkt der Wirkung?
- Passt die tatsächliche Ressourcenverteilung zum gewünschten Mix?
- Ist die Verteilung eine begründete Entscheidung und keine übernommene Formel?

## Im Flywheel

Modul DRIVE, Bereich D2 Strategy.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D2 Strategy (Abb. 3.7 »Three Horizons of Growth nach McKinsey«). Originalquelle: McKinsey.
Original: Mehrdad Baghai, Stephen Coley, David White (McKinsey): The Alchemy of Growth, 1999. Zusammenfassung: McKinsey, Enduring Ideas: The three horizons of growth, 2009, https://www.mckinsey.com/capabilities/strategy-and-corporate-finance/our-insights/enduring-ideas-the-three-horizons-of-growth
