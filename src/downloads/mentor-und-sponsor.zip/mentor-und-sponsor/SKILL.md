---
name: mentor-und-sponsor
description: Mentoren finden und Sponsoren aufbauen für die eigene Karriereentwicklung, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand einen Mentor oder eine Mentorin sucht, eine Mentoring-Anfrage formulieren, das erste Mentoring-Gespräch vorbereiten, mehr Sichtbarkeit und Fürsprache für die eigene Arbeit aufbauen oder den Unterschied zwischen Mentor und Sponsor verstehen will. Auch für Führungskräfte, die selbst Mentor oder Sponsor für Mitarbeitende sein wollen. Führt durch eine Bestandsaufnahme, die Suche nach einem Mentor und die Bedingungen für Sponsoring.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 3 Dich weiterentwickeln und in Übergängen wachsen
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Mentor und Sponsor

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Mentor und Sponsor sind zwei verschiedene Rollen, die oft verwechselt werden. Der Unterschied ist fundamental, und beide zu haben ist ein wirksamer Hebel für die langfristige Karriereentwicklung.

- **Ein Mentor** gibt dir Rat, Perspektive und Reflexion. Er kennt deine Arbeit, deine Stärken und Schwächen und hilft dir, dich selbst besser zu verstehen. Das Gespräch ist oft informell, regelmäßig und persönlich. Ein guter Mentor stellt die richtigen Fragen und gibt selten fertige Antworten, weil die Antworten von dir kommen müssen. Solche Hinweise bekommt man nur von jemandem, der einen gut kennt, einem etwas zutraut und ehrlich genug ist, unbequeme Dinge anzusprechen.
- **Ein Sponsor** spricht für dich, wenn du nicht im Raum bist. Er öffnet Türen, empfiehlt dich für Möglichkeiten und setzt seinen eigenen Ruf ein, um dir zu helfen. Sponsoring passiert nicht durch Gespräche mit dir, sondern durch Gespräche über dich. »Du solltest Dominik für dieses Projekt in Betracht ziehen« ist Sponsoring. »Du solltest mehr Sichtbarkeit anstreben« ist Mentoring.

Ein Mentor ohne Sponsor gibt dir Wachstum ohne Sichtbarkeit. Du wirst besser, aber die Türen öffnen sich nicht, weil niemand weiß, dass du längst bereit bist. Die Kombination ist mächtig: ein Mentor, der dir hilft, wirklich gut zu werden, und ein Sponsor, der dafür sorgt, dass die richtigen Menschen das sehen.

Die Beziehung geht in beide Richtungen: Sie ist eine beiderseitige Gewinnbeziehung, und wer selbst Mentoren und Sponsoren hatte, sollte es weitergeben.

## Wann du sie einsetzt

- Wenn du einen Mentor suchst oder eine Mentoring-Anfrage stellen willst.
- Wenn du das erste Gespräch mit einem Mentor vorbereitest.
- Wenn du dich entwickelst, aber Türen sich nicht öffnen, weil deine Arbeit zu wenig sichtbar ist.
- Wenn du als Führungskraft selbst Mentor und Sponsor für deine Mitarbeitenden sein willst.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wo steht die Person beruflich, und wohin will sie? Hat sie heute Mentoren oder Sponsoren? Sucht sie einen Mentor, will sie Sponsoring aufbauen, oder will sie selbst Mentor und Sponsor sein? Frag nichts, was sie schon gesagt hat.
- Geh die Teile des Ablaufs durch, die zum Anliegen passen. Eine Frage pro Schritt, dann auf die Antwort warten.
- Nenne keine konkreten Personen als mögliche Mentoren oder Sponsoren, die die Person nicht selbst genannt hat.
- Challenge Antworten gegen »Worauf du achten musst«. Benenne direkt, wenn die Person Mentor und Sponsor verwechselt oder Sponsoring erzwingen will.
- Biete an, die Mentoring-Anfrage und die drei wichtigsten Fragen für das erste Gespräch zu formulieren.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Bestandsaufnahme.** Frage: *»Wer gibt dir heute Rat und Perspektive, und wer spricht für dich, wenn du nicht im Raum bist?«* Die Antworten den beiden Rollen zuordnen. Gut ist eine Antwort, die zeigt, wo eine der beiden Rollen fehlt.

2. **Mentor finden: Kandidaten.** Mentoren findet man durch Gespräche. Frage: *»Wer ist einen Weg gegangen, den du gehen willst? Wen bewunderst du, und warum? Wessen Führungsstil inspiriert dich?«* Nicht nur an offensichtliche Vorbilder denken. Oft sitzen die besten Mentoren im direkten Umfeld: Menschen aus dem Arbeitsalltag, Peers, Leute aus dem Netzwerk. Entscheidend ist die Chemie. Eine Mentoring-Beziehung trägt nur, wenn sie auf beiden Seiten stimmt.

3. **Mentor finden: direkt fragen.** Nicht mit einer langen E-Mail, die erklärt, wie viel du lernen könntest, sondern kurz und ehrlich, etwa: »Ich bewundere, wie du X gemacht hast. Wärst du bereit, dich einmal im Quartal mit mir zu treffen und mir deine Zeit zu schenken?« Die meisten erfahrenen Führungskräfte sagen Ja, wenn jemand so klar fragt.
   Frage: *»Wie lautet deine Anfrage in zwei Sätzen?«*

4. **Erstes Gespräch vorbereiten.** Frage: *»Was willst du aus dieser Mentoring-Beziehung mitnehmen? Was sind deine drei wichtigsten Fragen?«* Ein gut vorbereitetes erstes Gespräch zeigt, dass du die Zeit des Mentors respektierst und ernsthaft lernst.

5. **Sponsor aufbauen: Bedingungen prüfen.** Sponsoren entstehen nicht durch Fragen, sondern durch Vertrauen. Jemand wird dein Sponsor, wenn drei Bedingungen erfüllt sind:
   - Er kennt deine Arbeit aus erster Hand und schätzt sie.
   - Er glaubt, dass deine Entwicklung seinen eigenen Ruf stärkt.
   - Er hat genug Einfluss, um aktiv zu helfen.

   Frage: *»Wer erfüllt heute schon eine oder zwei dieser Bedingungen, und welche fehlt?«*

6. **Sponsor aufbauen: Bedingungen schaffen.** Du kannst nicht erzwingen, dass jemand dein Sponsor wird, aber du kannst die Bedingungen schaffen: in den richtigen Räumen präsent sein, sichtbar gute Arbeit leisten, Beziehungen mit Menschen pflegen, die Einfluss haben (nicht als Networking-Taktik, sondern als echte Verbindung), und durch Ergebnisse zeigen, dass eine Empfehlung von dir eine sichere Wette ist.
   Frage: *»Was tust du in den nächsten drei Monaten, damit die richtigen Menschen deine Arbeit aus erster Hand kennen?«*

7. **Selbst Mentor und Sponsor sein.** Frage: *»Für wen in deinem Team bist du Mentor, und für wen sprichst du, wenn diese Person nicht im Raum ist?«* Die besten Leader tun beides gleichzeitig: Sie lernen von oben und geben nach unten weiter.

## Beispiel

Nach dem Studium gründete Dominik Kenzler mit Dark Horse seine zweite eigene Firma und war dort neun Jahre. Jede der fünf Start-up-Rollen danach kam über Sponsoren oder Mentoren zustande. Oliver Kunath war CFO bei sevdesk, die beiden arbeiteten eng zusammen. Er vernetzte Dominik mit zwei der Gründer von vialytics. Aus dem Austausch entstand das Angebot für die Rolle als CPTO. Entscheidend: Oliver kannte beide Seiten genau, Dominik und seine Arbeitsweise ebenso wie das Unternehmen. Das erhöhte die Wahrscheinlichkeit für einen guten Fit für alle Beteiligten.

Seine prägenden Mentoren, Mate Galic bei Native Instruments und Nicholas Goubert, standen ihm auch Jahre später noch zur Seite, als sie längst nicht mehr seine Vorgesetzten waren. Eine gute Mentoring-Beziehung endet nicht mit dem gemeinsamen Arbeitsverhältnis.

## Worauf du achten musst

- **Mentor und Sponsor verwechseln.** Rat ist keine Fürsprache. Wer nur Mentoren hat, wächst ohne Sichtbarkeit.
- **Lange, erklärende Anfragen.** Kurz und ehrlich fragen wirkt besser.
- **Nur offensichtliche Vorbilder ansprechen.** Die besten Mentoren sitzen oft im direkten Umfeld.
- **Chemie ignorieren.** Die Beziehung trägt nur, wenn sie auf beiden Seiten stimmt.
- **Unvorbereitet ins erste Gespräch.** Ein gutes erstes Gespräch zeigt dem Mentor, dass du seine Zeit respektierst und ernsthaft lernst.
- **Sponsoring erfragen wollen.** Sponsoren entstehen nicht durch Fragen, sondern durch Vertrauen. Erzwingen kannst du es nicht.
- **Networking als Taktik.** Beziehungen zu einflussreichen Menschen tragen nur als echte Verbindung.
- **Nur nehmen.** Die Beziehung geht in beide Richtungen. Gib selbst weiter.

## Ergebnis

```markdown
# Mentor und Sponsor: [Name]
Stand: [Datum]

| Person | Rolle heute (Mentor / Sponsor / keine) | Was sie für mich tut |
|---|---|---|

## Mentor
**Kandidat:innen (und warum):** …
**Meine Anfrage:** »…«
**Was ich aus der Beziehung mitnehmen will:** …
**Meine drei wichtigsten Fragen:** 1. … 2. … 3. …

## Sponsor
| Person | Kennt meine Arbeit aus erster Hand | Meine Entwicklung stärkt ihren Ruf | Genug Einfluss |
|---|---|---|---|

**Was ich in den nächsten drei Monaten tue, um die Bedingungen zu schaffen:** …

## Selbst Mentor und Sponsor
**Für wen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Kannst du für dich klar benennen, wer Mentor und wer Sponsor ist, und wo eine Rolle fehlt?
- Ist deine Mentoring-Anfrage kurz, ehrlich und konkret?
- Hast du für das erste Gespräch ein Ziel und drei Fragen?
- Kennen Menschen mit Einfluss deine Arbeit aus erster Hand?
- Für wen bist du selbst Mentor oder Sponsor?

## Im Flywheel

Modul YOURSELF, Teil 3 Dich weiterentwickeln und in Übergängen wachsen. Das Buch verbindet die Methode mit dem LEAD-Kapitel: Mentoring und Sponsoring sind ein zentraler Teil davon, wie du deine Mitarbeitenden entwickelst (L5 Grow Your People).

Verwandte Skills:
- `executive-presence`: Den Hinweis auf Executive Presence bekam Dominik Kenzler von seinem Mentor Mate Galic, ein Beispiel für die Rolle eines Mentors.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Methode Mentor und Sponsor.
