---
name: now-next-later
description: Eine Roadmap im Format Now, Next, Later nach Janna Bastow und Simon Cast aufbauen, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand eine Roadmap ohne feste Termine erstellen, Vorhaben nach Nähe und Gewissheit statt nach Datum ordnen, lange Diskussionen über Deadlines und Machbarkeit vermeiden, zu viel parallele Arbeit im Now sichtbar machen oder eine operative Teamplanung in schnelllebigem Umfeld aufsetzen will. Auch als Ergänzung zur GO Product Roadmap für Stakeholder.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D4 Guiding Principles (Strategic Planning)
  origin: Janna Bastow und Simon Cast
  deep_dive: false
  version: "1.0"
---

# Now, Next, Later

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Janna Bastow und Simon Cast.

## Worum es geht

Now, Next, Later wurde 2012 von Janna Bastow und Simon Cast erfunden. Das Format verzichtet bewusst auf feste Termine. Bastow nennt klassische Timeline-Roadmaps »date theater«, ein Schauspiel, bei dem alle so tun, als wären die Deadlines realistisch.

Das Format ordnet alle Vorhaben in drei Spalten, die sich nicht nach Zeit unterscheiden, sondern nach Nähe und Gewissheit (Abb. 3.17):

| Spalte | Frage | Detailtiefe und Konfidenz | Typisch |
|---|---|---|---|
| **Now** | Woran arbeiten wir gerade? | Höchste Detailtiefe, hohe Konfidenz, konkret und committed. | zwei bis vier Wochen |
| **Next** | Was kommt als Nächstes? | Mittlere Detailtiefe und Konfidenz, Richtung steht, Details offen. | ein bis drei Monate |
| **Later** | Was ist auf dem Radar? | Geringe Detailtiefe, niedrige Konfidenz, bewusst grob gehalten, ohne Garantie. | |

**Die Prinzipien:** Priorität statt Timeline, abnehmende Detailtiefe, kontinuierlicher Flow. Items wandern von rechts nach links, sobald sie reifer und gewisser werden. Das unterstützt »Stop starting, start finishing« und zeigt sofort, wenn zu viel gleichzeitig im Now steckt.

Now, Next, Later ist immer ein guter Startpunkt, weil es viele langwierige Diskussionen vermeidet, die sich um Deadlines und Machbarkeit drehen. Strategie soll beantworten, was wir tun sollen und warum. Wie genau wir das tun, ist eine Frage der Umsetzung.

## Wann du sie einsetzt

- In schnelllebigen Umfeldern.
- Als operative Teamplanung.
- Ergänzend zur GO Product Roadmap für Stakeholder.
- Als Timeframe-Format einer strategischen Roadmap.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Team oder Produkt? Für wen ist die Roadmap (Team, Stakeholder)? Gibt es eine bestehende Liste von Vorhaben? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Steckt zu viel im Now? Tauchen Termine auf? Benenne das direkt und kurz.
- Erfinde keine Vorhaben der Person. Fehlt etwas, markiere es als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Das Buch beschreibt keinen festen Ablauf. Die Schritte ordnen die Spalten und Prinzipien aus dem Buch.

1. **Vorhaben sammeln.** Frage: *»Welche Vorhaben habt ihr gerade auf dem Tisch, egal wie konkret?«*

2. **Now füllen.** Frage: *»Woran arbeitet ihr gerade, konkret und committed?«* Gut ist die Antwort, wenn die Items detailliert beschrieben sind und das Team sie in etwa zwei bis vier Wochen abschließen kann. Frag nach, wenn es mehr ist, als das Team gleichzeitig fertigstellen kann.

3. **Next füllen.** Frage: *»Was kommt als Nächstes, wo steht die Richtung, aber die Details sind offen?«* Typischer Horizont: ein bis drei Monate.

4. **Later füllen.** Frage: *»Was ist auf dem Radar, bewusst grob?«* Gut ist die Antwort, wenn die Einträge grob bleiben und nicht als Zusage formuliert sind.

5. **Flow prüfen.** Frage: *»Was ist reif genug, um nach links zu wandern, und was liegt im Later, das ihr eigentlich streichen könntet?«*

## Beispiel

Im Kapitel SHIP zeigt Abb. 5.8 eine fiktive Team-Roadmap im Now-Next-Later-Prinzip für ein Invoice-Team bei sevdesk (Spalten Current, Near Term, Future, Vermerk »Subject to Change«):
- Current: Rabatte (in Entwicklung), wiederkehrende Rechnungen (Testing), E-Invoice-Funktionalität für XRechnung und ZUGFeRD (in Entwicklung).
- Near Term: Realtime Preview (Discovery), WYSIWYG Editor (Discovery).
- Future: AI Price Suggestions (Idee), AI Enhanced Writing (Idee).

## Worauf du achten musst

- **Zu viel im Now.** Dann wird nichts wirklich fertig.
- **Later als Friedhof statt als Radar.** Later ist Radar, kein Ablageort für alles, was nie wandert.
- **Versteckte Deadlines.** Sie bringen das »date theater« zurück.
- **Nur Machbarkeit planen.** Ginge es immer nur darum, was mit den jetzigen Ressourcen machbar ist, könnte keine Organisation Innovationen realisieren. Die Diskussion um Deadlines und Machbarkeit kann bei strategischen Plänen in die Irre führen und viel Zeit kosten.

## Ergebnis

Vorlage: `templates/now-next-later.md`.

```markdown
# Now, Next, Later: [Team / Produkt]
Stand: [Datum] · Kann sich ändern.

| Now (hohe Konfidenz) | Next (mittlere Konfidenz) | Later (niedrige Konfidenz) |
|---|---|---|
| Was aktuell in Umsetzung ist, konkret und committed | Was als Nächstes ansteht, Richtung steht, Details offen | Ideen für später, bewusst grob |
| … | … | … |
| … | … | … |

**Wandert als Nächstes nach links:** …
**Aus Later gestrichen:** …
**Offene Punkte:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Passt das Now zu dem, was das Team gleichzeitig wirklich fertigstellen kann?
- Ist das Later ein Radar, oder liegen dort Items, die nie wandern?
- Ist die Roadmap frei von versteckten Deadlines?
- Nimmt die Detailtiefe von Now über Next zu Later ab?
- Ist klar, welche Items als Nächstes nach links wandern?

## Im Flywheel

Modul DRIVE, Bereich D4 (im Buch »Guiding Principles«, inhaltlich Strategic Planning).

Verwandte Skills:
- `go-product-roadmap`: Now, Next, Later ergänzt die GO Product Roadmap für Stakeholder.
- `roadmap-anatomy`: Now, Next, Later ist ein mögliches Format für die Timeframes einer Roadmap.
- `team-roadmap`: die operative Seite im Kapitel SHIP, also wie du eine Roadmap im Alltag führst und lebendig hältst.
- `shape-up`: Die Roadmap kommuniziert die strategische Richtung, Shape Up formt die einzelnen Vorhaben darin als Bets.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D4 Guiding Principles, Frameworks für Strategic Planning, Abb. 3.17 (im Buch fälschlich als »OGSM-Modell« beschriftet, zeigt die Now-Next-Later-Roadmap). Beispiel aus Kapitel SHIP, Abb. 5.8. Originalquelle: Janna Bastow und Simon Cast.

Original: Janna Bastow: Why I Invented the Now-Next-Later Roadmap, ProdPad, 2022. https://www.prodpad.com/blog/invented-now-next-later-roadmap/
