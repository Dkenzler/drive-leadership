# Now, Next, Later Roadmap

Nach Abb. 3.17 im Drive Leadership Playbook, nach Janna Bastow und Simon Cast.

**Team / Produkt:**
**Stand:**
**Hinweis:** Kann sich ändern. Keine Termine.

| Now (hoch) | Next (mittel) | Later (niedrig) |
|---|---|---|
| Was aktuell in Umsetzung ist. Hohe Konfidenz, konkret und committed. | Was als Nächstes ansteht. Mittlere Konfidenz, Richtung steht, Details offen. | Ideen für später. Niedrige Konfidenz, bewusst grob gehalten. |
| | | |
| | | |
| | | |

Items wandern von rechts nach links, sobald sie reifer und gewisser werden.

**Wandert als Nächstes nach links:**
**Aus Later gestrichen:**
