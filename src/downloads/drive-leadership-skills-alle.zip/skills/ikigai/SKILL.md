---
name: ikigai
description: "Den persönlichen Sinn als Führungskraft klären mit Ikigai, dem japanischen Konzept vom Grund, warum man morgens aufsteht, in der Vier-Kreise-Darstellung nach Andrés Zuzunaga und Marc Winn, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand sich fragt, wozu er oder sie eigentlich führt, sich ausgebrannt oder leer fühlt, über einen Rollen- oder Karrierewechsel nachdenkt, den inneren Anker sucht oder alle paar Jahre prüfen will, ob Arbeit und persönliche Bedeutung noch zusammenpassen. Führt durch die vier Fragen: Was liebst du? In was bist du gut? Was braucht die Welt? Wofür wirst du bezahlt?"
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 1 Dich selbst kennen
  origin: Japanisches Konzept, Vier-Kreise-Darstellung nach Andrés Zuzunaga und Marc Winn
  deep_dive: false
  version: "1.0"
---

# Ikigai

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach einem japanischen Konzept, Vier-Kreise-Darstellung nach Andrés Zuzunaga und Marc Winn.

## Worum es geht

Ikigai ist ein japanisches Konzept. Der Begriff setzt sich zusammen aus »iki« (Leben) und »gai« (Wert, Sinn). Ikigai beschreibt den Grund, warum man morgens aufsteht. Es ist keine Karrierestrategie und kein Produktivitätswerkzeug, sondern die Frage nach dem, was dir persönlich Bedeutung gibt.

Ikigai entsteht in der Schnittmenge von vier Fragen. In der Mitte, wo sich alle vier Kreise überschneiden, liegt dein Ikigai (Abb. 6.1). Die Abbildung benennt außerdem die Überschneidungen zweier Kreise als Passion, Mission, Berufung und Profession, und sie beschreibt Zustände, in denen nur ein Teil zusammenkommt: erfüllt, aber nicht wirklich reich. Wohlhabend, aber mit dem Gefühl von Unsicherheit. Komfortabel, aber mit dem Gefühl von Leere. Selbstzufrieden, aber mit dem Gefühl, nutzlos zu sein.

Leadership ohne persönlichen Sinn ist auf Dauer nicht tragfähig. Wer nur für externe Ziele arbeitet, Karriere, Anerkennung, Gehalt, verliert irgendwann die Energie, die echte Führung braucht. Ikigai hilft, den inneren Anker zu finden. Es geht nicht um das eine perfekte Ziel, sondern um die Verschiebung hin zu der Schnittmenge, in der mehr von dem zusammenkommt, was dir Energie gibt, was du gut kannst und was gebraucht wird.

## Wann du sie einsetzt

- Wenn du dich fragst, wozu du hier bist und ob deine Arbeit dir noch Bedeutung gibt.
- Wenn du merkst, dass du vor allem für externe Ziele arbeitest (Karriere, Anerkennung, Gehalt) und dir die Energie ausgeht, die echte Führung braucht.
- Alle paar Jahre erneut, weil sich Antworten verändern. Was mit 30 stimmt, muss mit 40 nicht mehr passen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: In welcher Rolle arbeitest du gerade? Was ist der Anlass, dich jetzt mit Ikigai zu beschäftigen? Hast du die Übung schon einmal gemacht? Frag nichts, was die Person schon gesagt hat.
- Das ist eine persönliche Reflexion, kein Workshop. Arbeite ruhig und in Ruhe. Die Person soll schreiben, nicht nur antworten. Empfiehl, sich eine Stunde zu nehmen.
- Stell die vier Fragen einzeln. Warte auf jede Antwort, bevor du zur nächsten gehst. Bewerte die Antworten dabei nicht.
- Challenge nur dort, wo Antworten ausweichen oder allgemein bleiben: Frag nach konkreten Situationen und nach dem, was andere in der Person sehen. Kein Lob als Füllmaterial.
- Deute keine Lebensentscheidungen für die Person. Du machst Überschneidungen und Lücken sichtbar, die Schlüsse zieht sie selbst.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« (Vorlage: `templates/ikigai.md`) und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Was liebst du?** Was tust du gerne, womit verlierst du das Zeitgefühl, was gibt dir Energie?
   Frage: *»Bei welchen Tätigkeiten verlierst du das Zeitgefühl, und was davon gibt dir Energie?«*
   Gut ist die Antwort, wenn sie konkrete Tätigkeiten nennt, nicht Rollen oder Titel.

2. **In was bist du gut?** Wo liegen deine echten Stärken, die andere in dir sehen?
   Frage: *»Welche Stärken sehen andere in dir, und woran machst du das fest?«*
   Gut ist die Antwort, wenn sie sich auf Rückmeldungen oder Ergebnisse stützt, nicht nur auf Selbstbild.

3. **Was braucht die Welt?** Was schafft echten Wert für andere, wo wird dein Beitrag gebraucht?
   Frage: *»Wo wird dein Beitrag wirklich gebraucht, und für wen schafft er Wert?«*

4. **Wofür wirst du bezahlt?** Was davon lässt sich in eine tragfähige berufliche Tätigkeit übersetzen?
   Frage: *»Was davon lässt sich in eine tragfähige berufliche Tätigkeit übersetzen, heute oder künftig?«*

5. **Nebeneinanderstellen, nicht bewerten.** Die vier Antworten nebeneinander stehen lassen, ohne sofort zu bewerten.

6. **Überschneidungen und Lücken suchen.** Wo gibt es Überschneidungen? Wo gibt es Lücken? Welcher der in Abb. 6.1 beschriebenen Zustände kommt dir bekannt vor?
   Frage: *»Wo überschneiden sich deine Antworten, und welcher Kreis ist in deiner aktuellen Arbeit am schwächsten vertreten?«*

7. **Nachhallen lassen.** Kein sofortiger Entschluss. Die Person lässt das Ergebnis wirken und notiert, in welche Richtung sie sich verschieben möchte.
   Frage: *»Was wäre eine Verschiebung, durch die mehr von dem zusammenkommt, was dir Energie gibt, was du gut kannst und was gebraucht wird?«*

## Beispiel

Einer von Dominik Kenzlers großen Träumen war, eine eigene Firma zu gründen. Mit der Gründung von Dark Horse ging dieser Traum in Erfüllung. In zehn Jahren Beratung musste er aber immer wieder auf höchstem Niveau abliefern, oft in Projekten von nur ein bis zwei Monaten, und sich ständig neu beweisen. Das hat ihn ausgebrannt, mit wiederkehrenden Imposter-Momenten. In Führungspositionen in Start-ups merkte er: Die Rolle fühlte sich an wie eine Art Selbstständigkeit, aber mit viel mehr Zeit, Wirkung zu erzeugen und Vertrauen aufzubauen, auf dem er aufbauen konnte, statt es sich immer neu zu erarbeiten. Plötzlich kam viel mehr zusammen, was er gerne macht. Heute berät er nur noch, wenn Menschen gezielt wegen seiner Erfahrungsthemen kommen.

## Worauf du achten musst

- **Sofort bewerten.** Die Antworten erst nebeneinander stehen lassen, ohne sofort zu bewerten.
- **Ikigai als Karrierestrategie behandeln.** Es ist kein Produktivitätswerkzeug und keine Karriereplanung, sondern die Frage nach persönlicher Bedeutung.
- **Das eine perfekte Ziel suchen.** Es geht um eine Verschiebung hin zur Schnittmenge, nicht um die eine richtige Antwort.
- **Nur für externe Ziele arbeiten.** Karriere, Anerkennung und Gehalt allein tragen nicht dauerhaft.
- **Einmal machen und abhaken.** Antworten verändern sich. Die Frage gehört alle paar Jahre neu gestellt.

## Ergebnis

Vorlage: `templates/ikigai.md`.

```markdown
# Mein Ikigai
Stand: [Datum] · Aktuelle Rolle: [Rolle]

| Frage | Meine Antwort |
|---|---|
| Was liebst du? | … |
| In was bist du gut? | … |
| Was braucht die Welt? | … |
| Wofür wirst du bezahlt? | … |

**Überschneidungen:** …
**Lücken:** …
**Richtung der Verschiebung:** …
**Nächster Check:** [in ein paar Jahren oder beim nächsten Übergang]
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hast du alle vier Fragen schriftlich beantwortet, bevor du bewertet hast?
- Beruht deine Antwort zu Stärken auch darauf, was andere in dir sehen?
- Hast du benannt, wo Überschneidungen und wo Lücken liegen?
- Beschreibt dein Ergebnis eine Richtung, nicht ein einziges perfektes Ziel?
- Weißt du, wann du die Frage das nächste Mal stellst?

## Im Flywheel

Modul YOURSELF, Teil 1 Dich selbst kennen. YOURSELF ist der äußere Ring des Leadership Flywheel, der Drive, Lead und Ship trägt.

Verwandte Skills:
- `hedgehog-concept`: Laut Buch stellt das Hedgehog Concept von Jim Collins ähnliche Fragen für die Strategie (Was kannst du am besten? Wofür brennst du? Was treibt deinen wirtschaftlichen Motor?). Ikigai stellt sie aus persönlicher Perspektive.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Teil 1 Dich selbst kennen, Ikigai: Wozu bin ich hier?, Abb. 6.1 Ikigai-Diagramm nach Andrés Zuzunaga und Marc Winn.

Original: Andrés Zuzunaga: Purpose-Diagramm mit vier Kreisen, um 2011. Marc Winn: What is your Ikigai?, 2014, https://theviewinside.me/what-is-your-ikigai/
