# Ikigai

Nach Abb. 6.1 im Drive Leadership Playbook, Ikigai-Diagramm nach Andrés Zuzunaga und Marc Winn.

Nimm dir eine Stunde, am besten schriftlich. Beantworte die vier Fragen so ehrlich wie möglich und lass die Antworten zuerst nebeneinander stehen, ohne zu bewerten.

**Datum:**
**Aktuelle Rolle:**

## 1. Du liebst es
Was liebst du? Was tust du gerne, womit verlierst du das Zeitgefühl, was gibt dir Energie?

## 2. Du bist großartig darin
In was bist du gut? Wo liegen deine echten Stärken, die andere in dir sehen?

## 3. Die Welt braucht es
Was braucht die Welt? Was schafft echten Wert für andere, wo wird dein Beitrag gebraucht?

## 4. Du wirst dafür bezahlt
Wofür wirst du bezahlt? Was davon lässt sich in eine tragfähige berufliche Tätigkeit übersetzen?

## Schnittmengen
Die Abbildung benennt die Überschneidungen als Passion, Mission, Berufung und Profession. In der Mitte liegt dein Ikigai.

Wo überschneiden sich deine Antworten?

Wo gibt es Lücken?

Welcher Zustand kommt dir bekannt vor?
- [ ] Erfüllt, aber nicht wirklich reich.
- [ ] Wohlhabend, aber mit dem Gefühl von Unsicherheit.
- [ ] Komfortabel, aber mit dem Gefühl von Leere.
- [ ] Selbstzufrieden, aber mit dem Gefühl, nutzlos zu sein.

## Nachhallen lassen
In welche Richtung willst du dich verschieben?

Nächster Check (in ein paar Jahren):
