---
name: gem
description: Strategische Produktprioritäten mit GEM setzen (Growth, Engagement, Monetization) nach Gibson Biddle, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand festlegen will, was auf Produktebene gerade am wichtigsten ist, eine Forced-Rank-Rangfolge zwischen Wachstum, Nutzung und Monetarisierung braucht, Zielkonflikte zwischen Teams auflösen will (etwa Discount gegen Preiserhöhung) oder die Priorisierung für eine neue Unternehmensphase neu setzt. Verhindert, dass alle drei Dimensionen als »gleich wichtig« gelten.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D3 Set Strategic Goals
  origin: Gibson Biddle
  deep_dive: false
  version: "1.0"
---

# GEM

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Gibson Biddle.

## Worum es geht

GEM ist ein Framework für strategische Ziele in der Produktentwicklung. Es priorisiert innerhalb von drei Dimensionen:

- **Growth:** Wachstum, etwa Year-over-Year Member Growth.
- **Engagement:** Nutzung und Bindung, etwa Monthly Retention.
- **Monetization:** Monetarisierung, etwa Lifetime Value oder Gross Margin.

Der Clou ist die Forced-Rank Prioritization: Du musst dich entscheiden, was gerade am wichtigsten ist. Nicht alle drei gleichzeitig, es muss eine klare Rangfolge geben. Die Rangfolge bestimmt, wie Teams bei Zielkonflikten entscheiden. Das Framework macht implizite Annahmen explizit und zwingt zu einer ehrlichen Antwort auf die Frage: Was ist uns gerade wirklich am wichtigsten?

## Wann du sie einsetzt

- Strategische Prioritäten auf Produktebene setzen.
- Wenn Teams sich gegenseitig die Ziele verwässern, weil keine Rangfolge zwischen Wachstum, Nutzung und Monetarisierung besteht.
- Wenn das Unternehmen in eine neue Phase kommt und die Rangfolge neu gesetzt werden muss.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Produkt oder welchen Bereich? In welcher Phase ist das Unternehmen? Welche Zielkonflikte gibt es gerade zwischen Teams? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Akzeptiere keinen Gleichstand zwischen zwei Dimensionen. Benenne das direkt.
- Erfinde keine Kennzahlen oder Werte der Person. Fehlt etwas, markiere es als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Das Buch beschreibt keinen festen Ablauf. Die Schritte ordnen die Elemente aus dem Buch.

1. **Die drei Dimensionen konkretisieren.** Für Growth, Engagement und Monetization je eine Metrik benennen.
   Frage: *»Woran messt ihr Wachstum, Nutzung und Bindung sowie Monetarisierung in eurem Produkt?«* Gut ist die Antwort, wenn jede Dimension eine konkrete Metrik hat.

2. **Forced Rank festlegen.** Eine klare Rangfolge aus eins, zwei, drei.
   Frage: *»Was ist euch gerade wirklich am wichtigsten, und was kommt danach?«* Gut ist die Antwort, wenn es keinen Gleichstand gibt.

3. **Rangfolge an der Unternehmensphase prüfen.** Die Rangfolge hängt von der Phase ab und kann wechseln.
   Frage: *»Passt diese Rangfolge zur Phase, in der ihr gerade seid?«*

4. **Am Zielkonflikt testen.** Einen echten Konflikt zwischen zwei Teams durch die Rangfolge entscheiden.
   Frage: *»Nenn mir einen aktuellen Konflikt zwischen zwei Teams. Was entscheidet die Rangfolge?«* Gut ist das Ergebnis, wenn beide Teams daraus eine klare Guidance ableiten können.

## Beispiel

Netflix hat die Reihenfolge je nach Unternehmensphase gewechselt. In der Wachstumsphase: Growth > Engagement > Monetization. In der Reifephase: Engagement > Monetization > Growth.

Dominik Kenzler war in Situationen, in denen Growth und Monetization als gleich wichtig eingeschätzt wurden. Das erzeugt ein Set-up mit gegenteiligen Priorisierungen: Wer mehr Neukunden will, fährt eine Discount Strategy. Wer Monetization und Margen verbessern will, erhöht die Preise. Das eine Team setzt auf fallende Preise und verwässert damit das Ziel des anderen. Keines der Teams hat die Guidance, wie es untereinander die richtigen Prioritäten setzt.

## Worauf du achten musst

- **Gleichstand zwischen Dimensionen.** Alle drei oder zwei davon als »gleich wichtig« zu deklarieren, hebelt das Framework aus. Es muss eine klare Rangfolge geben.
- **Growth und Monetization gleichsetzen.** Gerade diese beiden stehen sich oft diametral entgegen. Gleichrangig erzeugen sie gegenläufige Teamziele.
- **Rangfolge nicht an die Phase anpassen.** Die Reihenfolge ist keine Dauerentscheidung. Sie wechselt mit der Unternehmensphase.
- **Keine Guidance für Teams.** Als Leader ist es deine Aufgabe, ein System zu schaffen, in dem es eine klare Priorisierung gibt. Kennt ein Team die Rangfolge nicht, entscheidet es im Konflikt allein und oft falsch.

## Ergebnis

```markdown
# GEM: [Produkt / Bereich]
Stand: [Datum] · Unternehmensphase: …

| Rang | Dimension | Metrik |
|---|---|---|
| 1 | Growth / Engagement / Monetization | … |
| 2 | … | … |
| 3 | … | … |

**Warum diese Rangfolge in dieser Phase:** …
**Zielkonflikt-Test:** Konflikt … · Entscheidung laut Rangfolge: …
**Wer die Rangfolge kennen muss:** …
**Offene Punkte:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Gibt es eine klare Rangfolge ohne Gleichstand?
- Hat jede Dimension eine konkrete Metrik?
- Passt die Rangfolge zur aktuellen Unternehmensphase?
- Löst die Rangfolge einen echten Zielkonflikt zwischen zwei Teams?
- Kennen alle Teams die Rangfolge?

## Im Flywheel

Modul DRIVE, Bereich D3 Set Strategic Goals.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D3 Set Strategic Goals, Frameworks für strategische Ziele. Originalquelle: Gibson Biddle.
Original: Gibson Biddle: The GEM Model, https://gibsonbiddle.medium.com/9-the-gem-model-65c89face5de
