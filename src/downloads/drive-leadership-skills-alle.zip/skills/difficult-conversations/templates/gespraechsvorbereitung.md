# Difficult Conversation: Gesprächsvorbereitung

Nach Abb. 4.14 im Drive Leadership Playbook (Difficult Conversation vs. Learning Conversation), nach Douglas Stone, Bruce Patton, Sheila Heen.

**Gegenüber:**
**Anlass:**
**Termin:**

## Das »Was ist passiert?«-Gespräch

| Frage | Bei mir | Beim Gegenüber (vermutet, im Gespräch erfragen) |
|---|---|---|
| Warum sehen wir die Situation unterschiedlich? Was sind jeweils Informationen und Überlegungen? | | |
| Welche Wirkung hatte das Verhalten? Was war die Absicht? | | |
| Welchen Beitrag hat jede Seite geleistet? | | |

## Das Gefühlsgespräch

| Frage | Bei mir | Beim Gegenüber (vermutet) |
|---|---|---|
| Welche Gefühle sind im Spiel? Wie drücke ich sie ohne Vorwurf aus? | | |

## Das Identitätsgespräch

| Frage | Bei mir | Beim Gegenüber (vermutet) |
|---|---|---|
| Was sagt die Situation über mich aus? Wovor habe ich eigentlich Angst? Was könnte an der anderen Sichtweise wahr sein? | | |

## Gesprächswerkzeuge

**Einstieg als Third Story:** »…«

**Zirkuläre Frage:** »Wie, glaubst du, erlebt … diese Situation?«

**Reframing:** »…«

## Im Gespräch
- [ ] Zuhören, bis sich die andere Person gehört und verstanden fühlt.
- [ ] Absicht und Wirkung auf beiden Seiten ansprechen.
- [ ] Gemeinsam klären, welchen Beitrag jede Seite geleistet hat und wie das Problem gelöst werden kann.
