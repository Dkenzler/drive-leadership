---
name: difficult-conversations
description: Schwierige Gespräche vorbereiten und führen mit Difficult Conversations von Douglas Stone, Bruce Patton und Sheila Heen (Harvard Negotiation Project), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand ein Konfliktgespräch, ein Gespräch über mangelnde Leistung oder Eigeninitiative, eine Auseinandersetzung mit Kolleg:innen oder ein anderes Gespräch vorbereiten will, das sich anfühlt, als könne es nicht gut ausgehen. Führt durch die drei Gespräche (Was ist passiert, Gefühle, Identität), den Wechsel zum Lerngespräch, den Einstieg mit der Third Story, zirkuläre Fragen und Reframing.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L5 Grow Your People
  origin: Douglas Stone, Bruce Patton und Sheila Heen (Harvard Negotiation Project)
  deep_dive: false
  version: "1.0"
---

# Difficult Conversations

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Douglas Stone, Bruce Patton und Sheila Heen.

## Worum es geht

Difficult Conversations ist ein Framework aus dem Harvard Negotiation Project. Es basiert auf jahrelanger Forschung zu Konflikten und schwierigen Gesprächen und bietet einen strukturierten Ansatz für Gespräche, die sich anfühlen, als würden sie nie gut ausgehen.

Das zentrale Argument: Was wie ein schwieriges Gespräch aussieht, besteht aus drei gleichzeitig ablaufenden Gesprächen.

- **Das Was-ist-passiert-Gespräch.** Wer hat was getan? Wer hat recht? Wer trägt die Schuld? Darüber glauben wir meistens zu reden. Aber die Fakten sind weniger strittig als die Interpretationen und Absichten, die wir daran knüpfen.
- **Das Gefühlsgespräch.** Welche Emotionen sind im Spiel? Was hat sie ausgelöst? Dieses Gespräch läuft oft parallel, ohne dass es explizit wird. Nicht adressierte Gefühle kommen irgendwann trotzdem raus, meistens zur falschen Zeit.
- **Das Identitätsgespräch.** Was sagt diese Situation über mich aus? Bin ich kompetent? Fair? Eine gute Führungskraft? Das persönlichste der drei Gespräche und oft das, was am meisten blockiert.

Das Ziel ist nicht Konfrontation, sondern Transformation: Aus einer Difficult Conversation wird eine Learning Conversation (Lerngespräch). Der Unterschied liegt nicht im Thema, sondern in der Haltung. Abb. 4.14 zeigt die Verschiebung in allen drei Gesprächen:

| Gespräch | Schwieriges Gespräch | Lerngespräch |
|---|---|---|
| Was ist passiert: Sichtweisen | Wessen Sichtweise ist richtig und wessen falsch? Es gibt nur entweder … oder. | Warum sehen wir die Situation unterschiedlich? Was sind jeweils Informationen und Überlegungen? |
| Was ist passiert: Absicht und Wirkung | Die Person wollte diesen Impact auf mich haben. | Ich mag die Auswirkungen des Verhaltens auf mich nicht. Ich frage mich, was die Absicht war. Ich kenne meine Absicht: War das auch tatsächlich der Impact? |
| Was ist passiert: Beiträge | Es ist die Schuld der anderen Person. | Beide haben zu diesem Ergebnis beigetragen. Lass uns herausfinden, welchen Beitrag jede Seite geleistet hat und wie das Problem gelöst werden kann. |
| Gefühle | Meine Gefühle sind ihre Schuld. Ich sollte sie entweder damit konfrontieren oder schweigen, weil es vermutlich nichts bringt. | Meine Gefühle sagen etwas über mich und deren Verhalten aus. Ich kann meine Gefühle ohne Vorwürfe ausdrücken und die Gefühle der anderen Person empathisch anerkennen, ohne ihre Sichtweise als die einzig richtige zu bestätigen. |
| Identität | Die Person greift meine Identität ungerechtfertigt an! Ich bin doch nicht …! | Realistischerweise könnte an dem, was die Person sagt, was Wahres dran sein. Wovor habe ich eigentlich Angst? Wie kann ihre Sichtweise berechtigt sein, ohne dass sie infrage stellt, wer ich bin, und umgekehrt? |

## Wann du sie einsetzt

- Vor Gesprächen, die sich anfühlen, als würden sie nie gut ausgehen.
- Wenn du ein Verhalten ansprechen musst, das du bisher nur als Vorwurf formulieren kannst (»Du hast in letzter Zeit kaum Eigeninitiative gezeigt«).

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Mit wem ist das Gespräch (Rolle, Beziehung)? Worum geht es aus deiner Sicht? Was steht für dich auf dem Spiel? Frag nichts, was die Person schon gesagt hat.
- Arbeite beide Seiten durch: Welche drei Gespräche laufen bei der Person selbst, welche vermutlich beim Gegenüber? Was das Gegenüber denkt oder fühlt, ist eine Vermutung. Markiere es so und formuliere daraus Fragen für das Gespräch.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen die linke Spalte der Tabelle und gegen »Worauf du achten musst«. Klingt eine Antwort nach Schuld, Entweder-oder oder unterstellter Absicht, benenne das direkt und kurz. Kein Lob als Füllmaterial.
- Erfinde keine Fakten über die andere Person oder die Situation.
- Schließe mit der Gesprächsvorbereitung im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Was-ist-passiert-Gespräch sortieren.** Fakten von Interpretationen und unterstellten Absichten trennen.
   Frage: *»Was ist passiert, und welche Deutung hängst du daran?«* Gut ist die Antwort, wenn Beobachtung und Interpretation getrennt stehen und die Frage »Warum sehen wir es unterschiedlich?« die Frage »Wer hat recht?« ersetzt.

2. **Absicht und Wirkung trennen.** Eine schlechte Wirkung bedeutet nicht automatisch eine schlechte Absicht. Und umgekehrt: Gute Absichten entschuldigen keine schlechten Wirkungen.
   Frage: *»Welche Wirkung hatte das Verhalten auf dich, und was weißt du tatsächlich über die Absicht? Und wie könnte deine eigene Absicht beim Gegenüber gewirkt haben?«* Gut ist die Antwort, wenn beide Seiten dieser Gleichung benannt sind.

3. **Beiträge statt Schuld.** Beide Seiten haben zum Ergebnis beigetragen.
   Frage: *»Was war dein eigener Beitrag zu dieser Situation?«* Gut ist die Antwort, wenn sie einen echten eigenen Anteil enthält.

4. **Gefühlsgespräch klären.** Welche Gefühle sind im Spiel, bei dir und vermutlich beim Gegenüber?
   Frage: *»Was fühlst du, und wie kannst du es ohne Vorwurf aussprechen?«* Gut ist die Antwort, wenn das Gefühl als eigenes formuliert ist, nicht als Schuld der anderen Person.

5. **Identitätsgespräch klären.** Was sagt die Situation für dich über dich aus?
   Frage: *»Was an diesem Gespräch berührt dein Selbstbild, und wovor hast du eigentlich Angst?«* Gut ist die Antwort, wenn die Person anerkennen kann, dass an der Sicht des Gegenübers etwas Wahres dran sein könnte, ohne dass das ihr Selbstbild infrage stellt.

6. **Einstieg als Third Story formulieren.** Nicht mit der eigenen Perspektive einsteigen (»Du hast …«), sondern neutral und beobachtend, so wie eine außenstehende Person die Situation beschreiben würde. Dann mit Lernhaltung fragen, was die andere Person wahrgenommen und gefühlt hat.
   Frage: *»Wie würde eine unbeteiligte Person die Situation beschreiben?«* Gut ist der Einstieg, wenn er keine Anklage enthält und mit einer echten Frage endet.

7. **Fragen und Reframings vorbereiten.** Zwei Werkzeuge aus der systemischen Beratung, die mit dem Prinzip der Allparteilichkeit und Neutralität arbeiten:
   - **Zirkuläre Fragen** laden das Gegenüber ein, die Perspektive eines Dritten einzunehmen: »Wie, glaubst du, erlebt dein Kollege diese Situation?« Das bringt Selbstreflexion in Gang, ohne dass man anklagen muss.
   - **Reframing** beschreibt ein Verhalten in einem anderen Rahmen, sodass es eine neue Bedeutung bekommt. Nicht »Du bist desinteressiert«, sondern »Ich sehe, dass du dich auf andere Prioritäten konzentrierst. Lass uns darüber reden.«

   Frage: *»Welche zirkuläre Frage und welches Reframing passen zu deinem Gespräch?«*

8. **Im Gespräch: erst zuhören.** Das Gespräch lässt sich erst in eine konstruktivere Richtung lenken, wenn sich die andere Person gehört und verstanden fühlt. Im Zweifel: zuhören. Danach gemeinsam herausfinden, welchen Beitrag jede Seite geleistet hat und wie das Problem gelöst werden kann.
   Frage: *»Woran merkst du im Gespräch, dass sich dein Gegenüber verstanden fühlt?«*

## Beispiel

Statt »Du hast in letzter Zeit kaum Eigeninitiative gezeigt« könnte der Einstieg als Third Story lauten: »Ich beobachte, dass bei unseren Projekten oft auf Anweisungen gewartet wird, statt eigenständig voranzugehen. Ich würde gerne verstehen, wie du das erlebst.« Der erste Einstieg erzeugt sofort Abwehr. Der zweite öffnet den Raum für ein echtes Gespräch.

## Worauf du achten musst

- **Mit der eigenen Position einsteigen.** »Du hast …« erzeugt sofort Abwehr. Besser: Third Story und neugierige Lernhaltung.
- **Nur über Fakten reden.** Das Was-ist-passiert-Gespräch ist das, worüber wir zu reden glauben. Gefühle und Identität laufen trotzdem mit, und nicht adressierte Gefühle kommen zur falschen Zeit raus.
- **Absicht aus Wirkung ableiten.** Eine schlechte Wirkung bedeutet nicht automatisch eine schlechte Absicht. Und die eigene gute Absicht entschuldigt keine schlechte Wirkung.
- **Schuld statt Beiträge.** Wer die Schuld bei der anderen Person sucht, landet im Entweder-oder statt bei einer Lösung.
- **Zu früh lenken.** Solange sich die andere Person nicht gehört und verstanden fühlt, lässt sich das Gespräch nicht konstruktiv steuern.

## Ergebnis

Eine Gesprächsvorbereitung, die die Person mitnehmen kann. Vorlage: `templates/gespraechsvorbereitung.md`.

```markdown
# Gesprächsvorbereitung: [Gegenüber / Anlass]

**Was ist passiert (Beobachtung):** …
**Meine Interpretation:** …
**Warum wir es vermutlich unterschiedlich sehen:** …
**Wirkung auf mich:** … · **Was ich über die Absicht weiß:** …
**Mein eigener Beitrag:** …
**Meine Gefühle (ohne Vorwurf):** …
**Was es für mein Selbstbild bedeutet:** …
**Vermutungen zur anderen Seite (offen, im Gespräch erfragen):** …

**Einstieg (Third Story):** »…«
**Zirkuläre Frage:** »…«
**Reframing:** »…«
**Ziel am Ende:** gemeinsames Verständnis der Beiträge und nächster Schritt zur Lösung
```

## Mini-Check

Abgeleitet aus den typischen Fehlern:
- Beginnt dein Einstieg neutral und beobachtend statt mit »Du hast …«?
- Hast du alle drei Gespräche vorbereitet, auch Gefühle und Identität?
- Hast du Wirkung und Absicht getrennt, auf beiden Seiten?
- Kannst du deinen eigenen Beitrag zur Situation benennen?
- Bist du bereit, zuerst zuzuhören, bis sich dein Gegenüber verstanden fühlt?

## Im Flywheel

Modul LEAD, Bereich L5 Grow Your People.

Verwandte Skills:
- `feedback-einholen`: Das Buch verweist darauf als Gegenrichtung zu SBI, Radical Candor und schwierigen Gesprächen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L5 Grow Your People, Difficult Conversations (Abb. 4.14), Verweis in YOURSELF, Feedback einholen. Originalquelle: Douglas Stone, Bruce Patton, Sheila Heen: Difficult Conversations (Harvard Negotiation Project).

Original: Douglas Stone, Bruce Patton, Sheila Heen: Difficult Conversations. How to Discuss What Matters Most, Viking, 1999.
