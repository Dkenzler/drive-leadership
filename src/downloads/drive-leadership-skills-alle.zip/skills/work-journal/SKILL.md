---
name: work-journal
description: "Ein Work Journal einrichten und führen, im Format, das Dominik Kenzler von Tanner Christensen kennengelernt hat, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn eine Führungskraft regelmäßig reflektieren, den Überblick über viele parallele Themen behalten, aus der eigenen Arbeit lernen, Muster erkennen oder Fieldnotes für Projekt-Retros, Case Studies und Performance Reviews sammeln will. Typische Auslöser: Wochenreflexion, Onboarding in einem neuen Job, Journaling-Routine aufbauen, Einträge nach drei Monaten auswerten, KI als Journaling-Unterstützung nutzen. Führt durch Einrichtung, die drei Kernfragen und die Auswertung nach zwölf Wochen."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 1 Dich selbst kennen
  origin: Dominik Kenzler, nach dem Format von Tanner Christensen
  deep_dive: false
  version: "1.0"
---

# Work Journal

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, Format nach Tanner Christensen.

## Worum es geht

Ein Work Journal ist eines der einfachsten und wirkungsvollsten Werkzeuge für Selbstführung: ein Arbeitsjournal, in dem du festhältst, was in deinem Arbeitsleben passiert, das Gute wie das Schwierige. Regelmäßig, ein paar Minuten, schriftlich.

Es löst zwei Probleme auf einmal. Erstens hilft es, den Überblick zu bewahren: Im Alltag verschwimmen die Wochen, wer regelmäßig schreibt, behält den roten Faden über viele parallele Themen. Zweitens erleichtert es das Lernen: Gedanken im Kopf bleiben diffus, auf Papier werden sie konkret, und Muster werden sichtbar. Welche Situationen kosten Energie? Welche Entscheidungen bereue ich regelmäßig? Wo reagiere ich, statt zu gestalten? Außerdem dokumentiert es deine Arbeit und die deiner Teams, als Sammlung von Fieldnotes, auf die du zurückgreifen kannst.

Das Journal ist kein Tagebuch und kein Protokoll, sondern ein Reflexionswerkzeug. Die Qualität der Fragen entscheidet über die Qualität der Reflexion.

## Wann du sie einsetzt

- Als wöchentliche Routine, fest im Kalender.
- Besonders im Onboarding in einem neuen Job oder einer neuen Rolle, wenn sehr viel auf dich einprasselt.
- Gerade in hektischen Phasen, weil sonst alles an dir vorbeifließt.
- Als Quelle, wenn du ein Projekt reflektierst, einen Performance Review vorbereitest oder die Entwicklung eines Teammitglieds nachvollziehen willst.
- Nach drei Monaten zur Auswertung deiner Muster.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Führst du schon ein Journal, oder startest du neu? Wofür vor allem: Reflexion, Überblick, Projektdokumentation? Wann in der Woche hast du realistisch 15 Minuten? Frag nichts, was die Person schon gesagt hat.
- Unterscheide drei Einstiege: Einrichten (Ablauf Schritte 1 bis 3), einen Eintrag schreiben (Schritte 4 und 5), Einträge auswerten (Schritt 7).
- Beim Schreiben: Stell die Fragen einzeln und warte auf die Antwort. Formuliere unsortierte Gedanken der Person auf Wunsch knapp aus, aber schreib keine Reflexion für sie. Schreiben und Reflexion bleiben ihre Aufgabe.
- Challenge gegen »Worauf du achten musst«. Vor allem: Wird der Eintrag zur Aufgabenliste? Benenne das direkt und kurz. Kein Lob als Füllmaterial.
- Bei der Auswertung: Mach Muster sichtbar, die über mehrere Einträge auftauchen. Belege jedes Muster mit den Einträgen, aus denen es stammt. Erfinde keine Muster und keine Ereignisse.
- Schließe mit dem Eintrag oder der Auswertung im Format aus »Ergebnis« (Vorlage: `templates/work-journal.md`) und geh bei der Einrichtung den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Format wählen.** Ein Format, das du wirklich nutzt und von überall erreichst, auch unterwegs zwischen zwei Meetings. Wichtiger als das Werkzeug ist die Regelmäßigkeit.
   Frage: *»Wo schreibst du, sodass du es auch zwischen zwei Meetings erreichst?«*

2. **Festen Zeitpunkt reservieren.** Zum Beispiel 15 Minuten am Freitagnachmittag vor dem Shutdown oder am Montagmorgen vor dem Start der Woche. Tanner Christensen blockt sich diese Zeit fest im Kalender, um konsequent zu bleiben.
   Frage: *»Welcher feste Termin pro Woche, und steht er schon im Kalender?«*

3. **Projektseiten anlegen (optional).** Wer das Journal auch zur Projektdokumentation nutzt, legt pro größerem Projekt eine Seite an: ein kurzer Steckbrief mit Ziel und Status, dann fortlaufende Notizen zu Fortschritt, Entscheidungen und Learnings. So entsteht eine ehrliche Chronik dessen, was wirklich passiert ist.

4. **Mit drei Fragen schreiben.**
   1. *Was war der wichtigste Moment dieser Woche?* Das muss kein Highlight sein. Es kann ein schwieriges Gespräch, eine falsche Entscheidung oder ein unerwartetes Lernen sein.
   2. *Was habe ich daraus gelernt?* Nicht, was du getan hast, sondern was du mitnimmst.
   3. *Was würde ich beim nächsten Mal anders machen?* Die handlungsorientierteste Frage. Sie verhindert, dass Reflexion zur Nabelschau wird.

   Gut ist ein Eintrag, wenn er beschreibt, wie etwas erlebt wurde, und eine konkrete Konsequenz enthält.

5. **Tiefer gehen (optional).** Was hat mir diese Woche Energie gegeben, was hat sie gekostet? Habe ich diese Woche so geführt, wie ich führen will? Was habe ich vermieden, was ich hätte angehen sollen? Und die Frage von Jerry Colonna (»Reboot«): »Wie habe ich selbst zu der Situation beigetragen, die ich eigentlich nicht will?« Sie fragt nach der eigenen Handlungsmacht, ist unbequem und führt deshalb weiter als die meisten anderen.

6. **KI als Unterstützung nutzen.** KI kann an die feste Journaling-Zeit erinnern, helfen, einen unsortierten Gedanken schneller auszuformulieren, oder über mehrere Wochen Muster sichtbar machen, die dir selbst entgehen. Schreiben und Reflexion bleiben deine Aufgabe. Die Hürde, anzufangen und dranzubleiben, wird kleiner.

7. **Nach drei Monaten auswerten.** Die Einträge der letzten zwölf Wochen lesen. Was fällt auf? Welche Themen tauchen immer wieder auf? Welche Entscheidungen hast du mehrfach bereut? Welche Situationen haben immer wieder Energie gekostet? Diese Muster sind das Wertvollste, was das Journal produziert. Sie zeigen, wo deine echten Entwicklungsfelder liegen.
   Frage: *»Welches Thema taucht in deinen Einträgen am häufigsten auf, und was sagt es über dein Entwicklungsfeld?«*

## Beispiel

Dominik Kenzler schreibt seine Notizen per Hand auf einem reMarkable Tablet und in Notion. Am Ende der Woche führt er alles zusammen und dokumentiert die Learnings der Woche. Aus den Weekly Notes ergeben sich auch Themen für sein wöchentliches Staff Meeting. Gerade in hektischen Phasen ertappt er sich dabei, es zu überspringen. Sein Ziel bleibt: jede Woche dokumentieren, und sei es nur 15 Minuten. Tanner Christensen, Design Leader, der unter anderem bei Netflix, Meta, Lyft und Atlassian gearbeitet hat, nutzt sein Journal auch, um aus den Notizen später Case Studies zu bauen.

## Worauf du achten musst

- **Das Journal wird zur Aufgabenliste.** Es geht nicht darum, was du getan hast, sondern wie du es erlebt hast.
- **Perfektionismus.** Das Journal muss nicht literarisch sein. Drei ehrliche Sätze sind wertvoller als eine halbe Stunde ausgewogener Formulierungen.
- **In hektischen Phasen aufhören.** Genau dann ist der Wert am größten, weil sonst alles an dir vorbeifließt.

## Ergebnis

Vorlage: `templates/work-journal.md`.

```markdown
# Work Journal: Woche [KW / Datum]

1. **Wichtigster Moment dieser Woche:** …
2. **Was ich daraus gelernt habe:** …
3. **Was ich beim nächsten Mal anders mache:** …

(optional) Energie gegeben: … · Energie gekostet: … · So geführt, wie ich führen will? … · Vermieden: …
(optional) Wie habe ich selbst zu der Situation beigetragen, die ich eigentlich nicht will? …

Themen für das Staff Meeting: …
```

Auswertung nach zwölf Wochen:

```markdown
# Work Journal: Auswertung [Zeitraum]
| Muster | Belegt durch Einträge vom | Entwicklungsfeld |
|---|---|---|
| Wiederkehrendes Thema: … | … | … |
| Mehrfach bereute Entscheidung: … | … | … |
| Wiederkehrender Energieverlust: … | … | … |
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Steht dein fester Journaling-Termin im Kalender?
- Beschreiben deine Einträge, wie du etwas erlebt hast, statt aufzulisten, was du getan hast?
- Enthält jeder Eintrag eine Antwort auf »Was würde ich beim nächsten Mal anders machen?«?
- Schreibst du auch in hektischen Wochen, und sei es nur 15 Minuten?

## Im Flywheel

Modul YOURSELF, Teil 1 Dich selbst kennen. YOURSELF ist der äußere Ring des Leadership Flywheel, der Drive, Lead und Ship trägt.

Verwandte Skills:
- `performance-reviews`: Das Journal liefert laut Buch die Fieldnotes, um einen Performance Review vorzubereiten.
- `weekly-staff-meeting`: Aus den Weekly Notes ergeben sich Themen für das wöchentliche Staff Meeting.
- `breathwork`: Laut Buch ist das Work Journal Teil der Verarbeitung von Stress nach belastenden Phasen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Teil 1 Dich selbst kennen, Work Journal. Format nach Tanner Christensen. Reflexionsfrage nach Jerry Colonna: Reboot.
