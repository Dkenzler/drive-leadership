# Work Journal

Nach dem Work Journal im Drive Leadership Playbook (Format nach Tanner Christensen). Einmal pro Woche, etwa 15 Minuten, fester Termin im Kalender.

## Wöchentlicher Eintrag

**Woche / Datum:**

1. **Was war der wichtigste Moment dieser Woche?**
   (Kein Highlight nötig: ein schwieriges Gespräch, eine falsche Entscheidung, ein unerwartetes Lernen.)

2. **Was habe ich daraus gelernt?**
   (Nicht, was du getan hast, sondern was du mitnimmst.)

3. **Was würde ich beim nächsten Mal anders machen?**

### Tiefer gehen (optional)
- Was hat mir diese Woche Energie gegeben, was hat sie gekostet?
- Habe ich diese Woche so geführt, wie ich führen will?
- Was habe ich vermieden, was ich hätte angehen sollen?
- Wie habe ich selbst zu der Situation beigetragen, die ich eigentlich nicht will? (Jerry Colonna)

## Projektseite (eine pro größerem Projekt)

**Projekt:**
**Ziel:**
**Status:**

| Datum | Fortschritt | Entscheidungen | Learnings |
|---|---|---|---|
| | | | |

## Auswertung nach drei Monaten

Lies die Einträge der letzten zwölf Wochen.

- Was fällt mir auf?
- Welche Themen tauchen immer wieder auf?
- Welche Entscheidungen habe ich mehrfach bereut?
- Welche Situationen haben immer wieder Energie gekostet?
- Wo liegen damit meine echten Entwicklungsfelder?
