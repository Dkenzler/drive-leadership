---
name: one-on-one-skip-level
description: Gute 1:1s und Skip Levels mit Mitarbeitenden aufsetzen und führen, aus dem Drive Leadership Playbook von Dominik Kenzler (mit Impulsen von Kim Scott und Julie Zhuo). Nutze diesen Skill, wenn eine Führungskraft 1:1s mit Direct Reports einführen oder verbessern will, merkt, dass 1:1s zu Statusmeetings geworden sind, Frequenz und Format festlegen, ein einzelnes 1:1 vorbereiten, mehr ehrliches Feedback bekommen oder Skip Levels mit den Mitarbeitenden ihrer Führungskräfte einführen will. Führt durch Agenda-Eigentum, die drei Ebenen eines guten 1:1 (Prioritäten, Entwicklung, Feedback in beide Richtungen), Warnsignale, Frequenz und den Zweck von Skip Levels.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L4 Set the Stage
  origin: Dominik Kenzler, mit Impulsen von Kim Scott und Julie Zhuo
  deep_dive: false
  version: "1.0"
---

# 1:1 und Skip Level

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, mit Impulsen von Kim Scott und Julie Zhuo.

## Worum es geht

1:1 sind regelmäßige Einzelgespräche zwischen dir und deinen Direct Reports. Sie sind das wichtigste Führungsinstrument, über das du verfügst. Nicht, weil sie regelmäßig stattfinden, sondern weil sie ein zentraler Ort sind, an dem echte Entwicklung passiert und der ausschließlich deinen Mitarbeitenden gehört. Das Ziel ist kein angenehmer Austausch, sondern ein ehrliches Gespräch über Entwicklung, Ziele und darüber, was du als Lead tun kannst, um zu unterstützen.

Ein 1:1 ist kein Statusmeeting und kein Update-Kanal. Updates lassen sich schriftlich abdecken. Kim Scott in »Radical Candor«: »Das 1:1 ist deine beste Möglichkeit, wirklich zuzuhören. Zu verstehen, was aus Sicht deines Gegenübers funktioniert und was nicht. Und gleichzeitig die Beziehung aufzubauen, die ehrliche Gespräche überhaupt erst möglich macht.«

Ein Skip Level ist ein 1:1 mit Personen, die eine Ebene tiefer in deiner Organisation sitzen, also mit den Direct Reports deiner Direct Reports. Es geht nicht primär um deren Entwicklung, sondern um ein direktes Bild dessen, was in der Organisation passiert, jenseits der gefilterten Version, die durch die Hierarchie nach oben kommt.

## Wann du sie einsetzt

- 1:1: mit jedem Direct Report, regelmäßig.
- Wenn 1:1s zu Update-Runden oder Wohlfühlgesprächen geworden sind.
- Wenn du ein neues Team übernimmst und verstehen willst, wie 1:1s dort gelebt werden.
- Skip Level: wenn du mehrere Führungsebenen verantwortest und wissen willst, wie deine Führungskräfte führen, ob Erwartungen klar sind, ob Entscheidungen verstanden werden und ob strukturelle Probleme auf dem Weg nach oben verschwinden.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wie viele Direct Reports, und gibt es eine zweite Führungsebene? Wie laufen die 1:1s heute? Geht es um das Format insgesamt oder um ein konkretes Gespräch? Frag nichts, was die Person schon gesagt hat.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Wer bestimmt die Agenda? Geht es um Updates?
- Bereitet die Person ein einzelnes 1:1 vor, hilf ihr bei ihren Fragen und ihrer Feedbackfrage, nicht bei einer eigenen Agenda: Die gehört der anderen Person.
- Erfinde nichts über die Mitarbeitenden. Arbeite mit dem, was die Person schildert.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**1. Ist-Stand ehrlich ansehen.** Die Namen der Meetings sind überall gleich, was darin passiert, ist von Team zu Team verschieden. Oft geben sich zwei Personen kurz ein Update und gehen wieder auseinander: keine Agenda, keine echten Fragen, kein Momentum.
Frage: *»Worüber habt ihr in den letzten drei 1:1s gesprochen, und wer hat die Themen gesetzt?«*

**2. Agenda-Eigentum klären.** Der häufigste Fehler: Die Führungskraft bestimmt, worüber geredet wird. Die Agenda gehört der anderen Person. Deine Aufgabe ist zuzuhören, Fragen zu stellen und Hindernisse aus dem Weg zu räumen. Julie Zhuo: »Deine Aufgabe als Führungskraft ist nicht, Ratschläge zu erteilen oder die Situation zu retten. Es ist, die andere Person zu unterstützen, selbst die Antwort zu finden, denn sie hat mehr Kontext als du.« Das setzt klare Erwartungen voraus: Die Person kommt vorbereitet. Was ist diese Woche wichtig? Was blockiert dich? Wo brauchst du Unterstützung? Wer unvorbereitet kommt, bekommt das direkt gespiegelt.
Frage: *»Wie kommunizierst du, dass die Agenda der anderen Person gehört und was du an Vorbereitung erwartest?«*

**3. Die drei Ebenen.** Jede hat ihren Platz:
- **Aktuelle Prioritäten:** Die ein, zwei, drei wichtigsten Themen der Woche. Wo hängt etwas fest? Was braucht die Person, um voranzukommen?
- **Entwicklung und Ziele:** Wo steht die Person im Vergleich zu ihren eigenen Zielen? Was läuft gut, was nicht? Wie schätzt sie die eigene Leistung ein? Dieser Teil fällt oft weg, weil er unangenehmer ist. Wer nie über Entwicklung spricht, erfährt zu spät, wenn jemand feststeckt oder unzufrieden ist.
- **Feedback in beide Richtungen:** Was kann die Person dir mitgeben, was du ihr? Kim Scott: »Wenn du nur gute Nachrichten hörst, ist das kein Zeichen, dass alles gut läuft. Es ist ein Zeichen, dass die Person nicht das Vertrauen hat, dir die Wahrheit zu sagen.« Frag explizit: »Was könnte ich tun oder lassen, das die Zusammenarbeit einfacher machen würde?« Und lass die Frage nicht fallen, bis eine ehrliche Antwort kommt.

Feedback im 1:1 ja, aber nicht Feedback sammeln, um es loszuwerden.
Frage: *»Wann kam im letzten Monat Entwicklung zur Sprache, und wann hast du zuletzt nach Feedback für dich gefragt?«*

**4. Frequenz und Format festlegen.** Orientierung: wöchentlich 30 bis 50 Minuten. Bei mehr als zehn Direct Reports alle zwei Wochen 25 Minuten. Dominiks Ideal liegt bei fünf bis sieben, maximal zehn Direct Reports. Kim Scott beschränkt sich selbst auf fünf, weil echtes Zuhören anstrengend ist. 1:1s so selten wie möglich absagen; das registriert die andere Person. Wenn es nicht anders geht, verschieben, am besten auf den folgenden Tag. Format und Ort dürfen variieren: persönlich, Videocall, in regelmäßigen Abständen Walk and Talk oder Lunch. Kim Scott empfiehlt, das Format auch für die eigene Energie zu optimieren, Hauptsache, das Gespräch wird nicht als ein weiteres Meeting wahrgenommen.
Frage: *»Wie viele Direct Reports hast du, und welche Frequenz ist damit realistisch, ohne abzusagen?«*

**5. Warnsignale prüfen.** Ein funktionierendes 1:1 fühlt sich ein bisschen unbequem an. Das ist ein Zeichen, dass echte Themen auf dem Tisch sind. Warnsignale:
- Jemand sagt das 1:1 regelmäßig ab: Die Partnerschaft ist für diese Person nicht produktiv.
- Jemand liefert nur Updates, die in einer Nachricht stehen könnten: Das Format wird falsch genutzt.
- Es gibt nie Kritik in deine Richtung: Du bekommst kein echtes Feedback.

**6. Skip Levels einführen.** Zweck: verstehen, wie deine Führungskräfte tatsächlich führen, ob Erwartungen klar sind, ob Entscheidungen verstanden werden, ob es strukturelle Probleme gibt, die auf dem Weg nach oben verschwinden. Kein Kontrollinstrument und kein Weg, deine Führungskräfte zu umgehen. Das muss klar kommuniziert sein. Skip Levels funktionieren nur, wenn alle wissen, dass sie stattfinden, und die direkte Führungskraft sich nicht hintergangen fühlt. Orientierung: einmal pro Quartal, bei neuen Teams oder in kritischen Phasen häufiger.
Frage: *»Wie kündigst du Skip Levels deinen Führungskräften an, bevor das erste stattfindet?«*

## Beispiel

Dominik Kenzler hat viele Manager gesehen, sich selbst eingeschlossen, die das 1:1 als Statusmeeting behandelt haben. Sein langjähriger Vorgesetzter und Mentor Nicholas Goubert fragte ihn irgendwann, ob es okay wäre, jedes zweite ihrer 1:1s als Walk and Talk per Telefon zu machen. Das gab beiden Luft im Kalender, und Dominik übernahm es für seine Direct Reports.

## Worauf du achten musst

- **1:1 als Statusmeeting.** Updates gehören in schriftliche Form.
- **Die Führungskraft setzt die Agenda.** Das dreht den Sinn des Formats um.
- **Entwicklung fällt weg.** Weil sie unangenehmer ist als laufende Projekte.
- **Nur gute Nachrichten.** Kein Zeichen, dass alles gut läuft, sondern fehlendes Vertrauen.
- **Feedback sammeln, um es loszuwerden.** Das 1:1 ist kein Ablageort für aufgestaute Kritik.
- **Absagen.** Jede Absage ist ein Signal. Verschieben statt absagen.
- **Wohlfühlgespräch.** Gute 1:1s fühlen sich manchmal ein bisschen unbequem an (Mark Rabkin, zitiert von Julie Zhuo in »The Making of a Manager«).
- **Skip Level ohne Transparenz.** Weiß die direkte Führungskraft nichts davon oder fühlt sich hintergangen, funktioniert es nicht.

## Ergebnis

```markdown
# 1:1- und Skip-Level-Set-up: [Führungskraft]
Stand: …

## 1:1s
| Direct Report | Frequenz | Dauer | Format | Letztes Gespräch über Entwicklung |
|---|---|---|---|---|
| | | | | |

Erwartung an die Vorbereitung (von der anderen Person):
- Was ist diese Woche wichtig?
- Was blockiert dich?
- Wo brauchst du Unterstützung?

Feste Feedbackfrage an mich: »Was könnte ich tun oder lassen, das die Zusammenarbeit einfacher machen würde?«

Beobachtete Warnsignale: …

## Skip Levels
Rhythmus: … (Orientierung: einmal pro Quartal)
Angekündigt bei den Führungskräften am: …
Worauf ich achte: Wie führen meine Führungskräfte? Sind Erwartungen klar? Werden Entscheidungen verstanden? Gibt es strukturelle Probleme?
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)
- Gehört die Agenda der anderen Person, und kommt sie vorbereitet?
- Kommen alle drei Ebenen vor: Prioritäten, Entwicklung, Feedback in beide Richtungen?
- Fragst du explizit nach Feedback für dich, bis eine ehrliche Antwort kommt?
- Verschiebst du statt abzusagen?
- Wissen deine Führungskräfte, dass Skip Levels stattfinden, und wozu?

## Im Flywheel

Modul LEAD, Bereich L4 Set the Stage. Wie du Feedback im 1:1 gibst, vertieft das Buch in L5 Grow Your People.

Verwandte Skills:
- `walk-and-talk`: eignet sich besonders für 1:1s.
- `feedback-einholen`: am Ende jedes 1:1 eine kurze Feedbackfrage an dich.
- `leadership-blueprint`: in einem der ersten 1:1s mit Direct Reports teilen.
- `weekly-staff-meeting`: Themen, die nur eine Person betreffen, gehören ins 1:1, nicht ins Staff Meeting.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L4 Set the Stage sowie YOURSELF zu Feedback einholen, Walk and Talk und Leadership Blueprint. Zitate: Kim Scott, Radical Candor. Julie Zhuo, The Making of a Manager (mit einem Rat von Mark Rabkin).
