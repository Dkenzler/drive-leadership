---
name: roadmap-anatomy
description: Eine strategische Roadmap nach den fünf Kernelementen aus »Product Roadmaps Relaunched« (C. Todd Lombardo, Bruce McCarthy, Evan Ryan, Michael Connors) aufbauen oder prüfen, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand eine Roadmap für Produkt, Team oder Bereich erstellen, eine bestehende Roadmap auf Vision, Business Objectives, Timeframes, Themes und Disclaimer prüfen, optionale Elemente wie Confidence Levels oder Zielkunden auswählen oder Roadmap und Release- oder Projektplan sauber trennen will.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D4 Guiding Principles (Strategic Planning)
  origin: C. Todd Lombardo, Bruce McCarthy, Evan Ryan, Michael Connors
  deep_dive: false
  version: "1.0"
---

# Anatomie einer Roadmap

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach C. Todd Lombardo, Bruce McCarthy, Evan Ryan und Michael Connors.

## Worum es geht

Bevor es um Formate geht, lohnt ein Blick auf die Grundstruktur: Was gehört auf eine Roadmap und was nicht? Bruce McCarthy und sein Team treffen in »Product Roadmaps Relaunched« eine klare Unterscheidung: Eine Roadmap ist ein strategisches Artefakt. Ein Release Plan ist ein taktisches Artefakt. Die Roadmap steuert Outcomes, der Projektplan steuert Outputs. Wer beides vermischt, verliert beides.

**Fünf Kernelemente.** Jede gute Roadmap hat fünf Bausteine:

1. **Vision:** Wohin wollen wir? Die Vision gibt die Richtung, aber nicht die Details. Ohne sie fehlt der Rahmen für alles, was folgt.
2. **Business Objectives:** Was wollen wir erreichen? Messbare Ziele, die erklären, warum die Roadmap existiert. Sie helfen Stakeholdern zu verstehen, welchen Wert die Arbeit hat.
3. **Timeframes:** Welche Zeithorizonte? Breite Zeiträume, wie Quartale oder Now, Next, Later. Keine spezifischen Deadlines.
4. **Themes:** Was sind die großen Themen? Sie beschreiben Kundenbedürfnisse oder Probleme, nicht Features oder Funktionen, und fokussieren auf das Was und Warum, nicht auf das Wie.
5. **Disclaimer:** Wie sicher sind wir? Ein Hinweis, dass sich Dinge ändern können. Klingt defensiv, schützt aber beide Seiten. Was auf einer Roadmap steht, ist keine Zusage, sondern eine Visualisierung der strategischen Themen und eine Sequenz der Prioritäten. Der Disclaimer ist zentral für jede Roadmap.

**Optionale Elemente.** Je nach Zielgruppe können weitere Elemente sinnvoll sein:
- Confidence Levels (wie sicher ist die Planung?)
- Status / Stage of Development (Discovery, Prototype, Pre-Production)
- Zielkunde
- Produktbereiche (Product Areas)

Aber Vorsicht: Jede zusätzliche Information kann verwirren. Weniger ist oft mehr.

**Was nicht auf die Roadmap gehört:** Projektpläne, Gantt-Charts, detaillierte Timelines, Ressourcenplanung, Abhängigkeiten. Das gehört in den Release- oder Umsetzungsplan. Die Roadmap zeigt die Richtung, der Projektplan den Weg dorthin.

## Wann du sie einsetzt

- Eine strategische Roadmap für Produkt, Team oder Bereich aufbauen.
- Eine bestehende Roadmap prüfen: Sind alle fünf Kernelemente da? Steht etwas drauf, das in den Projektplan gehört?
- Als Realitätscheck: Passt die Ambition zur Kapazität?
- Um den strategischen Plan sichtbar zu machen: was in welcher Reihenfolge passiert, und damit auch, was nicht passiert.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Produkt, Team oder welchen Bereich? Für welche Zielgruppe ist die Roadmap (Board, Executives, Team Leads, Teams, Vertrieb)? Gibt es schon eine Roadmap oder Vision und Ziele? Frag nichts, was die Person schon gesagt hat.
- Bringt die Person eine bestehende Roadmap mit, prüfe sie gegen die fünf Kernelemente und die Liste dessen, was nicht draufgehört, bevor du neu aufbaust.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Tauchen Features statt Themes auf, oder feste Deadlines statt breiter Zeiträume? Benenne das direkt und kurz.
- Erfinde keine Ziele, Themen oder Termine der Person. Fehlt etwas, markiere es als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Die Schritte folgen den fünf Kernelementen in der Reihenfolge des Buchs, ergänzt um die optionalen Elemente.

1. **Vision.** Frage: *»Wohin wollt ihr? Wie lautet die Vision in einem Satz?«* Gut ist die Antwort, wenn sie die Richtung gibt, aber keine Details.

2. **Business Objectives.** Frage: *»Was wollt ihr erreichen, und woran messt ihr es?«* Gut ist die Antwort, wenn die Ziele messbar sind und erklären, warum die Roadmap existiert.

3. **Timeframes.** Frage: *»In welchen breiten Zeiträumen plant ihr, etwa Quartale, Halbjahre oder Now, Next, Later?«* Gut ist die Antwort, wenn keine spezifischen Deadlines auftauchen.

4. **Themes.** Frage: *»Welche Kundenbedürfnisse oder Probleme wollt ihr in welchem Zeitraum angehen?«* Gut ist die Antwort, wenn sie Was und Warum beschreibt, nicht Features oder das Wie.

5. **Disclaimer.** Frage: *»Wie macht ihr auf der Roadmap sichtbar, dass sich Dinge ändern können?«* Gut ist die Antwort, wenn klar wird, dass die Roadmap keine Zusage ist.

6. **Optionale Elemente wählen.** Frage: *»Was braucht eure Zielgruppe zusätzlich: Confidence Levels, Stage of Development, Zielkunden, Produktbereiche?«* Gut ist die Auswahl, wenn jedes Element für diese Zielgruppe einen Zweck hat. Im Zweifel weglassen.

7. **Aussortieren.** Frage: *»Steht etwas auf der Roadmap, das in den Release- oder Umsetzungsplan gehört: Tasks, Gantt-Charts, detaillierte Timelines, Ressourcen, Abhängigkeiten?«* Alles davon wandert in den Umsetzungsplan.

## Beispiel

Abb. 3.14 zeigt eine Roadmap für den fiktiven Gartenschlauch »The Wombatter Hose«:

- **Produkt-Vision:** Perfekte Rasenflächen und Gärten durch perfekte Wasserverteilung.
- **Timeframes:** H1'26, H2'26, 2027, Future.
- **Themes:** Unkaputtbarer Schlauch, Schonende Bewässerung empfindlicher Pflanzen, Umgang mit Extremwetter, Golfrasen-Qualität für den Garten, Mehr Reichweite, Unbegrenzte Erweiterbarkeit, Dünger ausbringen.
- **Objectives:** Stückzahlen steigern, Retouren senken, Defekte insgesamt senken. Ø Verkaufspreis verdoppeln. DACH-Region Expansion.
- **Zielkunden:** Stuttgart & Karlsruhe, DACH-Kernregionen, DACH & Benelux, Profimarkt.
- **Konfidenz:** 90 %, 75 %, 50 %, 25 %.
- **Phase:** Materialtests, Discovery, Prototyp, Vorproduktion.
- **Externe Treiber:** Partner Showcase 19. April, Garten- und Landschaftsmesse, Baumarkt- und Werkzeugmesse 23. Juni.

Die Anmerkungen der Abbildung erklären die Elemente: Die Features des Unkaputtbaren Schlauchs stehen zu 90 % fest, Marketing und Vertrieb können mit Vermarktung beginnen. Features späterer Themen sind noch nicht reif, um außerhalb des Entwicklungsteams diskutiert zu werden. Zielkunden sind entscheidend für die Planung von Vertrieb und Marketing. Konfidenz verhindert, dass der Vertrieb zu viel verspricht. Externe Treiber sind zeitlich fixe Gelegenheiten und geben Kontext, was wann bereit sein muss.

## Worauf du achten musst

- **Roadmap und Release Plan vermischen.** Die Roadmap steuert Outcomes, der Projektplan Outputs. Wer beides vermischt, verliert beides.
- **Features statt Themes.** Themes beschreiben Kundenbedürfnisse oder Probleme, nicht Funktionen.
- **Feste Deadlines.** Timeframes sind breite Zeiträume, keine Termine.
- **Kein Disclaimer.** Ohne ihn wird jeder Eintrag als Zusage gelesen. Jackie Bavaro: »Eine Roadmap in der Strategie ist kein Commitment.«
- **Zu viele optionale Elemente.** Jede zusätzliche Information kann verwirren.
- **Zu granular.** Strategic Planning definiert Initiativen, nicht Aufgaben.
- **Keine Updates.** Ein Plan, der einmal im Jahr erstellt und dann ignoriert wird, ist nutzlos.
- **Bereiche fehlen.** Der Plan muss alle relevanten Bereiche einschließen: Produkt, Technologie, Operations, Go-to-Market. Fehlt einer, treffen Teams dort Entscheidungen ohne Kontext.

## Ergebnis

Eine Roadmap mit den fünf Kernelementen und den gewählten optionalen Elementen, dazu eine Liste dessen, was in den Umsetzungsplan verschoben wurde. Vorlage: `templates/roadmap.md`.

```markdown
# Roadmap: [Produkt / Team / Bereich]
Stand: [Datum] · Zielgruppe: …

**Vision:** …

| | [Zeitraum 1] | [Zeitraum 2] | [Zeitraum 3] | [Zeitraum 4] |
|---|---|---|---|---|
| Themes | … | … | … | … |
| Business Objectives | … | … | … | … |
| (optional) Konfidenz | … % | … % | … % | … % |
| (optional) Phase | … | … | … | … |
| (optional) Zielkunden | … | … | … | … |
| (optional) Externe Treiber | … | … | … | … |

**Disclaimer:** Diese Roadmap ist keine Zusage. Sie zeigt strategische Themen und die Sequenz der Prioritäten. Inhalte können sich ändern.
**Bewusst nicht auf der Roadmap:** …
**In den Umsetzungsplan verschoben:** …
**Offene Punkte:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Enthält die Roadmap alle fünf Kernelemente: Vision, Business Objectives, Timeframes, Themes, Disclaimer?
- Beschreiben die Themes Probleme oder Kundenbedürfnisse statt Features?
- Arbeitet ihr mit breiten Zeiträumen statt mit Deadlines?
- Hat jedes optionale Element einen Zweck für die Zielgruppe?
- Sind Tasks, Timelines, Ressourcen und Abhängigkeiten im Umsetzungsplan statt auf der Roadmap?

## Im Flywheel

Modul DRIVE, Bereich D4 (im Buch »Guiding Principles«, inhaltlich Strategic Planning).

Verwandte Skills:
- `now-next-later`: ein mögliches Format für die Timeframes.
- `go-product-roadmap`: ein Roadmap-Format, das Outcomes vor Outputs stellt.
- `team-roadmap`: die operative Seite im Kapitel SHIP, also wie du eine Roadmap im Alltag führst, Confidence sichtbar machst und sie lebendig hältst.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D4 Guiding Principles, Strategic Planning und Frameworks für Strategic Planning, Anatomie einer Roadmap, Abb. 3.14. Originalquelle: C. Todd Lombardo, Bruce McCarthy, Evan Ryan, Michael Connors: Product Roadmaps Relaunched.

Original: C. Todd Lombardo, Bruce McCarthy, Evan Ryan, Michael Connors: Product Roadmaps Relaunched, O'Reilly, 2017.
