# Roadmap: Kernelemente und optionale Elemente

Nach Abb. 3.14 im Drive Leadership Playbook, nach »Product Roadmaps Relaunched« von C. Todd Lombardo, Bruce McCarthy, Evan Ryan und Michael Connors.

**Produkt / Team / Bereich:**
**Stand:**
**Zielgruppe der Roadmap:**

## Vision
Wohin wollen wir?

## Roadmap

| | Zeitraum 1: | Zeitraum 2: | Zeitraum 3: | Future |
|---|---|---|---|---|
| **Themes** (Kundenbedürfnis oder Problem, kein Feature) | | | | |
| **Business Objectives** (messbar) | | | | |
| Features (nur wo reif) | | | | |
| Zielkunden (optional) | | | | |
| Konfidenz in % (optional) | | | | |
| Phase / Stage of Development (optional) | | | | |
| Produktbereich (optional) | | | | |
| Externe Treiber (optional) | | | | |

Timeframes: breite Zeiträume (Halbjahre, Quartale, Jahre oder Now, Next, Later), keine Deadlines.

## Disclaimer
Was auf dieser Roadmap steht, ist keine Zusage. Sie zeigt die strategischen Themen und die Sequenz der Prioritäten. Dinge können sich ändern.

## Was wir bewusst nicht machen

## Gehört in den Release- oder Umsetzungsplan, nicht hierher
Projektpläne, Gantt-Charts, detaillierte Timelines, Ressourcenplanung, Abhängigkeiten:
