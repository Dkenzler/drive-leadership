---
name: braintrust
description: "Quality Reviews nach dem Vorbild des Pixar Braintrust (Ed Catmull, Creativity, Inc.) aufsetzen und führen, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand ehrliches Feedback auf laufende Arbeit organisieren will, ohne dass der Review zur Bewertungssession wird. Typische Auslöser: Design Critique, Product Review oder Peer Review einführen, Review-Rhythmus festlegen, eine Review-Runde zusammenstellen, Feedback als Notes statt Anweisungen geben, Qualität vor einem Release prüfen, Reviews, in denen niemand offen spricht. Führt durch die fünf Bedingungen: Fachleute als Peers, das Werk statt der Person, Notes statt Vorschriften, Candor ohne Grausamkeit, das Ganze reviewen."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S5 Ensure Quality
  origin: Ed Catmull
  deep_dive: true
  version: "1.0"
---

# Quality Review / Braintrust

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Ed Catmull.

## Worum es geht

Reviews sind keine bürokratischen Pflichten, sondern das operative Herzstück der Qualitätssicherung. Ein Quality Review im Sinne des Braintrust ist kein Tribunal, bei dem die Führung urteilt und das Team zuhört. Er ist ein Gespräch, in dem erfahrene Leute helfen, Probleme früh zu sehen und zu verstehen. Ziel ist nicht, recht zu behalten, sondern dass die Arbeit besser wird.

Ed Catmull, Mitgründer von Pixar, beschreibt den Braintrust in »Creativity, Inc.« als das Werkzeug, mit dem Pixar Filme aus einem schwachen ersten Zustand zu dem entwickelt, was am Ende im Kino läuft. Sein Ausgangspunkt: Am Anfang taugen alle Filme nichts. Dieser Satz nimmt die Scham aus der frühen Arbeit und macht es möglich, Unfertiges offen zu zeigen. Eine Gruppe erfahrener Filmemacher schaut sich den aktuellen Stand an und gibt ehrliches, direktes Feedback. Catmull vergleicht es mit einem Kreis von Ärzten, die gemeinsam in einem Konzil auf einen Fall schauen.

Der Braintrust beruht nicht auf gutem Willen oder Höflichkeit, sondern auf konkreten Bedingungen, die offene und nützliche Kritik möglich machen. Das Entscheidende: Er hat keine Entscheidungsbefugnis. Er berät, die verantwortliche Person entscheidet. Das nimmt den defensiven Charakter aus Reviews.

Reviews leisten dreierlei: Sie machen die Arbeit besser, statt sie zu benoten. Sie holen den Blick von außen, den im Projekt niemand mehr hat. Und sie bauen eine gemeinsame Vorstellung von »gut«, weil die Qualitätsbar am konkreten Objekt gezeigt statt behauptet wird.

## Wann du sie einsetzt

- Laufende Arbeit regelmäßig reviewen, nicht erst am Ende.
- Ein Review-Format einführen: wöchentliche Design Critique, monatlicher Product Review, Peer Review vor dem Release.
- Einen Review-Rhythmus für die Organisation aufsetzen, von der Führungsebene getragen.
- Reviews reparieren, in denen niemand offen spricht oder die sich in Meinungen und gut gemeinten Ratschlägen verlieren.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Arbeit soll reviewt werden (Produkt, Kampagne, Dokument, Projekt)? Gibt es schon ein Review-Format, und was läuft daran schief? Welche Rolle hat die Person im Review (verantwortlich für die Arbeit, Leitung, Teil der Runde)? Frag nichts, was sie schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten. Hat die Person schon ein Format, prüfe es gegen die fünf Bedingungen und steig dort ein, wo es hakt.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Hat der Review Autorität? Sitzt die Führungskraft so im Raum, dass sie die Offenheit dämpft? Benenne Schwächen direkt und kurz.
- Hilf beim Formulieren von Notes: Formuliert die Person eine Lösungsanweisung, übersetze sie in ein benanntes Problem mit Wirkung.
- Erfinde keine Fakten über das Team oder die Arbeit der Person. Fehlt etwas, markiere es als offen.
- Biete an, Einladung, Ablauf und Moderationsfragen für die Review-Session zu erstellen.
- Schließe mit dem Review-Setup im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Die fünf Bedingungen aus Abb. 5.21 stecken in den Schritten 1 bis 6: Fachleute als Peers, niemand hat Weisungsrecht über die Arbeit (1, 2). Das Werk, nicht die Person (3). Notes statt Vorschriften (4). Candor ohne Grausamkeit (5). Das Ganze reviewen (6). Rhythmus und Headline (7, 8) machen daraus ein dauerhaftes Format.

1. **Fachleute als Peers zusammenstellen.** Der Braintrust besteht aus Menschen mit tiefem Verständnis der Sache, die den Prozess selbst durchlaufen haben. Es geht nicht um Hierarchie, sondern um Sachverstand und Empathie. Gesucht sind Leute, die das Handwerk beurteilen können und der Arbeit wohlgesonnen sind.
   Frage: *»Wer kann diese Arbeit fachlich beurteilen, steckt nicht selbst in den Details und will, dass sie gelingt?«*
   Gut ist die Antwort, wenn die Auswahl nach Sachverstand erfolgt, nicht nach Rang.

2. **Feedback strikt von Autorität trennen.** Das wichtigste Prinzip. Der Review berät, die verantwortliche Person entscheidet selbst, was sie mit dem Feedback macht. Sobald der Review verbindliche Anweisungen ausspricht, kippt er von Hilfe in Kontrolle, und die Offenheit verschwindet. Nimm die Macht aus dem Raum, dann entstehen ehrliche Gespräche.
   Frage: *»Wer entscheidet nach dem Review, was umgesetzt wird, und wissen das alle in der Runde?«*
   Gut ist die Antwort, wenn eindeutig die verantwortliche Person entscheidet.

3. **Das Werk unter das Mikroskop legen, nicht die Person.** Zur Diskussion steht die Arbeit, nicht der Mensch, der sie gemacht hat. Catmulls Formel: Du bist nicht deine Idee. Wer diese Trennung schafft, nimmt die Verteidigungshaltung aus dem Raum.

4. **Notes geben, keine Lösungen vorschreiben.** Eine Note benennt ein Problem und seine Wirkung, ohne die Lösung vorzugeben. Statt »Mach den Button blau und schieb ihn nach links« heißt es: »Mir ist der Button gar nicht aufgefallen.« Das Erste nimmt dem Owner die Lösung aus der Hand, das Zweite weist auf ein Problem hin, das er auf seine Weise lösen kann. Gute Notes sind spezifisch, rechtzeitig und auf die Sache bezogen.
   Frage: *»Welche Beobachtungen habt ihr? Formuliere jede als Problem und seine Wirkung, ohne Lösung.«*

5. **Candor halten, Grausamkeit vermeiden.** Candor zielt auf die Arbeit, Grausamkeit auf die Person. »Dieser Flow ist verwirrend, ich verstehe nicht, was ich als Nächstes tun soll« ist Candor. »Dieses Design ist schlecht, hast du überhaupt an die Nutzenden gedacht?« ist ein Angriff. Der Inhalt mag ähnlich sein, die Wirkung ist gegensätzlich.

6. **Das Ganze reviewen, nicht nur die Scheibe.** Qualität lebt in den Übergängen. Zeigt jedes Team nur seinen Ausschnitt, sieht niemand das Gesamtbild. Brian Chesky hat Airbnb nach 2020 darauf umgestellt, das Produkt als Ganzes zu reviewen, nicht Stück für Stück.
   Frage: *»Zeigt ihr im Review den gesamten Stand oder nur ausgewählte Teile?«*

7. **Einen festen Rhythmus etablieren.** Reviews, die nur stattfinden, wenn Zeit übrig ist, finden nie statt. Jedes Projekt bekommt je nach Phase eine feste Taktung: wöchentlich, zweiwöchentlich oder monatlich. Bei Pixar trifft sich der Braintrust über die gesamte Laufzeit eines Films, nicht einmal am Ende. Qualität auf Organisationsebene entsteht durch vorhersehbare Reviews, die von der Führungsebene getragen werden.
   Frage: *»In welcher Taktung wird dieses Projekt reviewt, und steht der Termin fest im Kalender?«*

8. **Die Ergebnisse headlinen.** Nach der Session verdichtet eine Person die vielen Beobachtungen zu den wenigen zentralen Punkten. So wird aus einem langen Gespräch eine handhabbare Essenz, mit der die verantwortliche Person weiterarbeiten kann.
   Frage: *»Wer verdichtet nach der Session die Notes zu den wenigen zentralen Punkten?«*

## Beispiel

Bei Native Instruments verbrachte Mate Galic, Dominik Kenzlers Mentor und Manager, ein komplettes Wochenende damit, die Maschine+ zu testen, das erste eigenständige Hardwaregerät des Unternehmens, das eigentlich in die Produktion gehen sollte. Er schrieb ein langes Review-Dokument mit allen Beobachtungen. Die Botschaft: nicht gut genug. Ladezeiten zu lang, wichtige Funktionen fehlten oder waren nicht ausgereift. Er stoppte den Release, verschob ihn und setzte die Erwartungen neu.

Dominik Kenzler hat bei sevdesk und Native Instruments zwei feste Formate etabliert: eine wöchentliche Design Critique und monatliche Product Reviews, in denen Teams ihre wichtigsten Projekte als Ganzes präsentierten. Ziel beider Formate: Arbeit sichtbar machen, bevor sie fertig ist, offen über Qualität sprechen und andere Expert:innen einbeziehen.

## Worauf du achten musst

- **Den Review zur Bewertungssession machen.** Sobald Mitarbeitende einen Review fürchten, zeigen sie ihre geschönte Arbeit, nicht ihre ehrliche. Der Review ist ein Gespräch über die Sache, kein Urteil über die Person.
- **Den Review mit Autorität aufladen.** Schreibt der Review verbindlich vor, was zu tun ist, entsteht Abwehr statt Offenheit. Die Trennung von Feedback und Entscheidung ist die Bedingung, dass er funktioniert.
- **Reviews verschieben, wenn es eng wird.** Reviews, die verschoben, abgesagt oder durch Status-Updates ersetzt werden, sind kein Qualitätsmechanismus, sondern ein Schönwetterritual.
- **Die Offenheit nicht schützen.** Blockaden, Angst vor Blamage, Höflichkeit und Respekt vor Rang kommen ständig zurück. Catmull sieht seine wichtigste Aufgabe darin, die Bedingungen für Candor immer wieder herzustellen. Er hielt Steve Jobs bewusst aus den Braintrust-Meetings heraus, weil dessen dominante Präsenz die offene Diskussion erstickt hätte. Auch die eigene Anwesenheit als Führungskraft kann die Wahrheit im Raum unterdrücken. Catmulls Warnzeichen: Wenn auf den Fluren mehr Wahrheit gesprochen wird als in den Meetings, gibt es ein Problem.
- **Mikromanagement mit Involvement verwechseln.** In den Details sein heißt, die Arbeit gut genug zu kennen, um sie beurteilen zu können. Brian Chesky nennt das Oversight, wie ein Vorstand gegenüber einem CEO: Fragen stellen, Ergebnisse sehen, Standards setzen, aber nicht sagen, wie es gemacht werden soll.

## Ergebnis

```markdown
# Quality Review: [Format / Projekt]
Stand: [Datum] · Verantwortlich für die Arbeit: [Name / Rolle]

**Format:** Braintrust / Design Critique / Product Review / Peer Review
**Rhythmus:** wöchentlich / zweiwöchentlich / monatlich · nächster Termin: …
**Runde (Fachleute als Peers):** … (Auswahl nach Sachverstand, nicht Rang)
**Entscheidung liegt bei:** … (Review berät, entscheidet nicht)
**Was gezeigt wird:** der gesamte Stand von …

## Notes aus der Session
| Beobachtung (Problem + Wirkung, keine Lösung) | von |
|---|---|
| | |

## Headline (die wenigen zentralen Punkte)
1. …
2. …
3. …

**Headline verfasst von:** …
**Was die verantwortliche Person damit macht:** …
```

## Mini-Check

- Hat dein Review echte Fachleute am Tisch versammelt, die das Handwerk beurteilen können und der Arbeit wohlgesonnen sind?
- Ist klar, dass der Review berät und nur die verantwortliche Person entscheidet, sodass der Review keine Autorität hat?
- Geben die Beteiligten Notes, die Probleme benennen statt Lösungen vorzuschreiben?
- Reviewt ihr die Arbeit als Ganzes und in festem Rhythmus, nicht nur einzelne Teile am Ende?
- Schützt du aktiv die Offenheit, auch indem du deine eigene Wirkung als Führungskraft im Raum bedenkst?

## Im Flywheel

Modul SHIP, Bereich S5 Ensure Quality.

Der Braintrust ist die stärkste Ausprägung eines Quality Review, das Prinzip skaliert nach unten. Eine wöchentliche Design Critique, ein monatlicher Product Review oder ein Peer Review, bei dem vor dem Release noch jemand über die Arbeit schaut, folgen derselben Logik: ehrliches Feedback ohne Autorität, bezogen auf die Arbeit, in festem Rhythmus. Nicht jedes Review braucht die Führungskraft. Wer allein an etwas arbeitet, verliert den Abstand, eine zweite Person sieht sofort, was man selbst nicht mehr sieht.

Verwandte Skills:
- `performance-reviews`: Abgrenzung laut Buch. Der Quality Review schaut auf die Arbeit, der Performance Review auf die Person und ihre Entwicklung. Beide brauchen Klarheit und Ehrlichkeit, verfolgen aber verschiedene Ziele und sollten nicht vermischt werden.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S5 Ensure Quality, Einleitung und Quality Review und Deep Dive Braintrust, Abb. 5.21. Originalquelle: Ed Catmull: Creativity, Inc.

Original: Ed Catmull mit Amy Wallace: Creativity, Inc., 2014.
