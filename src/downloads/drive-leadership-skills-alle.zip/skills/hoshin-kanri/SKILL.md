---
name: hoshin-kanri
description: "Strategische Planung mit Hoshin Kanri (»Kompass-Management«, von Toyota entwickelt) und dem Catchball-Prozess, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand in einer größeren Organisation mit mehreren Ebenen Prioritäten im Dialog mit den Teams klären, Vision, Durchbruchziele, Jahresziele, Strategien, Maßnahmen und Kennzahlen in einer Matrix verbinden oder Alignment herstellen will, weil frühere Strategien an der Umsetzung gescheitert sind. Schlanke Fassung: Das Buch nutzt vor allem den Catchball-Gedanken, nicht die volle Form mit X-Matrix, A3-Reports und mehrstufigen Review-Zyklen."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D4 Guiding Principles (Strategic Planning)
  origin: Toyota
  deep_dive: false
  version: "1.0"
---

# Hoshin Kanri

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Toyota.

## Worum es geht

Hoshin Kanri bedeutet »Kompass-Management«. Das Framework stammt aus den 1960er-Jahren und wurde von Toyota entwickelt. In seiner vollen Form ist es ziemlich komplex, mit X-Matrix, A3-Reports und mehrstufigen Review-Zyklen. Das Buch nimmt es auf, weil es Ansätze enthält, die für das strategische Planen sehr nützlich sind, vor allem den Catchball-Prozess, um sich im Team über Prioritäten klar zu werden.

Die Kernidee: Die konkrete Ausgestaltung entsteht im Dialog mit den Teams. Der Ball geht hin und her, bis echtes Alignment entsteht. Das ist die methodische Antwort auf das, was Nickey Skarstad, ehemals Director of Product Management bei Etsy, auf den Punkt bringt: Strategie sollte nicht im stillen Kämmerlein entwickelt werden, es geht darum, die Menschen mitzunehmen.

Abb. 3.16 zeigt die Struktur als Matrix mit diesen Feldern:
- **Vision**
- **Durchbruchziele** (3 bis 5 Jahre)
- **Jahresziele**
- **Strategien**
- **Maßnahmen**
- **Kennzahlen**
- verantwortliche **Bereiche**

## Wann du sie einsetzt

- In größeren Organisationen mit mehreren Ebenen.
- Wenn Alignment das Hauptproblem ist.
- Wenn frühere Strategien an der Umsetzung gescheitert sind.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wie viele Ebenen hat die Organisation, und für welche plant die Person? Gibt es eine Vision und Ziele? Woran ist die letzte Strategie in der Umsetzung gescheitert? Frag nichts, was die Person schon gesagt hat.
- Das Buch beschreibt Hoshin Kanri knapp und konzentriert sich auf den Catchball-Gedanken. Arbeite mit der schlanken Fassung. Wenn die Person die volle Form mit X-Matrix, A3-Reports und Review-Zyklen will, sag, dass das Buch sie nicht ausführt.
- Catchball findet mit den Teams statt, nicht mit dir. Biete an, den Entwurf, die Fragen für die Catchball-Runden und eine Übersicht der Rückmeldungen vorzubereiten.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz.
- Erfinde keine Ziele, Zahlen oder Bereiche der Organisation. Fehlt etwas, markiere es als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Das Buch beschreibt keinen festen Ablauf. Die Schritte ordnen die Felder aus Abb. 3.16 und den Catchball-Gedanken aus dem Text.

1. **Vision festhalten.** Frage: *»Was ist die Vision, an der sich alle Ebenen ausrichten?«*

2. **Durchbruchziele (3 bis 5 Jahre).** Frage: *»Was wollt ihr in drei bis fünf Jahren erreicht haben?«* Gut ist die Antwort, wenn sie wenige, große Ziele nennt.

3. **Jahresziele.** Frage: *»Was muss dafür in diesem Jahr erreicht werden?«* Gut ist die Antwort, wenn jedes Jahresziel auf ein Durchbruchziel einzahlt.

4. **Strategien, Maßnahmen, Kennzahlen, Bereiche als Entwurf.** Frage: *»Mit welchen Strategien und Maßnahmen wollt ihr die Jahresziele erreichen, woran messt ihr sie, und welcher Bereich ist verantwortlich?«* Das ist ein Entwurf, keine Vorgabe.

5. **Catchball mit den Teams.** Den Entwurf an die Teams geben, Rückmeldungen einholen, anpassen, zurückgeben. Der Ball geht hin und her, bis echtes Alignment entsteht.
   Frage: *»Mit welchen Teams spielt ihr den Ball, und was fragt ihr sie?«* Gut ist das Ergebnis, wenn die Teams die konkrete Ausgestaltung mitentwickelt haben und nicht nur informiert wurden.

## Beispiel

Abb. 3.16 zeigt die Matrix an einem Beispiel. Die Einträge in den Feldern für Vision, Durchbruchziele, Jahresziele und Strategien lauten: Marktführer in der Branche werden, Jahresgewinn um 30 % steigern, Umsatz um 20 % steigern, Marktanteil um 10 % erhöhen, Produktionskosten um 8 % senken, neue Kundensegmente erschließen und neue Vertriebswege öffnen. Maßnahmen: Produktion effizienter gestalten, Einkaufs- und Lieferbedingungen verhandeln, Werbung für Produkte ausbauen. Kennzahlen: verkaufte Stückzahlen, Herstellungskosten, Kundenzufriedenheit. Bereiche: Produktion, Einkauf, Marketing.

## Worauf du achten musst

(abgeleitet aus dem Text des Buchs)

- **Strategie im stillen Kämmerlein.** Die Kernidee ist der Dialog. Wird der Entwurf nur verkündet, ist es kein Catchball.
- **Zu früh aufhören.** Der Ball geht hin und her, bis echtes Alignment entsteht, nicht nur eine Runde.
- **Die volle Form erzwingen.** Hoshin Kanri ist in voller Form komplex. Für die meisten Fälle reicht der Catchball-Gedanke.
- **Kein Alignment zwischen Bereichen.** Bereichspläne, die nicht aufeinander abgestimmt sind, führen zu Konflikten und Doppelarbeit. Strategic Planning ist ein Alignment-Prozess.

## Ergebnis

Vorlage: `templates/hoshin-matrix.md`.

```markdown
# Hoshin Kanri: [Organisation]
Stand: [Datum] · Ebene: …

**Vision:** …
**Durchbruchziele (3 bis 5 Jahre):** …
**Jahresziele:** …

| Strategie | Maßnahme | Kennzahl | Bereich |
|---|---|---|---|
| … | … | … | … |

**Catchball-Runden**
| Team | Rückmeldung | Anpassung |
|---|---|---|
| … | … | … |

**Stand Alignment:** erreicht / offen bei …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Zahlen die Jahresziele auf die Durchbruchziele ein, und diese auf die Vision?
- Hat jede Maßnahme eine Kennzahl und einen verantwortlichen Bereich?
- Haben die Teams die konkrete Ausgestaltung im Dialog mitentwickelt?
- Ging der Ball so lange hin und her, bis echtes Alignment entstanden ist?
- Sind die Pläne der Bereiche aufeinander abgestimmt?

## Im Flywheel

Modul DRIVE, Bereich D4 (im Buch »Guiding Principles«, inhaltlich Strategic Planning).

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D4 Guiding Principles, Frameworks für Strategic Planning, Abb. 3.16. Originalquelle laut Buch: Toyota, 1960er-Jahre.

Original: Yoji Akao (Hrsg.): Hoshin Kanri. Policy Deployment for Successful TQM, Productivity Press, 1991.
