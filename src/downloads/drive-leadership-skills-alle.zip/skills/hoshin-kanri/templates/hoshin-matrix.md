# Hoshin Kanri: Matrix

Nach Abb. 3.16 im Drive Leadership Playbook.

**Organisation / Ebene:**
**Stand:**

## Vision

## Durchbruchziele (3 bis 5 Jahre)
1.
2.

## Jahresziele
1.
2.
3.

## Strategien
1.
2.

## Maßnahmen, Kennzahlen, Bereiche

| Maßnahme | Kennzahl | Bereich |
|---|---|---|
| | | |
| | | |
| | | |

## Catchball

| Runde | Team | Rückmeldung | Anpassung |
|---|---|---|---|
| 1 | | | |
| 2 | | | |

**Alignment erreicht:** ja / offen bei
