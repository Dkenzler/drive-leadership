# 360-Grad-Feedback

Nach der Methode »Feedback aktiv einholen« im Drive Leadership Playbook. Ein- bis zweimal im Jahr, drei bis fünf Personen aus verschiedenen Richtungen, alle bekommen denselben Fragenkatalog.

**Name:**
**Zeitraum:**

## Wen du fragst

| Person | Richtung (Direct Report / Peer / Führungskraft) | Angefragt am | Antwort erhalten |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

## Fragenkatalog (für alle gleich)

1. Was mache ich gut?
2. Wo habe ich blinde Flecken?
3. Was sollte ich ändern?

## Antworten

| Person / Richtung | Was mache ich gut? | Wo habe ich blinde Flecken? | Was sollte ich ändern? |
|---|---|---|---|
| | | | |

## Muster über die Quellen hinweg

| Thema | Wie oft genannt | Aus welchen Richtungen |
|---|---|---|
| | | |

## Was ich angehe

| Thema | Maßnahme | Zurückgespielt an | Am |
|---|---|---|---|
| | | | |
