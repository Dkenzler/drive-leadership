---
name: feedback-einholen
description: Als Führungskraft aktiv Feedback einholen, statt darauf zu warten, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand ehrliches Feedback auf die eigene Führung will, spezifische Feedbackfragen formulieren, Feedback in 1:1s verankern, ein 360-Grad-Feedback mit Direct Reports, Peers und Vorgesetzten aufsetzen, Feedback von außen (Mentor, Coach, Peers in anderen Unternehmen) holen, Feedback auswerten und den Kreis schließen will. Auch hilfreich bei Spannungen mit einem anderen Team, weil aktiv eingeholtes Feedback Konflikte lösen und Vertrauen aufbauen kann.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 1 Dich selbst kennen
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Feedback aktiv einholen

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Die meisten Führungskräfte warten auf Feedback, die wenigsten holen es sich aktiv. Das ist ein strukturelles Problem: Feedback kommt selten von allein, und wenn es kommt, kommt es zu spät.

Je höher du in einer Organisation angesiedelt bist, desto seltener bekommst du ehrliches Feedback. Menschen zögern, ihre Vorgesetzten zu korrigieren, passen ihre Botschaften an und sagen, was du ihrer Meinung nach hören willst. Das ist keine Böswilligkeit, es ist menschlich. Aber wer nicht aktiv fragt, bleibt blind für die eigenen blinden Flecken.

Susan Cain (»Quiet«) ergänzt: Selbstvertrauen folgt dem Können, nicht umgekehrt. Feedback ist der direkteste Weg, zu sehen, wo du wirklich stehst und wo du als Nächstes wachsen kannst. Und eine Führungskraft, die Feedback einfordert, schafft eine Kultur, in der Feedback in alle Richtungen fließt. Du kannst in deinem Team keine Feedbackkultur erwarten, wenn du selbst keine vorlebst.

## Wann du sie einsetzt

- Laufend, am Ende jedes 1:1.
- Ein- bis zweimal im Jahr als strukturiertes 360-Grad-Feedback.
- Wenn du Muster sehen willst, die im Alltag unsichtbar bleiben: mit Feedback von außen.
- Bei Spannungen mit einem anderen Team oder Bereich.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Zu welchem Thema oder welcher Situation willst du Feedback? Von wem kannst du es bekommen (Direct Reports, Peers, Vorgesetzte, extern)? Holst du schon Feedback ein, und wie? Frag nichts, was die Person schon gesagt hat.
- Unterscheide drei Einstiege: Fragen formulieren (Schritte 1 bis 3), 360-Grad-Feedback aufsetzen (Schritt 4 mit `templates/360-feedback.md`), Feedback auswerten und zurückspielen (Schritte 6 und 7).
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist die Feedbackfrage spezifisch? Benenne Schwächen direkt und kurz. Kein Lob als Füllmaterial.
- Bei der Auswertung: Arbeite nur mit dem Feedback, das die Person dir gibt. Erfinde keine Aussagen, und gib keine eigene Einschätzung ihrer Persönlichkeit ab. Kennzeichne, welches Thema aus wie vielen Quellen kommt.
- Schließe mit dem Plan oder der Auswertung im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Direkt und spezifisch fragen.** Die schlechteste Feedbackfrage ist »Hast du Feedback für mich?«. Sie ist zu offen und erzeugt nur höfliche Allgemeinplätze. Besser sind konkrete Fragen, etwa:
   - »Ich habe das Meeting heute so geführt. Was hätte ich besser machen können?«
   - »Ich glaube, meine Kommunikation in diesem Projekt war nicht klar genug. Stimmst du zu? Was könnte ich konkret ändern?«
   - »Welche meiner Gewohnheiten als Führungskraft hilft dir am meisten? Welche stört dich?«

   Frage: *»Zu welcher konkreten Situation oder Gewohnheit willst du Feedback? Lass uns daraus eine spezifische Frage machen.«*
   Gut ist die Frage, wenn sie sich auf eine konkrete Situation oder ein konkretes Verhalten bezieht. Je konkreter die Frage, desto nützlicher die Antwort.

2. **In 1:1s verankern.** Am Ende jedes 1:1 eine kurze Feedbackfrage an dich: »Was könnte ich in unserer Zusammenarbeit besser machen?« Als Routine normalisiert das Feedback als bidirektionalen Fluss statt als Einbahnstraße nach unten.
   Frage: *»In welchen 1:1s startest du damit, und ab wann?«*

3. **Feedback von außen holen.** Von Peers in anderen Unternehmen, von einem Mentor, von einem Coach. Menschen ohne direkten Kontext zu deiner Arbeit sehen oft Muster, die im Alltag unsichtbar bleiben, und haben keinen Grund, dir zu schmeicheln.
   Frage: *»Wer außerhalb deines Unternehmens kennt deine Arbeit gut genug, um ehrlich Rückmeldung zu geben?«*

4. **360-Grad-Feedback durchführen.** Ein- bis zweimal im Jahr drei bis fünf Personen aus verschiedenen Richtungen fragen: Direct Reports, Peers, deine Führungskraft. Allen denselben Fragenkatalog stellen:
   - Was mache ich gut?
   - Wo habe ich blinde Flecken?
   - Was sollte ich ändern?

   Frage: *»Welche drei bis fünf Personen fragst du, und deckt die Auswahl alle Richtungen ab?«*

5. **Aufschreiben.** Feedback hören ist eine Sache, es aufnehmen eine andere. Schreib auf, was du hörst.

6. **Muster suchen.** Die Muster über verschiedene Quellen hinweg sind die wertvollsten Informationen. Wenn dasselbe Thema von drei verschiedenen Menschen kommt, ist es kein Zufall.
   Frage: *»Welche Themen kommen aus mehreren Quellen, und welche davon willst du aktiv angehen?«*

7. **Zurückkommunizieren, was du getan hast.** Zum Beispiel: »Du hast mir gesagt, dass meine Kommunikation in Meetings zu wenig Raum für andere lässt. Ich habe seitdem versucht, mehr Fragen zu stellen, bevor ich meine Position teile. Wie nimmst du das wahr?« Das schließt den Kreis, zeigt, dass Feedback bei dir landet, und ermutigt die Person, dir ehrlich zu begegnen.
   Frage: *»Wem spielst du zurück, was du geändert hast, und wann?«*

## Beispiel

Bei sevdesk hatte Dominik Kenzler mit Sergio einen starken Product Director im Team. Bei einem Projekt gab es Spannungen mit dem Marketing-Team. Sergio holte sich daraufhin aktiv 360-Grad-Feedback bei seinen Peers und beim Marketing-Team ein, fasste alles zusammen, ergänzte die Themen, die er aktiv angehen wollte, und teilte das offen mit dem Marketing-Team. Alle Beteiligten waren beeindruckt von dieser Offenheit, und die Zusammenarbeit war sofort auf einem deutlich besseren Niveau. Aktiv eingeholtes Feedback ist nicht nur ein Werkzeug zur Selbstentwicklung, es kann auch Konflikte lösen und Vertrauen aufbauen.

## Worauf du achten musst

- **Auf Feedback warten.** Es kommt selten von allein, und dann zu spät.
- **Zu offen fragen.** »Hast du Feedback für mich?« erzeugt Allgemeinplätze. Die Spezifität der Frage entscheidet über die Qualität der Antwort.
- **Nur aus einer Richtung fragen.** Die Muster über verschiedene Quellen hinweg sind die wertvollsten Informationen.
- **Hören, aber nicht aufnehmen.** Feedback hören ist eine Sache, es aufnehmen eine andere. Schreib auf und such nach Mustern.
- **Den Kreis nicht schließen.** Erst das Zurückmelden zeigt, dass Feedback bei dir landet, und ermutigt die Person, dir ehrlich zu begegnen.

## Ergebnis

Vorlage für das 360-Grad-Feedback: `templates/360-feedback.md`.

```markdown
# Feedback-Plan: [Name]
Stand: [Datum]

**Spezifische Feedbackfragen:**
1. …
2. …

**Routine:** Frage am Ende jedes 1:1 ab [Datum]: »Was könnte ich in unserer Zusammenarbeit besser machen?«
**Feedback von außen:** [Personen]
**360-Grad-Feedback:** [Zeitraum] · Direct Reports: … · Peers: … · Führungskraft: …

## Auswertung
| Thema | Genannt von (Anzahl / Richtung) | Gehe ich an? | Maßnahme |
|---|---|---|---|
| | | | |

**Zurückgespielt an:** … am …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Bezieht sich jede deiner Feedbackfragen auf eine konkrete Situation oder Gewohnheit?
- Fragst du Menschen aus verschiedenen Richtungen, auch von außen?
- Hast du aufgeschrieben, was du gehört hast, und nach Mustern über mehrere Quellen gesucht?
- Hast du den Personen zurückgemeldet, was du mit ihrem Feedback gemacht hast?

## Im Flywheel

Modul YOURSELF, Teil 1 Dich selbst kennen. YOURSELF ist der äußere Ring des Leadership Flywheel, der Drive, Lead und Ship trägt. Feedback ist laut Buch eines von drei Dingen, die helfen, die eigenen Muster zu erkennen, neben bewusster Selbstbeobachtung und Persönlichkeitstests.

Verwandte Skills:
- `sbi-feedback`, `radical-candor`, `difficult-conversations`: Im LEAD-Kapitel geht es darum, wie du Feedback gibst. Diese Methode dreht die Richtung um.
- `persoenlichkeitstests`: die zweite externe Perspektive auf dich selbst.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Einleitung und Teil 1 Dich selbst kennen, Feedback aktiv einholen. Zitierte Stimme: Susan Cain: Quiet.
