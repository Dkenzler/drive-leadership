# Odyssey Plan

Nach Abb. 6.10 im Drive Leadership Playbook, nach Bill Burnett und Dave Evans. Ein Blatt pro Plan, drei Pläne insgesamt.

**Plan:** 1 (aktueller Weg, konsequent verlängert) / 2 (wenn Plan 1 wegfiele) / 3 (wenn Geld und das Urteil anderer keine Rolle spielten)

## TITEL

(wenige Worte, die den Kern einfangen)

## ZEITLEISTE ÜBER FÜNF JAHRE

Beruflich und persönlich, auch Nichtberufliches.

| Jahr 1 | Jahr 2 | Jahr 3 | Jahr 4 | Jahr 5 |
|---|---|---|---|---|
| | | | | |

## DIE VIER REGLER

| Regler | Skala | Einschätzung |
|---|---|---|
| Ressourcen | wenig bis viel | |
| Likability | kalt bis heiß | |
| Confidence | unsicher bis sicher | |
| Coherence | gering bis hoch | |

## ZWEI BIS DREI OFFENE FRAGEN

-
-
-
