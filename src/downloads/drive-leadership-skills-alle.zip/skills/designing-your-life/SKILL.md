---
name: designing-your-life
description: Die eigene Laufbahn und das Leben als Designproblem angehen mit Designing Your Life nach Bill Burnett und Dave Evans (Stanford Life Design Lab), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand an einem Wendepunkt steht, das Gefühl hat, nur noch zu funktionieren, über die nächsten fünf Jahre nachdenkt, Karriereoptionen durchspielen, einen Plan B entwickeln oder festgefahrene Überzeugungen über die eigene Laufbahn lösen will. Führt durch das Reframen dysfunktionaler Überzeugungen, das Erkennen von Gravity Problems, drei Odyssey Plans mit Titel, Fünf-Jahres-Zeitleiste, vier Reglern und offenen Fragen sowie kleine Prototypen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 3 Dich weiterentwickeln und in Übergängen wachsen
  origin: Bill Burnett und Dave Evans
  deep_dive: false
  version: "1.0"
---

# Designing Your Life

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Bill Burnett und Dave Evans.

## Worum es geht

Die meisten Methoden im YOURSELF-Kapitel arbeiten im Jetzt. Designing Your Life zoomt heraus: auf die große Linie, deine Laufbahn und dein Leben als Ganzes. Wer weiß, wohin er sich langfristig entwickeln will, trifft auch im Alltag bessere Entscheidungen.

Die Methode stammt von Bill Burnett und Dave Evans, die das Life Design Lab an der Stanford University gegründet haben. Ihre Grundidee: Man kann das eigene Leben mit denselben Prinzipien angehen wie ein gutes Designproblem. Designer denken nicht nach vorne, sie bauen nach vorne. Statt im Kopf nach der richtigen Antwort zu suchen, gehen sie neugierig vor, probieren aus und lernen aus dem, was die Realität zurückspielt. Du musst nicht den einen perfekten Plan finden. Du erkundest mehrere Richtungen und findest deinen Weg im Gehen.

Das Herzstück sind die Odyssey Plans: drei verschiedene Pläne für die nächsten fünf Jahre. Der Sinn ist nicht, sich für einen Plan zu entscheiden, sondern zu erkennen, dass es mehrere gute Leben in dir gibt. Das nimmt Druck von der Vorstellung, es gäbe genau eine richtige Entscheidung, die du nicht verpassen darfst.

## Wann du sie einsetzt

- An Wendepunkten.
- In Phasen, in denen du das Gefühl hast, nur noch zu funktionieren, ohne zu wissen, wohin.
- Einmal im Jahr, idealerweise außerhalb des Alltags. Das reicht völlig.

Kein Werkzeug für den hektischen Dienstag. Es ist der Gegenpol zum Tagesgeschäft: der Moment, in dem du nicht das nächste Problem löst, sondern fragst, welches Leben du gerade baust.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wo steht die Person gerade beruflich und persönlich? Gibt es einen konkreten Anlass oder Wendepunkt? Wie viel Zeit hat sie für die Übung? Frag nichts, was sie schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten. Die drei Odyssey Plans nacheinander, nicht gleichzeitig.
- Die Pläne sind die Ideen der Person. Stelle Fragen, die sie konkreter machen, aber schlage keine eigenen Lebenswege vor.
- Challenge Antworten gegen »Worauf du achten musst«. Benenne direkt, wenn Plan 2 nur eine Variante von Plan 1 ist oder Plan 3 aus Vernunftgründen weggefiltert wird.
- Schließe mit den drei Plänen im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Dysfunktionale Überzeugungen reframen.** Viele Menschen stecken fest, weil sie unausgesprochenen Annahmen folgen, die Burnett und Evans dysfunktionale Überzeugungen nennen. Typische Beispiele: »Ich muss meine eine wahre Berufung finden.« »Es ist zu spät für einen Wechsel.« »Ich muss die beste Version meiner selbst werden.« Sie klingen plausibel, blockieren aber. Umdeutungen aus dem Buch: Aus »Ich muss meine Berufung finden« wird »Leidenschaft entsteht, indem ich etwas ausprobiere, darin besser werde und Gefallen daran finde.« Aus »Es ist zu spät« wird »Ich starte von dort, wo ich gerade bin.«
   Frage: *»Welcher Satz über deine Laufbahn hält dich gerade fest, und wie lautet er umgedeutet?«*

2. **Gravity Problems erkennen.** Umstände, an denen du nichts ändern kannst, so wenig wie an der Schwerkraft. Wer sein Leben lang klagt, dass eine bestimmte Rolle in seiner Branche schlecht bezahlt ist, kämpft gegen ein Naturgesetz. Die sinnvolle Antwort ist Akzeptanz. Erst dann kannst du aufhören, Energie hineinzustecken, und dich auf das konzentrieren, was gestaltbar ist.
   Frage: *»Wogegen kämpfst du, das sich nicht ändern lässt?«*

3. **Odyssey Plans entwerfen.** Drei verschiedene Pläne, jeweils für die nächsten fünf Jahre. Es geht nicht darum, den Rest des Lebens zu planen, sondern nur das, was als Nächstes kommt. Jeden Plan als grobe Zeitleiste über fünf Jahre skizzieren, bewusst auch mit Persönlichem und Nichtberuflichem.
   - **Plan 1: der aktuelle Weg, konsequent verlängert.** Was passiert, wenn du genau so weitermachst: dieselbe Richtung, der nächste logische Karriereschritt, die Idee, die du ohnehin im Kopf hast. Frage: *»Wie sehen deine nächsten fünf Jahre aus, wenn du so weitermachst wie bisher?«*
   - **Plan 2: wenn Plan 1 plötzlich wegfiele.** Deine Branche oder dein Funktionsbereich wäre über Nacht keine Option mehr. Frage: *»Was würdest du tun, wenn dein bisheriger Weg versperrt wäre?«* Oft liegt hier eine Richtung, die du längst spürst, aber nie zu Ende gedacht hast.
   - **Plan 3: wenn Geld und das Urteil anderer keine Rolle spielten.** Frage: *»Was würdest du tun, wenn du wüsstest, dass du davon leben könntest und niemand die Augenbrauen hebt?«* Du entwirfst diesen Plan nicht, um ihn umzusetzen, sondern um an Ideen heranzukommen, die du dir sonst nie erlauben würdest.

4. **Titel geben.** Jedem Plan einen kurzen Titel in wenigen Worten, der seinen Kern einfängt.

5. **Die vier Regler.** Für jeden Plan ein schneller Check. Das hält die Bewertung ehrlich und vergleichbar, statt dass ein Plan aus dem Bauchgefühl gewinnt.
   - **Ressourcen:** Hast du, was du brauchst: Zeit, Geld, Fähigkeiten, Kontakte? (wenig bis viel)
   - **Likability:** Wie fühlst du dich bei diesem Plan? (kalt bis heiß)
   - **Confidence:** Wie zuversichtlich bist du, dass du ihn umsetzen könntest? (unsicher bis sicher)
   - **Coherence:** Ergibt der Plan in sich Sinn und passt er zu dem, wer du bist, und zu deiner Sicht auf Arbeit und Leben? (gering bis hoch)

6. **Offene Fragen festhalten.** Für jeden Plan zwei bis drei offene Fragen, die nach dem Entwerfen auftauchen. Sie sind wertvoller als die Pläne selbst, weil sie zeigen, was du als Nächstes herausfinden musst.
   Frage: *»Was müsstest du wissen, um diesen Plan ernsthaft beurteilen zu können?«*

7. **Bias to Action: Prototypen.** Ein Plan auf dem Papier ist eine Hypothese. Burnett und Evans empfehlen, Richtungen mit kleinen Prototypen zu testen, statt sie endlos durchzudenken: ein Gespräch mit jemandem, der den Weg schon gegangen ist, ein kleines Projekt nebenbei, eine Hospitanz, ein Workshop, ein erster Schritt. Die Antworten liegen in der Welt, nicht in deinem Kopf.
   Frage: *»Mit welchem kleinen Prototyp beantwortest du die wichtigste offene Frage?«*

## Beispiel

Dominik Kenzler hatte schon im Designstudium zwei Dinge im Kopf: irgendwann eine eigene Firma gründen und Produkte entwickeln. Das blieb über Jahre sein Zielbild, mit Abbiegungen. Eine Zeit lang war er glücklich auf dem Design-Leadership-Pfad, erkannte dann aber, dass er für sein Zielbild die gesamte Produktverantwortung braucht, und bewegte sich wieder stärker in Richtung Product Leadership. Das ist Plan 1: kein starrer Weg, sondern einer, den er immer wieder anpasst. Mit dem Aufkommen von KI denkt er oft über Plan 2 nach: gemeinsam mit seinem Zwillingsbruder Patrick, Innovationsberater, der ursprünglich Architektur studiert hat, alte Häuser kaufen, renovieren, eine Marke und Website aufbauen und sie wieder verkaufen. Er wird diesen Plan vermutlich nie umsetzen. Ihn zu durchdenken gibt ihm trotzdem Ruhe, weil es zeigt, dass es mehr als einen Weg gibt.

## Worauf du achten musst

- **Den einen perfekten Plan suchen.** Es gibt mehrere gute Leben. Ziel ist nicht die Entscheidung für einen Plan.
- **Plan 2 als Variante von Plan 1.** Er soll eine ernsthafte zweite Möglichkeit sein, nicht die Verfeinerung der ersten.
- **Plan 3 wegfiltern, weil er unwahrscheinlich ist.** Genau darum geht es: Zugang zu allen Ideen, auch zu denen, die du sonst sofort verwirfst.
- **Nur Karriere planen.** Persönliches und Nichtberufliches gehören in die Zeitleiste.
- **Zu weit planen.** Fünf Jahre, nur das, was als Nächstes kommt, nicht der Rest des Lebens.
- **Nach Bauchgefühl bewerten.** Die vier Regler halten den Vergleich ehrlich.
- **Gegen Gravity Problems kämpfen.** Energie in Unveränderliches fehlt beim Gestaltbaren.
- **Nur grübeln.** Ohne Prototyp bleibt jeder Plan eine Hypothese.

## Ergebnis

Vorlage je Plan: `templates/odyssey-plan.md`.

```markdown
# Designing Your Life: [Name]
Stand: [Datum]

**Umgedeutete Überzeugung:** »…« wird zu »…«
**Gravity Problems, die ich akzeptiere:** …

| | Plan 1: [Titel] | Plan 2: [Titel] | Plan 3: [Titel] |
|---|---|---|---|
| Jahr 1 | | | |
| Jahr 2 | | | |
| Jahr 3 | | | |
| Jahr 4 | | | |
| Jahr 5 | | | |
| Ressourcen (wenig bis viel) | | | |
| Likability (kalt bis heiß) | | | |
| Confidence (unsicher bis sicher) | | | |
| Coherence (gering bis hoch) | | | |
| Offene Fragen | | | |

**Nächster Prototyp:** … · **Beantwortet die Frage:** … · **Bis:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Unterscheiden sich deine drei Pläne grundsätzlich, oder sind sie Varianten eines Wegs?
- Enthält jede Zeitleiste auch Persönliches und Nichtberufliches?
- Hast du jeden Plan entlang der vier Regler bewertet, nicht nur nach Gefühl?
- Hast du pro Plan zwei bis drei offene Fragen notiert?
- Welcher kleine Prototyp testet als Nächstes eine Richtung in der Realität?

## Im Flywheel

Modul YOURSELF, Teil 3 Dich weiterentwickeln und in Übergängen wachsen. Letzte Methode des Kapitels.

Verwandte Skills:
- `positive-future-fiction`: Die Gravity Problems verbinden sich laut Buch direkt mit dem stoischen Kern von PFF: Konzentriere dich auf das, was du verändern kannst. Abgrenzung: PFF malt ein positives Zukunftsbild, um Sorgen zu entkräften. Die Odyssey Plans öffnen mehrere parallele Zukünfte, um Optionen sichtbar zu machen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Methode Designing Your Life (Abb. 6.10). Originalquelle: Bill Burnett, Dave Evans: Designing Your Life.

Original: Bill Burnett, Dave Evans: Designing Your Life. How to Build a Well-Lived, Joyful Life, Knopf, 2016, https://designingyour.life
