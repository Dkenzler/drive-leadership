---
name: weekly-priorities
description: "Weekly Priorities aus dem Drive Leadership Playbook von Dominik Kenzler: das Bindeglied zwischen quartalsweisen OKRs und dem Alltag. Jede Person oder jedes Team legt montags drei bis fünf Prioritäten für die Woche fest und reflektiert am Ende der Woche. Nutze diesen Skill, wenn jemand die eigene Woche oder die des Teams planen, Quartalsziele in konkrete Wochenprioritäten übersetzen, ein kurzes Async-Update formulieren, Dringendes von Wichtigem trennen oder eine zu lange To-do-Liste auf das Wesentliche reduzieren will."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S1 Set Goals
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Weekly Priorities

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Weekly Priorities beantworten die Frage: Was ist diese Woche wirklich wichtig? Nicht, was ist dringend, sondern, was bewegt uns am meisten in Richtung unserer Ziele.

OKRs geben die Richtung für ein Quartal vor. Aber ein Quartal ist lang. Ohne wöchentliche Übersetzung koppelt sich die tägliche Arbeit leicht von den Quartalszielen ab, Dringendes verdrängt Wichtiges. Weekly Priorities zwingen zur Übersetzung: Was muss ich diese Woche konkret tun, um mein Objective voranzubringen?

Der zweite Wert ist Transparenz. Teilen Teams ihre Weekly Priorities, etwa in einem kurzen Async-Update, entsteht ein Bild, woran die Organisation gerade arbeitet. Das ermöglicht schnelle Korrekturen.

## Wann du sie einsetzt

- Am Anfang jeder Woche, typischerweise montags, für die kommenden fünf Tage.
- Am Ende der Woche zur kurzen Reflexion.
- Wenn die Alltagsarbeit sich von den Quartalszielen entfernt hat.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens zwei Fragen: Gilt die Planung für die Person selbst oder für ein Team? Welche OKRs oder Quartalsziele gelten gerade? Frag nichts, was die Person schon gesagt hat.
- Das Format ist bewusst einfach. Halte das Gespräch kurz, drei Fragen reichen.
- Challenge gegen »Worauf du achten musst«. Vor allem: Ist das eine Prioritätenliste oder eine To-do-Liste? Mehr als fünf Punkte kürzen lassen.
- Erfinde keine Aufgaben. Wenn die Person nur eine Aufgabenliste mitbringt, frag, welche drei davon das Objective am meisten bewegen.
- Soll das Ergebnis geteilt werden, formuliere es als kurzes Async-Update (Slack-Nachricht, geteiltes Dokument oder Stand-up). Das Tool ist nicht wichtig.
- Schließe mit den Weekly Priorities im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Wochenanfang, typischerweise montags: planen**

1. **Die wichtigsten Prioritäten.** Frage: *»Was sind deine drei wichtigsten Prioritäten diese Woche?«* Drei bis fünf, nicht mehr. Gut ist die Antwort, wenn jede Priorität etwas bewegt, nicht nur etwas abarbeitet.

2. **Einzahlung auf die OKRs.** Frage: *»Wie zahlen sie auf deine OKRs ein?«* Gut ist die Antwort, wenn jede Priorität einem Objective oder Key Result zugeordnet werden kann. Lässt sich eine nicht zuordnen, frag, ob sie wirklich Priorität ist oder nur dringend.

3. **Hindernisse der letzten Woche.** Frage: *»Was hat dich letzte Woche aufgehalten?«*

**Ende der Woche: reflektieren**

4. **Kurze Reflexion.** Was wurde erreicht? Was nicht? Warum?
   Frage: *»Welche Prioritäten hast du geschafft, welche nicht, und woran lag es?«*

## Worauf du achten musst

- **Weekly Priorities werden zur To-do-Liste.** Eine To-do-Liste enthält alles, was erledigt werden muss. Weekly Priorities enthalten das Wichtigste, was bewegt werden muss.
- **Mehr als fünf Punkte.** Dann ist es keine Prioritätenliste.
- **Dringendes statt Wichtiges.** Prioritäten, die nicht auf die Quartalsziele einzahlen, gehören hinterfragt.

## Ergebnis

```markdown
# Weekly Priorities: [Name / Team] · KW [Nummer]

| # | Priorität | Zahlt ein auf (Objective / Key Result) |
|---|---|---|
| 1 | … | … |
| 2 | … | … |
| 3 | … | … |

**Was mich letzte Woche aufgehalten hat:** …

## Reflexion (Ende der Woche)
- Erreicht: …
- Nicht erreicht: …
- Warum: …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Sind es höchstens fünf Punkte?
- Zahlt jede Priorität auf ein Objective oder Key Result ein?
- Steht auf der Liste das, was bewegt werden muss, oder alles, was erledigt werden muss?
- Hast du die Prioritäten geteilt und am Ende der Woche reflektiert?

## Im Flywheel

Modul SHIP, Bereich S1 Set Goals.

Verwandte Skills:
- `okrs`: Weekly Priorities übersetzen die quartalsweisen OKRs in die Woche.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S1 Set Goals, Abschnitt Weekly Priorities.
