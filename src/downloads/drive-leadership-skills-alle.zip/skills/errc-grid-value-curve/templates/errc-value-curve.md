# ERRC Grid & Value Curve

Nach Abb. 3.4 (ERRC Grid nach W. Chan Kim und Renée Mauborgne) und Abb. 3.5 (Strategy Canvas) im Drive Leadership Playbook.

Reihenfolge: 1. Wettbewerbsfaktoren, 2. Kurve der Branche, 3. ERRC Grid, 4. neue Value Curve.

**Angebot / Markt:**
**Stand:**
**Bezugslinie (Branche oder stärkste Wettbewerber):**

## 1. Wettbewerbsfaktoren (fünf bis zehn)

Leitfragen: Wofür zahlt die Kundschaft, und worüber wird verglichen? Wofür wirbt die Branche durchgängig? Welche Posten treiben die Kosten? Was erlebt die Kundschaft von der Auswahl über den Kauf bis zur Nutzung?

## 2. und 4. Value Curve

Angebotsniveau relativ zur Branche, von niedrig (1) bis hoch (5).

| Wettbewerbsfaktor | Branche / Wettbewerber | Neue Value Curve |
|---|---|---|
| | | |
| | | |
| | | |
| | | |
| | | |
| (neu geschaffen) | | |

## 3. ERRC Grid

| ELIMINATE | RAISE |
|---|---|
| Welche Faktoren, um die die Branche lange konkurriert hat, sollten abgeschafft werden? | Welche Faktoren sollten deutlich über den Branchenstandard gehoben werden? |
| | |
| **REDUCE** | **CREATE** |
| Welche Faktoren sollten deutlich unter den Branchenstandard gesenkt werden? | Welche Faktoren sollten geschaffen werden, die die Branche nie geboten hat? |
| | |

## Prüfung der neuen Kurve

- [ ] Klarer Fokus auf wenige Faktoren
- [ ] Weicht sichtbar von den anderen ab
- [ ] Lässt sich in einem einprägsamen Satz zusammenfassen:
