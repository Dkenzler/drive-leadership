---
name: errc-grid-value-curve
description: Sich vom Wettbewerb klar unterscheiden mit ERRC Grid und Value Curve (Strategy Canvas) aus dem Blue-Ocean-Ansatz von W. Chan Kim und Renée Mauborgne, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Differenzierungsstrategie entwickeln, das eigene Angebot mit Wettbewerbern vergleichen, den Verdrängungswettbewerb verlassen, Wettbewerbsfaktoren einer Branche bestimmen oder entscheiden will, was weggelassen, reduziert, verstärkt oder neu geschaffen wird. Führt von den Wettbewerbsfaktoren über die Branchenkurve und das ERRC Grid zur neuen Value Curve.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D2 Strategy
  origin: W. Chan Kim und Renée Mauborgne
  deep_dive: false
  version: "1.0"
---

# ERRC Grid & Value Curve

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach W. Chan Kim und Renée Mauborgne.

## Worum es geht

ERRC Grid und Value Curve stammen aus dem Blue-Ocean-Ansatz von W. Chan Kim und Renée Mauborgne. Beide verfolgen dasselbe Ziel: sich nicht im Verdrängungswettbewerb aufzureiben, sondern einen eigenen Raum zu schaffen, in dem du dich klar unterscheidest.

Das **ERRC Grid** stellt vier Fragen:

- **Eliminate:** Welche Faktoren, um die die Branche lange konkurriert hat, sollten abgeschafft werden?
- **Reduce:** Welche Faktoren sollten deutlich unter den Branchenstandard gesenkt werden?
- **Raise:** Welche Faktoren sollten deutlich über den Branchenstandard gehoben werden?
- **Create:** Welche Faktoren sollten geschaffen werden, die die Branche nie geboten hat?

Die **Value Curve** macht das Ergebnis sichtbar. Im Original ist sie die Linie auf dem Strategy Canvas, der Darstellung, die die Kurven mehrerer Anbieter nebeneinander zeigt. Auf der waagerechten Achse stehen die Wettbewerbsfaktoren, also die wenigen Dinge, in die eine Branche investiert und über die Kundschaft entscheidet. Auf der senkrechten Achse steht, wie stark ein Anbieter jeden Faktor bedient, von niedrig bis hoch. Verbindet man die Punkte, entsteht die Kurve.

Beide Tools zwingen dazu, nicht nur zu addieren, sondern auch bewusst zu subtrahieren.

## Wann du sie einsetzt

- Wenn du dich differenzieren willst.
- Um sichtbar zu machen, wo du dem Feld gleichst und wo du dich absetzt.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welches Angebot und welchen Markt geht es? Wer sind die stärksten Wettbewerber oder wie sieht der Branchenstandard aus? Arbeitet die Person allein oder mit einem Team? Frag nichts, was sie schon gesagt hat.
- Halte die Reihenfolge ein: erst Faktoren und Branchenkurve, dann ERRC, dann die neue Kurve. Wer mit dem ERRC Grid startet, hat keine Bezugslinie.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Steht in Eliminate und Reduce etwas, oder wird nur addiert?
- Erfinde keine Fakten über Markt, Kundschaft oder Wettbewerber. Bewertungen, die die Person nicht belegen kann, markierst du als Einschätzung.
- Arbeitet die Person mit einem Team, biete an, Ablauf und Moderationsfragen zu erstellen.
- Die Value Curve lässt sich als Tabelle abbilden. Möchte die Person die Kurve zeichnen, gib die Werte so aus, dass sie direkt in ein Liniendiagramm übertragen werden können.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Wettbewerbsfaktoren auflisten.** Die eigentliche Arbeit steckt in den Faktoren auf der waagerechten Achse. Sie sind nicht beliebig, sondern das, worauf der Wettbewerb im Markt hinausläuft. Leitfragen:
   - Wofür zahlt die Kundschaft, und worüber wird verglichen?
   - Wofür wirbt die Branche durchgängig?
   - Welche Posten treiben die Kosten?
   - Was erlebt die Kundschaft entlang ihres Weges, von der Auswahl über den Kauf bis zur Nutzung?

   Frage: *»Worüber vergleicht deine Kundschaft Anbieter in deinem Markt?«*
   Gut ist die Liste, wenn sie fünf bis zehn Faktoren umfasst und Naheliegendes mit Selbstverständlichem mischt, das sonst niemand hinterfragt.

2. **Die Kurve der Branche zeichnen.** Zuerst die Kurve der Branche oder der stärksten Wettbewerber. Das ist die Bezugslinie. Die Einordnung von niedrig bis hoch ist relativ, nicht absolut: wahrgenommene Stärke im Vergleich zur Branche, keine Messwerte.
   Frage: *»Wie stark bedient die Branche oder dein stärkster Wettbewerber jeden Faktor, von niedrig bis hoch?«*
   Gut ist die Antwort, wenn sie jeden Faktor relativ zur Branche einordnet.

3. **Das ERRC Grid füllen.** Für jeden Faktor entscheiden: weglassen, verringern, verstärken. Und neue Faktoren schaffen, die die Branche nie geboten hat.
   Frage pro Feld, etwa: *»Welcher Faktor, um den die Branche lange konkurriert, könnte ganz wegfallen?«*
   Gut ist die Antwort, wenn Eliminate und Reduce ebenso gefüllt sind wie Raise und Create.

4. **Die neue Value Curve eintragen.** Die Entscheidungen aus dem Grid in eine eigene Kurve übertragen, neben die Kurve der Branche.
   Frage: *»Wo liegt deine neue Kurve bei jedem Faktor, einschließlich der neu geschaffenen?«*
   Gut ist die Kurve, wenn sie eine eigene Form hat: an manchen Stellen bewusst tief, an anderen höher.

5. **Die Kurve prüfen.** Eine starke Kurve hat dreierlei: einen klaren Fokus auf wenige Faktoren, sie weicht sichtbar von den anderen ab, und sie lässt sich in einem einprägsamen Satz zusammenfassen.
   Frage: *»Wie lautet der eine Satz, der deine neue Kurve beschreibt?«*

## Beispiel

Cirque du Soleil im Vergleich zu klassischen Zirkussen wie Ringling Brothers (Abb. 3.5). Wettbewerbsfaktoren des klassischen Zirkus sind etwa Starartisten, Tiershows, Ticketpreis, mehrere Manegen, Verkauf in den Gängen, Nervenkitzel und Gefahr sowie der Veranstaltungsort.

- **Eliminate:** teure Artistennummern, Tiershows, mehrere Manegen, Verkauf in den Gängen.
- **Reduce:** Spaß und Humor, Nervenkitzel und Gefahr.
- **Raise:** einzigartiger Veranstaltungsort.
- **Create:** ein durchgehendes Thema, mehrere wechselnde Produktionen, eine veredelte Atmosphäre, künstlerische Musik und Tanz, nahe am Theater.

In der Kurve sieht man das sofort. Wo der klassische Zirkus hoch liegt, läuft Cirque tief, und wo der klassische Zirkus nichts bietet, läuft Cirque hoch. Diese gegenläufige Form ist der sichtbare Beweis einer eigenständigen Position, erreicht durch Subtraktion ebenso wie durch Addition.

## Worauf du achten musst

- **Nur addieren.** Ohne Eliminate und Reduce entsteht keine eigene Form, nur eine höhere Kurve.
- **Deckungsgleiche Kurven.** Liegt deine Kurve auf der der Branche, bietest du dasselbe wie alle.
- **Beliebige Faktoren.** Faktoren müssen das abbilden, worauf der Wettbewerb im Markt tatsächlich hinausläuft, einschließlich des Selbstverständlichen, das niemand hinterfragt.
- **Absolute statt relative Bewertung.** Es geht um wahrgenommene Stärke im Vergleich zur Branche, nicht um Messwerte.
- **Ohne Bezugslinie arbeiten.** Erst die Kurve der Branche, dann die eigene.
- **Den Vorsprung für dauerhaft halten.** Dominik Kenzler beobachtet, dass selbst ein Blue Ocean nach kürzester Zeit wieder zu Verdrängung und Wettbewerb führt. Beispiel aus dem Buch: Künstliche Intelligenz nach dem Durchbruch von ChatGPT im November 2022, wo innerhalb weniger Monate starke Wettbewerber auftraten.

## Ergebnis

Grid und Kurve auf einer Seite. Vorlage: `templates/errc-value-curve.md`.

```markdown
# ERRC Grid & Value Curve: [Angebot / Markt]
Stand: [Datum] · Bezugslinie: [Branche / Wettbewerber]

## Value Curve (niedrig 1 bis hoch 5, relativ zur Branche)
| Wettbewerbsfaktor | Branche / Wettbewerber | Neue Kurve | ERRC |
|---|---|---|---|
| … | | | Eliminate / Reduce / Raise / Create / unverändert |

## ERRC Grid
| Eliminate | Raise |
|---|---|
| … | … |
| **Reduce** | **Create** |
| … | … |

**Die neue Kurve in einem Satz:** …
**Offene Einschätzungen, die geprüft werden müssen:** …
```

## Mini-Check

Aus der Drive Checklist (Strategy):
- Beschreibt die Strategie, was euch unterscheidet, und nicht nur, was ihr besser machen wollt?

(abgeleitet aus den typischen Fehlern)
- Umfasst die Liste fünf bis zehn Faktoren, darunter auch Selbstverständliches?
- Habt ihr zuerst die Kurve der Branche gezeichnet?
- Stehen in Eliminate und Reduce echte Entscheidungen?
- Hat die neue Kurve einen klaren Fokus, weicht sichtbar ab und lässt sich in einem Satz sagen?

## Im Flywheel

Modul DRIVE, Bereich D2 Strategy.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D2 Strategy (Abb. 3.4 und 3.5), Operating System, Impact First. Originalquelle: W. Chan Kim, Renée Mauborgne: Blue Ocean Strategy. Abb. 3.5 nach Sage Growth Partners.
Original: W. Chan Kim, Renée Mauborgne: Blue Ocean Strategy. Harvard Business School Press, 2005. https://www.blueoceanstrategy.com/tools/errc-grid/
