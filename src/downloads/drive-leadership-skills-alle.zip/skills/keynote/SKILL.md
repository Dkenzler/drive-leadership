---
name: keynote
description: Eine Vision als Keynote oder Präsentation erzählen, nach dem Vorbild früher Start-up-Decks, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand ein Zukunftsbild für Unternehmen, Produkt oder Bereich vor Publikum vermitteln, eine Visions-Keynote oder einen Talk aufbauen, ein Vision Deck mit wenigen Seiten strukturieren oder eine überladene Präsentation auf eine klare Dramaturgie reduzieren will. Führt durch die Leitfragen Problem, Größe von Problem und Markt, Lösung und Potenzial und baut eine Seitenfolge mit einem Gedanken pro Seite.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D1 Target Picture
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Keynote

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Keynotes und TED Talks können ein perfektes Mittel sein, um ein Zukunftsbild zu vermitteln. Sie können auch sterbenslangweilig sein, wenn dem Publikum nach der zweiten Folie voller Tabellen und Kleingedrucktem der Kopf schwirrt. Eine gute Story, richtig erzählt und mit einer durchdachten Präsentation, kann inspirieren und Zukunftsbilder erzeugen.

Als Vorlage dienen frühe Start-up-Decks. Dort geht es genau darum, Investierende auf wenigen Seiten von einer Vision zu überzeugen. Wenige Fragen zwingen zur Klarheit:

- Welches Problem lösen wir?
- Wie groß sind Problem und Markt?
- Wie sieht die mögliche Lösung aus, und welches Potenzial steckt darin?

Was ein gutes Deck lehrreich macht, ist nicht der Inhalt, sondern Reihenfolge und Reduktion. Es erzählt eine Geschichte vom Problem über die Lösung bis zum Potenzial, und jede Seite bietet genau einen Gedanken.

## Wann du sie einsetzt

- Ein Zukunftsbild für Unternehmen, Produkt oder Bereich vor Publikum vermitteln.
- Eine Vision in einer Präsentation kommunizieren, etwa vor Team, Organisation oder Investierenden.
- Eine bestehende Präsentation prüfen, die zu voll, zu lang oder ohne Dramaturgie ist.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Vision soll vermittelt werden? Vor welchem Publikum und in welchem Format (Bühne, Meeting, Deck zum Lesen)? Gibt es schon Material? Frag nichts, was die Person schon gesagt hat.
- Das Buch beschreibt keine feste Schrittfolge, sondern die Leitfragen der Start-up-Decks und die Dramaturgie des Airbnb-Decks. Nutze beides als Gerüst für das Gespräch.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Hat die Person schon ein Deck, prüf es Seite für Seite gegen »Worauf du achten musst«.
- Challenge jede Antwort: Hat die Seite genau einen Gedanken? Braucht es diese Seite überhaupt? Benenne Schwächen direkt und kurz.
- Erfinde keine Zahlen zu Markt, Kundschaft oder Wettbewerb. Fehlt etwas, markiere es als offen.
- Schließe mit der Seitenfolge im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Der eine Satz.** Worum geht es, in einem kurzen Satz? Das Airbnb-Deck sagt es in sieben Worten.
   Frage: *»Wie lautet deine Vision in einem Satz, den jemand weitererzählen kann?«*
   Gut ist die Antwort, wenn sie kurz ist und ohne Erklärung verständlich.

2. **Das Problem.** Welches Problem lösen wir?
   Frage: *»Welches Problem löst ihr, und für wen?«*
   Gut ist die Antwort, wenn das Problem konkret ist und das Publikum es wiedererkennt.

3. **Größe von Problem und Markt.** Wie groß sind Problem und Markt?
   Frage: *»Wie groß ist das Problem, und wie viel davon könnt ihr realistisch erreichen?«*
   Gut ist die Antwort, wenn sie zwischen dem erreichbaren Markt und dem realistisch erreichbaren Anteil unterscheidet, so wie das Airbnb-Deck.

4. **Die Lösung.** Wie sieht die mögliche Lösung aus?
   Frage: *»Wie sieht die Lösung aus, in wenigen einfachen Schritten erklärt?«*
   Gut ist die Antwort, wenn sich die Lösung so schlicht erklären lässt wie »suchen, vergleichen, buchen«.

5. **Das Potenzial.** Welches Potenzial steckt darin?
   Frage: *»Was wird möglich, wenn das gelingt?«*

6. **Reihenfolge und Reduktion.** Die Inhalte in eine Seitenfolge bringen, vom Problem über die Lösung bis zum Potenzial. Pro Seite genau ein Gedanke. Für Visionen, die ein Geschäft beschreiben, dient die Dramaturgie des Airbnb-Decks als Orientierung (siehe »Beispiel«).
   Frage: *»Welcher eine Gedanke gehört auf diese Seite, und was fliegt raus?«*
   Gut ist das Ergebnis, wenn es mit wenigen Seiten auskommt und sich jede Seite in einem Satz zusammenfassen lässt.

## Beispiel

Das Series-A-Deck von Airbnb aus der Frühzeit kommt mit rund einem Dutzend Seiten aus und führt in klarer Dramaturgie durch das Geschäft:

1. Ein Satz in sieben Worten: »Book rooms with locals, rather than hotels.«
2. Problem: hohe Hotelpreise, Distanz zur Stadt, fehlende echte lokale Erlebnisse.
3. Lösung: eine Plattform, die Reisende und Gastgebende verbindet, günstiger und persönlicher als ein Hotel.
4. Marktgröße: erreichbarer Markt, unterschieden vom realistisch buchbaren Anteil.
5. Produkt in drei einfachen Schritten: suchen, vergleichen, buchen.
6. Geschäftsmodell: eine schlichte Gebühr pro Transaktion.
7. Gewinnung der ersten Nutzenden.
8. Abgrenzung vom Wettbewerb.
9. Eigene Vorteile: Vorsprung als Erster, vertrauenswürdiges, designgetriebenes Produkt, aktive Community.
10. Erst am Ende: Finanzen und Team.

## Worauf du achten musst

- **Folien voller Tabellen und Kleingedrucktem.** Das Publikum ist nach der zweiten Seite raus.
- **Mehrere Gedanken pro Seite.** Jede Seite bietet genau einen Gedanken.
- **Inhalt vor Dramaturgie.** Die Wirkung kommt aus Reihenfolge und Reduktion: vom Problem über die Lösung zum Potenzial.
- **Ohne Story.** Eine Präsentation ohne erzählte Geschichte erzeugt kein Zukunftsbild.

## Ergebnis

```markdown
# Keynote: [Titel der Vision]
Publikum: [wer] · Anlass: [wo, wann] · Dauer: [Minuten]

**Der eine Satz:** …

| # | Seite | Der eine Gedanke |
|---|---|---|
| 1 | Der eine Satz | … |
| 2 | Problem | … |
| 3 | Größe von Problem und Markt | … |
| 4 | Lösung | … |
| 5 | Potenzial | … |
| … | … | … |

**Offen (Zahlen, Belege, Bilder):** …
```

## Mini-Check

Aus der Drive Checklist (Target Picture):
- Hast du ein klares Zielbild für deinen Verantwortungsbereich?
- Kennt dein Team das Zielbild und kann es wiedergeben?

(abgeleitet aus den typischen Fehlern)
- Lässt sich die Vision in einem Satz sagen?
- Bietet jede Seite genau einen Gedanken?
- Führt die Reihenfolge vom Problem über die Lösung zum Potenzial?
- Gibt es Seiten mit Tabellen oder Kleingedrucktem, die du streichen kannst?

## Im Flywheel

Modul DRIVE, Bereich D1 Target Picture. Eines der Formate, mit denen eine Vision ein Bild bekommt, das andere sehen und teilen können.

Das Buch vertieft Präsentation und Kommunikation im Bereich D5 Communicate Direction. Verwandte Skills:
- `presentation-strategy-worksheet`
- `core-message-future-scenario`
- `star-moment`
- `minto-pyramid-principle`
- `50-25-25-rule`

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D1 Target Picture. Beispiel: Series-A-Deck von Airbnb.
