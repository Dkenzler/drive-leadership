# NFF gegen PFF

Nach Abb. 6.9 im Drive Leadership Playbook, nach Jonathan Abon. Zwei Spalten zum Sammeln, was schiefgehen oder gelingen könnte.

**Situation:**
**Datum:**

| NEGATIVE FUTURE FICTION | | POSITIVE FUTURE FICTION |
|---|---|---|
| **Was alles schiefgehen könnte?** | umkehren | **Was alles gelingen könnte?** |
| | | |
| | | |
| | | |
| | | |

Beide Zukünfte sind gleich unsicher. Du entscheidest, worauf du deinen Fokus richtest.

**Was passiert wirklich, falls das Schlimmste eintritt?**

**Mein nächster Schritt:**
