---
name: positive-future-fiction
description: Sorgen entkräften und den Fokus auf einen positiven Ausgang lenken mit Positive Future Fiction (PFF) nach Jonathan Abon, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand sich Sorgen macht, im Kopf negative Szenarien durchspielt (Negative Future Fiction), vor einem schwierigen Gespräch, einer Präsentation oder Verhandlung steht, eine große, langfristige oder riskante Initiative durchhalten muss oder zu Jahresbeginn, in einer neuen Rolle oder nach einem schwierigen Quartal ein positives Zukunftsbild schreiben will. Führt durch den Rückblick auf ein erfolgreiches Jahr in der Vergangenheitsform und die Gegenüberstellung von NFF und PFF.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 3 Dich weiterentwickeln und in Übergängen wachsen
  origin: Jonathan Abon
  deep_dive: false
  version: "1.0"
---

# Positive Future Fiction

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Jonathan Abon.

## Worum es geht

Positive Future Fiction, kurz PFF, ist eine Reflexionsmethode, die zwei Dinge verbindet: die bewusste Vorstellung eines positiven Zukunftsbildes und das Reframing negativer Gedankenmuster. Die Grundidee: Stell dir so konkret wie möglich vor, wie der Erfolg aussieht. Nicht als abstraktes Ziel, sondern als lebendiges Bild.

Sorge ist die Annahme eines negativen Ausgangs. Jonathan Abon nennt das Negative Future Fiction (NFF). Wir malen uns aus, was schiefgehen könnte, und erleben diesen Schmerz, bevor irgendetwas passiert ist. Das Gehirn tut das automatisch, besonders unter Stress, und erzeugt dadurch noch mehr Stress. PFF ist die bewusste Umkehrung. Das ist kein naives Schönreden, sondern eine Entscheidung, worauf du deine mentale Energie lenkst. Beide Zukünfte sind in diesem Moment gleich unsicher. Die eine lähmt, die andere befähigt.

PFF steht auf einem stoischen Fundament: Das meiste können wir nicht kontrollieren, wohl aber unsere Reaktion. Jonathans Prinzipien: Akzeptiere die Situation als das, was sie ist. Sei dir deiner Emotionen bewusst, aber bestrafe dich nicht für sie. Suche nach der Lektion. Konzentriere dich weniger auf das Ergebnis als auf den nächsten Schritt, auf den Effort. Einen Schritt nach dem anderen.

PFF wirkt auf zwei Ebenen. Erstens entlarvt sie negative Vorstellungen: Zu Ende gedacht, bricht selten etwas wirklich Schlimmes zusammen. Zweitens wirkt sie im laufenden Projekt als wiederkehrende Erinnerung, wofür du das tust. Daraus ziehst du Motivation, auch in zähen Phasen weiterzumachen.

## Wann du sie einsetzt

- Bei größeren, langfristigen oder risikoreichen Initiativen. Dort meldet sich der Kopf am lautesten mit negativen Szenarien, und dort brauchst du über längere Zeit einen Grund, dranzubleiben.
- In Übergangsphasen: am Anfang eines neuen Jahres, beim Start einer neuen Rolle, nach einem schwierigen Quartal, wenn das Umfeld unsicher ist.
- Im Kleinen: bevor du in eine schwierige Situation gehst, ein Gespräch, eine Präsentation, eine Verhandlung, und merkst, dass dein Kopf negative Szenarien malt.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Geht es um einen konkreten, bald anstehenden Moment oder um ein größeres Vorhaben oder Jahr? Was beschäftigt die Person gerade? Wie viel Zeit hat sie jetzt? Frag nichts, was sie schon gesagt hat.
- Wähle die passende Variante: die kurze Übung NFF gegen PFF für den Moment oder den ausführlichen Jahresrückblick (30 bis 40 Minuten).
- Eine Frage pro Schritt, dann auf die Antwort warten.
- Die Person schreibt ihr Zukunftsbild selbst. Du stellst Fragen, die es konkreter machen. Formuliere es nicht für sie aus und erfinde keine Erfolge.
- Challenge Antworten gegen »Worauf du achten musst«. Benenne direkt, wenn das Bild abstrakt bleibt oder in der Zukunftsform steht.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Variante A: Im Kleinen, vor einer schwierigen Situation (NFF gegen PFF, Abb. 6.9)**

1. **Negative Future Fiction sammeln.** Frage: *»Was alles könnte schiefgehen?«* Alles aufschreiben lassen.
2. **Zu Ende denken.** Frage: *»Was passiert wirklich, falls das eintritt?«* Oft zeigt sich, dass es gar nicht so dramatisch ist. Dahinter steckt häufig etwas wie die Angst, jemanden zu enttäuschen.
3. **Positive Future Fiction sammeln.** Frage: *»Was alles könnte gelingen?«* Beide Listen sind gleich spekulativ. Die negative Zukunft ist kein bisschen wahrscheinlicher, du hast sie nur automatisch zuerst gemalt.
4. **Umkehren.** Den positiven Ausgang bewusst vorstellen. Frage: *»Was ist dein nächster Schritt, den du kontrollieren kannst?«*

**Variante B: Das erfolgreiche Jahr (30 bis 40 Minuten, ruhige Umgebung)**

1. **Perspektive einnehmen.** Stell dir vor, du blickst in zwölf Monaten auf ein sehr erfolgreiches Jahr zurück.
2. **Aufschreiben, was passiert ist.** So konkret und detailliert wie möglich. Fragen, eine nach der anderen:
   - *»Welche Ziele hast du erreicht?«*
   - *»Was hat sich in deinem Team verändert?«*
   - *»Wie sprichst du mit anderen über deine Arbeit in diesem Jahr?«*
   - *»Wie fühlt es sich an?«*
3. **In der Vergangenheitsform schreiben.** Als wäre es bereits geschehen. Das aktiviert andere Denkmuster als Ziele in der Zukunftsform. »Ich habe X erreicht« ist wirkungsvoller als »Ich möchte X erreichen«. Gut ist ein Text, der ein Bild erzeugt, nicht eine Zielliste.
4. **Wiederkehrend nutzen.** Frage: *»Wann schaust du wieder auf dieses Bild, gerade in zähen Phasen?«* PFF ist keine einmalige Übung am Jahresanfang, sondern eine wiederkehrende Erinnerung.

## Beispiel

Jonathan Abon, Kollege von Dominik Kenzler und VP Product bei Utopia, hat PFF als Teil seines persönlichen Performance-Frameworks für sich entwickelt, als Sammlung dessen, was ihm hilft, in schwierigen Phasen klar und handlungsfähig zu bleiben. Er teilte es mit Dominik, als das Unternehmen in einer kritischen Lage war. Während um sie herum vieles unsicher wurde, blieb Jonathan ruhig und fokussiert. Dieser Teil seines Frameworks hat Dominiks eigenem Mindset geholfen.

## Worauf du achten musst

- **Schönreden statt Fokus lenken.** PFF ist kein Selbstbetrug. Beide Zukünfte sind gleich unsicher, du entscheidest nur, worauf du den Fokus richtest.
- **Abstrakt bleiben.** Nicht als abstraktes Ziel, sondern als lebendiges Bild, so konkret und detailliert wie möglich.
- **Zukunftsform verwenden.** »Ich möchte« statt »Ich habe« aktiviert nicht dieselben Denkmuster.
- **Negative Szenarien nicht zu Ende denken.** Zu Ende gedacht, bricht selten etwas wirklich Schlimmes zusammen. Allein das nimmt der Sorge viel von ihrer Kraft.
- **Am Ergebnis festhalten.** Du kontrollierst nicht das Ergebnis, sondern den nächsten Schritt.
- **Einmalig bleiben.** Die Wirkung im laufenden Projekt entsteht durch wiederholtes Erinnern.

## Ergebnis

Vorlage für die kurze Übung: `templates/nff-pff.md`.

```markdown
# Positive Future Fiction: [Name]
Datum: [Datum] · Blick zurück aus: [Datum in 12 Monaten]

## Rückblick auf ein sehr erfolgreiches Jahr (Vergangenheitsform)
**Diese Ziele habe ich erreicht:** …
**So hat sich mein Team verändert:** …
**So spreche ich mit anderen über meine Arbeit in diesem Jahr:** …
**So fühlt es sich an:** …

## Mein nächster Schritt
…

**Wiedervorlage:** [wann ich wieder auf dieses Bild schaue]
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Ist dein Zukunftsbild konkret genug, dass jemand anderes es sich vorstellen kann?
- Steht es in der Vergangenheitsform?
- Hast du die negativen Szenarien zu Ende gedacht, statt sie nur zu verdrängen?
- Kennst du deinen nächsten Schritt, den du selbst kontrollierst?
- Weißt du, wann du wieder auf dieses Bild schaust?

## Im Flywheel

Modul YOURSELF, Teil 3 Dich weiterentwickeln und in Übergängen wachsen.

Verwandte Skills:
- `designing-your-life`: Das Buch grenzt ab. PFF malt ein positives Zukunftsbild, um Sorgen zu entkräften und Motivation zu schaffen. Die Odyssey Plans öffnen bewusst mehrere parallele Zukünfte, um Optionen sichtbar zu machen. Die Gravity Problems dort knüpfen an den stoischen Kern von PFF an.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Methode Positive Future Fiction (Abb. 6.9). Originalquelle: persönliches Performance-Framework von Jonathan Abon.
