# Extreme Clarity im Meeting

Nach Abb. 5.19 im Drive Leadership Playbook: Der Ablauf von der Vorbereitung bis zur Zusammenfassung, nach Naomi Gleit.

**Meeting:**
**Datum:**
**Teilnehmende:**
**Mitschrift (sichtbar für alle):**

## Vorher

### 1. Agenda + Pre-read
Rund einen Tag vorher verschicken.

- [ ] Agenda verschickt am:
- [ ] Pre-read verschickt am:

Was entschieden werden muss:

## Während

### 2. Sichtbares Element
Ein Artefakt, an dem sich alle orientieren.

Agenda / Entscheidungsübersicht / Skizze der nächsten Schritte:

### 3. Drei Optionen
Optionen mit klarer Empfehlung.

1. Option A:
2. Option B:
3. Option C:

Empfehlung und Begründung:

### 4. Entscheidungen
Nächste Schritte in Echtzeit festhalten.

- Entscheidung:
- Nächster Schritt (wer, was, bis wann):
- Nächster Schritt (wer, was, bis wann):
- Wer muss es wissen:

## Danach

### 5. Zusammenfassung
Innerhalb eines Tages nachschicken.

- [ ] Verschickt am:
- Empfänger:innen (auch nicht Anwesende):
