---
name: extreme-clarity
description: Extreme Clarity nach Naomi Gleit (Meta), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn nach Meetings jede Person etwas anderes verstanden hat, Entscheidungen immer wieder aufgemacht werden, dieselben Fragen ständig neu auftauchen oder Teams in die falsche Richtung laufen. Hilft, ein Meeting klar vorzubereiten, zu führen und abzuschließen (Agenda und Pre-read, sichtbares Element, drei Optionen mit Empfehlung, Entscheidungen in Echtzeit festhalten, Zusammenfassung), Dokumente referenzierbar zu machen und eine Canonical Nomenclature festzulegen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S3 Create Execution Clarity
  origin: Naomi Gleit
  deep_dive: true
  version: "1.0"
---

# Extreme Clarity

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Naomi Gleit.

## Worum es geht

Extreme Clarity ist ein Prinzip von Naomi Gleit, Head of Product bei Meta. Die Kernaussage: Klarheit ist der Kern operationaler Exzellenz in einer Organisation. Klarheit bedeutet nicht, dass alle einer Meinung sind. Sie bedeutet, dass alle dasselbe Verständnis und denselben Wissensstand haben: Alle kennen das Ziel, die möglichen Optionen und die nächsten Schritte.

»Extreme Clarity is when everyone is on the same page. It does not mean that everyone agrees about what to do, it means that everyone shares the same understanding of the facts.« (Naomi Gleit)

Extreme Clarity eliminiert das unvermeidliche »Ich dachte, du meintest …«. Jedes Meeting, jede Präsentation und jedes Dokument soll dieselbe geteilte Basis schaffen. Das Prinzip bleibt nicht abstrakt, sondern besteht aus einer Handvoll konkreter Gewohnheiten, die jede und jeder übernehmen kann. Klarheit entsteht an zwei Orten täglich neu oder geht dort verloren: in Meetings und in Dokumenten.

Je größer die Organisation, desto wichtiger wird Extreme Clarity und desto schwieriger ist sie herzustellen. Was in einem Team von fünf Personen über Zuruf funktioniert, braucht in einer wachsenden Organisation bewusste Struktur. Klarheit ist deshalb eine Führungsdisziplin und nicht abhängig vom Kommunikationstalent.

## Wann du sie einsetzt

- Du bereitest ein Meeting vor, in dem etwas entschieden werden soll.
- Die Organisation wächst schnell, Teams wissen nicht mehr, was die anderen tun, und es entstehen ständig Reibungsverluste.
- Du erkennst Symptome schwacher operativer Kommunikation:
  - Mitarbeitende stellen Fragen, die bereits beantwortet wurden.
  - Teams arbeiten in die falsche Richtung, fertige Arbeit muss korrigiert oder neu priorisiert werden.
  - Gerüchte entstehen, weil offizielle Information fehlt.
  - Getroffene Entscheidungen werden wieder aufgemacht.
  - Das Team wirkt unsicher oder abwartend und wartet auf deine Freigabe.
- Dieselbe Frage wird je nach Gesprächspartner anders beantwortet. Das ist laut Buch der Test: Dann fehlt Klarheit.
- In einer Runde gibt es ein unbequemes Thema, um das alle herumschleichen. Im Geiste von Extreme Clarity benennst du den Elefanten im Raum, sachlich und respektvoll, nie persönlich.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welches Meeting, Projekt oder Dokument geht es? Was soll am Ende entschieden oder klar sein? Wer ist beteiligt? Frag nichts, was die Person schon gesagt hat.
- Arbeite mit dem Ablauf vorher, während, danach (siehe `templates/meeting-ablauf.md`). Hat die Person ein konkretes Meeting, bereite es mit ihr vor. Geht es um ein wiederkehrendes Problem, prüfe mit ihr, an welcher Stelle des Ablaufs Klarheit verloren geht.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen, wenn sie schon Material hat.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Enthält ein Entwurf alles statt nur das Nötige? Endet das Meeting ohne festgehaltene Entscheidung? Benenne Schwächen direkt und kurz.
- Legt die Person ein Dokument vor, prüfe es gegen die Formatregeln aus Schritt 6 und schlag konkrete Änderungen vor.
- Erfinde keine Fakten über Organisation, Projekt oder Beteiligte. Fehlt etwas, markiere es als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Leitfrage für alles: *»Wenn jemand nach diesem Meeting gefragt wird, was entschieden wurde, was würde er oder sie sagen?«* Gehen die Antworten auseinander, war das Meeting nicht klar genug.

**Vorher**

1. **Agenda und Pre-read verschicken.** Agenda und Vorbereitungsmaterial gehen deutlich vor dem Meeting raus, als Faustregel rund einen Tag vorher. Wer den Raum betritt, weiß, worum es geht und worüber entschieden werden muss. Das verschiebt die Denkarbeit nach vorne und macht das Meeting kürzer und schärfer.
   Frage: *»Was muss in diesem Meeting entschieden werden, und was müssen die Teilnehmenden vorher gelesen haben?«* Gut ist die Antwort, wenn die Entscheidung konkret benannt ist und das Pre-read nur das enthält, was für diese Entscheidung nötig ist.

**Während**

2. **Mit einem sichtbaren Element arbeiten.** Ein Artefakt, an dem sich alle orientieren: Agenda, Entscheidungsübersicht oder Skizze der nächsten Schritte. Wer zu spät kommt, versteht auf einen Blick, wo die Runde steht und was bereits besprochen wurde. Gleit arbeitet stark visuell, weil reines Zuhören zu leicht auseinanderdriftet.
   Frage: *»Was sehen alle während des Meetings, und woran erkennt jemand, der zu spät kommt, wo ihr gerade steht?«*

3. **Entscheidungen als drei Optionen mit Empfehlung präsentieren.** Statt eine fertige Lösung zu verteidigen oder eine offene Frage in den Raum zu werfen, legst du drei Optionen vor und sprichst eine begründete Empfehlung aus. Das gibt der Runde etwas Konkretes zum Entscheiden und macht die Abwägung transparent.
   Frage: *»Welche drei Optionen gibt es, und welche empfiehlst du mit welcher Begründung?«* Gut ist die Antwort, wenn die Optionen echte Alternativen sind und die Empfehlung begründet ist.

4. **Entscheidungen und nächste Schritte in Echtzeit festhalten.** Das stärkste Element. Bevor das Meeting endet, werden Entscheidungen und nächste Schritte schriftlich festgehalten, sichtbar für alle, solange die Runde noch zusammen ist. Widerspricht jemand dem Aufgeschriebenen, ist das kein Störfall, sondern ein gutes Signal: Die Klärung passiert jetzt, nicht später in Einzelgesprächen.
   Frage: *»Wer schreibt im Meeting sichtbar mit, und wann in der Agenda ist Zeit dafür reserviert?«* Gut ist die Antwort, wenn eine Person benannt ist und die letzten Minuten dafür eingeplant sind.

**Danach**

5. **Zusammenfassung nachschicken.** Innerhalb eines Tages folgen kurze Notizen mit den Entscheidungen und den nächsten Schritten. Das schließt die Schleife und gibt allen, auch den nicht Anwesenden, denselben Stand.
   Frage: *»Wer muss die Zusammenfassung bekommen, auch wer nicht dabei war?«*

**Dokumente und Sprache**

6. **Dokumente sauber und referenzierbar halten.** Gleit legt Wert auf wenige, aufgeräumte Formate:
   - ein einheitliches Format für alle Dokumente und Präsentationen, minimale, aufgeräumte Templates,
   - Listen nummerieren statt bulletten, damit man auf einen Punkt verweisen kann (»Ich widerspreche Punkt 3.«),
   - Links hinter einem Wort wie »hier« verstecken, keine rohen URLs,
   - fett nur für Überschriften und Satzanfänge, nicht wahllos mitten im Text.

   Frage: *»Zeig mir das Dokument oder die Agenda. Kann jemand auf einen einzelnen Punkt verweisen?«*

7. **Canonical Nomenclature etablieren.** Benutzen verschiedene Personen dieselben Wörter und meinen Unterschiedliches, fehlt ein gemeinsames Vokabular. Definiere die zentralen Begriffe eines Projekts einmal verbindlich, damit »fertig«, »Launch« oder »Erfolg« für alle dasselbe heißen.
   Frage: *»Welche zwei oder drei Begriffe werden in diesem Projekt unterschiedlich verstanden?«*

## Beispiel

Ein im Meeting festgehaltenes Ergebnis kann laut Buch schlicht so aussehen: Entscheidung: Wir gehen mit Option B, dem schlankeren Onboarding. Nächster Schritt: Lena baut den Prototyp bis Freitag. Nächster Schritt: Tarek prüft die Tracking-Anforderungen bis Mittwoch. Wer muss es wissen: Support und Marketing. Vier Zeilen, und niemand verlässt den Raum mit einer anderen Vorstellung als der Rest.

Dominik Kenzler hat bei CLARK und Utopia Music erlebt, wie sich die Mitarbeitendenzahl in weniger als zwölf Monaten verdreifachte. Teams wussten teilweise nicht, was die anderen taten, es entstanden ständig Reibungsverluste. Nur mit Disziplin, Einfachheit und einem Dokument, auf das alle zugreifen, ließ sich das ändern.

## Worauf du achten musst

- **Klarheit mit Vollständigkeit verwechseln.** Ein klares Dokument enthält nicht alles, sondern genau das, was die Lesenden brauchen, um zu verstehen, was entschieden wurde und was als Nächstes passiert. Wer Vollständigkeit anstrebt, produziert Dokumente, die niemand liest.
- **Meetings ohne klares Ende verlassen.** Der häufigste Bruch passiert in den letzten fünf Minuten. Endet das Meeting ohne festgehaltene Entscheidung und nächste Schritte, ist alles davor verschenkt. Das Echtzeit-Festhalten ist nicht optional.
- **Auf Gewohnheit statt auf System vertrauen.** Extreme Clarity scheitert selten am Willen, aber fast immer an alten Gewohnheiten: Entscheidungen werden mündlich getroffen und unterschiedlich erinnert, Präsentationen sind voll, aber ohne Botschaft. Nur bewusste, wiederholte Anwendung macht die Praktiken zur neuen Gewohnheit.
- **Nomenklatur unausgesprochen lassen.** Viele Konflikte sind in Wahrheit Begriffskonflikte. Solange niemand die zentralen Wörter definiert, redet die Runde aneinander vorbei.
- **Frameworks als Bürokratie missverstehen.** Gleit glaubt an Frameworks für die Dinge, die Extreme Clarity erzeugen sollen. Es geht dabei um Tempo: Klare Formate und wiederkehrende Strukturen reduzieren Reibung und machen die Organisation schneller, nicht langsamer.

## Ergebnis

Ein vorbereitetes Meeting nach dem Ablauf vorher, während, danach. Vorlage: `templates/meeting-ablauf.md`.

```markdown
# Extreme Clarity: [Meeting / Projekt]
Datum: [Datum] · Teilnehmende: [Namen oder Rollen] · Mitschrift: [Name]

**Was entschieden werden muss:** …

## Vorher (rund einen Tag vorher verschicken)
**Agenda:**
1. …
2. …
**Pre-read:** [Link hier]

## Während
**Sichtbares Element:** Agenda / Entscheidungsübersicht / Skizze der nächsten Schritte
**Optionen:**
1. Option A: …
2. Option B: …
3. Option C: …
**Empfehlung:** Option …, weil …

**In Echtzeit festgehalten:**
- Entscheidung: …
- Nächster Schritt: [Name], [was], bis [Datum]
- Nächster Schritt: [Name], [was], bis [Datum]
- Wer muss es wissen: …

## Danach (innerhalb eines Tages)
**Zusammenfassung an:** [auch nicht Anwesende]

## Canonical Nomenclature
1. [Begriff]: [verbindliche Definition]
```

## Mini-Check

- Bekommt jede Runde vorab eine Agenda und ein Pre-read, sodass die Denkarbeit vor dem Meeting beginnen kann?
- Werden Entscheidungen und nächste Schritte im Meeting sichtbar für alle festgehalten?
- Präsentierst du Entscheidungen als Optionen mit Empfehlung, statt eine Lösung zu verteidigen oder eine offene Frage zu stellen?
- Sind eure Dokumente referenzierbar, also nummerierte Listen, saubere Links, sparsames Fett?
- Gibt es für die zentralen Begriffe eines Projekts eine verbindliche, geteilte Definition?

## Im Flywheel

Modul SHIP, Bereich S3 Create Execution Clarity. Im Operating System des Buchs taucht Extreme Clarity außerdem unter Poking Holes auf: unbequeme Fragen stellen und den Elefanten im Raum benennen.

Verwandte Skills:
- `canonical-document`: Der Ort, an dem die Klarheit dauerhaft wohnt. Extreme Clarity beschreibt die Praxis im Moment, in Meetings und einzelnen Dokumenten. Das Echtzeit-Festhalten fließt ins Canonical Document, die Canonical Nomenclature gilt für beide.
- `decision-log`: Am Ende wichtiger Meetings werden die Entscheidungen in Echtzeit ins Log übertragen. Das passt direkt zum Real-time Editing aus Extreme Clarity.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Operating System, Poking Holes, Kapitel SHIP, S3 Create Execution Clarity und Deep Dive Extreme Clarity. Originalquelle: Naomi Gleit, Head of Product bei Meta.

Original: Naomi Gleit: Extreme Clarity, 2022, https://naomi.com/extreme-clarity-c977d38f56dc. Die Meeting-Praktiken (Pre-read, Visual, drei Optionen mit Empfehlung, Real-time Editing, Notizen danach) zusätzlich in: Lenny's Podcast mit Naomi Gleit, 2024, https://www.lennysnewsletter.com/p/metas-head-of-product-naomi-gleit
