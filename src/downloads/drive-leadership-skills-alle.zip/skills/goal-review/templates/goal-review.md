# Goal Review

Nach Abb. 5.2 im Drive Leadership Playbook. Führe den Review am Ende jedes Planungszeitraums durch. Dauer: 60 Minuten.

**Team:**
**Planungszeitraum:**
**Datum:**

## Vorbereitung (vorab mit dem Team teilen)

| Key Result / Zielvorgabe | erreicht / teilweise erreicht / nicht erreicht | Warum |
|---|---|---|
| | | |

## 1. Was haben wir erreicht?
- Welche Ziele wurden vollständig geliefert?
- Welche Key Results wurden erreicht?
- Was hat besonders gut funktioniert?

## 2. Was nicht und warum?
- Welche Ziele wurden nicht erreicht?
- Lag der Fehler in der Planung oder in der Discovery?
- War es ungeplante Arbeit?
- War das Ziel falsch kalibriert?

## 3. Learnings (optional)
- Was nehmen wir mit in den nächsten Zyklus?
- Was ändern wir an der Planung?
- Was ändern wir am Zielprozess?
