---
name: goal-review
description: "Goal Review aus dem Drive Leadership Playbook von Dominik Kenzler: der Abschluss eines Planungszyklus als Accountability-Session. Commitments werden bewertet, Abweichungen erklärt und Konsequenzen für die nächste Planung gezogen. Nutze diesen Skill, wenn jemand das Ende eines Quartals oder Zyklus auswerten, OKRs oder Key Results rückblickend bewerten, einen Quartalsrückblick vorbereiten oder moderieren, Ursachen für verfehlte Ziele finden oder aus einer Rechtfertigungsrunde eine Analyserunde machen will. Liefert Vorbereitung, 60-Minuten-Ablauf und Review-Dokument."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S1 Set Goals
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Goal Review

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Der Goal Review ist der Abschluss eines Planungszyklus. Er beantwortet vier Fragen: Was haben wir erreicht? Was nicht? Warum nicht? Und lag der Fehler in der Planung, in ungeplanter Arbeit, in der Discovery oder woanders?

Ein Goal Review ist kein Retro, auch wenn er Elemente davon enthalten kann. Er ist primär eine Accountability-Session: Commitments werden bewertet, Abweichungen erklärt und Konsequenzen für die nächste Planung gezogen. Der Ausgangspunkt ist immer die Frage: Haben wir geliefert, was wir committet haben?

Ein schlechter Goal Review ist eine Rechtfertigungsrunde, in der Teams externe Gründe suchen. Ein guter ist eine Analyserunde. Nicht erreichte Ziele brauchen eine klare Erklärung, nicht als Bestrafung, sondern weil Commitments nur Gewicht haben, wenn sie eingefordert werden. Das ist der Unterschied zwischen einer Planungs- und einer Absichtskultur.

## Wann du sie einsetzt

- Am Ende jedes Planungszeitraums. Ob sechs Wochen, acht Wochen oder ein Quartal, hängt vom Operating Rhythm des Unternehmens ab.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welcher Zeitraum wird reviewt? Welche Ziele oder Key Results waren committet? Wer nimmt teil? Frag nichts, was die Person schon gesagt hat.
- Der Review findet im Team statt. Hilf zuerst bei der schriftlichen Vorbereitung, dann biete Agenda und Moderationsfragen für das Meeting an (siehe `templates/goal-review.md`).
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge gegen »Worauf du achten musst«. Vor allem: Werden externe Gründe gesucht, oder wird analysiert? Wird Fortschritt als Erfolg verkauft?
- Erfinde keine Ergebnisse oder Ursachen. Wo die Person den Grund nicht kennt, markiere ihn als offen für das Meeting.
- Schließe mit dem Review-Dokument im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Vorbereitung**

1. **Einschätzung je Ziel schreiben.** Geh die Ziele des Planungszeitraums durch und schreib für jedes Key Result oder jede Zielvorgabe eine kurze Einschätzung: erreicht, teilweise erreicht, nicht erreicht, und warum. Teile das vor dem Meeting mit dem Team.
   Frage: *»Wie steht jedes committete Ziel: erreicht, teilweise erreicht oder nicht erreicht?«* Gut ist die Antwort, wenn sie am vorab definierten Zielwert gemessen ist, nicht am Fortschritt.

**Meeting (60 Minuten reichen)**

2. **Was haben wir erreicht?** Mit den Commitments starten: Welche Ziele wurden vollständig geliefert? Welche Key Results wurden erreicht? Was hat besonders gut funktioniert?

3. **Was nicht, und warum?** Welche Ziele wurden nicht erreicht? Lag der Fehler in der Planung oder in der Discovery? War es ungeplante Arbeit? War das Ziel falsch kalibriert? Die Analysefragen laut Buch: Waren unsere Ziele richtig kalibriert? Haben wir die richtigen Key Results gewählt? Hat ungeplante Arbeit unsere Kapazität gefressen? Was würden wir beim nächsten Mal anders formulieren oder priorisieren?
   Frage: *»Wo lag die Ursache: Planung, Discovery, ungeplante Arbeit oder Kalibrierung?«* Gut ist die Antwort, wenn sie eine Ursache im eigenen Einflussbereich benennt, nicht nur äußere Umstände.

4. **Learnings (optional).** Ähnlich einer Retro: Was nehmen wir mit in den nächsten Zyklus? Was ändern wir an der Planung? Was ändern wir am Zielprozess?

## Worauf du achten musst

- **Rechtfertigungsrunde.** Teams erklären, warum Ziele nicht erreicht wurden, und suchen externe Gründe. Umlenken auf Analyse.
- **Retro statt Accountability.** Learnings sind optional. Der Ausgangspunkt bleibt: Haben wir geliefert, was wir committet haben?
- **Fortschritt als Erfolg werten.** Bewertet wird gegen das vorab definierte Ziel, nicht gegen den Stand zu Beginn.
- **Verfehlte Ziele ohne Erklärung stehen lassen.** Dann verlieren Commitments ihr Gewicht.
- **Zu lang.** Was länger als 60 Minuten dauert, verliert sich in Details.
- **Ohne Vorbereitung ins Meeting.** Die Einschätzungen gehören vorab geteilt.

## Ergebnis

Vorlage für Vorbereitung und Meeting: `templates/goal-review.md`.

```markdown
# Goal Review: [Team] · [Zeitraum]
Datum: [Datum] · Teilnehmende: …

| Ziel / Key Result | Zielwert | Ist | Status | Warum |
|---|---|---|---|---|
| … | … | … | erreicht / teilweise / nicht erreicht | … |

## Was haben wir erreicht?
- Vollständig geliefert: …
- Erreichte Key Results: …
- Besonders gut funktioniert: …

## Was nicht und warum?
- Nicht erreicht: …
- Ursache (Planung / Discovery / ungeplante Arbeit / Kalibrierung / anderes): …

## Konsequenzen für die nächste Planung
- …

## Learnings (optional)
- Mitnehmen in den nächsten Zyklus: …
- Änderung an der Planung: …
- Änderung am Zielprozess: …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hast du vor dem Meeting für jedes Key Result eine Einschätzung mit Begründung geteilt?
- Hat jedes nicht erreichte Ziel eine klare Erklärung mit Ursache?
- War es eine Analyse- und keine Rechtfertigungsrunde?
- Habt ihr Konsequenzen für die nächste Planung festgehalten?
- Blieb der Review bei etwa 60 Minuten?

## Im Flywheel

Modul SHIP, Bereich S1 Set Goals.

Verwandte Skills:
- `okrs`: Der Goal Review bewertet die Key Results des Zyklus.
- `commitment-ceremony`: Was dort committet wurde, wird im Goal Review eingefordert.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S1 Set Goals, Abschnitt Goal Review (Abb. 5.2), dazu »Erfolg wird vorab definiert, nicht auf dem Weg«.
