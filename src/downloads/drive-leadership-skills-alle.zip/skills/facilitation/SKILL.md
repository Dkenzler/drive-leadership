---
name: facilitation
description: Facilitation nach Alex Pukinskis (»Remotely Productive«), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand ein Meeting, eine Entscheidungsrunde oder einen Workshop vorbereiten oder besser führen will, wenn Meetings ohne Ergebnis enden, die Lautesten dominieren oder alle gleichzeitig analysieren, brainstormen und entscheiden. Auch, wenn du in einem schlecht laufenden Meeting sitzt, das du nicht leitest. Führt durch Rahmen und Pre-read, sichtbares Mitschreiben, getrennte Phasen, Raum für Stille, Fragetechnik und Entscheidungen in Echtzeit.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S3 Create Execution Clarity
  origin: Alex Pukinskis
  deep_dive: false
  version: "1.0"
---

# Facilitation

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Alex Pukinskis.

## Worum es geht

Facilitation ist keine Moderationsfähigkeit, sondern eine Führungsfähigkeit. Wer Meetings gut führt, schafft Klarheit, baut Vertrauen auf und bringt Teams schneller zu guten Entscheidungen. Wer es schlecht macht, vergeudet die teuerste Ressource einer Organisation: die gemeinsame Zeit.

Alex Pukinskis beschreibt Facilitation als einen Tanz zwischen Vulnerabilität und Kontrolle. Echte Zusammenarbeit gelingt nur, wenn wir anderen etwas Kontrolle abgeben, um zu sehen, was passiert, und offen für neue Informationen sind. Ohne Vertrauen und Offenheit halten Menschen ihre Meinungen, ihr Wissen und ihre Ideen zurück.

Viele denken bei Facilitation an Workshops. Der größte Hebel liegt aber darin, alle Meetings genauso ernst zu nehmen, weil sie viel mehr Zeit im Arbeitsalltag einnehmen, als man glaubt. Nur ein Meeting mit klarem Outcome hat einen Wert. Alles andere ist teure Beschäftigung.

## Wann du sie einsetzt

- Vor jedem Meeting, das zu einem Ergebnis kommen soll, nicht nur vor Workshops.
- Wenn Meetings ohne Agenda, ohne klares Ziel und ohne dokumentierte Entscheidungen laufen.
- Wenn die lauteste Meinung gewinnt statt der besten.
- Wenn du als teilnehmende Person merkst, dass ein Meeting schlecht läuft.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welches Meeting (Anlass, Dauer, remote oder vor Ort)? Welches Ergebnis soll am Ende stehen? Wer nimmt teil, und leitet die Person das Meeting selbst? Frag nichts, was die Person schon gesagt hat.
- Leitet die Person das Meeting, geh die Prinzipien 1 bis 6 als Vorbereitung durch und erstelle am Ende einen Facilitation-Plan. Leitet sie es nicht, spring zu Prinzip 7.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist das Outcome des Meetings klar, oder wird nur moderiert, damit alle zu Wort kommen? Benenne Schwächen direkt und kurz.
- Erfinde keine Teilnehmenden, Positionen oder Inhalte. Was fehlt, markierst du als offen.
- Biete an, konkrete Moderationsfragen und Formulierungen für die einzelnen Phasen vorzubereiten.
- Schließe mit dem Plan im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Die Prinzipien aus »Remotely Productive«, in der Reihenfolge, in der sie im Meeting greifen.

1. **Einen Rahmen anbieten.** Bevor das Meeting beginnt, wissen alle, wie es ablaufen wird. Im besten Fall gibt es ein Pre-read, das alle gelesen haben. Dann startest du nicht mit einer Erklärung, sondern mit Fragen: »Welche Fragen habt ihr zu diesem Ansatz?« So kommen Bedenken früh auf den Tisch, und das Meeting beginnt mit einem gemeinsamen Verständnis der Ausgangslage.
   Frage: *»Was ist das Outcome des Meetings, und was sollen alle vorher gelesen haben?«* Gut ist die Antwort, wenn das Outcome ein Ergebnis ist (eine Entscheidung, ein Plan), kein Thema.

2. **Menschen durch Mitschreiben sichtbar machen.** Menschen müssen sich gesehen, gehört und wertgeschätzt fühlen. Wer ihre Worte sichtbar aufschreibt, hilft dabei. Wer sich gehört fühlt, ist offener für andere Perspektiven und weniger defensiv gegenüber Kritik. Teile ein Dokument, das alle sehen, und schreib während des Meetings mit. Das ist kein Protokoll für später, sondern ein Werkzeug für jetzt.
   Frage: *»Wo schreibst du sichtbar mit, und wer macht das, wenn du selbst sprichst?«*

3. **Analysen, Ideen, Entscheidungen und nächste Schritte trennen.** Wenn alle gleichzeitig analysieren, brainstormen und entscheiden, entsteht Chaos, und die lauteste Meinung gewinnt. Gib jeder Phase ihren eigenen Raum: Erst: Was wissen wir? Dann: Was bedeutet das? Was sind mögliche Lösungen? Erst am Ende: Was entscheiden wir? Die Trennung klingt formal, fühlt sich im Meeting aber natürlich an.
   Frage: *»Wie viel Zeit bekommt jede Phase, und an welcher Stelle wird entschieden?«* Gut ist die Antwort, wenn die Entscheidung erst nach Analyse und Lösungssuche kommt.

4. **Platz für die Stillen machen.** Ohne Facilitation bekommen die Lautesten die meiste Zeit. Das ist unfair und strategisch falsch, denn Menschen mit geringerem sozialem Status oder weniger Selbstsicherheit sehen oft Dinge, die andere übersehen. Öffne aktiv Raum, nicht mit »Hat noch jemand etwas zu sagen?«, sondern mit direkter Ansprache: »Wir haben von Jamie und Stu noch nichts gehört. Was denkt ihr?«
   Frage: *»Wer in der Runde wird voraussichtlich wenig sagen, aber etwas Wichtiges wissen?«*

5. **Den Dialog aktiv steuern.** Offene und geschlossene Fragen steuern das Tempo. »Was noch?« lädt ein, mehr zu sagen. »Gibt es noch etwas?« lädt ein, abzuschließen. Willst du eine Phase vertiefen, stell offene Fragen. Willst du weiterkommen, stell geschlossene.
   Frage: *»In welcher Phase willst du vertiefen, in welcher weiterkommen?«*

6. **Entscheidungen in Echtzeit dokumentieren.** Das stärkste Prinzip: Bevor das Meeting endet, werden Entscheidungen und nächste Schritte schriftlich vor allen festgehalten, live und sichtbar. Widerspricht jemand dem Aufgeschriebenen, ist das ein positives Signal: Klärung passiert jetzt, nicht danach in Einzelgesprächen. Nichts ist teurer, als ein Meeting zu beenden und sich zu fragen: Was haben wir gerade entschieden?
   Frage: *»Wie viele Minuten reservierst du am Ende, um Entscheidungen und nächste Schritte vor allen festzuhalten?«*

7. **Als teilnehmende Person in schlechten Meetings helfen.** Leitest du das Meeting nicht und es läuft schlecht, nutz aktiv den Chat:
   - Entscheidungen dokumentieren: »Decision: Wir verschieben das Audit auf Dezember.«
   - Empfehlungen notieren: »Empfehlung von Len: Wir verschieben das Audit.«
   - Bei Abschweifen: »Ich glaube, wir sind vom Thema abgekommen. Brauchen wir diese Diskussion, bevor wir eine Entscheidung treffen können?«

   So erhöhst du die Qualität, ohne übergriffig zu wirken.
   Frage: *»Was läuft in dem Meeting schief, und welchen dieser drei Chat-Beiträge kannst du beim nächsten Mal setzen?«*

## Beispiel

Dominik Kenzler hat in der Beratung bei Dark Horse und PwC weit über 100 Workshops geleitet und moderiert. Alex Pukinskis, damals Director of Planning and Execution bei Native Instruments, heute Head of Product bei Wero, hat für ihn die Messlatte bei Facilitation höher gelegt. Die Formulierungen in den Schritten 4 und 7 (Jamie und Stu, das Audit, Len) sind die Beispiele aus dem Buch.

## Worauf du achten musst

- **Facilitation mit Moderation verwechseln.** Ein Moderator sorgt dafür, dass alle zu Wort kommen. Ein Facilitator sorgt dafür, dass das Meeting sein Ziel erreicht. Das ist ein fundamentaler Unterschied.
- **Meetings ohne Agenda, ohne klares Ziel und ohne dokumentierte Entscheidungen.** Der häufigste Ausdruck dieses Missverständnisses. Solche Meetings kosten Zeit und erzeugen das Gegenteil von Klarheit.
- **Mit einer Erklärung starten statt mit Fragen.** Bedenken zeigen sich dann erst im Verlauf des Meetings.
- **Alles gleichzeitig.** Analysieren, brainstormen und entscheiden in einem Durchgang: Die lauteste Meinung gewinnt, nicht die beste.
- **Allgemeine Einladungen an die Stillen.** »Hat noch jemand etwas zu sagen?« öffnet keinen Raum. Direkte Ansprache tut es.

## Ergebnis

Ein Facilitation-Plan für das Meeting.

```markdown
# Facilitation-Plan: [Meeting]
Datum: [Datum] · Dauer: [Min] · Teilnehmende: [Namen oder Rollen]
Facilitator: [Name] · Mitschrift sichtbar in: [Dokument]

**Outcome:** Am Ende steht …
**Pre-read:** [Link hier] · verschickt am …
**Einstiegsfrage:** »Welche Fragen habt ihr zu diesem Ansatz?«

| Phase | Leitfrage | Zeit | Fragetyp |
|---|---|---|---|
| Analyse | Was wissen wir? | … | offen |
| Bedeutung | Was bedeutet das? | … | offen |
| Lösungen | Was sind mögliche Lösungen? | … | offen / geschlossen |
| Entscheidung | Was entscheiden wir? | … | geschlossen |
| Festhalten | Entscheidungen und nächste Schritte live notieren | … | |

**Direkt ansprechen:** [Namen], »Wir haben von … noch nichts gehört. Was denkt ihr?«

**Festgehalten:**
- Decision: …
- Nächster Schritt: [wer], [was], bis [wann]
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hat das Meeting ein klar benanntes Outcome, nicht nur ein Thema?
- Startest du mit Fragen zum Pre-read statt mit einer Erklärung?
- Haben Analyse, Lösungssuche und Entscheidung jeweils eigenen Raum?
- Hast du die Stillen namentlich eingeplant?
- Werden Entscheidungen und nächste Schritte vor Meetingende sichtbar für alle festgehalten?

## Im Flywheel

Modul SHIP, Bereich S3 Create Execution Clarity.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S3 Create Execution Clarity. Originalquelle: Alex Pukinskis: Remotely Productive.

Original: Alex Pukinskis: Remotely Productive. Leading better online meetings and workshops, 2024, https://remotely-productive.com/
