---
name: visiontype
description: Eine Firmen- oder Produktvision als kurzes Video zeigen mit dem Visiontype, aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand ein Zukunftsbild erlebbar machen, ein zwei- bis fünfminütiges Visionsvideo konzipieren, eine Produktvision in einer konkreten Szene zeigen oder ein Konzept für ein KI-generiertes Video oder einen Realfilm vorbereiten will. Führt von Thema und Zeithorizont über die Szene bis zu einem Konzept mit Szenenfolge.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D1 Target Picture
  origin: Mike Aurelio (laut Abb. 3.1)
  deep_dive: false
  version: "1.0"
---

# Visiontype

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Mike Aurelio (laut Abb. 3.1).

## Worum es geht

Visiontypes sind kurze Videos von zwei bis fünf Minuten, die ein Zukunftsbild zeigen. Sie können animiert oder als Realfilm produziert sein und Produkte oder Services einschließen. Was vor ein paar Jahren noch aufwendig war, lässt sich heute dank KI-gestützter Bild- und Videogenerierung ohne großes Team umsetzen.

Abb. 3.1 ordnet den Visiontype auf einer Zeitachse ab heute ein: zwischen dem eigenen Produkt im Bereich des Wahrscheinlichen und der Sci-Fi Zone. Die Bereiche dazwischen heißen plausibel und möglich.

## Wann du sie einsetzt

- Für große Themen wie Firmenvision oder Produktvision.
- Wenn ein Zukunftsbild gezeigt statt beschrieben werden soll.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Vision soll gezeigt werden (Firma, Produkt)? Wer soll das Video sehen? Wie soll es entstehen (animiert, Realfilm, KI-generiert)? Frag nichts, was die Person schon gesagt hat.
- Das Buch beschreibt keinen festen Ablauf. Die Schritte unten strukturieren das Gespräch entlang dessen, was das Buch über Visiontypes sagt, und enden in einem Konzept, mit dem die Person das Video produzieren oder beauftragen kann.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Prüf jede Szene gegen Abb. 3.1: Ist sie nur das heutige Produkt, oder schon Science-Fiction? Benenne das direkt.
- Erfinde keine Fakten über Produkt oder Organisation. Was offen ist, markierst du als offen.
- Schließe mit dem Konzept im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Thema und Flughöhe.** Welche Vision zeigt das Video: Firmenvision, Produktvision oder ein anderes Zielbild?
   Frage: *»Welches Zukunftsbild soll das Video zeigen, und für wen?«*

2. **Zeithorizont einordnen.** Wie weit liegt das Bild in der Zukunft, und wo liegt es zwischen heutigem Produkt und Sci-Fi Zone?
   Frage: *»Was davon gibt es heute schon, was ist plausibel, was nur möglich?«*
   Gut ist die Antwort, wenn das Bild über das heutige Produkt hinausgeht, ohne in die Sci-Fi Zone abzudriften.

3. **Die Szene.** Wer steht im Mittelpunkt, und in welcher Alltagssituation zeigt sich das Zukunftsbild? Beim Knowledge Navigator ist es ein Professor, der mit seinem Tablet durch seinen Tag geht.
   Frage: *»Welche Person erleben wir, in welcher Situation, und was tut sie dort?«*
   Gut ist die Antwort, wenn Produkt oder Service im Handeln einer konkreten Person sichtbar werden.

4. **Szenenfolge.** Die Momente, die das Video zeigt, in eine Reihenfolge bringen. Zwei bis fünf Minuten Länge.
   Frage: *»Welche Momente zeigt das Video, und in welcher Reihenfolge?«*

5. **Umsetzung.** Animiert, Realfilm oder KI-gestützte Bild- und Videogenerierung?
   Frage: *»Wie soll das Video entstehen, und wer setzt es um?«*

## Beispiel

Der Knowledge Navigator von Apple aus dem Jahr 1987: Ein Professor aus Berkeley öffnet sein Tablet. Ein KI-Assistent mit Avatar begrüßt ihn, geht die täglichen Aufgaben durch, verbindet ihn per Videocall mit einer Kollegin, um einen Artikel zu besprechen, und fügt im Nachgang alle relevanten Informationen zusammen. Das war 1987, in der Anfangszeit der Desktop-Computer.

Apple zeigte in fünf Minuten eine Vision von KI-Assistenten, generativen Avataren, Internet, Filesharing, portablen Touch-Devices, Sprachsteuerung und synchroner Kollaboration. Nahezu alle großen Innovationen im Consumer-Tech-Bereich der letzten 40 Jahre stecken in diesem Video.

## Worauf du achten musst

Das Buch nennt keine typischen Fehler. Die Punkte folgen aus der Definition und Abb. 3.1.

- **Nur das heutige Produkt zeigen.** Dann ist es ein Produktvideo, kein Zukunftsbild.
- **In die Sci-Fi Zone abdriften.** Abb. 3.1 setzt die Visiontype Zone bewusst vor die Sci-Fi Zone.
- **Zu lang werden.** Ein Visiontype dauert zwei bis fünf Minuten.

## Ergebnis

```markdown
# Visiontype: [Titel]
Vision: [Firma / Produkt] · Publikum: [wer] · Länge: [2 bis 5 Min] · Umsetzung: [animiert / Realfilm / KI-generiert]

**Zukunftsbild in einem Satz:** …
**Zeithorizont:** … · heute schon da: … · plausibel: … · möglich: …

**Hauptperson und Situation:** …

| # | Moment | Was wir sehen | Was es über die Zukunft zeigt |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |

**Offen:** …
```

## Mini-Check

Aus der Drive Checklist (Target Picture):
- Hast du ein klares Zielbild für deinen Verantwortungsbereich?
- Ist das Zielbild dokumentiert und zugänglich?
- Kennt dein Team das Zielbild und kann es wiedergeben?

(abgeleitet aus den typischen Fehlern)
- Geht das Video über das heutige Produkt hinaus?
- Bleibt es diesseits der Sci-Fi Zone?
- Passt es in zwei bis fünf Minuten?

## Im Flywheel

Modul DRIVE, Bereich D1 Target Picture. Eines der Formate, mit denen eine Vision ein Bild bekommt, das andere sehen und teilen können.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D1 Target Picture (Abb. 3.1 »Visiontype von Mike Aurelio«). Beispiel: Knowledge Navigator, Apple, 1987.

Original: Mike Aurelio (DesignMap): Visiontypes: A Tool for Strategic Innovation, 2018. https://uxplanet.org/visiontypes-a-tool-for-strategic-innovation-755c680f4536
