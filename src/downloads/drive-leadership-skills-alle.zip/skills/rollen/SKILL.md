---
name: rollen
description: Rollen als Kombination aus Fachrichtung, Level und Fähigkeiten beschreiben, mit dem Baustein Rollen aus Design Your Organisation im Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand eine Rollenbeschreibung erstellen, Verantwortungsbereich und Scope einer Position klären, Erwartungen an eine Rolle festhalten, Rollen im Team dokumentieren oder die Grundlage für eine Job Description oder Hiring Scorecard legen will. Setzt voraus, dass Fachrichtung, Level und Fähigkeiten bekannt sind, und führt sie zu einer Rolle zusammen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L1 Design Your Organisation
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Rollen

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Rollen sind die Kombination aus Fachrichtung, Level und Fähigkeiten. Sie beschreiben eine spezifische Position im Unternehmen: einen klaren Verantwortungsbereich, einen definierten Scope, konkrete Erwartungen und die dazugehörigen Fähigkeiten. In Abb. 4.1 ist die Rolle die Synthese der anderen Bausteine aus Design Your Organisation.

Wer vorher Fachrichtungen, Spezialisierungen, Fähigkeiten und Levels definiert hat, merkt, wie diese Bausteine in einer Rolle zusammenfließen, und wie gezielt man innerhalb oder außerhalb der Organisation nach Profilen suchen kann, die die Rolle erfüllen. Aus den vorhandenen Bausteinen lässt sich direkt eine Rollenbeschreibung oder Job Description ableiten.

Hier kommt alles zusammen. Die Bausteine wirken auf das Performance Management, helfen, klare Erwartungen zu kommunizieren und mit Mitarbeitenden darüber zu sprechen, was gute Arbeit auf ihrem Level konkret bedeutet. Sie sind die Grundlage für neue Rollenbeschreibungen und für Hiring Scorecards.

## Wann du sie einsetzt

- Wenn eine Position neu entsteht oder nachbesetzt werden soll.
- Wenn Rollen und Verantwortlichkeiten im Team nicht dokumentiert oder nicht für alle zugänglich sind.
- Als Vorarbeit für Job Description und Hiring Scorecard.
- In Gesprächen darüber, was gute Arbeit auf einem Level konkret bedeutet.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welche Position geht es? Gibt es schon Organisationsmap, Fähigkeitenmatrix und Level-Framework? Wofür wird die Rolle gebraucht (Dokumentation, Besetzung, Entwicklungsgespräch)? Frag nichts, was die Person schon gesagt hat.
- Die Rolle setzt sich aus vorhandenen Bausteinen zusammen. Fehlt einer, sag das und verweise auf den passenden Skill (`organisationsmap`, `faehigkeitenmatrix`, `career-track-levels`). Arbeite nur mit einer Annahme weiter, wenn die Person das will, und markiere sie.
- Beschreibe die Rolle, nicht die Person, die sie gerade innehat.
- Das Buch beschreibt keine feste Schrittfolge. Der Ablauf unten ordnet die Bestandteile einer Rolle aus dem Buch.
- Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen, wenn sie schon Material hat.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz.
- Erfinde keine Fakten über die Organisation der Person. Fehlende Informationen markierst du als offen.
- Schließe mit der Rollenbeschreibung im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Fachrichtung zuordnen.** In welcher Funktion und Fachrichtung sitzt die Rolle, gegebenenfalls mit welcher Spezialisierung?
   Frage: *»In welcher Fachrichtung sitzt die Rolle, und braucht es eine bestimmte Spezialisierung?«*

2. **Level festlegen.** Auf welchem Level ist die Rolle angesiedelt, im Management- oder im Expert-Pfad?
   Frage: *»Auf welchem Level und in welchem Pfad liegt die Rolle?«* Gut ist die Antwort, wenn sie sich auf ein bestehendes Level-Framework bezieht, nicht auf einen Titel.

3. **Verantwortungsbereich und Scope klären.** Wofür ist die Rolle verantwortlich, und wie weit reicht sie?
   Frage: *»Wofür genau ist die Person in dieser Rolle verantwortlich, und wo endet ihr Scope?«* Gut ist die Antwort, wenn sich der Bereich klar von benachbarten Rollen abgrenzt.

4. **Fähigkeiten zuordnen.** Welche Fähigkeiten aus der Fähigkeitenmatrix braucht die Rolle, auf welchem Niveau?
   Frage: *»Welche Fähigkeiten braucht die Rolle, und auf welchem Niveau laut Rubric?«*

5. **Erwartungen formulieren.** Was bedeutet gute Arbeit in dieser Rolle auf diesem Level konkret? Hier fließen auch die Werte und Verhaltenserwartungen aus Design Your Organisation ein.
   Frage: *»Woran erkennst du, dass jemand diese Rolle gut ausfüllt?«*

6. **Dokumentieren und zugänglich machen.** Die Rollenbeschreibung ablegen, sodass sie für alle zugänglich ist, und als Grundlage für Job Description und Scorecard nutzen.
   Frage: *»Wo liegt die Beschreibung, sodass alle im Team sie finden?«*

## Worauf du achten musst

- **Rolle ohne Bausteine.** Ohne definierte Fachrichtung, Level und Fähigkeiten bleibt die Rolle eine vage Jobbeschreibung.
- **Rolle um eine Person herum beschreiben.** Organisationen, die um einzelne Menschen gebaut sind, tragen selten langfristig.
- **Unklarer Scope.** Ohne klaren Verantwortungsbereich lassen sich Erwartungen nicht kommunizieren.
- **Beschreibung in der Schublade.** Rollen und Verantwortlichkeiten gehören dokumentiert und für alle zugänglich.

## Ergebnis

```markdown
# Rolle: [Bezeichnung]
Stand: [Datum] · Verantwortlich: [Führungskraft]

| Baustein | Inhalt |
|---|---|
| Funktion / Fachrichtung | … |
| Spezialisierung (falls relevant) | … |
| Level / Pfad | … / Management oder Expert |
| Verantwortungsbereich | … |
| Scope | … |
| Fähigkeiten (mit Niveau laut Rubric) | … |
| Erwartungen: gute Arbeit auf diesem Level heißt | … |
| Werte und Verhaltenserwartungen | … |

Abgelegt unter: …
Offen: …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Lässt sich die Rolle vollständig aus Fachrichtung, Level und Fähigkeiten herleiten?
- Beschreibt sie die Position und nicht die Person, die sie gerade besetzt?
- Ist der Verantwortungsbereich klar von benachbarten Rollen abgegrenzt?
- Ist die Rollenbeschreibung dokumentiert und für alle zugänglich?

## Im Flywheel

Modul LEAD, Bereich L1 Design Your Organisation.

Verwandte Skills:
- `organisationsmap`: liefert Funktion, Fachrichtung und Spezialisierung.
- `faehigkeitenmatrix`: liefert die Fähigkeiten und Rubrics.
- `career-track-levels`: liefert Level und Pfad.
- `job-description`: übersetzt die interne Rollenbeschreibung in ein externes Dokument.
- `hiring-scorecard`: Die Bausteine der Rolle sind die Grundlage der Scorecard.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L1 Design Your Organisation (Abb. 4.1, und) sowie LEAD Checklist.
