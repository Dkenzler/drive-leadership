# Drive Leadership Playbook: Skills

89 Skills zu den Methoden aus dem Drive Leadership Playbook von Dominik Kenzler (Murmann). Jeder Skill führt Schritt für Schritt durch eine Methode und endet mit einem ausgefüllten Ergebnis. Statt ein Template zu drucken, lädst du den Skill in den Agenten oder das LLM, das du bereits nutzt.

## Nutzen

- **Claude (Apps, Claude Code):** Ordner des Skills als ZIP hochladen bzw. nach `~/.claude/skills/<slug>/` kopieren.
- **ChatGPT, Copilot, andere LLMs:** Inhalt von `SKILL.md` (und bei Bedarf der Dateien in `templates/`) als Anweisung in einen neuen Chat, ein Custom GPT oder einen Agenten einfügen.

Starte mit `leadership-flywheel`, wenn du nicht weißt, welche Methode passt. Der Skill ordnet deine Situation ein und verweist auf die passenden Skills.

## Aufbau

```
skills/<slug>/SKILL.md          Methode, Ablauf, typische Fehler, Ergebnisformat, Mini-Check
skills/<slug>/templates/*.md    Vorlagen, Worksheets, Agenden aus dem Buch (44 Skills)
catalog.json                    Metadaten aller Skills für die Website
downloads/<slug>.zip            Ein ZIP pro Skill
```

## Übersicht

| Modul | Skills |
|---|---|
| Flywheel | 1 |
| DRIVE | 25 |
| LEAD | 23 |
| SHIP | 25 |
| YOURSELF | 15 |

Inhaltliche Grundlage ist ausschließlich das Buch. Die Skills ersetzen keine Entscheidung: Bei Methoden, die Menschen betreffen, bereitet der Skill vor, entscheiden tut die Führungskraft.
