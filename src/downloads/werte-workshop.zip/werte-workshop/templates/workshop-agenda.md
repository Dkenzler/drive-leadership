# Werte-Workshop: Agenda

Nach Abb. 4.16 im Drive Leadership Playbook, Workshop-Mechanik nach Matt Ström-Awn. Zwei Sessions à rund 90 Minuten an zwei aufeinanderfolgenden Tagen. Die Zeiten sind ein Vorschlag.

**Konstellation:** Leadership-Team / Peer-Kreis / Team
**Teilnehmende:** bis etwa 10 Personen, die die Werte verantworten oder leben
**Moderation:**
**Mitschrift:**
**Termin Tag 1:**
**Termin Tag 2:**
**Material:** viele Post-its, Klebepunkte, dicke Stifte (remote: gemeinsames Board und Video)

## Prework (Moderation)

- [ ] Klären, was einen guten von einem belanglosen Wert unterscheidet: Werte, die auf jedes Unternehmen zutreffen, sagen nichts. Tragfähig sind Werte, die eine echte Entscheidung enthalten und auch als Gegenteil aktiv sein könnten.
- [ ] Beide Termine gemeinsam planen, an aufeinanderfolgenden Tagen.

## Agenda

| Tag | Thema | Zeit |
|---|---|---|
| 1 | Check-in | 10 Min |
| 1 | Align | 15 Min |
| 1 | Diverge: Werte schreiben | 25 Min |
| 1 | Converge: Clustern | 25 Min |
| 1 | Vote | 10 Min |
| 1 | Check-out | 5 Min |
| 2 | Check-in und Rückblick | 10 Min |
| 2 | Erwartungen je Wert | 65 Min |
| 2 | Check-out | 15 Min |

## Ergebnis Tag 1: gewählte Werte (4 bis 5)

| Cluster-Label | Punkte |
|---|---|
| | |

## Ergebnis Tag 2: Erwartungen je Wert

| Wert | Daran erkennt man, dass wir ihn leben | Daran erkennt man, dass wir ihn verletzen |
|---|---|---|
| | | |

**Synthese durch:**

## Spielregeln

- Erst still schreiben, dann diskutieren.
- Die Führungskraft bringt keine fertigen Werte mit.
- Erwartungen als beobachtbares Verhalten, nicht als Wiederholung des Werts.
