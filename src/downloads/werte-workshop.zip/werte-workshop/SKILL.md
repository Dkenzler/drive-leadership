---
name: werte-workshop
description: Werte und Verhaltenserwartungen klären und im Team verankern, mit Werte & Erwartungen und dem Werte-Workshop aus dem Drive Leadership Playbook, Workshop-Mechanik nach Matt Ström-Awn. Nutze diesen Skill, wenn jemand die eigenen Prinzipien als Führungskraft schärfen, die echten Erwartungen der Geschäftsführung verstehen, Unternehmenswerte gegen die Realität prüfen, Firmenwerte definieren oder aktualisieren, mit Peers gemeinsame Werte klären oder mit dem Team festlegen will, wie bestehende Werte konkret gelebt werden. Übersetzt Werte in beobachtbares Verhalten und liefert eine zweitägige Workshop-Agenda.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L1 Design Your Organisation
  origin: Dominik Kenzler; Workshop-Mechanik nach Matt Ström-Awn
  deep_dive: true
  version: "1.0"
---

# Werte & Erwartungen: Werte-Workshop

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, Workshop-Mechanik nach Matt Ström-Awn.

## Worum es geht

Neben Fähigkeiten spielen beim Org Design Prinzipien und Eigenschaften eine Rolle, die keine Progression haben. Fähigkeiten lernt man schrittweise. Eigenschaften und Haltungen lassen sich zwar entwickeln, aber es gibt keine Stufen: Jemand arbeitet proaktiv oder nicht. Es gibt kein Beginner- oder Expert-Level für Proaktivität. Beispiele aus dem Buch: Self-Starter, High Agency (Hindernisse eigenständig aus dem Weg räumen, statt auf Erlaubnis zu warten), High Urgency (das Bewusstsein, dass Geschwindigkeit zählt und Themen nicht liegen bleiben dürfen).

Entscheidend ist, diese Erwartungen nicht stillschweigend vorauszusetzen, sondern offen zu machen, damit Menschen informiert entscheiden können, ob es zu ihnen passt. Das Ergebnis ist eine kurze, ehrliche Liste von Prinzipien und Erwartungen. Kein Poster, kein Manifest, sondern Klarheit darüber, worauf es ankommt und was Menschen wissen müssen, bevor sie ins Team kommen.

Werte, die von oben verordnet werden, hängen als Poster an der Wand und ändern nichts am Verhalten. Werte, die ein Team gemeinsam erarbeitet hat, prägen Entscheidungen. Der Werte-Workshop ist eine fokussierte Sitzung, in der ein Team oder Leadership-Team die wichtigsten Werte und die dazugehörigen Verhaltenserwartungen gemeinsam erarbeitet. Er leistet drei Dinge:

- **Echte Verbindlichkeit.** Menschen tragen mit, woran sie mitgeschrieben haben. Der Wert liegt nicht im Ergebnisdokument, sondern in der geteilten Urheberschaft.
- **Beobachtbares Verhalten statt abstrakter Werte.** »Ownership« heißt für die einen, niemanden zu fragen, für die anderen, alles abzustimmen. Erst die konkrete Erwartung neben jedem Wert macht Werte nutzbar für Feedback, Hiring und Entscheidungen.
- **Eine gemeinsame Sprache.** Wenige geteilte Begriffe beschleunigen Entscheidungen und machen Konflikte besprechbar.

## Wann du sie einsetzt

- Als Führungskraft, um die eigenen Werte und Erwartungen zu klären und transparent zu machen.
- Im Leadership-Team, um Firmenwerte zu definieren oder zu aktualisieren, was sich gerade in Start-ups anbietet.
- Im Peer-Kreis, um sich über gemeinsame Werte zu verständigen.
- Mit dem Team, um zu klären, wie ihr bestehende Firmenwerte konkret lebt.
- Erneut, wenn das Team stark wächst oder sich der Kontext deutlich verschiebt.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Geht es um die eigenen Werte und Erwartungen als Führungskraft oder um einen Workshop? Wenn Workshop: in welcher Konstellation (Leadership-Team, Peers, Team) und mit wie vielen Personen? Gibt es formulierte Unternehmenswerte? Frag nichts, was die Person schon gesagt hat.
- Teil A arbeitest du mit der Person allein durch. Für Teil B erstellst du Agenda, Prework und Moderationsfragen (siehe `templates/workshop-agenda.md`). Den Workshop selbst führt das Team, du formulierst keine Werte vor.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen, wenn sie schon Material hat.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Würde irgendein Team das Gegenteil behaupten? Steht neben jedem Wert beobachtbares Verhalten? Benenne Schwächen direkt und kurz.
- Erfinde keine Werte oder Erwartungen der Geschäftsführung. Was die Person nicht weiß, markierst du als offen und als Frage für das Gespräch mit der Geschäftsführung.
- Nach dem Workshop kannst du bei der Synthese helfen: Rohmaterial verdichten, ohne neue Werte hinzuzufügen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

### Teil A: Eigene Werte und Erwartungen klären

Drei Perspektiven helfen, die eigenen Werte und Erwartungen zu schärfen.

1. **Eigene Haltung klären.** Starte bei dir.
   Frage: *»Welche Eigenschaften sind in der Zusammenarbeit mit dir nicht verhandelbar? Was unterscheidet die besten Talente, mit denen du gearbeitet hast, von den schwierigsten? Welches Verhalten tolerierst du nicht, auch wenn die Ergebnisse stimmen?«*

2. **Erwartungen der Geschäftsführung verstehen.** Mit der Geschäftsführung oder der vorgesetzten Person sprechen, nicht über die offiziellen Unternehmenswerte, sondern über die echten Erwartungen. Oft gibt es eine Differenz zwischen dem, was kommuniziert wird, und dem, was tatsächlich zählt. Diese Differenz zu kennen, ist entscheidend.
   Frage: *»Was ist deiner Geschäftsführung wirklich wichtig? Welches Verhalten wird belohnt, welches nicht?«* Hat die Person das Gespräch noch nicht geführt, bereite die Fragen dafür vor.

3. **Mit den Unternehmenswerten abgleichen.** Falls es formulierte Unternehmenswerte gibt, gegen die Realität prüfen. Die brauchbaren übernehmen, den Rest nicht ignorieren, aber auch nicht blind weiterreichen.
   Frage: *»Welche Unternehmenswerte werden tatsächlich gelebt? Welche sind veraltet oder zu abstrakt, um im Alltag wirksam zu sein?«*

4. **Transparent machen.** Die kurze Liste mit konkreten Beispielen versehen, die die Verhaltensweisen illustrieren. Dann wird die Kommunikation besonders wirkungsvoll.
   Frage: *»Welches konkrete Beispiel zeigt, was du mit diesem Wert meinst?«*

### Teil B: Werte-Workshop

**Set-up.** Eine kleine Runde bis etwa zehn Personen. Teilnehmende sind die, die die Werte verantworten oder leben, weitere Rollen braucht es nicht. Eine Person moderiert, hält die Zeit und achtet darauf, dass alle beitragen. Eine Person schreibt mit und sichert die Ergebnisse. Material: viele Post-its, Klebepunkte, dicke Stifte (sie zwingen zur Kürze). Remote geht mit gemeinsamem Board und Video.

**Prework.** Die moderierende Person klärt vorab, was einen guten von einem belanglosen Wert unterscheidet. Werte, die auf jedes Unternehmen zutreffen, etwa vertrauenswürdig oder innovativ, sagen nichts. Tragfähig sind Werte, die eine echte Entscheidung enthalten und auch als Gegenteil aktiv sein könnten. Zwei Sessions à rund 90 Minuten an zwei aufeinanderfolgenden Tagen, beide Termine von vornherein zusammen planen.

**Tag 1: Werte (rund 90 Minuten)**

1. **Check-in (10 Min).** Reihum ein kurzes, ehrliches Status-Update, beginnend bei der moderierenden Person. Ein bisschen Verletzlichkeit am Anfang schafft psychologische Sicherheit für ehrliche Werte.
2. **Align (15 Min).** Knapp in Ziele und Begriffe einführen, Raum für Rückfragen. Am Ende haben alle dasselbe Verständnis davon, was ein guter Wert ist.
3. **Diverge: Werte schreiben (25 Min).** Timer stellen, jede Person schreibt still für sich Werte, einen pro Post-it, die ganze Zeit über. Wer feststeckt, schreibt den ersten Gedanken noch mal auf und knüllt ihn weg. Die moderierende Person achtet darauf, ob jemand nicht schreibt, und hilft leise.
4. **Converge: Clustern (25 Min).** Reihum liest jede Person ihre Werte vor und klebt sie an die Wand. Ähnliche Werte bilden ein Cluster mit einem einzigen Label. Aus »Zusammenarbeit«, »Team Spirit« und »gemeinsam stark« wird ein Cluster mit dem Label »Team Spirit«.
5. **Vote (10 Min).** Klebepunkte auf die Cluster verteilen, mehrere Punkte auf ein Cluster sind erlaubt. Ziel: vier bis fünf Werte, hinter denen die Gruppe steht.
6. **Check-out (5 Min).** Kurzer Abschluss reihum, spiegelbildlich zum Check-in.

**Tag 2: Erwartungen (rund 90 Minuten)**

Die Werte gelten jetzt als gesetzt und werden in konkretes Verhalten übersetzt. Das ist eine analytische Denkbewegung, deshalb der eigene Tag.

1. **Check-in und Rückblick (10 Min).** Status-Update reihum, dann die gewählten Werte noch einmal zeigen. Wer über Nacht eine Formulierung anfassen will, darf das.
2. **Erwartungen je Wert (65 Min).** Für jeden Wert: Woran erkennt man im Verhalten, dass wir ihn leben, und woran, dass wir ihn verletzen? Als beobachtbares Verhalten formulieren, nicht als Wiederholung des Werts. Wert für Wert, mit Zeit für Diskussion.
   Moderationsfrage: *»Woran würde jemand von außen sehen, dass wir diesen Wert leben?«*
3. **Check-out (15 Min).** Steht das Ergebnis, fehlt etwas, fühlt es sich tragfähig an? Festlegen, wer das Rohmaterial zur finalen Fassung verdichtet.

**Danach: Synthese.** Eine Person oder ein kleiner Kreis destilliert die finale Fassung: die wenigen Werte sauber benannt, je Wert ein, zwei erklärende Sätze und die beobachtbaren Verhaltenserwartungen. Entscheidend ist die Sichtbarkeit danach: Je öfter Team und Nachbarteams die Werte sehen und je klarer die Erwartungen, desto tiefer setzen sie sich fest.

## Beispiel

Die großen Unternehmensberatungen machen ihre Erwartungen offen: Wer sich dort bewirbt, weiß, dass die Kultur lange Arbeitswochen, hohen Druck und proaktives Arbeiten verlangt. Das muss nicht allen gefallen, aber Menschen können informiert entscheiden.

Molly Graham beschreibt, dass ein einzelnes Statement von Mark Zuckerberg in einem All-Hands mehr kulturellen Einfluss hatte als alle Initiativen, die ihr Team hätte anstoßen können. Aufgabe des Leadership-Teams ist es, die Werte so weiterzutragen, dass Entscheidungen im Sinne der Gründer getroffen werden, auch wenn diese nicht im Raum sind. Shreyas Doshi beobachtete bei Stripe, dass Patrick und John Collison Kultur durch ihr eigenes Verhalten skalierten, nicht über Dokumente.

Matt Ström-Awn, Design-Leader beim »Wall Street Journal«, trug zunächst fertige Prinzipien ins Team und verschenkte damit das gemeinsame Ringen. Erst als das Team seine Prinzipien selbst schrieb, wurden sie breit akzeptiert und im Alltag benutzt. Die meistgewählten Prinzipien hat er anschließend redigiert und als Poster veröffentlicht.

Beispiel für eine Verhaltenserwartung: nicht »Wir sind verlässlich«, sondern »Wir sagen zu, was wir halten können, und melden uns früh, wenn etwas kippt«.

## Worauf du achten musst

- **Fertige Werte mitbringen.** Der häufigste und teuerste Fehler. Mit vorformulierten Werten wird der Workshop zur Abstimmungsshow, und die Verbindlichkeit entsteht nicht. Als Führungskraft beim Schreiben bewusst zurückhalten.
- **Belanglose Werte durchwinken.** Heißt ein Cluster »Qualität« oder »Vertrauen«, nachfragen: Würde irgendein Team das Gegenteil behaupten? Wenn nein, ist es kein unterscheidender Wert.
- **Bei den Werten stehen bleiben.** Ohne Verhaltenserwartung bleiben Werte folgenlos. Session 2 nicht ausfallen lassen.
- **Die lautesten Stimmen gewinnen lassen.** Keine Diskussion vor dem stillen Schreiben, sonst ankern alle an der ersten geäußerten Meinung.
- **Die zweite Session verschleppen.** Liegen Tage oder Wochen dazwischen, ist der Schwung weg. Beide Sessions als festen 2-Tages-Block an aufeinanderfolgenden Tagen planen.
- **Offizielle Werte ungeprüft weiterreichen.** Die echten Erwartungen der Geschäftsführung weichen oft von den kommunizierten ab.

## Ergebnis

Agenda für den Workshop: `templates/workshop-agenda.md`.

```markdown
# Werte und Erwartungen: [Team / Bereich]
Stand: [Datum] · Erarbeitet von: [Runde] · Synthese: [Person]

## Werte (4 bis 5)
### [Wert 1]
Was er bedeutet (1 bis 2 Sätze): …
Daran erkennt man, dass wir ihn leben: …
Daran erkennt man, dass wir ihn verletzen: …
Beispiel: …

### [Wert 2]
…

## Abgleich (Teil A)
- Nicht verhandelbar für mich als Führungskraft: …
- Echte Erwartungen der Geschäftsführung: …
- Unternehmenswerte: übernommen … · veraltet oder zu abstrakt …

## Sichtbarkeit
Wo und wie Team und Nachbarteams die Werte sehen: …
```

## Mini-Check

- Habt ihr die Werte still und einzeln geschrieben, bevor diskutiert wurde?
- Bleibt am Ende eine kleine Zahl (vier bis fünf), nicht eine lange Liste?
- Enthält jeder Wert das Gegenteil, oder ist er so allgemein, dass ihn niemand bestreiten würde?
- Steht neben jedem Wert eine beobachtbare Verhaltenserwartung, kein zweiter abstrakter Begriff?
- Hat das Team selbst geschrieben und abgestimmt, statt deine fertigen Werte zu bestätigen?
- Sind beide Sessions von vornherein als 2-Tages-Block an aufeinanderfolgenden Tagen geplant?

## Im Flywheel

Modul LEAD, Bereich L1 Design Your Organisation.

Verwandte Skills:
- `team-charter`: das umfassende Format (Purpose, Capabilities, Werte, interne und externe Normen, Measures of Success) über mehrere Sessions. Werte sind ein Baustein davon. Den Werte-Workshop nimmst du, wenn du gezielt nur das Fundament aus Werten und Erwartungen setzen willst.
- `job-description`: Verhaltenserwartungen fließen in den Bereich Arbeitsweise und Haltung ein.
- `hiring-scorecard`: Die Scorecard baut auf den Verhaltenserwartungen auf.

Die Mechanik skaliert: Für größere Organisationen lässt sie sich auf mehrere Gruppen oder längere Sessions strecken. Die Grundbewegung aus Diverge und Converge bleibt gleich.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L1 Design Your Organisation, Werte & Erwartungen und Deep Dive Werte-Workshop (Abb. 4.16). Workshop-Mechanik nach Matt Ström-Awns Workshop zu Design Principles, im Buch auf Werte und Erwartungen übertragen.
