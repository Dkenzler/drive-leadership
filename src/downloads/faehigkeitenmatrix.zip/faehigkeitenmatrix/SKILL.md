---
name: faehigkeitenmatrix
description: Fähigkeiten (Capabilities) je Fachrichtung definieren und über Rubrics mit den Levels verbinden, mit der Fähigkeitenmatrix aus dem Drive Leadership Playbook, aufbauend auf Peter Merholz. Nutze diesen Skill, wenn jemand ein Career Framework oder Progression Framework aufbaut, klar machen will, was im Team konkret erwartet wird, Fähigkeiten in Craft, Strategie und Kollaboration ordnen, Rubrics von Developing bis Expert formulieren oder eine Grundlage für Assessment, Feedback, Job Description und Hiring Scorecard schaffen will.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L1 Design Your Organisation
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Fähigkeitenmatrix

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, aufbauend auf Peter Merholz.

## Worum es geht

Steht fest, welche Funktionen und Fachrichtungen eine Organisation braucht, folgt die nächste Frage: Welche Fähigkeiten muss jede dieser Fachrichtungen mitbringen? Fähigkeiten sind die Grundbausteine jeder Karrierearchitektur. Peter Merholz nennt sie das »Atom«, auf dem alles aufbaut.

Das Buch verwendet bewusst den breiteren Begriff Capabilities. Er meint nicht nur fachliches Handwerk, sondern auch Haltung, strategisches Denken und professionelles Verhalten. Fähigkeiten lassen sich in drei Kategorien einteilen:

- **Craft (Handwerk):** die fachlichen Fähigkeiten, die eine Fachrichtung definieren. Jede Fachrichtung hat ihr eigenes Craft.
- **Strategie:** Fähigkeiten über das reine Handwerk hinaus, etwa Marktverständnis, technologische Einordnung, unternehmerisches Denken.
- **Kollaboration:** übergreifende Kompetenzen wie Kommunikation, Zusammenarbeit, Strukturierung von Arbeit oder die Fähigkeit, sich in einer Organisation zu bewegen.

Klar definierte Fähigkeiten machen sichtbar, was du von den Menschen in deinem Team konkret erwartest. Nicht als vage Jobbeschreibung, sondern als Beschreibung dessen, was sich beobachten, entwickeln und bewerten lässt.

Die Fähigkeiten bleiben über die Levels einer Fachrichtung weitgehend dieselben. Was sich verändert, sind Anspruch und Gewichtung. Bei Junioren machen Craft-Fähigkeiten den größten Anteil aus, auf Senior- und Lead-Level gewinnen strategische und kollaborative Fähigkeiten deutlich an Gewicht. Die Verbindung von Fähigkeiten und Levels stellen **Rubrics** her: Sie beschreiben für jede Fähigkeit, wie sich erwartetes Verhalten und erwartete Ergebnisse auf jedem Level unterscheiden, und machen den Unterschied zwischen »Developing«, »Intermediate«, »Advanced« und »Expert« greifbar. Rubrics sind der Kern eines guten Career Frameworks. Ohne sie bleiben Level-Definitionen abstrakt und subjektiv.

## Wann du sie einsetzt

- Wenn nach der Organisationsmap klar ist, welche Fachrichtungen es gibt, und nun die Erwartungen je Fachrichtung beschrieben werden sollen.
- Beim Aufbau eines Career Frameworks, damit transparent wird, wo jemand steht, was der nächste Entwicklungsschritt ist und worauf sich Feedback beziehen kann.
- Als Grundlage für das Team-Assessment, für Job Descriptions und Hiring Scorecards.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Fachrichtung(en) soll die Matrix entstehen? Gibt es schon ein Level-Framework? Wofür wird sie zuerst gebraucht (Career Framework, Assessment, Hiring)? Frag nichts, was die Person schon gesagt hat.
- Das Buch beschreibt keine feste Schrittfolge. Der Ablauf unten ordnet die Bausteine aus dem Buch in eine Reihenfolge für das Gespräch.
- Arbeite Fachrichtung für Fachrichtung. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen, wenn sie schon Material hat.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist die Fähigkeit beobachtbar, oder ist sie eine vage Eigenschaft? Benenne Schwächen direkt und kurz.
- Erfinde keine Fähigkeiten oder Rubric-Beschreibungen für die Organisation der Person. Mach Vorschläge nur als Formulierungshilfe für das, was sie selbst beschreibt, und markiere Lücken als offen.
- Schließe mit der Matrix im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Fachrichtung festlegen.** Die Matrix entsteht pro Fachrichtung, weil jede Fachrichtung ihr eigenes Set an Fähigkeiten mitbringt.
   Frage: *»Für welche Fachrichtung beschreiben wir die Fähigkeiten, und was ist ihr Beitrag zur Strategie?«*

2. **Craft-Fähigkeiten sammeln.** Welche fachlichen Fähigkeiten definieren diese Fachrichtung?
   Frage: *»Welche fachlichen Fähigkeiten machen diese Fachrichtung aus?«* Gut ist die Antwort, wenn die Fähigkeiten spezifisch für diese Fachrichtung sind und sich beobachten lassen.

3. **Strategische und kollaborative Fähigkeiten ergänzen.** Welche Fähigkeiten gehen über das Handwerk hinaus, und welche übergreifenden Kompetenzen braucht die Fachrichtung in der Zusammenarbeit?
   Frage: *»Welche strategischen Fähigkeiten und welche Fähigkeiten in der Zusammenarbeit erwartest du?«*

4. **Granularität prüfen.** Nicht mehr als 20 Fähigkeiten insgesamt tracken. Zu viele, und der Überblick geht verloren. Zu wenige, und die Matrix wird ungenau.
   Frage: *»Wie viele Fähigkeiten stehen jetzt auf der Liste, und welche lassen sich zusammenfassen?«*

5. **Rubrics formulieren.** Für jede Fähigkeit beschreiben, wie sich erwartetes Verhalten und erwartete Ergebnisse auf jedem Level unterscheiden (Developing, Intermediate, Advanced, Expert). Dabei die Gewichtung mitdenken: Welche Kategorie zählt auf welchem Level stärker?
   Frage: *»Woran erkennst du bei dieser Fähigkeit den Unterschied zwischen Developing, Intermediate, Advanced und Expert?«* Gut ist die Antwort, wenn sie Verhalten und Ergebnisse beschreibt, nicht nur Adjektive steigert.

6. **Einordnen und kommunizieren.** Fähigkeiten sind Voraussetzung und wichtiger Baustein, aber nie der einzige Indikator für Beförderung und Karriereentwicklung. Die weiteren Bausteine sind Impact (Wirkung), Qualität der Arbeit und Verhalten. Das sollte den Mitarbeitenden klar kommuniziert werden.
   Frage: *»Wie machst du deinem Team klar, dass Fähigkeiten ein Baustein sind, aber Impact, Qualität und Verhalten genauso zählen?«*

## Beispiel

Craft im Key Account Management: Beziehungsaufbau, Verhandlungsführung, Pipeline-Steuerung. Craft im Backend Engineering: Systemarchitektur, Datenmodellierung, Code-Qualität.

Anspruch je Level am Beispiel Vertrieb: Ein Junior muss Verhandlungsführung auf grundlegendem Niveau beherrschen. Bei einem Senior werden eine ausgeprägtere Verhandlungsführung, komplexere Deals, ein schwierigeres Gegenüber und höhere Eigenverantwortung erwartet.

Warum Fähigkeiten allein nicht reichen, zeigt der Mannschaftssport: Spieler, die beim alten Verein jede Woche treffen, haben nach einem Wechsel Ladehemmung. Sie haben ihre Fähigkeiten nicht verloren, sie setzen sie im neuen System nur nicht in Wirkung um. Umgekehrt kann jemand mit Wirkung und starken Fähigkeiten durch schlechtes Verhalten gegenüber dem Team mehr zerstören, als die eigene Leistung aufbaut.

## Worauf du achten musst

- **Nur Handwerk erfassen.** Capabilities umfassen auch Strategie und Kollaboration. Fehlen sie, fehlt genau das, was auf Senior- und Lead-Level an Gewicht gewinnt.
- **Pro Level andere Fähigkeiten definieren.** Die Fähigkeiten bleiben weitgehend gleich. Was sich ändert, sind Anspruch und Gewichtung.
- **Ohne Rubrics arbeiten.** Level-Definitionen bleiben dann abstrakt und subjektiv.
- **Falsche Granularität.** Mehr als 20 Fähigkeiten überfordern, zu wenige machen die Matrix ungenau.
- **Vage Beschreibungen.** Eine Fähigkeit, die sich nicht beobachten, entwickeln und bewerten lässt, ist eine Jobbeschreibung, keine Erwartung.
- **Fähigkeiten als einzigen Indikator nutzen.** Impact, Qualität der Arbeit und Verhalten gehören dazu.

## Ergebnis

```markdown
# Fähigkeitenmatrix: [Fachrichtung]
Stand: [Datum] · Verantwortlich: [Rolle]
Anzahl Fähigkeiten gesamt: [max. 20]

| Kategorie | Fähigkeit | Developing | Intermediate | Advanced | Expert |
|---|---|---|---|---|---|
| Craft | … | … | … | … | … |
| Strategie | … | … | … | … | … |
| Kollaboration | … | … | … | … | … |

## Gewichtung nach Level
- Junior: Schwerpunkt …
- Senior / Lead: Schwerpunkt …

## Weitere Bausteine neben Fähigkeiten
Impact, Qualität der Arbeit, Verhalten: wie sie in Karriereentscheidungen einfließen: …

## Offen
- …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Deckt die Matrix alle drei Kategorien ab: Craft, Strategie, Kollaboration?
- Bleibst du bei höchstens 20 Fähigkeiten?
- Gibt es für jede Fähigkeit eine Rubric, die Verhalten und Ergebnisse je Level beschreibt?
- Ist jede Fähigkeit so formuliert, dass sie sich beobachten, entwickeln und bewerten lässt?
- Wissen deine Mitarbeitenden, dass Fähigkeiten nicht der einzige Maßstab für Beförderungen sind?

## Im Flywheel

Modul LEAD, Bereich L1 Design Your Organisation.

Verwandte Skills:
- `organisationsmap`: liefert die Fachrichtungen, für die die Fähigkeiten beschrieben werden.
- `career-track-levels`: Rubrics verbinden Fähigkeiten mit den Levels.
- `rollen`: Eine Rolle kombiniert Fachrichtung, Level und Fähigkeiten.
- `assessment-prozess`: Beobachtungen und Gespräche werden über Zielbild und Fähigkeitenmatrix gelegt.
- `job-description`: Fähigkeiten und Qualifikationen werden direkt aus den Rubrics abgeleitet.
- `hiring-scorecard`: Die Scorecard baut direkt auf den Fähigkeiten-Rubrics auf.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L1 Design Your Organisation. Begriff »Atom« nach Peter Merholz.
