---
name: minto-pyramid-principle
description: "Botschaften strukturieren mit dem Minto Pyramid Principle von Barbara Minto (»The Pyramid Principle«), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Entscheidungsvorlage, ein Status-Update, eine Executive Summary, ein Memo, eine Präsentation oder eine Slack-Nachricht an Führungskräfte schreiben will, zu lange braucht, um auf den Punkt zu kommen, oder chronologisch statt vom Ergebnis her erzählt. Baut die Botschaft als Pyramide auf: Kernaussage zuerst, darunter zwei bis vier stützende Argumente, darunter Details und Daten (Bottom line up front)."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D5 Communicate Direction
  origin: Barbara Minto
  deep_dive: false
  version: "1.0"
---

# Minto Pyramid Principle

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Barbara Minto.

## Worum es geht

Die meisten Menschen kommunizieren so, wie sie denken: chronologisch. Erst der Kontext, dann die Analyse, schließlich die Schlussfolgerung. Das Publikum muss bis zum Ende warten, um zu verstehen, worauf es hinausläuft. In Präsentationen und Meetings führt das zu Ungeduld, Verwirrung, oder die Zuhörenden schalten ab.

Barbara Minto, ehemalige McKinsey-Beraterin, hat dafür das Pyramid Principle entwickelt. Beginne mit der Kernaussage, dann liefere die Argumente, die sie stützen. An der Spitze der Pyramide steht die Hauptbotschaft, die Antwort oder Empfehlung. Darunter die unterstützenden Argumente, typischerweise zwei bis vier. Darunter, falls nötig, die Details und Daten, die diese Argumente belegen.

Das Prinzip wirkt, weil es sofort Orientierung gibt. Wer die Hauptaussage kennt, kann die folgenden Argumente einordnen und ist oft sogar gespannt auf die Begründung. Ursprünglich wurde es für schriftliche Kommunikation entwickelt, für Memos und Reports bei McKinsey. Es funktioniert genauso für Präsentationen, Updates und kurze Slack-Nachrichten: überall dort, wo Klarheit wichtiger ist als Spannung.

## Wann du sie einsetzt

- Entscheidungsvorlagen, Status-Updates, Executive Summaries.
- Immer, wenn die Zeit des Publikums begrenzt ist.
- Besonders in der Kommunikation mit Führungskräften, die schnell zum Punkt kommen wollen.
- In internationalen Kontexten.

Kultureller Hinweis aus dem Buch: In Deutschland ist der klassische Aufbau oft umgekehrt: Problem, Analyse, Lösung. Erst wird gezeigt, dass das Thema verstanden wurde, dann kommt die Empfehlung. Das gilt als gründlich und seriös. Im US-Business-Kontext ist es andersherum, beim Militär heißt das »Bottom line up front«. Für deutsche Leser:innen fühlt sich das anfangs ungewohnt an, ist aber gerade international und gegenüber Führungskräften mit wenig Zeit extrem wirksam.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wer ist das Publikum? Welches Format (Memo, Update, Präsentation, Nachricht)? Was soll danach passieren? Frag nichts, was die Person schon gesagt hat.
- Bringt die Person einen fertigen Text mit, baue ihn nicht neu, sondern zeige, wo die Kernaussage heute steht, und zieh sie nach vorn.
- Geh den Ablauf von oben nach unten durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge gegen »Worauf du achten musst«. Vor allem: Steht vor der Kernaussage noch Kontext? Gibt es mehr als vier Argumente?
- Erfinde keine Argumente, Zahlen oder Belege. Fehlt ein Beleg, markiere ihn als offen.
- Schließe mit der Pyramide und dem ausformulierten Text im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Kernaussage festlegen.** Die Hauptbotschaft, Antwort oder Empfehlung an die Spitze.
   Frage: *»Wenn dein Publikum nur einen Satz liest oder hört: Welcher ist es?«* Gut ist die Antwort, wenn sie eine Empfehlung oder Antwort ist und nicht Kontext oder Vorgeschichte.

2. **Stützende Argumente sammeln.** Zwei bis vier Argumente, die die Kernaussage begründen. Jedes beantwortet die Frage »Warum?«.
   Frage: *»Warum stimmt deine Kernaussage? Nenne die zwei bis vier wichtigsten Gründe.«* Gut ist die Antwort, wenn jedes Argument die Kernaussage direkt stützt und es höchstens vier sind.

3. **Belege zuordnen, falls nötig.** Details und Daten unter das Argument, das sie belegen.
   Frage: *»Welche Fakten oder Zahlen belegen jedes Argument?«* Gut ist die Antwort, wenn jeder Beleg genau einem Argument zugeordnet ist. Belege ohne Argument sind Kandidaten zum Streichen.

4. **In Reihenfolge ausformulieren.** Kernaussage zuerst, dann die Begründung. Die Pyramide durchhalten, nicht abschweifen.
   Frage: *»Steht deine Kernaussage im ersten Satz?«* Gut ist die Antwort, wenn der Text genau der Pyramide folgt.

## Beispiel

Statt: »Wir haben folgende Zahlen analysiert, letzte Woche verschiedene Szenarien durchgespielt und mit dem Team gesprochen, daher glauben wir, dass wir das Projekt um drei Monate verschieben sollten.«

Besser: »Wir sollten das Projekt um drei Monate verschieben. Drei Gründe: Das Budget reicht nicht, das Team ist überlastet, und der Markt ist noch nicht bereit.«

Die Kernaussage zuerst, dann die Begründung.

## Worauf du achten musst

- **Zu viel Kontext vor der Kernaussage.** Das Publikum wartet, statt einzuordnen.
- **Mehr als vier Hauptargumente.** Die Pyramide verliert ihre Klarheit.
- **Die Pyramide nicht durchhalten.** Zwischendurch abschweifen und damit die Struktur aufgeben.

## Ergebnis

Nach Abb. 3.18 im Buch.

```markdown
# Pyramide: [Thema]
Publikum: … · Format: …

**Kernbotschaft:** …

1. **Argument (Warum):** …
   - Beleg: …
2. **Argument (Warum):** …
   - Beleg: …
3. **Argument (Warum, optional):** …
   - Beleg: …

**Ausformuliert (Kernaussage zuerst):**
…

**Offene Belege:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Steht die Kernaussage im ersten Satz, ohne Kontext davor?
- Ist die Kernaussage eine Antwort oder Empfehlung?
- Hast du höchstens vier Hauptargumente, und stützt jedes die Kernaussage direkt?
- Gehört jeder Beleg zu genau einem Argument?
- Bleibt der Text durchgehend in der Pyramide, ohne abzuschweifen?

## Im Flywheel

Modul DRIVE, Bereich D5 Communicate Direction.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D5 Communicate Direction, Abb. 3.18. Originalquelle: Barbara Minto: The Pyramid Principle. Logic in Writing and Thinking, 1981.
Original: Barbara Minto: The Pyramid Principle. Logic in Writing and Thinking, Minto International, London, 1978 (überarbeitete Ausgabe 1981). Erweiterte Fassung: The Minto Pyramid Principle. Logic in Writing, Thinking and Problem Solving, 1996. https://www.barbaraminto.com
