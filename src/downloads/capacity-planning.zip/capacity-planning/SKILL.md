---
name: capacity-planning
description: "Capacity Planning in sechs Schritten aus dem Drive Leadership Playbook von Dominik Kenzler: die verfügbare Kapazität eines Teams sichtbar machen, bevor Commitments eingegangen werden. Nutze diesen Skill, wenn jemand ein Quartal, Halbjahr oder einen Sprint realistisch planen, Teamkapazität berechnen, Urlaub, Feiertage, Teilzeit und Onboarding einrechnen, Puffer für ungeplante Arbeit festlegen, Szenarien wie Ausfälle oder neue Initiativen durchspielen oder chronische Überlastung im Team vermeiden will. Führt durch Detailgrad, Maßeinheit, Zeitraum, Verfügbarkeit, Einplanung und Szenarienvergleich."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S2 Plan & Prioritize
  origin: Dominik Kenzler (das Buch nennt keine Urheber:in)
  deep_dive: false
  version: "1.0"
---

# Capacity Planning

Aus dem Drive Leadership Playbook von Dominik Kenzler. Das Buch nennt für die Methode keine Urheber:in.

## Worum es geht

Jedes Team hat eine endliche Kapazität. Ferien, Krankheit, Meetings, Onboarding, technische Schulden: All das frisst Zeit. Wer das nicht einkalkuliert, macht Pläne, die auf dem Papier gut aussehen und in der Praxis scheitern. Dominik hat selten erlebt, dass ein Team seine Kapazität überschätzt. Fast immer gilt das Gegenteil.

Capacity Planning macht die verfügbare Kapazität des Teams sichtbar, bevor du Commitments eingehst. Du bestimmst als Leader das Tempo, aber auf einer realistischen Basis, sonst verlierst du das Vertrauen deiner Mitarbeitenden.

Dahinter steht der **Planning-Fallacy-Effekt** aus der Verhaltenspsychologie: Wir unterschätzen systematisch, wie lange Dinge dauern, auch wenn wir es aus Erfahrung besser wissen sollten. In der Planungsphase sind alle optimistisch, Ablenkungen werden ausgeblendet. Capacity Planning ist deshalb ein Schutzinstrument für das Team. Wer realistisch plant, gibt dem Team die Möglichkeit, wirklich zu committen, ohne permanent überlastet zu sein. Chronische Überlastung ist eine der häufigsten Ursachen für sinkende Qualität, Burn-out und fehlende Ownership.

## Wann du sie einsetzt

- Vor jeder Planungsrunde, bevor Commitments eingegangen werden.
- Laufend im Operating Rhythm, sobald sich etwas ändert: jemand wird krank, ein neues Projekt kommt herein, Prioritäten verschieben sich.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welches Team oder welche Teams? Für welchen Zeitraum? Welche Initiativen sollen eingeplant werden? Frag nichts, was die Person schon gesagt hat.
- Geh die sechs Schritte der Reihe nach durch. Eine Frage pro Schritt, dann auf die Antwort warten. Hat die Person schon Zahlen, übernimm sie und prüfe nur.
- Rechne transparent. Zeig, wie du von der Bruttokapazität über Abwesenheiten zur planbaren Kapazität kommst, und wende den Puffer an.
- Challenge gegen »Worauf du achten musst«. Vor allem: Ist die Verfügbarkeit wirklich geklärt? Liegt die eingeplante Arbeit über 70 bis 80 Prozent?
- Erfinde keine Personenzahlen, Abwesenheiten oder Aufwände. Fehlende Werte markierst du als offen.
- Schließe mit dem Kapazitätsplan im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Detailgrad festlegen.** Auf welcher Ebene wird geplant? Für die Quartalsplanung reicht ein grober Überblick auf Initiative-Ebene. Je näher der Umsetzungszeitraum rückt, desto feiner wird die Planung, auf Feature- oder Task-Ebene.
   Frage: *»Planst du auf Ebene von Initiativen, Features oder Tasks?«* Gut ist die Antwort, wenn der Detailgrad zum Abstand bis zur Umsetzung passt.

2. **Maßeinheit wählen.** Personentage, Stunden, Story Points oder Kosten. Was gewählt wird, ist weniger wichtig als Konsistenz: Alle Teams arbeiten mit derselben Einheit, damit Pläne vergleichbar bleiben.
   Frage: *»In welcher Einheit messt ihr Aufwand, und nutzen alle beteiligten Teams dieselbe?«*

3. **Zeitraum definieren.** Halbjahr, Quartal oder Sprint bestimmen den Planungshorizont. Beim Vergleich von Szenarien bleibt derselbe Zeitraum.
   Frage: *»Für welchen Zeitraum planst du?«*

4. **Verfügbarkeit der Teams klären.** Wie viele Personen stehen wann zur Verfügung? Ferien, Feiertage, Teilzeitmodelle und Onboarding-Zeit berücksichtigen. Dieser Schritt wird am häufigsten übersprungen und führt am häufigsten zu Planungsfehlern.
   Frage: *»Wer steht im Zeitraum zur Verfügung, und welche Ferien, Feiertage, Teilzeit und Onboarding-Zeiten kennst du schon?«* Gut ist die Antwort, wenn sie pro Person konkret ist, nicht »das Team ist voll da«.

5. **Arbeit einplanen und priorisieren.** Zieldaten setzen, Aufwände schätzen, Ressourcen zuweisen. Faustregel: nie mehr als 70 bis 80 Prozent der verfügbaren Kapazität verplanen. Der Rest ist Puffer für ungeplante Arbeit. Ungeplante Arbeit wird dabei aktiv bewertet: Ist das wirklich dringend? Wirklich wichtiger als das bereits Geplante?
   Frage: *»Welche Initiativen passen in die planbare Kapazität, und was fällt heraus, wenn ihr bei 70 bis 80 Prozent bleibt?«*

6. **Szenarien vergleichen.** Was passiert, wenn ein Teammitglied ausfällt? Was, wenn eine neue Initiative hinzukommt? Szenarien helfen, Risiken früh zu erkennen und Alternativen zu entwickeln, bevor ein Problem entsteht.
   Frage: *»Was würdet ihr streichen oder verschieben, wenn eine Person ausfällt oder eine neue Initiative dazukommt?«*

## Worauf du achten musst

- **Einmal gemacht, nie aktualisiert.** Wird jemand krank, kommt ein Projekt herein oder verschieben sich Prioritäten, muss die Kapazität neu berechnet werden. Capacity Planning ist ein laufender Prozess im Operating Rhythm.
- **Verfügbarkeit überspringen.** Der häufigste Auslöser für Planungsfehler.
- **Über 70 bis 80 Prozent verplanen.** Wer ungeplante Arbeit nicht einkalkuliert, hat keinen realistischen Plan.
- **Uneinheitliche Maßeinheiten.** Dann sind Pläne zwischen Teams nicht vergleichbar.
- **Optimismus der Planungsphase.** Planning Fallacy: Schätzungen gegen die Erfahrung prüfen.

## Ergebnis

Vorlage: `templates/capacity-plan.md`.

```markdown
# Capacity Plan: [Team] · [Zeitraum]
Stand: [Datum] · Detailgrad: Initiative / Feature / Task · Einheit: …

## Verfügbarkeit
| Person / Rolle | Verfügbar brutto | Ferien / Feiertage | Teilzeit | Onboarding | Verfügbar netto |
|---|---|---|---|---|---|
| … | | | | | |
| **Summe** | | | | | |

**Planbare Kapazität (70 bis 80 Prozent von netto):** …
**Puffer für ungeplante Arbeit:** …

## Eingeplante Arbeit
| Initiative | Aufwand | Zieldatum | Verantwortlich |
|---|---|---|---|
| … | | | |
| **Summe** | | | |

**Nicht eingeplant (passt nicht in die Kapazität):** …

## Szenarien
| Szenario | Auswirkung | Reaktion |
|---|---|---|
| Ausfall einer Person | … | … |
| Neue Initiative | … | … |

**Nächste Aktualisierung:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Ist die Verfügbarkeit pro Person mit Ferien, Feiertagen, Teilzeit und Onboarding geklärt?
- Liegt die eingeplante Arbeit bei höchstens 70 bis 80 Prozent der verfügbaren Kapazität?
- Nutzen alle beteiligten Teams dieselbe Maßeinheit und denselben Zeitraum?
- Habt ihr mindestens ein Ausfall- und ein Zusatzszenario durchgespielt?
- Ist festgelegt, wann und bei welchem Anlass die Kapazität neu berechnet wird?

## Im Flywheel

Modul SHIP, Bereich S2 Plan & Prioritize.

Verwandte Skills:
- `commitment-ceremony`: Capacity Planning macht die Kapazität sichtbar, bevor Commitments eingegangen werden. In der Ceremony wird gefragt, ob Ressourcen vorhanden und ungeplante Arbeit eingeplant ist.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S2 Plan & Prioritize, Abschnitt Ungeplante Arbeit ist Teil des Plans und Abschnitt Capacity Planning (Abb. 5.9).
