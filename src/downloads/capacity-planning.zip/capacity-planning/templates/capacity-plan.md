# Capacity Planning in sechs Schritten

Nach Abb. 5.9 im Drive Leadership Playbook.

**Team:**
**Datum:**

## Step 1: Detailgrad festlegen
Initiative / Feature / Task:

## Step 2: Maßeinheit wählen
Personentage / Stunden / Story Points / Kosten (für alle Teams gleich):

## Step 3: Zeitraum definieren
Halbjahr / Quartal / Sprint:

## Step 4: Verfügbarkeit klären

| Person / Rolle | Verfügbar brutto | Ferien | Feiertage | Teilzeit | Onboarding | Verfügbar netto |
|---|---|---|---|---|---|---|
| | | | | | | |
| **Summe** | | | | | | |

## Step 5: Arbeit einplanen
Planbare Kapazität (max. 70 bis 80 Prozent von netto):
Puffer für ungeplante Arbeit:

| Initiative | Aufwand | Zieldatum | Ressourcen / Verantwortlich | Priorität |
|---|---|---|---|---|
| | | | | |
| **Summe** | | | | |

## Step 6: Szenarien vergleichen
(gleicher Zeitraum wie Step 3)

| Szenario | Auswirkung auf die Kapazität | Alternative |
|---|---|---|
| Ein Teammitglied fällt aus | | |
| Eine neue Initiative kommt hinzu | | |
| | | |
