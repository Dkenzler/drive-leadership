---
name: calendar-review
description: Kalender nach Impact und Energie auswerten mit dem Calendar Review nach Claire Hughes Johnson (Scaling People), ergänzt um Varianten von Matt Mochary und Design Dept., aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand sich ausgelaugt fühlt, den Kalender entrümpeln, Meetings streichen oder delegieren, Fokuszeit schaffen oder verstehen will, welche Termine Energie geben und welche kosten. Führt durch den quartalsweisen Review der letzten vier Wochen, ordnet jeden Termin in die Matrix Impact gegen Energie ein (schützen und ausbauen, bewusst dosieren, umgestalten, streichen oder delegieren) und endet mit konkreten Kalenderänderungen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 2 Dich im Alltag steuern
  origin: Claire Hughes Johnson, mit Varianten von Matt Mochary und Design Dept. (Mia Blume)
  deep_dive: false
  version: "1.0"
---

# Calendar Review: Impact und Energie

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Claire Hughes Johnson, mit Varianten von Matt Mochary und Design Dept.

## Worum es geht

Dein Kalender ist eine der ehrlichsten Aussagen darüber, wie du führst. Nicht, was du sagst oder was du priorisierst, sondern womit du tatsächlich Zeit verbringst. Der Calendar Review prüft jeden Termin auf zwei Fragen: Hat er auf deine Ziele eingezahlt (Impact)? Und hat er dir Energie gegeben oder gekostet?

Aus den beiden Achsen entsteht eine Matrix mit vier Feldern, die für jeden Termin eine klare Handlungsoption liefert. Die meisten Führungskräfte optimieren ihre Zeit, seltener ihre Energie. Ein voller Kalender mit effizienten Meetings kann dich trotzdem leer und erschöpft zurücklassen. Ein weniger voller Kalender mit den richtigen Momenten gibt dir mehr Kapazität als zwölf Stunden ununterbrochene Reaktionsarbeit.

Das Buch nennt drei Varianten, die sich kombinieren lassen:

- **Claire Hughes Johnson (»Scaling People«):** Einmal im Quartal den Kalender durchgehen und für jeden Termin die zwei Fragen stellen.
- **Matt Mochary (»The Great CEO Within«):** Zwei Wochen lang am Ende jeder Stunde markieren, ob du mehr oder weniger Energie hast als vorher. Grün für mehr, rot für weniger. Für jede rote Aktivität gibt es drei Optionen: streichen, delegieren oder so gestalten, dass sie nicht mehr Energie kostet.
- **Design Dept. (Mia Blume):** Die Termine der letzten zwei Wochen durchgehen, in einem Zeitraum, der für eine normale Arbeitswoche repräsentativ ist. Jedes Meeting wird markiert: gibt Energie, zieht Energie oder neutral. Entscheidend ist, jeweils das »Warum« dazuzuschreiben.

## Wann du sie einsetzt

- Einmal pro Quartal als fester Review, 30 Minuten.
- Wenn du merkst, dass dein Kalender voll ist, aber Energie oder Wirkung fehlen.
- Wenn du verstehen willst, wie sich deine Energie über den Tag verteilt, um deine Tage bewusster zu strukturieren.
- Drei Monate nach dem letzten Review, um zu prüfen, ob sich Muster verändert haben.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Rolle hat die Person? Hat sie Zugriff auf die letzten vier Wochen ihres Kalenders (oder will sie die Stunden-Variante nach Matt Mochary erst zwei Wochen lang sammeln)? Gibt es einen konkreten Anlass, etwa Erschöpfung oder fehlende Fokuszeit? Frag nichts, was sie schon gesagt hat.
- Bitte die Person, ihre Termine als Liste einzufügen (Titel, Dauer, Häufigkeit reicht). Arbeite mit dieser Liste. Erfinde keine Termine.
- Geh Termin für Termin oder in Blöcken gleichartiger Termine vor. Pro Termin: Impact hoch oder niedrig? Energie gibt, kostet oder neutral? Warum?
- Bestehe auf dem »Warum«. Laut Buch ist es entscheidend, es jeweils dazuzuschreiben.
- Challenge jede Einordnung gegen »Worauf du achten musst«. Benenne direkt, wenn ein Termin geschont wird. Kein Lob als Füllmaterial.
- Frag zum Schluss nach dem, was fehlt, und leite aus der Matrix konkrete Änderungen ab.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Zeitraum festlegen.** Die letzten vier Wochen (Quartals-Review nach Hughes Johnson) oder zwei repräsentative Wochen (Design Dept.). Frage: *»Welcher Zeitraum steht für eine normale Arbeitswoche, ohne Urlaub, Offsite oder Sonderlage?«* Gut ist ein Zeitraum, der den Alltag abbildet.

2. **Jeden Termin bewerten.** Für jeden Termin die zwei Fragen von Claire Hughes Johnson: *»Hat dieser Termin auf deine Ziele eingezahlt?«* und *»Hat er dir Energie gegeben oder gekostet?«* Dazu das Warum in einem Satz. Gut ist eine Antwort, die konkret sagt, was Energie gibt oder zieht (Format, Menschen, Thema, Uhrzeit).

3. **In die Matrix einordnen.** Nach Abb. 6.5:

   | | Energie gibt | Energie kostet |
   |---|---|---|
   | **Impact hoch** | Schützen und ausbauen: mehr davon einplanen | Umgestalten: wichtig, aber anstrengend, Format ändern |
   | **Impact niedrig** | Bewusst dosieren: angenehm, aber wenig Impact, Zeit im Blick behalten | Streichen, delegieren: oder asynchron lösen |

   Energieneutrale Termine wie Status-Updates liegen in der Mitte: kurz halten und die Agenda strikt einhalten.

4. **Handlungsoption je Feld ableiten.**
   - Hoher Impact, gibt Energie: schützen und ausbauen. Das ist, wovon du mehr brauchst.
   - Wenig Impact, kostet Energie: das Erste, was du streichst, delegierst oder asynchron löst.
   - Gibt Energie, wenig Impact: bewusst dosieren und die Zeit im Blick behalten.
   - Hoher Impact, kostet Energie: selten streichbar. Das Format so umgestalten, dass es weniger zieht.

   Frage: *»Was genau änderst du an diesem Termin?«* Gut ist eine Antwort, die im Kalender sichtbar wird.

5. **Was fehlt?** Frage: *»Was fehlt komplett in deinem Kalender? Deep Work, also ungestörte Fokuszeit für wichtige Projekte? Reflexionszeit? Gespräche mit Menschen, die dich inspirieren?«* Diese Termine verschwinden zuerst, wenn der Kalender voll wird. Sie sollten die letzten sein, die gestrichen werden.

6. **Veränderungen einplanen.** Aktiv im Kalender umsetzen. Beispiele aus dem Buch: ein wöchentliches Recurring Meeting streichen, den Freitagvormittag als fokussierte Arbeitszeit blocken, eine monatliche Lunchverabredung mit jemandem einplanen, dessen Perspektiven dich bereichern.

7. **Wiederholen.** Den Review in drei Monaten erneut machen. Hat sich etwas verändert? Sind die Muster anders? Hast du Energie gewonnen oder verloren?

## Beispiel

Dominik Kenzler bekam in einem Leadership Coaching die Aufgabe, alle Termine in seinem Kalender durchzugehen und zu markieren, welche Meetings Energie kosten und welche Energie geben, jeweils mit dem Warum. Das veränderte zwei Dinge: Er verstand besser, wie sich seine Energie über den Tag verteilt, und er begann, seinen Kalender bewusst danach zu strukturieren.

## Worauf du achten musst

- **Nur Zeit optimieren.** Effiziente Meetings allein lösen das Problem nicht. Die Frage ist, ob der Termin Energie gibt oder kostet.
- **Einordnung ohne Warum.** Entscheidend ist, jeweils das »Warum« dazuzuschreiben.
- **Nicht repräsentativer Zeitraum.** Eine Ausnahmewoche verzerrt die Muster.
- **Anstrengende Termine mit hohem Impact streichen wollen.** Die lassen sich selten streichen. Hier hilft das Format, nicht der Rotstift.
- **Nur auf Vorhandenes schauen.** Was fehlt (Deep Work, Reflexionszeit, inspirierende Gespräche), verschwindet zuerst, wenn der Kalender voll wird. Es sollte als Letztes gestrichen werden.
- **Erkenntnisse ohne Kalenderänderung.** Der Review wirkt erst, wenn du aktiv Veränderungen einplanst.
- **Einmalig bleiben.** Ohne Wiederholung nach drei Monaten weißt du nicht, ob sich etwas verändert hat.

## Ergebnis

Vorlage: `templates/calendar-review-matrix.md`.

```markdown
# Calendar Review: [Name]
Zeitraum: [von] bis [bis] · Datum Review: [Datum] · Nächster Review: [Datum + 3 Monate]

| Termin | Häufigkeit / Dauer | Impact (hoch/niedrig) | Energie (gibt/neutral/kostet) | Warum | Feld |
|---|---|---|---|---|---|

**Schützen und ausbauen:** …
**Bewusst dosieren:** …
**Umgestalten (neues Format):** …
**Streichen, delegieren, asynchron lösen:** …
**Neutral (kurz halten, Agenda strikt):** …

**Was fehlt im Kalender:** …

**Konkrete Änderungen:**
1. …
2. …
3. …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Steht bei jedem Termin ein Warum, nicht nur eine Farbe?
- Hast du für jedes Feld der Matrix mindestens eine konkrete Handlung abgeleitet?
- Hast du für anstrengende Termine mit hohem Impact ein neues Format gefunden, statt sie zu streichen?
- Hast du benannt, was in deinem Kalender fehlt, und dafür Zeit geblockt?
- Steht der nächste Review in drei Monaten im Kalender?

## Im Flywheel

Modul YOURSELF, Teil 2 Dich im Alltag steuern. Gehört zur Grundthese »Manage deine Energie«.

Verwandte Skills:
- `walk-and-talk`: laut Buch eine der konkretesten Antworten auf den Quadranten »Umgestalten«.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Grundthese »Manage deine Energie« und Methode Calendar Review: Impact und Energie (Abb. 6.5). Originalquellen: Claire Hughes Johnson: Scaling People. Matt Mochary: The Great CEO Within. Workshop von Design Dept. (gegründet 2015 von Mia Blume).

Original: Claire Hughes Johnson: Scaling People. Tactics for Management and Company Building, Stripe Press, 2023. Matt Mochary: The Great CEO Within, 2019. Design Dept.: https://www.designdept.co
