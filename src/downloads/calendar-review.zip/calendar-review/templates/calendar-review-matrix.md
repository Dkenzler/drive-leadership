# Calendar Review-Matrix: Impact gegen Energie

Nach Abb. 6.5 im Drive Leadership Playbook. Zwei Fragen nach Claire Hughes Johnson: Hat der Termin auf meine Ziele eingezahlt (Impact)? Hat er mir Energie gegeben oder gekostet?

**Name:**
**Zeitraum (letzte vier Wochen oder zwei repräsentative Wochen):**
**Datum Review:**
**Nächster Review (in drei Monaten):**

## Termine

| Termin | Impact (hoch/niedrig) | Energie (gibt/neutral/kostet) | Warum |
|---|---|---|---|
| | | | |

## Matrix

| | Energie gibt | Energie kostet |
|---|---|---|
| **Impact hoch** | **SCHÜTZEN UND AUSBAUEN** Hoher Impact, gibt Energie. Mehr davon einplanen. | **UMGESTALTEN** Wichtig, aber anstrengend. Format ändern. |
| **Impact niedrig** | **BEWUSST DOSIEREN** Angenehm, aber wenig Impact. Zeit im Blick behalten. | **STREICHEN, DELEGIEREN** Wenig Impact, kostet Energie. Oder asynchron lösen. |

Energieneutrale Termine (z. B. Status-Updates): kurz halten, Agenda strikt einhalten.

### Schützen und ausbauen

### Bewusst dosieren

### Umgestalten

### Streichen, delegieren

### Neutral

## Was fehlt komplett in meinem Kalender?

- [ ] Deep Work (ungestörte Fokuszeit für wichtige Projekte):
- [ ] Reflexionszeit:
- [ ] Gespräche mit Menschen, die mich inspirieren:

## Geplante Veränderungen

| Veränderung | Ab wann |
|---|---|
| | |

## Beim nächsten Review

- Hat sich etwas verändert?
- Sind die Muster anders?
- Habe ich Energie gewonnen oder verloren?
