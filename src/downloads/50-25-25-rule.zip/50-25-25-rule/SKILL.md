---
name: 50-25-25-rule
description: Präsentationen, Reden und Ansprachen vorbereiten mit der 50-25-25 Rule von Terry Szuplat (Redenschreiber von Barack Obama, »Say It Well«), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Strategie- oder Visionspräsentation, ein All-Hands, eine Keynote, einen Pitch oder einen Toast vorbereiten muss, nicht weiß, wie er die verfügbare Zeit aufteilen soll, zu früh mit Slides anfängt oder regelmäßig zu wenig übt. Teilt die Vorbereitungszeit in 50 Prozent Denken, Recherche und Strukturieren, 25 Prozent Schreiben und 25 Prozent Überarbeiten und Üben und führt durch jede Phase.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D5 Communicate Direction
  origin: Terry Szuplat
  deep_dive: false
  version: "1.0"
---

# 50-25-25 Rule

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Terry Szuplat.

## Worum es geht

In Leadership-Rollen kommunizierst du regelmäßig an größere Gruppen, oft mit Präsentationen. Terry Szuplat, langjähriger Redenschreiber von Barack Obama, beschreibt in »Say It Well« eine einfache Aufteilung der Vorbereitungszeit:

- **50 Prozent** für Denken, Recherche und Strukturieren.
- **25 Prozent** für das eigentliche Schreiben.
- **25 Prozent** für Überarbeiten und Üben.

Das Prinzip funktioniert unabhängig vom Zeithorizont. Die meisten Menschen starten zu früh mit dem Schreiben oder den Slides, tippen drauflos und hoffen, dass sich die Struktur von selbst ergibt. Nach ein paar Absätzen stecken sie fest. Szuplat vergleicht das mit einer Autofahrt ohne Ziel. Die 50 Prozent am Anfang verhindern genau das.

Dahinter steht Szuplats Kernaussage: Jede Rede ist eine Performance, ob man will oder nicht. Das Publikum hat kein Skript in der Hand und kann nicht zurückblättern. Jeder Satz muss absolut klar sein. Wer akzeptiert, dass Sprechen vor Menschen eine Performance ist, gewinnt Kontrolle. Es geht nicht darum, laut oder charismatisch zu sein, sondern vorbereitet zu sein, jedes Wort bewusst zu wählen und die eigene Stimme zu finden.

## Wann du sie einsetzt

- Vor jeder Präsentation an eine größere Gruppe: Team, Bereich, Organisation.
- Bei Strategie- und Visionspräsentationen, die mit Überzeugung ankommen müssen.
- Unabhängig von der verfügbaren Zeit: ein Monat, eine Woche oder ein Toast am selben Abend.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Worum geht es in der Präsentation, und vor wem? Wann ist der Termin, und wie viel Vorbereitungszeit bleibt realistisch? Gibt es schon Material (Notizen, Entwurf, Slides)? Frag nichts, was die Person schon gesagt hat.
- Rechne die Zeit sofort in die drei Phasen um und schlage konkrete Kalenderblöcke vor.
- Geh die Phasen der Reihe nach durch. Eine Frage pro Schritt, dann auf die Antwort warten. Hat die Person schon Material, ordne es der passenden Phase zu und prüfe, ob die Denkphase wirklich abgeschlossen ist.
- Challenge gegen »Worauf du achten musst«. Vor allem: Will die Person schreiben oder Slides bauen, bevor Kernbotschaft und Struktur stehen, halte sie an.
- Für die Denkphase biete das Presentation Strategy Worksheet als Struktur an (Skill `presentation-strategy-worksheet`).
- Du schreibst keine Rede ins Blaue. Inhalte, Zahlen und Aussagen kommen von der Person. Fehlt etwas, markiere es als offen.
- Schließe mit dem Plan im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Zeit aufteilen.** Verfügbare Vorbereitungszeit bestimmen und im Verhältnis 50-25-25 aufteilen. Beispiele aus dem Buch: Ein Monat bedeutet zwei Wochen Denken, eine Woche Schreiben, eine Woche Überarbeiten. Eine Woche bedeutet drei Tage, zwei Tage, zwei Tage. Ein Toast am selben Abend bedeutet eine Stunde Nachdenken, 30 Minuten Schreiben, 30 Minuten Üben.
   Frage: *»Wie viel Zeit hast du bis zum Auftritt, und wann kannst du dir die drei Blöcke im Kalender freihalten?«* Gut ist die Antwort, wenn alle drei Blöcke tatsächlich geblockt sind, auch der letzte.

2. **Denken, Recherche, Strukturieren (50 Prozent).** Die entscheidenden Fragen klären, bevor ein Satz geschrieben wird. Notizen machen ist erlaubt und sinnvoll.
   Fragen: *»Was ist die Kernbotschaft? Was soll das Publikum mitnehmen? Welche Struktur trägt die Argumentation?«* Gut ist die Antwort, wenn die Kernbotschaft in einem Satz steht und die Struktur feststeht. Solange eine der drei Fragen offen ist, bleibt die Person in dieser Phase.

3. **Schreiben (25 Prozent).** Jetzt erst den Text oder die Slides erstellen. Mit geklärter Kernbotschaft und Struktur wird das Schreiben deutlich schneller und zielgerichteter.
   Frage: *»Zahlt jeder Teil deines Entwurfs auf die Kernbotschaft ein?«* Gut ist die Antwort, wenn die Person jeden Abschnitt einer Stelle ihrer Struktur zuordnen kann.

4. **Überarbeiten und Üben (25 Prozent).** Laut üben, nicht nur im Kopf. Die Präsentation mehrmals komplett durchgehen, bevor sie gehalten wird. Früh mit dem Proben anfangen: Laut Ken Kocienda begann Steve Jobs damit lange, bevor alles fertig war, und baute den Talk Stück für Stück auf.
   Frage: *»Wie oft hast du die Präsentation komplett und laut durchgesprochen?«* Gut ist die Antwort, wenn es mehrere vollständige, laute Durchläufe gab.

## Beispiel

Dominik Kenzler beschreibt sich als eher introvertierten Leader, der auf der Bühne Dinge relativierte und Strategien als Option präsentierte. Diese Präsentationen hatten kaum Wirkung. Das Gegenbild ist Daniel Haver, Gründer und CEO von Native Instruments: Er bereitete sich auf jede Präsentation akribisch vor, jedes Wort hatte Bedeutung, und er meinte zu 100 Prozent, was er sagte. Für introvertierte Leader war Szuplats Blick auf Präsentationen als Performance ein wichtiger Perspektivwechsel: Wirkung kommt aus Vorbereitung, nicht aus Lautstärke.

## Worauf du achten musst

- **Zu früh schreiben.** Dokument öffnen, drauflos tippen und auf Struktur hoffen. Führt zum Feststecken nach ein paar Absätzen.
- **Das Üben vernachlässigen.** Gerade Leader lassen die Zeit fürs Üben oft weg. Das mindert den Impact erheblich. Die 25 Prozent am Ende sind keine Option, sie sind der Unterschied zwischen Information und Impact.
- **Halbherzig vortragen.** Viele gute Präsentationen verlieren ihren Punch, weil die Überzeugung fehlt, obwohl Inhalt und Struktur stimmen. Visionen sind keine Optionen: kein Work-in-Progress, kein Mal-Schauen. Sag es mit Überzeugung.
- **Nervosität falsch deuten.** Unsicherheit auf der Bühne kommt selten vom Moment selbst, sondern vom Wissen, dass die Vorbereitung nicht optimal war.

## Ergebnis

```markdown
# Vorbereitungsplan: [Titel der Präsentation]
Termin: [Datum, Uhrzeit] · Publikum: [wer] · Verfügbare Zeit: [gesamt]

| Phase | Anteil | Zeitraum / Kalenderblock | Ergebnis der Phase |
|---|---|---|---|
| Denken, Recherche, Strukturieren | 50 % | … | Kernbotschaft und Struktur stehen |
| Schreiben | 25 % | … | Vollständiger Entwurf (Text oder Slides) |
| Überarbeiten und Üben | 25 % | … | Mehrere laute Komplettdurchläufe |

**Kernbotschaft (ein Satz):** …
**Was das Publikum mitnehmen soll:** …
**Tragende Struktur:** 1. … 2. … 3. …
**Offene Punkte:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Steht die Kernbotschaft in einem Satz, bevor du mit Text oder Slides beginnst?
- Hast du die Hälfte der Zeit für Denken, Recherche und Strukturieren reserviert?
- Sind die 25 Prozent für Überarbeiten und Üben fest im Kalender geblockt?
- Hast du die Präsentation mehrmals komplett und laut durchgesprochen?
- Trägst du die Richtung als klare Aussage vor, nicht als Option?

## Im Flywheel

Modul DRIVE, Bereich D5 Communicate Direction.

Verwandte Skills:
- `presentation-strategy-worksheet`: Laut Buch besonders nützlich als Struktur für die Denkzeit der 50-25-25 Rule.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D5 Communicate Direction. Originalquelle: Terry Szuplat: Say It Well.
Original: Terry Szuplat: Say It Well. Find Your Voice, Speak Your Mind, Inspire Any Audience, Harper Business, 2024. https://www.terryszuplat.com
