---
name: mut-zu-entscheidungen
description: "Zögern überwinden und mutiger entscheiden mit der Methode Mut zu Entscheidungen aus dem Drive Leadership Playbook von Dominik Kenzler, mit Bezug auf Ben Horowitz, Raaz Herzberg und Jeff Bezos. Nutze diesen Skill, wenn jemand eine Entscheidung seit Tagen oder Wochen vor sich herschiebt, ein unbequemes Gespräch vertagt, auf mehr Informationen wartet, Angst vor Fehlern, Konsequenzen oder Konflikten hat oder vom inneren Kritiker blockiert wird. Führt durch vier Schritte: Zögern benennen, Frist setzen, reversibel oder irreversibel unterscheiden, mit rund 70 Prozent Informationen entscheiden."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 2 Dich im Alltag steuern
  origin: Dominik Kenzler, mit Bezug auf Ben Horowitz, Raaz Herzberg und Jeff Bezos
  deep_dive: false
  version: "1.0"
---

# Mut zu Entscheidungen

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, mit Bezug auf Ben Horowitz, Raaz Herzberg und Jeff Bezos.

## Worum es geht

Leadership bedeutet, regelmäßig in Situationen zu sein, in denen es keine perfekte Antwort gibt: zwei schlechte Optionen, unvollständige Informationen, Zeitdruck, Menschen, die auf dich schauen. In diesen Momenten entscheidet nicht dein Wissen, sondern dein Mut.

Ben Horowitz: »Der schlimmste Fehler, den du als Leader machen kannst, ist Zögern. Das ist in der Regel das Destruktivste.« Nicht die falsche Entscheidung richtet den größten Schaden an, sondern die ausgebliebene. Teams spüren, wenn ihre Führungskraft einem schwierigen Thema ausweicht. Das Vertrauen erodiert, bevor jemand das Wort Entscheidung ausgesprochen hat.

Zögern hat fast immer einen von drei Gründen: Angst vor der falschen Entscheidung (Perfektionismus, das Warten auf 90 Prozent Datenlage, die nie kommt), Angst vor Konsequenzen (wenn es schiefgeht, werde ich verantwortlich gemacht) und Angst vor dem Konflikt, den eine klare Entscheidung erzeugt. Alle drei machen die Entscheidung zu einer Aussage über dich selbst. Eine Entscheidung ist aber keine Aussage über deinen Wert als Führungskraft. Sie ist eine Hypothese, was in einem bestimmten Moment mit den verfügbaren Informationen richtig ist.

Mut ist keine Abwesenheit von Angst, sondern die Bereitschaft, trotzdem zu handeln. Raaz Herzberg (Wiz) beschreibt es als Akzeptanz des möglichen Scheiterns: »Ich bin mir ziemlich sicher, dass ich scheitern könnte, und tue es trotzdem.« Das entkoppelt das Handeln vom Selbstwert. Wer sich die Erlaubnis gibt zu scheitern, kann entscheiden.

## Wann du sie einsetzt

- Wenn du merkst, dass du ein Thema umgehst, ein Gespräch verschiebst oder eine Entscheidung vertagst.
- Wenn eine Entscheidung seit Wochen auf deinem Tisch liegt.
- Wenn du auf mehr Informationen wartest, obwohl die vorhandenen reichen könnten.
- Wenn der innere Kritiker fragt: War es die richtige Entscheidung? Was passiert, wenn sie falsch war?

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welche Entscheidung geht es? Seit wann liegt sie? Wer ist betroffen? Frag nichts, was die Person schon gesagt hat.
- Geh die vier Schritte nacheinander durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Du triffst die Entscheidung nicht. Du hilfst der Person, das Zögern zu benennen und zu einer Entscheidung mit Frist zu kommen. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Challenge Antworten gegen »Worauf du achten musst«. Benenne direkt, wenn die Person noch mehr Informationen sammeln will, obwohl sie genug hat.
- Erfinde keine Fakten zur Situation. Fehlende Informationen markierst du als offen und fragst, ob sie für die Entscheidung wirklich nötig sind.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Zögern benennen.** Frage: *»Was genau hält dich zurück?«* Ordne die Antwort einem der drei Gründe zu: Angst vor der falschen Entscheidung, Angst vor Konsequenzen, Angst vor dem Konflikt. Oft reicht es, das zu benennen, um den Impuls zu durchbrechen. Gut ist eine Antwort, die den Grund konkret ausspricht, etwa »Ich will Person X nicht enttäuschen«.

2. **Frist setzen.** Horowitz hat als CEO schwierige Entscheidungen in Meetings erzwungen: »Wir verlassen diesen Raum nicht, bevor wir entschieden haben.« Die alltägliche Version: Eine Entscheidung, die du seit zwei Wochen vor dir herschiebst, bekommt heute eine Frist. Übermorgen. Nicht nächste Woche.
   Frage: *»Bis wann entscheidest du, konkret mit Datum?«* Gut ist ein Datum in den nächsten Tagen.

3. **Reversibel oder irreversibel?** Aus dem Kapitel Make Fast Decisions: Two-Way-Doors können schnell und kühn getroffen werden. Eine reversible Entscheidung ist kein Risiko, sondern ein Experiment. Behandle sie so. Viele Entscheidungen, die sich wie große Risiken anfühlen, sind reversibler als gedacht.
   Frage: *»Was passiert, wenn du dich falsch entscheidest? Kannst du es zurückdrehen, und was kostet das?«*

4. **Mit Ungewissheit entscheiden.** Jeff Bezos: 70 Prozent der Informationen reichen für die meisten Entscheidungen. Wer auf 90 Prozent wartet, wartet zu lange. Die restlichen 20 Prozent kosten unverhältnismäßig viel Zeit und verändern die Entscheidung meist kaum.
   Frage: *»Welche Information fehlt dir noch, und würde sie die Entscheidung wirklich ändern?«* Gut ist eine Antwort, die zeigt, dass die fehlende Information die Richtung nicht dreht.

5. **Entscheiden und als Hypothese formulieren.** Frage: *»Wie lautet deine Entscheidung, und was müsste passieren, damit du sie später korrigierst?«*

## Beispiel

Als Dominik Kenzler am Redesign von sevdesk arbeitete und ins Zweifeln kam, half ihm ein Anti-Pattern. Elon Musk benannte Twitter über Nacht in X um, aus Dominiks Sicht eine markenstrategische Katastrophe. Die monatlich aktiven Nutzer gingen anfangs zurück, aber die Plattform lief weiter und erholte sich. Wenn eine Organisation so eine Entscheidung übersteht, dann sind die Veränderungen eines Redesigns eher subtil und das Risiko nicht so groß. Mit diesem Gedanken brachte er seinen inneren Kritiker zum Schweigen.

## Worauf du achten musst

- **Die Entscheidung zur Aussage über dich machen.** Eine Entscheidung ist eine Hypothese mit den verfügbaren Informationen, kein Urteil über deinen Wert.
- **Auf 90 Prozent warten.** Die Datenlage, die alle Zweifel ausräumt, kommt nie.
- **Reversible Entscheidungen wie irreversible behandeln.** Two-Way-Doors sind Experimente, keine Risiken.
- **Keine Frist.** Eine Entscheidung, die du seit zwei Wochen vor dir herschiebst, braucht heute eine Frist. Übermorgen, nicht nächste Woche.
- **Konflikt hinausschieben.** Wer eine Entscheidung vermeidet, um niemanden unglücklich zu machen, verschiebt den Konflikt nur und verliert Vertrauen.
- **Mut mit Überstürzen verwechseln.** Es geht nicht um überstürztes Handeln, sondern um einen Standard: Entscheidungen auf Basis der verfügbaren Informationen, nicht auf Basis von Gewissheit, die es nie gibt.

## Ergebnis

```markdown
# Entscheidung: [Thema]
Stand: [Datum] · Liegt seit: [Zeitraum]

**Was mich zurückhält:** Angst vor falscher Entscheidung / vor Konsequenzen / vor Konflikt, konkret: …
**Frist:** [Datum]
**Reversibel?** ja / nein · Kosten einer Korrektur: …
**Vorhandene Informationen:** …
**Fehlende Informationen, und ob sie die Entscheidung ändern würden:** …

**Entscheidung (als Hypothese):** …
**Korrigiere ich, wenn:** …
**Wem ich sie bis wann kommuniziere:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Hast du benannt, welcher der drei Gründe dich zögern lässt?
- Hat die Entscheidung eine Frist in den nächsten Tagen?
- Hast du geprüft, ob die Entscheidung reversibel ist, und sie dann als Experiment behandelt?
- Würde die fehlende Information die Entscheidung wirklich ändern?
- Was zeigt dein Entscheidungsverhalten deinem Team darüber, was erlaubt ist?

## Im Flywheel

Modul YOURSELF, Teil 2 Dich im Alltag steuern. Gehört zur Grundthese »Habe den Mut, voranzugehen«. Als Leader modellierst du, was in deiner Organisation erlaubt ist: Wenn du zögerst, zögert das Team ebenfalls.

Verwandte Skills:
- `one-way-two-way-door`: Das Buch verweist auf die Unterscheidung reversibler und irreversibler Entscheidungen aus SHIP, S4 Make Fast Decisions.
- `timely-decisions`: Das Kapitel Make Fast Decisions beschreibt verschiedene Arten von Entscheidungen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Grundthese »Habe den Mut, voranzugehen« und Methode Mut zu Entscheidungen. Zitierte Quellen: Ben Horowitz (The Hard Thing About Hard Things), Raaz Herzberg (Wiz), Jeff Bezos.
