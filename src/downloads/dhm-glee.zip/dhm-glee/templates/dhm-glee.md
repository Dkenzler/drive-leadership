# DHM & GLEe

Nach dem Abschnitt DHM & GLEe und Abb. 3.6 (DHM Framework, frühes Beispiel von Netflix, Gibson Biddle) im Drive Leadership Playbook.

**Produkt:**
**Stand:**
**Beteiligte:**

## GLEe

Jede Phase dauert typischerweise drei bis fünf Jahre und ermöglicht erst die nächste.

| Phase | Inhalt | Zeitraum | Voraussetzung für die nächste Phase |
|---|---|---|---|
| **G**et big on (in einer Kategorie groß werden, sie dominieren) | | | |
| **L**ead (einen neuen Bereich anführen) | | | |
| **E**xpand (das Ganze erweitern, skalieren) | | | |

## DHM

Aktuelle Phase:

| Strategy | Delight | Hard to copy | Margin |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

- Delight: Begeistert die Idee die Nutzenden?
- Hard-to-copy: Ist sie schwer zu kopieren?
- Margin-enhancing: Verbessert sie die Marge?

Je mehr Kategorien eine Idee erfüllt, desto höher ihr strategischer Wert.

**Priorität:**
