---
name: dhm-glee
description: Produktstrategie entwickeln mit GLEe (Get big on, Lead, Expand) und DHM (Delight, Hard-to-copy, Margin-enhancing) von Gibson Biddle, ehemals VP Product bei Netflix, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine langfristige Produktvision in aufeinander aufbauende Phasen gliedern, entscheiden will, womit man anfängt, ohne sich zu verzetteln, eine Liste von Ideen oder Initiativen nach strategischem Wert priorisieren oder bestehende Ideen einer Due Diligence unterziehen will.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D2 Strategy
  origin: Gibson Biddle
  deep_dive: false
  version: "1.0"
---

# DHM & GLEe

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Gibson Biddle.

## Worum es geht

Beide Frameworks stammen von Gibson Biddle, dem ehemaligen VP Product bei Netflix. GLEe dient der langfristigen Ausrichtung, DHM der Bewertung konkreter Ideen und Initiativen.

**GLEe** ist ein Phasenmodell für die Formulierung langfristiger Produktvisionen und Ziele:

- **Get big on:** in einer Kategorie groß werden, sie dominieren.
- **Lead:** einen neuen Bereich anführen.
- **Expand:** das Ganze erweitern, skalieren.

Du musst nicht alles gleichzeitig machen. Jede Phase dauert typischerweise drei bis fünf Jahre und ermöglicht erst die nächste. GLEe zwingt zu zwei Dingen: groß denken und sequenziell planen. Es beantwortet die Frage, die nach der Vision offen bleibt: Wie fangen wir an, ohne uns zu verzetteln?

**DHM** hilft bei der nächsten Frage: Welche Initiativen haben innerhalb einer Phase den größten strategischen Wert?

- **Delight:** Begeistert die Idee die Nutzenden?
- **Hard-to-copy:** Ist sie schwer zu kopieren?
- **Margin-enhancing:** Verbessert sie die Marge?

Je mehr Kategorien eine Idee erfüllt, desto höher ihr strategischer Wert.

## Wann du sie einsetzt

- Produktstrategien entwickeln.
- GLEe: eine langfristige Produktvision in Phasen gliedern.
- DHM: eine Liste an Optionen und Ideen nach der Art ihres Impacts kategorisieren und priorisieren.
- DHM: eine Due Diligence bestehender Ideen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welches Produkt geht es? Gibt es schon eine Vision? Will die Person langfristig planen (GLEe), Ideen bewerten (DHM) oder beides? Frag nichts, was sie schon gesagt hat.
- Beide Teile funktionieren einzeln. Mit beidem: erst GLEe, dann DHM für die Initiativen der aktuellen Phase.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ermöglicht jede Phase wirklich die nächste?
- Erfinde keine Fakten über Produkt, Markt oder Zahlen. Bewertungen, die die Person nicht belegen kann, markierst du als Einschätzung.
- Arbeitet die Person mit einem Team, biete an, Ablauf und Moderationsfragen zu erstellen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Teil A: GLEe**

1. **Get big on.** In welcher Kategorie wollt ihr groß werden und sie dominieren?
   Frage: *»In welcher Kategorie könnt ihr groß werden, jetzt, mit dem, was ihr habt?«*
   Gut ist die Antwort, wenn sie eine klar umrissene Kategorie nennt.

2. **Lead.** Welchen neuen Bereich wollt ihr danach anführen?
   Frage: *»Welchen neuen Bereich könnt ihr anführen, sobald ihr in der ersten Kategorie groß seid?«*
   Gut ist die Antwort, wenn klar ist, was aus Phase 1 diesen Schritt erst ermöglicht.

3. **Expand.** Wie erweitert und skaliert ihr das Ganze?
   Frage: *»Wohin erweitert ihr, und was aus den ersten beiden Phasen macht das möglich?«*

4. **Abhängigkeiten prüfen.** Jede Phase dauert typischerweise drei bis fünf Jahre und ist Voraussetzung für die nächste.
   Frage: *»Was bringt jede Phase mit, ohne das die nächste nicht ginge?«*
   Gut ist die Antwort, wenn für jeden Übergang eine konkrete Voraussetzung benannt ist.

**Teil B: DHM**

5. **Ideen sammeln.** Die Optionen und Initiativen für die aktuelle Phase auflisten.
   Frage: *»Welche Ideen und Initiativen liegen für diese Phase auf dem Tisch?«*

6. **Jede Idee bewerten.** Für jede Idee drei Fragen: Begeistert sie die Nutzenden? Ist sie schwer zu kopieren? Verbessert sie die Marge?
   Frage pro Idee: *»Delight, Hard-to-copy, Margin: Welche davon trifft zu, und warum?«*
   Gut ist die Antwort, wenn jedes Ja begründet ist.

7. **Priorisieren.** Je mehr Kategorien eine Idee erfüllt, desto höher ihr strategischer Wert.
   Frage: *»Welche Ideen erfüllen die meisten Kategorien, und welche erfüllen keine?«*

## Beispiel

Netflix aus 2005:

- Get big on DVDs
- Lead streaming
- Expand worldwide

2005 war Streaming technisch kaum möglich, aber die Vision war klar. Netflix konzentrierte sich zunächst auf den DVD-Versand, baute eine Marke auf, erzielte Skaleneffekte und fand seinen Product-Market-Fit. Erst 2007, als die Internetverbindungen schnell genug waren und Netflix das Kapital hatte, startete Streaming. Die globale Expansion begann 2010 und baute auf dem Streaming auf, weil es skalierbarer war als der DVD-Versand. Ab 2012 folgte das nächste Kapitel: Original Content. Erst die globale Reichweite machte milliardenschwere Investitionen in eigene Produktionen rentabel.

Jede Phase war Voraussetzung für die nächste. Ohne DVD-Dominanz kein Kapital für Streaming. Ohne Streaming keine globale Expansion. Ohne globale Nutzerbasis kein Content-Investment.

Abb. 3.6 zeigt ein frühes DHM-Beispiel von Netflix mit den Spalten Strategy, Delight, Hard to copy, Margin. Bewertet werden unter anderem Personalisierung, Streaming, Original Content, Bild- und Tonqualität, DVDs am nächsten Tag, Preise und Pakete, Werbung, Verkauf gebrauchter DVDs, Filmempfehlungen, Social, kostenbasierte Titelauswahl, Entertainment, Open APIs, exklusive DVDs, interaktive Formate und AR/VR.

## Worauf du achten musst

Das Buch nennt keine typischen Fehler. Die Punkte folgen aus der Beschreibung.

- **Alles gleichzeitig wollen.** GLEe lebt davon, sequenziell zu planen.
- **Phasen ohne Abhängigkeit.** Ermöglicht eine Phase die nächste nicht, ist es eine Liste, kein Phasenmodell.
- **Zu klein denken.** GLEe zwingt auch dazu, groß zu denken.
- **DHM ohne Phase.** DHM bewertet Initiativen innerhalb einer Phase. Ohne Phase fehlt der Bezugspunkt.

## Ergebnis

Vorlage: `templates/dhm-glee.md`.

```markdown
# DHM & GLEe: [Produkt]
Stand: [Datum] · Beteiligte: [Namen oder Rollen]

## GLEe
| Phase | Inhalt | Zeitraum | Ermöglicht die nächste Phase durch |
|---|---|---|---|
| Get big on | … | … | … |
| Lead | … | … | … |
| Expand | … | … | … |

## DHM (Phase: …)
| Strategy / Idee | Delight | Hard to copy | Margin | Anzahl |
|---|---|---|---|---|
| … | ja / nein | ja / nein | ja / nein | 0 bis 3 |

**Priorität:** …
**Offen / Einschätzungen, die geprüft werden müssen:** …
```

## Mini-Check

Aus der Drive Checklist (Strategy):
- Beschreibt die Strategie, was euch unterscheidet, und nicht nur, was ihr besser machen wollt?

(abgeleitet aus den typischen Fehlern)
- Ermöglicht jede GLEe-Phase die nächste, und ist die Voraussetzung benannt?
- Wisst ihr, womit ihr jetzt anfangt, und was bewusst später kommt?
- Ist jede DHM-Bewertung begründet?
- Folgt die Priorität aus der Zahl der erfüllten Kategorien?

## Im Flywheel

Modul DRIVE, Bereich D2 Strategy.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D2 Strategy (Abb. 3.6). Originalquelle: Gibson Biddle, Netflix.
Original: Gibson Biddle: The GLEe Model, https://gibsonbiddle.medium.com/6-the-glee-model-6af740bdf3b1, und Gibson Biddle: A Summary of my Product Strategy Frameworks (DHM), https://askgib.substack.com/p/ask-gib-a-summary-of-my-product-strategy
