---
name: ogsm
description: Strategie mit OGSM (Objectives, Goals, Strategies, Measures) auf einer Seite planen, aus dem Drive Leadership Playbook von Dominik Kenzler. Methode aus Japan, von Procter & Gamble standardisiert. Nutze diesen Skill, wenn jemand aus einer strategischen Richtung einen einseitigen Plan machen, Jahresstrategie in Goals, Strategies, Kennzahlen und Aktionen mit Owner übersetzen, einen OGSM von der Unternehmens- auf die Team-Ebene kaskadieren oder einen bestehenden Plan auf eine durchgehende Sichtlinie prüfen will. Auch zur Vorbereitung eines OGSM-Workshops mit der Führungsrunde.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D4 Guiding Principles (Strategic Planning)
  origin: Japan, von Procter & Gamble verfeinert und standardisiert
  deep_dive: true
  version: "1.0"
---

# OGSM

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode aus dem Nachkriegs-Japan, von Procter & Gamble verfeinert und standardisiert.

## Worum es geht

OGSM steht für Objective, Goals, Strategies, Measures. Das Framework fasst die gesamte strategische Planung auf einer einzigen Seite zusammen. Eine Strategie scheitert selten an der Absicht, sondern daran, dass die Ebene der großen Ziele und die Ebene der täglichen Arbeit auseinanderfallen. OGSM verbindet beide.

Die vier Elemente (Abb. 3.15):
- **Objective (Wörter):** Was wir erreichen wollen, qualitativ und richtungsweisend.
- **Goals (Zahlen):** Woran wir das Erreichen messen. Quantitative Meilensteine, finanzielle und operative Leistungskennzahlen.
- **Strategies (Wörter):** Die Entscheidungen, mit denen wir Objective und Goals erreichen. Die großen Hebel.
- **Measures (Zahlen):** Wie der Fortschritt bei jeder Strategy gemessen wird, KPIs mit klarem Owner, dazu die Initiatives: Programme und Maßnahmen, die nötig sind, um die Strategies umzusetzen.

OGSM versucht, auf einer Seite auszudrücken, wofür ein klassischer Geschäftsplan 50 Seiten braucht. Genau diese Beschränkung ist der entscheidende Punkt: Sie zwingt zur Frage, was die wenigen wichtigen Dinge sind und was ihr nicht mehr tun müsst.

OGSM setzt eine strategische Richtung voraus. Woher sie kommt, ist offen: aus einer Strategieentscheidung, einer Analyse oder einem Framework. Der Wert liegt nicht im ausgefüllten Blatt, sondern in der Disziplin, die das eine Blatt erzwingt:

- **Wahl erzwingen.** Es passt nicht alles auf eine Seite. Du musst die Hebel benennen, auf die es ankommt, und ebenso klären, was ihr bewusst nicht verfolgt.
- **Durchgehende Sichtlinie.** Vom langfristigen Anspruch bis zur Kennzahl im wöchentlichen Teamtermin lässt sich jede Zeile auf die darüberliegende zurückführen. Jede Person kann ihre Arbeit bis zum Objective verfolgen.
- **Strategie überprüfbar machen.** OGSM ist kein Zielestapel, sondern eine zusammenhängende Annahme, wie euer Geschäft erfolgreich wird. Die Logik läuft von oben nach unten und als Qualitätsprüfung rückwärts. Bricht ein Glied der Kette, hat der Plan eine Lücke, die vor den Start gehört.

## Wann du sie einsetzt

- Eine strategische Richtung liegt vor und soll in einen Plan übersetzt werden, den jede Ebene lesen kann.
- Jahresstrategieplanung mit klarer Kaskade von der Unternehmens- bis zur Teamebene.
- Wenn Ziele, Strategien und Aktivitäten in getrennten Dokumenten nebeneinanderher leben.
- Einen bestehenden Plan prüfen: Hält die Kette von der Measure bis zum Objective?

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Ebene gilt der OGSM (Unternehmen, Bereich, Team)? Woher kommt die strategische Richtung? Arbeitet die Person allein oder bereitet sie eine Sitzung vor? Frag nichts, was sie schon gesagt hat.
- Fehlt eine strategische Richtung, sag das. OGSM übersetzt eine Richtung, es ersetzt die Strategieentscheidung nicht.
- Bereitet die Person eine Sitzung vor, erstelle Set-up, Ablauf und Moderationsfragen. Plane bei Erstnutzung eine zweite Runde ein. Arbeitet sie allein, geh den Ablauf mit ihr durch und markiere, was mit den Menschen aus der Umsetzung geprüft werden muss.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Steht im Objective eine Zahl? Sind es mehr als fünf Strategies? Misst eine Measure keine Strategy? Benenne das direkt und kurz.
- Erfinde keine Zahlen, Owner oder Termine. Fehlt etwas, markiere es als offen.
- Schließe mit dem OGSM im Format aus »Ergebnis«, lies ihn rückwärts und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**Set-up.** Die Führungsrunde, die für die Strategie verantwortlich ist, idealerweise ergänzt um ein, zwei Personen aus der Umsetzung. Drei bis sechs Personen, die das Vorhaben aus verschiedenen Blickwinkeln kennen, idealerweise Produkt, Technologie und eine kundennahe Rolle. Ein bis zwei Stunden für den ersten Entwurf, danach mindestens eine zweite Runde nach ein paar Tagen Abstand, weil die ersten Goals und Strategies fast immer zu viele und zu vage sind. Material: ein gemeinsames Dokument mit den vier Blöcken, sichtbar für alle, kein Foliendeck. Eine Person moderiert und schreibt mit.

1. **Das Objective formulieren.** Ein Satz, der ausdrückt, wo ihr in drei bis fünf Jahren stehen wollt. Qualitativ, richtungsweisend, eindeutig. Kein Visionspathos, sondern eine Aussage über das Geschäft, an der ihr später ablesen könnt, ob ihr angekommen seid. Ein Objective pro Plan.
   Frage: *»Wo wollt ihr in drei bis fünf Jahren stehen, in einem Satz?«* Gut ist die Antwort, wenn sie keine Zahl enthält und man trotzdem später prüfen kann, ob ihr angekommen seid.

2. **Die Goals ableiten.** Drei bis fünf messbare Ergebnisse, die das Objective in Zahlen übersetzen. SMART, also spezifisch, messbar, erreichbar, relevant und terminiert, oft finanziell codiert, etwa Umsatz, Marge oder Marktanteil im Zielsegment.
   Frage: *»Woran würdet ihr zweifelsfrei sehen, dass das Objective erreicht ist?«* Gut ist die Antwort, wenn jedes Goal eine Zahl mit Termin ist.

3. **Die Strategies wählen.** Die wenigen Entscheidungen, wie ihr die Goals erreicht. Hier liegt die eigentliche Arbeit, denn die Seite zwingt zur Auswahl. Eine gute Strategy basiert auf einer bewussten Wahl, scharf umrissen und in klaren Sätzen formuliert. Prüft, ob sie ein Goal wirklich bewegt. Nett reicht nicht und fliegt raus.
   Frage: *»Mit welchen drei bis fünf Entscheidungen erreicht ihr die Goals, und was lasst ihr dafür bewusst weg?«* Gut ist die Antwort, wenn jede Strategy ein Goal bewegt.

4. **Die Measures festlegen.** Pro Strategy zweierlei: erstens ein, zwei Kennzahlen, an denen ihr laufend seht, ob die Strategy wirkt. Zweitens die konkreten Aktionen, mit denen ihr sie umsetzt, jede mit verantwortlicher Person und Termin. Nehmt Kennzahlen, die ihr kennt. Besser mit einer vertrauten Kennzahl zu 80 % richtig liegen, als für 100 % eine neue zu erfinden, die niemand liest.
   Frage: *»Woran seht ihr laufend, ob diese Strategy wirkt, und wer macht was bis wann?«*

5. **Die Sichtlinie prüfen.** Den Plan rückwärts lesen. Jede Measure: Welche Strategy misst sie? Jede Strategy: Welches Goal stützt sie? Jedes Goal: Bestätigt es das Objective? Wo eine Verbindung fehlt oder doppelt belegt ist, nachschärfen, bis die Kette durchgängig hält. Erst dann ist der Plan fertig.

**Kaskade (optional).** Eine Strategy aus dem OGSM der oberen Ebene wird zum Objective der nächsten. Das Team darunter entwickelt eigene Goals, Strategies und Measures, und seine wichtigsten Kennzahlen tauchen oben als Aktionen wieder auf. So entsteht aus mehreren Seiten ein zusammenhängendes System, ohne dass eine einzelne Seite überladen wird.

## Beispiel

Toyota formulierte als Objective, von der Kundschaft als zuverlässigste und hochwertigste Automarke wahrgenommen zu werden. Das Ziel wurde Stufe um Stufe nach unten übersetzt, bis es in einzelnen Werken als nüchterne Kennzahl ankam: Fehler pro 100 Fahrzeuge, wöchentlich erfasst, dazu Garantiefälle und Anlageneffizienz.

Durchgängiges Beispiel aus dem Buch (Abb. 3.23): ein Anbieter von Projektmanagement-Software für mittelgroße Teams, der sich bereits entschieden hat, auf Digital- und Kreativagenturen zu fokussieren.

- **Objective:** In drei Jahren sind wir das Standard-Projektmanagement-Tool für Digital- und Kreativagenturen im deutschsprachigen Raum, die erste Wahl, wenn eine Agentur ein Tool einführt oder wechselt.
- **Goals:** 1. Jährlich wiederkehrender Umsatz im Agentur-Segment von X auf 3X. 2. Netto-Umsatzbindung über 115 Prozent. 3. Mehr als 500 zahlende Agenturen, die Hälfte über Empfehlung oder Partnerschaft gewonnen.
- **Strategies und Measures:**
  1. Branchentiefe statt Breite (Auslastungsplanung, Zeiterfassung, Kundenfreigaben). Kennzahl: Anteil aktiver Accounts, die agenturspezifische Funktionen nutzen. Aktion: Auslastungsplanung liefern, Product, bis Q3.
  2. Schnelle Time-to-Value mit branchenfertigen Vorlagen. Kennzahlen: Aktivierungsquote in der ersten Woche, Zeit bis zum ersten produktiv genutzten Projekt. Aktion: Vorlagen und geführtes Onboarding, Product und Customer Success, bis Q2.
  3. Wachstum über Agenturnetzwerke. Kennzahlen: Anteil Neukundschaft aus Empfehlung und Partnerschaft, Zahl aktiver Partnerschaften. Aktion: Partnerprogramm mit Agenturverbänden, Marketing und Sales, bis Q4.

Rückwärts gelesen hält die Kette: Die Aktivierungsquote misst Strategy 2, die das Retention Goal stützt, denn wer früh produktiv ist, bleibt und wächst. Das bestätigt das Objective, weil ein Tool, das Agenturen sofort nutzen, zur ersten Wahl wird.

## Worauf du achten musst

- **Objective und Goals verwechseln.** Das Objective ist ausformuliert und gibt die Richtung vor, die Goals stehen in Zahlen. Wer das vermischt, bekommt ein unmessbares Ziel oder eine Zahl ohne Sinn.
- **Zu viele Strategies.** Eine Seite mit zehn Strategien ist eine Aufgabenliste, kein Plan. Drei bis fünf werden bewusst gewählt.
- **Measures, die nichts steuern.** Kennzahlen, die gut aussehen, aber keine Strategy prüfen, kosten nur Aufmerksamkeit.
- **Goals und Measures gleichsetzen.** Goals sagen, ob ihr das Objective erreicht, sie sind das Ergebnis. Measures sagen, ob eure Strategien wirken, sie sind das Frühwarnsystem. Goals schaut man seltener an, Measures laufend.
- **Schreiben und weglegen.** Ein OGSM ist ein lebendes Dokument. Ohne regelmäßigen Blick auf die Measures, am besten im bestehenden Quartalsrhythmus, verkommt er zur Schublade.
- **Reines Top-down.** Wird der Plan ohne die Menschen geschrieben, die ihn umsetzen, fehlt die Bindung. Die Sichtlinie nützt wenig, wenn unten niemand weiß, dass sie existiert.

## Ergebnis

Ein OGSM auf einer Seite, rückwärts geprüft. Vorlage: `templates/ogsm-one-page.md`.

```markdown
# OGSM: [Organisation / Ebene]
Stand: [Datum] · Beteiligte: [Namen oder Rollen] · Quelle der Richtung: …

**Objective (ein Satz, qualitativ, 3 bis 5 Jahre):** …

**Goals (Zahlen, SMART):**
1. …
2. …
3. …

| Strategy (Wörter) | Measures: Kennzahlen | Aktionen (wer, bis wann) | Stützt Goal |
|---|---|---|---|
| 1. … | … | … · … · … | … |
| 2. … | … | … · … · … | … |
| 3. … | … | … · … · … | … |

**Bewusst nicht verfolgt:** …
**Sichtlinie rückwärts geprüft:** ja / Lücke bei …
**Review-Rhythmus der Measures:** …
```

## Mini-Check

- Steht das Objective in einem Satz, qualitativ und richtungsweisend, und gibt es nur eines?
- Sind die Goals Zahlen, SMART und an das Objective gebunden?
- Habt ihr euch auf drei bis fünf Strategies beschränkt, jede als bewusste Wahl?
- Hat jede Strategy mindestens eine Measure und konkrete Aktionen mit verantwortlicher Person und Termin?
- Hält die Sichtlinie rückwärts, von jeder Measure über Strategy und Goal bis zum Objective?
- Passt alles auf eine Seite?

## Im Flywheel

Modul DRIVE, Bereich D4 (im Buch »Guiding Principles«, inhaltlich Strategic Planning).

Verwandte Skills:
- `playing-to-win`: Eine vorher erarbeitete Cascade liefert eine gute Vorlage für Objective und Richtung. Nötig ist sie nicht, OGSM funktioniert mit jeder Quelle für die strategische Richtung.
- `okrs`: OGSM passt zur jährlichen Strategieplanung mit Kaskade, OKRs zu kürzeren, oft quartalsweisen Zyklen mit viel Beteiligung der Teams. Viele nutzen OGSM für die Jahresstrategie und OKRs für die quartalsweise Umsetzung darin.
- `strategic-objectives`: Ein Strategic Objective kann als Objective in einen OGSM einfließen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D4 Guiding Principles, Frameworks für Strategic Planning (Abb. 3.15) und Deep Dive OGSM (Abb. 3.23). Herkunft laut Buch: Japan, von Procter & Gamble verfeinert und standardisiert.

Original: Marc van Eck, Ellen Leenhouts: The One Page Business Strategy, Pearson, 2014 (beide ehemals Procter & Gamble). Die genaue Herkunft der Methode ist nicht belegt.
