# OGSM auf einer Seite

Nach Abb. 3.15 und Abb. 3.23 im Drive Leadership Playbook.

**Organisation / Ebene:**
**Stand:**
**Beteiligte:**
**Quelle der strategischen Richtung:**

## Objective (Wörter)
Was wir erreichen wollen, qualitativ. Ein Satz, drei bis fünf Jahre, ein Objective pro Plan.

## Goals (Zahlen)
Woran wir das Erreichen messen, quantitativ. Finanzielle und operative Leistungskennzahlen, drei bis fünf, SMART.

1.
2.
3.

## Strategies (Wörter) und Measures (Zahlen)
Strategies: die Entscheidungen, mit denen wir Objective und Goals erreichen, drei bis fünf.
Measures: Kennzahlen, wie wir den Fortschritt jeder Strategy messen, und Aktionen (Initiatives), die nötig sind, um die Strategy umzusetzen.

| Strategy | Kennzahlen | Aktionen | Wer | Wann | Stützt Goal |
|---|---|---|---|---|---|
| 1. | | | | | |
| 2. | | | | | |
| 3. | | | | | |

## Sichtlinie rückwärts

| Prüfung | Ergebnis |
|---|---|
| Jede Measure: Welche Strategy misst sie? | |
| Jede Strategy: Welches Goal stützt sie? | |
| Jedes Goal: Bestätigt es das Objective? | |

**Bewusst nicht verfolgt:**
**Review-Rhythmus der Measures:**
