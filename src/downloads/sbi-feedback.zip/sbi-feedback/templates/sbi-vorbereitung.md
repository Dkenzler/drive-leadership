# SBI-Feedback: Vorbereitung

Nach Abb. 4.11 im Drive Leadership Playbook, nach dem Center for Creative Leadership.

**An:**
**Art:** kritisch / positiv
**Wann und wo ansprechen:** (möglichst direkt danach, zehn Minuten reichen)

## S · Situation
Beschreibe den konkreten Kontext: wann, wo, in welcher Situation.

»…«

## B · Behavior
Beschreibe das konkrete, beobachtbare Verhalten, ohne Interpretation.

»…«

## I · Impact
Welche Wirkung hatte das Verhalten auf dich, das Team, das Projekt?

»…«

## Offene Frage
»Wie hast du die Situation erlebt?«

## Danach
Wie kann es in Zukunft besser laufen? (gemeinsam besprechen)
