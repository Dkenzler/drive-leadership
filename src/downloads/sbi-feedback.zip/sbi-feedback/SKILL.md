---
name: sbi-feedback
description: Feedback strukturiert formulieren mit SBI (Situation, Behavior, Impact) vom Center for Creative Leadership, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand ein Feedbackgespräch vorbereiten, kritisches oder positives Feedback an Mitarbeitende, Kolleg:innen oder die eigene Führungskraft geben, eine wiederkehrende Störung (etwa Unterbrechen in Meetings) ansprechen oder vages Lob in präzises Feedback übersetzen will. Führt durch die drei Elemente, trennt Verhalten von Interpretation und endet mit einer offenen Frage an das Gegenüber.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L5 Grow Your People
  origin: Center for Creative Leadership
  deep_dive: false
  version: "1.0"
---

# SBI-Feedback

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach dem Center for Creative Leadership.

## Worum es geht

SBI steht für Situation, Behavior, Impact. Es ist eines der klarsten und praktisch anwendbarsten Frameworks für strukturiertes Feedback. Es hilft, Feedback präzise, nachvollziehbar und ohne persönliche Bewertung zu formulieren.

Die meisten Feedbackgespräche scheitern nicht am Inhalt, sondern an der Form. Feedback, das als Angriff auf die Person wirkt statt als Rückmeldung zu einem Verhalten, erzeugt Abwehr statt Reflexion. SBI trennt das Verhalten vom Menschen: Du gibst keine Persönlichkeitsbewertung, sondern beschreibst, was du gesehen oder wahrgenommen hast und was es ausgelöst hat.

Feedback heißt im Buch: eine konkrete Rückmeldung zu einer Situation oder einem Verhalten, mit dem Ziel, etwas zu verbessern. Es ist nicht dasselbe wie Richtung geben. Beides klingt oft ähnlich, deshalb musst du benennen, welches Werkzeug du gerade benutzt.

## Wann du sie einsetzt

- Für jedes Feedback im Alltag. Dominik Kenzler gibt SBI jeder Person in seinem Team als erstes Feedback-Framework mit, weil es sich auf nahezu jeden Kontext anwenden lässt.
- Für entwicklungsorientiertes Feedback, etwa bei einem wiederkehrenden Verhalten.
- Für positives Feedback. Positives Feedback mit SBI ist präziser und wirkungsvoller als ein allgemeines »Gut gemacht«.
- Zeitnah: direkt nach der Situation, nicht gesammelt fürs Jahresgespräch.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Wem gibt die Person Feedback (Rolle, Beziehung)? Um welches Verhalten geht es? Ist es kritisches oder positives Feedback? Frag nichts, was sie schon gesagt hat.
- Prüfe, ob es wirklich Feedback ist. Will die Person eigentlich eine Richtung vorgeben oder eine Anweisung erteilen, sag ihr das. Dann muss sie es auch so benennen.
- Hat die Person nur eine Beschwerde (»Wie kann es sein, dass …«), hilf ihr zuerst, daraus eine Erwartung zu formulieren (»Meine Erwartung ist, dass …«). Eine Beschwerde ist oft eine verkannte Erwartung. Wer keine klare Erwartung hat, kann kein klares Feedback geben.
- Geh die drei Elemente einzeln durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist das Verhalten beobachtbar, oder steckt eine Interpretation darin? Benenne Schwächen direkt und kurz. Kein Lob als Füllmaterial.
- Erfinde keine Details zur Situation. Fehlt etwas (Datum, Meeting, Häufigkeit), frag nach oder markiere es als offen.
- Schließe mit dem ausformulierten Feedback im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Situation.** Den konkreten Kontext benennen, in dem das Verhalten aufgetreten ist. Nicht »manchmal« oder »immer«, sondern wann genau, in welchem Meeting, bei welchem Projekt.
   Frage: *»Wann und wo genau ist es passiert?«* Gut ist die Antwort, wenn sie einen konkreten Anker hat, den das Gegenüber wiedererkennt.

2. **Behavior.** Das beobachtbare Verhalten beschreiben, nicht die Interpretation oder Absicht dahinter. Nicht »Du bist desinteressiert«, sondern »Du hast in diesem Meeting zweimal auf dein Handy geschaut, während dein Kollege präsentiert hat.«
   Frage: *»Was genau hast du gesehen oder gehört?«* Gut ist die Antwort, wenn eine Kamera sie hätte aufzeichnen können: keine Eigenschaften, keine Motive, keine Absichten.

3. **Impact.** Die Wirkung des Verhaltens auf dich, auf das Team oder auf das Ergebnis beschreiben. Das ist der wichtigste Teil, weil er erklärt, warum das Feedback überhaupt relevant ist.
   Frage: *»Was hat das Verhalten bei dir, im Team oder im Projekt ausgelöst?«* Gut ist die Antwort, wenn das Gegenüber daraus versteht, warum das Verhalten eine Rolle spielt.

4. **Offene Frage.** Nach den drei Elementen eine offene Frage stellen: »Wie hast du die Situation erlebt?« Das gibt der anderen Person Raum, ihre Perspektive einzubringen.
   Frage: *»Mit welcher offenen Frage übergibst du an dein Gegenüber?«* Gut ist sie, wenn sie sich nicht mit Ja oder Nein beantworten lässt.

5. **Gemeinsam nach vorn.** Anschließend besprecht ihr gemeinsam, wie es in Zukunft besser laufen kann.

**Vorbereitung.** Nimm dir zehn Minuten, wenn es wieder passiert ist, und sprich die Person direkt danach an. Bereite dich kurz vor, am besten schreib die drei Elemente einmal auf. Vorlage: `templates/sbi-vorbereitung.md`.

## Beispiel

Jemand unterbricht dich regelmäßig in Meetings.

- **Situation:** »Im Team-Meeting letzte Woche und in der Woche davor …«
- **Behavior:** »… hast du mich unterbrochen, als ich meine Idee präsentieren wollte. Es ist jetzt schon drei Mal vorgekommen.«
- **Impact:** »Das führt dazu, dass ich meine Ideen nicht platzieren kann, und es schwächt meine Stellung im Team.«
- **Offene Frage:** »Wie hast du die Situation erlebt?«

## Worauf du achten musst

- **Die Situation überspringen.** Der häufigste Fehler. Feedback ohne konkreten Anker wirkt pauschal und ist schwer anzunehmen.
- **Den Impact weglassen.** Der zweite häufige Fehler. Ohne Wirkungsbeschreibung versteht die andere Person nicht, warum das Verhalten relevant ist.
- **Interpretation statt Verhalten.** »Du bist desinteressiert« ist eine Bewertung der Person und erzeugt Abwehr. Beschreibe, was du beobachtet hast.
- **Feedback aufsparen.** Feedback verliert seine Wirkung, je länger es zurückgehalten wird. Die Situation ist nicht mehr frisch, und die andere Person kann sich nicht mehr konkret erinnern.
- **Feedback und Richtung vermischen.** Klingt ein Feedback wie eine Vorgabe, oder eine Vorgabe wie ein Feedback, bleibt für das Gegenüber unklar, was gemeint ist.

## Ergebnis

Ein ausformuliertes Feedback, das die Person wörtlich so sagen kann. Vorlage für die Vorbereitung: `templates/sbi-vorbereitung.md`.

```markdown
# SBI-Feedback an [Name / Rolle]
Art: kritisch / positiv · Geplant für: [wann, wo]

**Situation:** »…«
**Behavior:** »…«
**Impact:** »…«
**Offene Frage:** »…«

**Erwartung für die Zukunft (falls nötig):** Meine Erwartung ist, dass …
**Offene Punkte:** …
```

## Mini-Check

Aus der LEAD Checklist des Buchs:
- Gibst du Feedback zeitnah und im SBI-Format?

Abgeleitet aus den typischen Fehlern:
- Nennt deine Situation einen konkreten Zeitpunkt oder Anlass statt »immer« oder »manchmal«?
- Beschreibst du beobachtbares Verhalten, ohne Absicht oder Eigenschaft zu unterstellen?
- Sagt der Impact, warum das Verhalten für dich, das Team oder das Ergebnis relevant ist?
- Endet das Feedback mit einer offenen Frage an die andere Person?

## Im Flywheel

Modul LEAD, Bereich L5 Grow Your People.

Verwandte Skills:
- `radical-candor`: Im selben Kapitel. Radical Candor beschreibt die Haltung (Care personally, Challenge directly), SBI die Form des einzelnen Feedbacks.
- `difficult-conversations`: Im selben Kapitel, für Gespräche, die über ein einzelnes Feedback hinausgehen.
- `feedback-einholen`: Das Buch verweist darauf als Gegenrichtung. SBI beschreibt, wie du Feedback gibst, Feedback einholen, wie du es dir holst.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L5 Grow Your People, SBI-Feedback (Abb. 4.11), Feedback gehört nicht aufgespart, LEAD Checklist, Verweis in YOURSELF, Feedback einholen. Originalquelle: Center for Creative Leadership.

Original: Center for Creative Leadership, Situation-Behavior-Impact (SBI), https://www.ccl.org/articles/leading-effectively-articles/closing-the-gap-between-intent-vs-impact-sbii/
