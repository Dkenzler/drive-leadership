# Leadership Blueprint

Nach dem Drive Leadership Playbook. Nicht länger als ein bis zwei Seiten. Vier Bereiche.

**Name / Rolle:**
**Für (Team):**
**Stand:**
**Nächste Überarbeitung (in einem Jahr):**

## 1. Wie ich führe?

- Was sind meine wichtigsten Führungsprinzipien?
- Was ist mir in der Zusammenarbeit besonders wichtig?
- Was können Mitarbeitende von mir erwarten, und was nicht?
- Meine Schwächen (ehrlich):

## 2. Wie ich am besten arbeite?

- Wann und wie kommuniziere ich am liebsten?
- Meine bevorzugten Kanäle:
- Wann ich Zeit ohne Unterbrechungen brauche, und wann ich gut erreichbar bin:
- Was mir hilft, in Meetings produktiv zu sein:

## 3. Was mich antreibt?

- Wofür stehe ich?
- Was motiviert mich?
- Welche Art von Arbeit gibt mir Energie?
- Was interessiert mich intellektuell?

## 4. Was ich von anderen erwarte?

- Wie ich Feedback gebe, und wie ich es annehme:
- Was ich in der Zusammenarbeit besonders schätze:
- Was mich frustriert, und wie ich damit umgehe:

## Jährliche Überarbeitung

- Was hat sich verändert?
- Was habe ich über mich selbst gelernt?
- Was ist nach wie vor richtig?
