---
name: leadership-blueprint
description: Die eigene Arbeitsweise für das Team transparent machen mit dem Leadership Blueprint aus dem Drive Leadership Playbook von Dominik Kenzler. Nutze diesen Skill, wenn jemand als Führungskraft ein kurzes Dokument schreiben will, wie er oder sie führt, arbeitet, was antreibt und was von anderen erwartet wird, etwa beim Start mit einem neuen Team, einer neuen Rolle, neuen Direct Reports oder für die jährliche Überarbeitung. Auch bei Anfragen wie »How to work with me« oder »User Manual für mich als Führungskraft«. Führt durch die vier Bereiche und hilft, den Blueprint im 1:1 zu teilen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 3 Dich weiterentwickeln und in Übergängen wachsen
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Leadership Blueprint

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Ein Leadership Blueprint ist ein kurzes Dokument, in dem du beschreibst, wie du führst, was du von anderen erwartest und wie man am besten mit dir zusammenarbeitet. Er richtet sich an dein Team und gibt ihm Richtung.

Das klingt selbstbezogen, ist aber das Gegenteil. In den ersten Wochen einer neuen Zusammenarbeit entwickeln Menschen Hypothesen darüber, wie ihre Führungskraft tickt, aus Beobachtungen, Gerüchten und Interpretationen, die oft wenig mit der Realität zu tun haben. Der Blueprint ersetzt diese Spekulation durch direkte Information. Das spart Zeit, reduziert Reibung und schafft eine ehrlichere Grundlage für die Zusammenarbeit.

Der gegenseitige Austausch ist wertvoller als das Dokument selbst. Er normalisiert das Sprechen über Arbeitsweisen, Präferenzen und Erwartungen. Viele Missverständnisse und Konflikte entstehen nicht aus böser Absicht, sondern aus unterschiedlichen Erwartungen, die nie ausgesprochen wurden.

## Wann du sie einsetzt

- Wenn du als Leader oder Manager deinen Direct Reports Richtung geben und Erwartungen klären willst.
- Zu Beginn einer neuen Zusammenarbeit, geteilt in einem der ersten 1:1s.
- Einmal im Jahr zur Überarbeitung.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Team schreibt die Person den Blueprint? Gibt es einen Anlass, etwa ein neues Team oder eine neue Rolle? Gibt es schon eine frühere Fassung? Frag nichts, was sie schon gesagt hat.
- Geh die vier Bereiche nacheinander durch. Pro Bereich eine Leitfrage stellen, dann auf die Antwort warten und bei Bedarf mit den weiteren Fragen des Bereichs nachhaken.
- Der Blueprint besteht aus den Aussagen der Person. Formuliere ihre Antworten klarer und kürzer, erfinde aber keine Prinzipien, Stärken oder Schwächen.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne direkt, wenn eine Aussage allgemein bleibt oder Schwächen fehlen.
- Achte auf die Länge: höchstens ein bis zwei Seiten.
- Schließe mit dem Blueprint im Format aus »Ergebnis« und geh den Mini-Check durch. Biete an, die Einladung an die Direct Reports vorzubereiten, einen eigenen Blueprint zu teilen.
- Antworte in der Sprache der Person.

## Ablauf

1. **Wie ich führe.** Frage: *»Was sind deine wichtigsten Führungsprinzipien?«* Nachfragen: Was ist dir in der Zusammenarbeit besonders wichtig? Was können Mitarbeitende von dir erwarten, und was nicht? Sei ehrlich, auch über Schwächen. Wenn du zum Beispiel in Stresssituationen weniger kommunikativ wirst, sag es. Gut ist eine Antwort mit mindestens einer ehrlich benannten Schwäche.

2. **Wie ich am besten arbeite.** Frage: *»Wann und wie kommunizierst du am liebsten?«* Nachfragen: Was sind deine bevorzugten Kanäle? Wann brauchst du Zeit ohne Unterbrechungen, und wann bist du gut erreichbar? Was hilft dir, in Meetings produktiv zu sein? Gut sind konkrete Zeiten, Kanäle und Formate.

3. **Was mich antreibt.** Frage: *»Wofür stehst du?«* Nachfragen: Was motiviert dich? Welche Art von Arbeit gibt dir Energie? Was interessiert dich intellektuell?

4. **Was ich von anderen erwarte.** Frage: *»Wie gibst du Feedback, und wie nimmst du es an?«* Nachfragen: Was schätzt du besonders in der Zusammenarbeit? Was frustriert dich, und wie gehst du damit um?

5. **Zu konkreten Sätzen verdichten.** Ein Blueprint lebt von konkreten, ehrlichen Aussagen, die eine Haltung zeigen. Beispiele für die Art von Sätzen aus dem Buch:
   - »Ich glaube nicht, dass zwölf Stunden pro Tag ein Team erfolgreich machen. Mir ist lieber, du priorisierst und bist in einem normalen Arbeitstag effektiv.«
   - »Urlaub ist aus einem Grund da. Die Arbeit wird immer da sein, wenn du gehst; und sie wird noch da sein, wenn du zurückkommst.«
   - »Mein Erfolg entsteht aus deinem Erfolg. Ich werde mir nie die Arbeit von anderen zuschreiben.«

   Frage: *»Welcher Satz aus deinen Antworten zeigt am klarsten, wie du tickst?«*

6. **Teilen.** Den Blueprint in einem der ersten 1:1s mit den Direct Reports teilen. Kurz erklären, warum du ihn erstellt hast. Die Direct Reports einladen, dasselbe für sich zu tun und es mit dir zu teilen.

7. **Jährlich überarbeiten.** Was hat sich verändert? Was hast du über dich selbst gelernt? Was ist nach wie vor richtig?

## Worauf du achten musst

- **Zu lang.** Der Blueprint sollte nicht länger als ein bis zwei Seiten sein. Er ist ein praktisches Dokument.
- **Allgemeine Aussagen.** Gute Sätze wirken, weil sie konkret sind und eine Haltung zeigen. Sie schaffen Vertrauen, lange bevor die erste schwierige Situation kommt.
- **Schwächen verschweigen.** Sei ehrlich, auch über deine Schwächen, etwa wenn du in Stresssituationen weniger kommunikativ wirst.
- **Nur senden, nicht austauschen.** Der Wert liegt im gegenseitigen Austausch, nicht im Dokument.
- **Liste persönlicher Eigenheiten.** Wenn plötzlich alle ein persönliches »How to work with me«-Dokument schreiben, entsteht die Erwartung, dass alle anderen diese Dokumente gelesen haben und sich danach richten. Das skaliert nicht, und die Organisation dreht sich zu stark um individuelle Bedürfnisse. Über allem stehen die Werte des Unternehmens und gemeinsame Leadership-Prinzipien. Der Blueprint richtet sich an dein Team.
- **Einmal schreiben, nie anfassen.** Überarbeite den Blueprint einmal im Jahr.

## Ergebnis

Vorlage: `templates/leadership-blueprint.md`.

```markdown
# Leadership Blueprint: [Name], [Rolle]
Stand: [Datum] · Für: [Team] · Nächste Überarbeitung: [Datum + 1 Jahr]

## 1. Wie ich führe
…

## 2. Wie ich am besten arbeite
…

## 3. Was mich antreibt
…

## 4. Was ich von anderen erwarte
…

**Geteilt in:** [1:1 mit …, Datum] · **Einladung an das Team, eigene Blueprints zu teilen:** ja / nein
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Passt dein Blueprint auf ein bis zwei Seiten?
- Enthält er mindestens eine ehrlich benannte Schwäche?
- Stehen darin konkrete Sätze, die eine Haltung zeigen, statt allgemeiner Aussagen?
- Hast du deine Direct Reports eingeladen, dasselbe für sich zu tun?
- Richtet er sich an dein Team und ordnet sich den Werten des Unternehmens unter?

## Im Flywheel

Modul YOURSELF, Teil 3 Dich weiterentwickeln und in Übergängen wachsen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Methode Leadership Blueprint.
