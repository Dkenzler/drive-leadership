---
name: disagree-and-commit
description: Disagree and Commit, ein Prinzip aus der Amazon-Führungskultur, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn eine Entscheidung trotz Meinungsverschiedenheit getroffen werden muss, ein Team auf Konsens wartet und Entscheidungen verwässern, jemand überstimmt wurde und die Entscheidung trotzdem vertreten soll, oder wenn eine Entscheidung nach außen halbherzig kommuniziert oder passiv sabotiert wird. Hilft, den Disagreement-Teil wirklich zu hören, das Commitment explizit zu machen und es nach außen zu vertreten.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S4 Make Fast Decisions
  origin: Amazon
  deep_dive: false
  version: "1.0"
---

# Disagree and Commit

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach der Amazon-Führungskultur.

## Worum es geht

Disagree and Commit ist ein Prinzip aus der Amazon-Führungskultur. Die Idee: Man kann inhaltlich anderer Meinung sein und trotzdem vollständig hinter einer Entscheidung stehen, sobald sie getroffen ist. Das klingt einfach, ist in der Praxis aber eine der schwierigsten Führungsdisziplinen.

In vielen Organisationen wird Konsens als Ziel angestrebt: Alle sollen überzeugt sein, bevor entschieden wird. Das hat seinen Preis. Entscheidungen verwässern, weil sich immer ein Kompromiss findet, der niemandem wehtut, aber auch nichts bewegt. Und die Entscheidung dauert ewig. Konsens ist manchmal wichtig, aber kein Ersatz für eine Entscheidung.

Disagree and Commit erlaubt ehrliche Meinungsverschiedenheiten und schützt gleichzeitig die Entscheidungsgeschwindigkeit. Bezos hat es so beschrieben: »Look, I know we disagree on this but will you gamble with me on it?« Das ist keine Unterdrückung von Meinungen, sondern die Bereitschaft, hinter einer Entscheidung zu stehen, auch wenn man sie nicht selbst getroffen hätte.

Committen heißt nicht, die eigene Meinung zu verstecken. Es heißt, die Entscheidung nach außen zu vertreten und das Team dahinter zu vereinen.

## Wann du sie einsetzt

- Eine Entscheidung steht an, und in der Runde gibt es echte Meinungsverschiedenheiten.
- Ein Team sucht Konsens, und die Entscheidung zieht sich oder verwässert zum Kompromiss.
- Du wurdest selbst überstimmt und musst die Entscheidung vor deinem Team vertreten. Als Leader ist es manchmal deine Aufgabe, Disagree and Commit vorzuleben, gerade dann.
- Jemand hat zugestimmt, setzt aber halbherzig um.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welche Entscheidung geht es? Ist sie schon getroffen oder steht sie noch an? Welche Rolle hat die Person: entscheidet sie, wurde sie überstimmt, oder soll jemand anderes committen? Frag nichts, was die Person schon gesagt hat.
- Je nach Rolle: Entscheidet die Person, geh die Schritte 1 bis 4 durch. Wurde sie überstimmt, arbeite mit Schritt 4. Geht es um halbherzige Umsetzung im Team, arbeite mit Schritt 5.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Wurde der Disagreement-Teil wirklich gehört, oder wird nur durchgesetzt? Benenne Schwächen direkt und kurz.
- Erfinde keine Positionen oder Aussagen anderer Beteiligter. Was fehlt, markierst du als offen.
- Biete an, die Formulierungen für das Meeting oder die Team-Kommunikation vorzubereiten.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Disagreement hören.** Die abweichenden Positionen kommen vollständig auf den Tisch, bevor entschieden wird.
   Frage: *»Wer ist anderer Meinung, und was genau ist sein oder ihr Argument?«* Gut ist die Antwort, wenn die Gegenposition so beschrieben ist, dass die Person, die sie vertritt, zustimmen würde.

2. **Entscheiden, nicht auf Konsens warten.** Die Entscheidung fällt, auch wenn nicht alle überzeugt sind.
   Frage: *»Wer entscheidet, und was ist die Entscheidung?«*

3. **Commitment explizit einholen.** Im Sinne des Bezos-Zitats: die Personen, die anderer Meinung sind, ausdrücklich fragen, ob sie trotz des Dissenses mitgehen.
   Frage: *»Wie fragst du die Personen, die anderer Meinung sind, ausdrücklich nach ihrem Commitment?«*

4. **Nach außen vertreten.** Wer committet, vertritt die Entscheidung nach außen und vereint das Team dahinter, auch wenn er oder sie überstimmt wurde.
   Frage: *»Wie kommunizierst du die Entscheidung deinem Team, ohne zögerlich zu klingen?«* Gut ist die Antwort, wenn die Botschaft die Entscheidung klar trägt und nicht zögerlich klingt.

5. **Umsetzung beobachten und ansprechen.** Committen zeigt sich im Handeln. Halbherzige Umsetzung ist Nicht-Commitment.
   Frage: *»Woran erkennst du in den nächsten Wochen, ob wirklich umgesetzt wird, und wie sprichst du es an, wenn nicht?«*

## Beispiel

Das Buch gibt das Bezos-Zitat als Beispiel: »Look, I know we disagree on this but will you gamble with me on it?« Ein eigenes Fallbeispiel enthält es zu dieser Methode nicht.

## Worauf du achten musst

- **Disagree and Commit als Werkzeug gegen Widerstand.** Der häufigste Fehler. »Wir haben entschieden, committe dazu«, ohne den eigentlichen Disagreement-Teil gehört zu haben, ist kein Disagree and Commit, sondern Durchsetzen.
- **Verbal committen, aber nicht handeln.** Passive Sabotage durch halbherzige Umsetzung ist besonders schädlich, weil sie schwer zu benennen ist. Sprich dieses Verhalten direkt an, wann immer du es beobachtest.
- **Intern disagreen, nach außen zögern.** Wer die Entscheidung dem Team gegenüber zögerlich kommuniziert, committet nicht wirklich. Das schwächt die Entscheidung und sendet ein konfuses Signal.
- **Konsens als Ziel.** Wer wartet, bis alle überzeugt sind, bekommt verwässerte Kompromisse und lange Entscheidungen.

## Ergebnis

```markdown
# Disagree and Commit: [Entscheidung]
Datum: [Datum] · Entscheidet: [Name]

**Entscheidung:** …

**Gehörte Gegenpositionen:**
| Person | Position und Argument | Gehört am |
|---|---|---|
| … | … | … |

**Commitment eingeholt von:** … am …
**Botschaft an das Team:** …
**Woran wir echte Umsetzung erkennen:** …
**Offen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Wurden die Gegenpositionen vollständig gehört, bevor entschieden wurde?
- Hast du das Commitment ausdrücklich eingeholt, statt es vorauszusetzen?
- Kommunizierst du die Entscheidung nach außen ohne Zögern, auch wenn du überstimmt wurdest?
- Zeigt sich das Commitment in der Umsetzung, und sprichst du halbherziges Handeln direkt an?

## Im Flywheel

Modul SHIP, Bereich S4 Make Fast Decisions.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S4 Make Fast Decisions. Originalquelle: Amazon-Führungskultur, Zitat Jeff Bezos.

Original: Jeff Bezos: 2016 Letter to Shareholders, 2017, https://www.aboutamazon.com/news/company-news/2016-letter-to-shareholders. Amazon Leadership Principle »Have Backbone; Disagree and Commit«, https://www.amazon.jobs/content/en/our-workplace/leadership-principles
