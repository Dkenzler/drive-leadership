---
name: canonical-document
description: Canonical Document nach Naomi Gleit (Meta), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn Informationen zu einem Projekt über Dokumente, Chats, E-Mails und Präsentationen verstreut sind, neue Leute fragen »Wo finde ich alles, was ich wissen muss?« und es keine eindeutige Antwort gibt, oder wenn ein Projekt, eine Initiative oder ein Workstream startet. Führt durch Ziel, Workstreams und Owner, People, Process und Canonical Nomenclature und erstellt ein schlankes Index-Dokument als die eine Antwort auf »Wo finde ich alles?«.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S3 Create Execution Clarity
  origin: Naomi Gleit
  deep_dive: false
  version: "1.0"
---

# Canonical Document

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Naomi Gleit.

## Worum es geht

Das Canonical Document ist ein Konzept von Naomi Gleit. Die Ausgangsfrage: Wenn jemand neu in ein Projekt einsteigt und fragt »Wo finde ich alles, was ich wissen muss?«, gibt es eine einzige Antwort? In den meisten Organisationen lautet die ehrliche Antwort: Nein. Informationen sind über Dokumente, Chats, E-Mails und Präsentationen verteilt, niemand hat den vollständigen Überblick.

Das Canonical Document ist das eine Dokument, das alle grundlegenden und kritischen Informationen zu einem Projekt enthält, mit Links zu allen nachgelagerten Detaildokumenten. Wer es liest, weiß: Was ist das Ziel? Wer arbeitet daran? Was sind die Workstreams, und wer verantwortet sie? Wie kommuniziert das Team? Es ist ein zentrales Werkzeug, damit alle Zugriff auf dieselben Informationen haben.

Das Canonical Document definiert auch die Sprache des Projekts, die Canonical Nomenclature: Wenn verschiedene Personen dieselben Wörter benutzen und Unterschiedliches meinen, fehlt ein gemeinsames Vokabular.

## Wann du sie einsetzt

- Bei jedem neuen Projekt oder jeder neuen Initiative.
- Wenn neue Personen in ein laufendes Projekt einsteigen und sich nicht orientieren können.
- Wenn Mitarbeitende Fragen stellen, die längst beantwortet wurden, weil die Information nicht auffindbar ist.
- Wenn im Projekt dieselben Begriffe unterschiedlich verstanden werden.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welches Projekt oder welche Initiative geht es? Gibt es schon ein Dokument, das diese Rolle einnehmen soll? Wer arbeitet mit? Frag nichts, was die Person schon gesagt hat.
- Starte klein. Das Buch empfiehlt für den Anfang drei Fragen (Schritt 1). Die Abschnitte A bis D aus der Struktur ergänzt du nur, soweit die Person sie jetzt schon füllen kann. Alles andere kommt mit der Zeit.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Wird das Dokument zum Archiv statt zum Index? Steht bei jedem Workstream ein Name statt eines Teams? Benenne Schwächen direkt und kurz.
- Erfinde keine Namen, Kanäle, Links oder Ziele. Was fehlt, markierst du als offen.
- Schließe mit dem Dokument im Format aus »Ergebnis« und geh den Mini-Check durch. Frag am Ende, wer das Dokument aktuell hält und wann es das nächste Mal geprüft wird.
- Antworte in der Sprache der Person.

## Ablauf

1. **Mit drei Fragen starten.** Für den Anfang reichen: Was ist das Ziel? Wer ist verantwortlich? Wo finde ich mehr?
   Frage: *»Was ist das Ziel des Projekts, wer ist verantwortlich, und wo liegen die wichtigsten Detaildokumente?«* Gut ist die Antwort, wenn das Ziel in einem oder zwei Sätzen steht und bei »verantwortlich« ein Name steht.

2. **A. Workstreams und Owner.** Die Workstreams des Projekts auflisten, pro Workstream ein Owner, bei Bedarf Tracks mit Sub-Owner.
   Frage: *»In welche Workstreams zerfällt das Projekt, und wer verantwortet jeden davon?«* Gut ist die Antwort, wenn jeder Workstream genau einen Namen hat, keine Abteilung.

3. **B. People.** Wer gehört zum Working Team, wer zum Leadership Team, und wer ist die direkt verantwortliche Person (DRI)?
   Frage: *»Wer arbeitet operativ mit, wer ist im Leadership Team, und wer ist DRI für das Gesamtprojekt?«*

4. **C. Process.** Wie kommuniziert das Team: Canonical Chat oder Slack Channel, Canonical Meeting Series und E-Mail-Liste.
   Frage: *»Wo läuft die Projektkommunikation, und welche wiederkehrenden Meetings gehören zum Projekt?«* Gut ist die Antwort, wenn es jeweils einen festen Ort gibt, nicht mehrere parallele.

5. **D. Canonical Nomenclature.** Die zentralen Begriffe des Projekts verbindlich festlegen: Begriff, Definition, Framework, Visual.
   Frage: *»Welche Begriffe werden im Projekt unterschiedlich verstanden oder brauchen eine verbindliche Definition?«*

6. **Links statt Inhalte.** Detailinformationen bleiben in den nachgelagerten Dokumenten. Das Canonical Document verlinkt sie.
   Frage: *»Welche Inhalte stehen im Entwurf, die besser in ein verlinktes Detaildokument gehören?«*

7. **Pflege festlegen.** Das Dokument muss aktuell bleiben. Ein veraltetes Canonical Document ist schlimmer als keines, weil es falsche Orientierung gibt.
   Frage: *»Wer hält das Dokument aktuell, und bei welchem Anlass wird es aktualisiert?«*

## Beispiel

Das Buch zeigt die Struktur als Abbildung (Abb. 5.10, Canonical Document-Struktur nach Naomi Gleit) mit vier Abschnitten: A. Workstreams + Owners, B. People, C. Process, D. Canonical Nomenclature. Ein durchgespieltes Beispiel enthält es nicht.

## Worauf du achten musst

- **Erstellt und vergessen.** Das Dokument wird am ersten Tag eines Projekts angelegt und danach nie mehr aktualisiert. Ein veraltetes Canonical Document gibt falsche Orientierung.
- **Zu umfangreich.** Wird das Dokument so lang, dass niemand es mehr liest, verfehlt es seinen Zweck. Weniger ist mehr. Das Canonical Document ist ein Index, kein Archiv.
- **Begriffe offen lassen.** Wenn dieselben Wörter Unterschiedliches meinen, fehlt ein gemeinsames Vokabular. Die Nomenklatur gehört ins Dokument.

## Ergebnis

Ein Canonical Document für das Projekt. Vorlage: `templates/canonical-document.md`.

```markdown
# Canonical Document: [Projekt]
Stand: [Datum] · Gepflegt von: [Name]

**Ziel:** …
**Verantwortlich (DRI):** [Name]
**Mehr finden:** [Links hier]

## A. Workstreams + Owners
1. [Workstream 1]: Owner [Name] · [Link]
   - [Track A]: Sub-Owner [Name]
2. [Workstream 2]: Owner [Name] · [Link]

## B. People
- Working Team: …
- Leadership Team: …
- DRI: [Name]

## C. Process
- Canonical Chat / Slack Channel: …
- Canonical Meeting Series + E-Mail-Liste: …

## D. Canonical Nomenclature
1. [Begriff]: [Definition] · Framework: … · Visual: …

**Offen:** …
```

## Mini-Check (abgeleitet aus den typischen Fehlern, ergänzt um die SHIP Checklist)

- Gibt es ein Canonical Document, das alle relevanten Informationen zum laufenden Projekt enthält?
- Findet eine neue Person darüber Ziel, Verantwortliche und Detaildokumente?
- Steht bei jedem Workstream ein Name, keine Abteilung?
- Ist das Dokument ein Index mit Links, kein Archiv?
- Ist festgelegt, wer es aktuell hält, und stimmt der Stand noch?

## Im Flywheel

Modul SHIP, Bereich S3 Create Execution Clarity.

Verwandte Skills:
- `extreme-clarity`: Das Canonical Document ist der Ort, an dem die Klarheit dauerhaft wohnt. Das Echtzeit-Festhalten aus Meetings fließt hinein, die Canonical Nomenclature gilt für beide.
- `dri`: Der Name des DRI ist im Canonical Document sichtbar.
- `decision-log`: Das Buch verweist beim Dokumentieren von Entscheidungen auf das Canonical Document.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S3 Create Execution Clarity, Abschnitt DRI, SHIP Checklist, Deep Dive Extreme Clarity, Gut zu wissen. Originalquelle: Naomi Gleit, Head of Product bei Meta.

Original: Naomi Gleit: Canonical Everything, 2022, https://naomi.com/canonical-everything-c85441a84e70
