# Canonical Document

Nach Abb. 5.10 im Drive Leadership Playbook: Canonical Document-Struktur nach Naomi Gleit.

**Projekt:**
**Stand:**
**Gepflegt von:**

**Was ist das Ziel?**
**Wer ist verantwortlich?**
**Wo finde ich mehr?**

## A. Workstreams + Owners

| Workstream | Owner | Link |
|---|---|---|
| Workstream 1 | | |
| Track A | Sub-Owner: | |
| Workstream 2 | | |
| Workstream 3 | | |

## B. People

| Rolle | Wer |
|---|---|
| Working Team | Liste: |
| Leadership Team | Liste: |
| DRI (direkt verantwortliche Person) | Name: |

## C. Process

| Kanal | Wo |
|---|---|
| Canonical Chat / Slack Channel | |
| Canonical Meeting Series + E-Mail-Liste | |

## D. Canonical Nomenclature

| Begriff | Definition | Framework | Visual |
|---|---|---|---|
| | | | |
