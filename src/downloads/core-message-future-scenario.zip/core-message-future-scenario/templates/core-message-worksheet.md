# Core Message Worksheet

Nach Abb. 3.24 im Drive Leadership Playbook, nach Ole Tillmann, »Beyond the Obvious«.

**Anlass / Publikum:**

## Objective
Was soll dein Publikum danach anders wissen, fühlen oder tun, und warum?

Mein Ziel ist …

weil …

## Core Message
Was ist dein Einblick, und was folgt daraus?

Da sich … verändert,

müssen wir …

## Iteration & Visualisierung
Schärfe den Satz und finde ein einfaches Bild dafür.

Geschärfter Satz:

Skizze:

