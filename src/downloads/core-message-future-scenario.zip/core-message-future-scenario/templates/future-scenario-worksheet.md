# Future Scenario Worksheet

Nach Abb. 3.25 im Drive Leadership Playbook, nach Ole Tillmann, »Beyond the Obvious«.

**Anlass / Publikum:**
**Core Message:**

## From
Die heutige Situation, knapp und konkret.

- 

## To
Das wünschenswerte Zukunftsbild.

- 

## How
Die Schritte und Strategien dorthin.

- 
