---
name: core-message-future-scenario
description: Eine Botschaft auf einen Satz verdichten und als Weg von heute nach morgen erzählen, mit dem Core Message Worksheet und dem Future Scenario Worksheet (From, To, How) von Ole Tillmann (»Beyond the Obvious«), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand Strategie, Vision oder Veränderung kommunizieren will, eine Präsentation vor Geschäftsführung, Team oder Organisation vorbereitet, zu viele Botschaften hat oder die Kernaussage nicht auf den Punkt bekommt. Führt durch Objective (»Ich will …, weil …«), Core Message (»Da …, müssen wir …«), Iteration und Visualisierung sowie From, To und How.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D5 Communicate Direction
  origin: Ole Tillmann
  deep_dive: true
  version: "1.0"
---

# Core Message & Future Scenario

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Ole Tillmann.

## Worum es geht

Wer einen wirklich guten Vortrag gesehen hat, erinnert sich selten an die Folien. Was bleibt, ist meist ein einziger Satz. Ole Tillmann hat über Jahre mit Hunderten TEDx-Speakern daran gearbeitet: Eine Präsentation wirkt, wenn das Publikum sie auf einen Gedanken eindampfen und weitererzählen kann. Zwei Worksheets aus seinem Buch »Beyond the Obvious« bauen diesen Effekt absichtlich ein. Sie bilden ein Paar: Das eine verdichtet, das andere erzählt.

- **Du reduzierst auf einen Gedanken.** Ein Publikum behält nicht zehn Punkte, sondern höchstens einen. Das Core Message Worksheet zwingt dich, diesen Gedanken zu benennen, bevor du an Folien denkst. Was nicht auf ihn einzahlt, fällt weg.
- **Du machst Veränderung als Weg sichtbar.** Eine Botschaft überzeugt selten als Behauptung, sondern als Bewegung. Das Future Scenario Worksheet beschreibt, wo ihr heute steht (From), wohin ihr wollt (To) und wie ihr dorthin kommt (How). Aus einer Aussage wird eine Geschichte, der das Publikum folgen kann.
- **Du bekommst einen ehrlichen Selbsttest.** Wenn du die wenigen Felder nicht klar füllen kannst, ist deine Botschaft noch nicht fertig. Das merkst du am Worksheet, nicht erst auf der Bühne.

Die Satzmuster »Ich will …, weil …«, »Da …, müssen wir …« und »From, To, How« sind keine Schreibhilfen, sondern zwingen zur Klarheit. Sie lassen sich nicht mit vagen Formulierungen füllen, ohne dass die Lücke auffällt. Die Worksheets sind bewusst klein gehalten. Sie sind kein Skript für den Vortrag, sondern das Denkwerkzeug davor.

## Wann du sie einsetzt

- Veränderung kommunizieren: einen möglichen Weg beschreiben. Wo starten wir, wo genau wollen wir hin, wie sieht der Weg aus?
- Besonders bei Strategie- und Visionskommunikation.
- Wenn eine Botschaft vor einem Publikum auf den Punkt und in Bewegung gebracht werden soll, etwa um eine Geschäftsführung von einer neuen Richtung zu überzeugen.

Abgrenzung laut Buch: Der PR/FAQ beschreibt die erreichte Produktzukunft aus Kundensicht. Er ist ein Denkwerkzeug, um eine Idee zu schärfen und ihre Annahmen sichtbar zu machen. Core Message und Future Scenario setzen später an. Sie sind Kommunikationswerkzeuge für eine bereits gefasste Botschaft. Das eine hilft dir zu denken, das andere zu überzeugen. Ist die Idee selbst noch unklar, ist dieser Skill zu früh.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Vor wem kommunizierst du? Worum geht es, welche Veränderung oder Richtung? Wann und in welchem Format? Frag nichts, was die Person schon gesagt hat.
- Arbeite in der Reihenfolge, die sich laut Buch bewährt hat: erst die eine Botschaft (Teil 1), dann der Weg (Teil 2). Hat die Person schon eine Core Message, prüfe sie und steig bei Teil 2 ein.
- Eine Frage pro Schritt, dann auf die Antwort warten.
- Halte die Satzmuster streng ein. Formuliere mit der Person um, bis der Satz ins Muster passt, statt das Muster aufzuweichen.
- Challenge gegen »Worauf du achten musst«. Vor allem: Gibt es mehr als eine Core Message? Fehlt die Empfehlung?
- Für die Visualisierung beschreibst du eine einfache Skizze in Worten. Zeichnen muss die Person selbst.
- Erfinde keine Fakten über die Organisation der Person. Wo Informationen fehlen, markiere sie als offen.
- Beide Worksheets lassen sich allein in etwa einer halben Stunde je Blatt ausfüllen. Empfiehl, sie danach mit einer Person zu besprechen, die das Publikum kennt.
- Schließe mit beiden Worksheets im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

### Teil 1: Core Message Worksheet

Beantwortet die Frage: Was ist der eine Satz, den dein Publikum mitnehmen soll? (Abb. 3.24)

1. **Objective.** Was willst du erreichen? Was soll dein Publikum nach dem Vortrag anders wissen, fühlen oder tun? Satzmuster: »Ich will …, weil …«. Das »weil« zwingt dich, den Grund zu benennen, nicht nur die Absicht.
   Frage: *»Was soll dein Publikum danach anders wissen, fühlen oder tun, und warum?«* Gut ist die Antwort, wenn sie ins Muster passt und das »weil« einen echten Grund nennt.

2. **Core Message.** Was ist dein besonderer Einblick ins Thema, und was empfiehlst du daraus? Satzmuster: »Da …, müssen wir …«. Der erste Teil ist die Beobachtung, der zweite die Schlussfolgerung. Eine Beobachtung allein ist noch keine Botschaft.
   Frage: *»Was ist dein Einblick, und was folgt daraus?«* Gut ist die Antwort, wenn sie ein Satz ist, beide Teile enthält und der zweite Teil eine Empfehlung ist.

3. **Iteration und Visualisierung.** Den Satz weiter schleifen, bis er sitzt, und ein einfaches Bild dafür suchen. Lässt sich der Kerngedanke in einer Skizze zeigen, ist er klar genug. Lässt er sich nicht zeichnen, ist er meist noch zu vage.
   Frage: *»Wie würdest du deinen Kerngedanken in einer einfachen Skizze zeigen?«* Gut ist die Antwort, wenn das Bild ohne Erklärung zum Satz passt.

### Teil 2: Future Scenario Worksheet

Bringt die Botschaft in Bewegung, als Weg von der Gegenwart in eine wünschenswerte Zukunft. (Abb. 3.25)

4. **From.** Die heutige Situation, knapp in Stichpunkten und möglichst visualisiert. Das ist der gemeinsame Ausgangspunkt, den dein Publikum wiedererkennt.
   Frage: *»Wo steht ihr heute, in knappen Stichpunkten, die dein Publikum sofort wiedererkennt?«* Gut ist die Antwort, wenn sie knapp ist und das Publikum sich darin wiederfindet.

5. **To.** Das wünschenswerte Zukunftsbild, an das dein Publikum glauben soll. Konkret und positiv, sodass man es sich vorstellen kann.
   Frage: *»Wie sieht die Zukunft aus, an die dein Publikum glauben soll?«* Gut ist die Antwort, wenn sie konkret und vorstellbar ist und mehr Gewicht hat als das From.

6. **How.** Die Schritte und Strategien, mit denen ihr von From nach To kommt. Das macht die Zukunft glaubwürdig, weil sie nicht nur erstrebenswert, sondern erreichbar wirkt.
   Frage: *»Mit welchen Schritten und Strategien kommt ihr dorthin?«* Gut ist die Antwort, wenn die Schritte plausibel sind und keine Wunschliste.

## Beispiel

Du leitest das Produktdesign in einem Unternehmen und willst die Geschäftsführung überzeugen, von immer neuen Einzelfunktionen auf ein durchgängiges Produkterlebnis umzustellen.

- **Objective:** »Ich will, dass die Geschäftsführung anders auf unsere Produktentwicklung blickt, weil wir mit immer mehr Einzelfunktionen die Nutzenden verlieren.«
- **Core Message:** »Da jedes neue Feature das Produkt komplexer macht, müssen wir aufhören, Funktionen zu zählen, und anfangen, das Erlebnis zu gestalten.«
- **Bild:** Viele einzelne Finanzprodukte (Konto, Karte, Aktien, Reiseversicherung) nicht als Sammlung anbieten, sondern als eine durchgehende Experience.
- **From:** viele Funktionen, unklare Nutzung, sinkende Zufriedenheit.
- **To:** ein durchgängiges Erlebnis, das Nutzende mühelos ans Ziel bringt und das man weiterempfiehlt.
- **How:** gemeinsame Erlebnisprinzipien, weniger, aber bessere Releases, eine Erfolgsmessung, die Zufriedenheit und Weiterempfehlung in den Mittelpunkt stellt.

Die Core Message liefert den Satz, den die Geschäftsführung weitererzählen kann. Das Future Scenario macht daraus eine Bewegung, der man folgen will. Keines der beiden Felder ließe sich überzeugend füllen, wenn die Botschaft selbst noch unklar wäre.

## Worauf du achten musst

- **Mehr als eine Core Message.** Wer drei Kernbotschaften hat, hat keine. Entscheide dich für den einen Gedanken und ordne alles andere unter.
- **Die Empfehlung weglassen.** Eine Core Message ist Einblick und Schlussfolgerung, das »Da« und das »Müssen wir«. Bleibt es bei der Beobachtung, fehlt dem Publikum, was es tun soll.
- **Im From verharren.** Die heutige Situation braucht nur so viel Raum, dass alle den Ausgangspunkt teilen. Das Publikum wartet auf das To, nicht auf eine lange Problembeschreibung.
- **Das How als Wunschliste.** Ohne plausible Schritte bleibt die Zukunft eine nette Idee. Das How macht den Unterschied zwischen Vision und Wunschdenken.
- **Folien vor der Botschaft bauen.** Die Worksheets kommen zuerst. Wer mit den Folien beginnt, gestaltet die Verpackung, bevor der Inhalt steht.

## Ergebnis

Beide Worksheets, ausgefüllt. Vorlagen: `templates/core-message-worksheet.md` und `templates/future-scenario-worksheet.md`.

```markdown
# Core Message & Future Scenario: [Anlass]
Publikum: … · Termin / Format: …

## Core Message
**Objective:** Mein Ziel ist …, weil …
**Core Message:** Da sich … verändert, müssen wir …
**Bild / Skizze:** …

## Future Scenario
**From (heute, knapp):**
- …
**To (wünschenswertes Zukunftsbild):**
- …
**How (Schritte und Strategien):**
- …

**Offen:** …
```

## Mini-Check

- Lässt sich deine Core Message in einem Satz sagen, im Muster »Da …, müssen wir …«?
- Enthält sie eine Empfehlung, nicht nur eine Beobachtung?
- Gibt es ein Bild, das den Kerngedanken zeigt?
- Sind From, To und How klar gefüllt, und bekommt das To mehr Gewicht als das From?
- Macht das How die Zukunft erreichbar, nicht nur wünschenswert?

## Im Flywheel

Modul DRIVE, Bereich D5 Communicate Direction.

Verwandte Skills:
- `pr-faq`: Arbeitet ebenfalls mit einem Zukunftsbild, setzt aber früher an. Der PR/FAQ schärft die Idee, Core Message und Future Scenario kommunizieren die gefasste Botschaft.
- `presentation-strategy-worksheet`: Ein weiteres Worksheet von Ole Tillmann für die Grundlagen einer Präsentation.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D5 Communicate Direction, Future Scenario Worksheet, und Deep Dive Core Message & Future Scenario, Abb. 3.24 und 3.25. Originalquelle: Ole Tillmann: Beyond the Obvious.
Original: Ole Tillmann: Beyond the Obvious. Agile Presentation Design, an innovator's guide to more impactful presentations, 2019. https://www.tillmann.com/book
