---
name: omtm
description: "OMTM (One Metric That Matters) aus dem Lean-Analytics-Ansatz von Alistair Croll und Benjamin Yoskovitz, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand für ein Team oder eine Phase die eine wichtigste Kennzahl finden, den Fokus für ein Quartal auf einen Indikator legen, eine bestehende Metrik prüfen (Vanity Metric oder Actionable Metric?) oder OMTM von der North Star Metric abgrenzen will. Prüft Kandidaten gegen vier Eigenschaften: messbar, beeinflussbar, relevant, fokussierend."
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S1 Set Goals
  origin: Alistair Croll und Benjamin Yoskovitz (Lean Analytics)
  deep_dive: false
  version: "1.0"
---

# OMTM (One Metric That Matters)

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Alistair Croll und Benjamin Yoskovitz.

## Worum es geht

Zu jedem Zeitpunkt gibt es eine Metrik, die wichtiger ist als alle anderen. Wer diese Metrik verbessert, macht das Unternehmen oder das Team stärker. OMTM ist kein dauerhaftes Ziel, sondern ein Fokusinstrument für eine bestimmte Phase. Was heute die wichtigste Metrik ist, kann in sechs Monaten nicht mehr relevant sein, weil das Problem gelöst ist oder sich die strategische Priorität verschoben hat.

**Abgrenzung zur North Star Metric:** Die North Star Metric ist langfristig und strategisch, misst den Kernwert des Unternehmens und verändert sich selten (Spotify: »Time spent listening.« Airbnb: »Nights booked.«). OMTM ist kurzfristig und operational. Es beantwortet die Frage: Worauf schauen wir dieses Quartal? Es ist der eine Indikator, auf den das Team seinen Fokus richtet, bis das Problem gelöst ist.

## Wann du sie einsetzt

- Wenn ein Team für eine Phase oder ein Quartal einen klaren Fokus braucht.
- Wenn zu viele Kennzahlen gleichzeitig verfolgt werden.
- Wenn eine bisherige OMTM erreicht ist und die nächste gefunden werden muss.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welches Team und welchen Zeitraum? Welches Problem oder welches Ziel steht gerade im Vordergrund? Welche Kennzahlen werden heute schon gemessen? Frag nichts, was die Person schon gesagt hat.
- Sammle Kandidaten und prüf jeden gegen die vier Eigenschaften. Am Ende steht genau eine Metrik.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge gegen »Worauf du achten musst«. Vor allem: Ist das eine Vanity Metric? Will das Team zwei Dinge gleichzeitig verbessern?
- Erfinde keine Daten oder Messbarkeit. Ist unklar, ob eine Metrik technisch erfasst werden kann, markiere das als offen.
- Schließe mit der OMTM im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Problem der Phase benennen.** Die OMTM gilt für eine bestimmte Phase und ein konkretes Problem.
   Frage: *»Welches Problem muss dein Team in dieser Phase lösen?«*

2. **Kandidaten sammeln.** Alle Metriken, die das Problem abbilden könnten.
   Frage: *»Welche Zahlen würden sich bewegen, wenn das Problem gelöst wird?«*

3. **Gegen die vier Eigenschaften prüfen.** Eine gute OMTM ist:
   - **messbar:** klar definiert und technisch erfassbar,
   - **beeinflussbar:** das Team kann sie durch seine Arbeit tatsächlich bewegen,
   - **relevant:** wenn sie sich verbessert, ist das ein echtes Signal für Fortschritt,
   - **fokussierend:** sie zwingt zu Priorisierungsentscheidungen.

   Frage je Kandidat: *»Kann dein Team diese Zahl selbst bewegen, und wäre eine Verbesserung ein echtes Signal für Fortschritt?«*

4. **Actionable statt Vanity prüfen.** Eine gute OMTM ist eine Actionable Metric: Wenn sie sich verändert, verstehst du, warum, und kannst reagieren.
   Frage: *»Wenn diese Zahl nächste Woche fällt, wüsstest du, warum, und was ihr tun würdet?«*

5. **Auf eine reduzieren.** Test aus dem Buch: Wenn das Team zwei Dinge gleichzeitig verbessern will, ist das kein OMTM. Eine Sache, jetzt.
   Frage: *»Wenn du nur eine dieser Metriken behalten dürftest, welche?«*

6. **Ablaufbedingung festlegen.** Wenn die Metrik erreicht ist, muss die nächste OMTM gefunden werden.
   Frage: *»Ab welchem Wert oder zu welchem Zeitpunkt prüft ihr, ob die OMTM gewechselt werden muss?«*

## Beispiel

Ein Beispiel, das Dominik inspiriert hat: der Anteil der Erstkund:innen, die ein zweites Mal buchen. Der Wert sagt mehr als jede gute Bewertung. Er zeigt, dass die erste Erfahrung so überzeugend war, dass jemand erneut Geld für denselben Service ausgibt, ein starkes Retention-Signal. Die Logik gilt für nahezu jeden Service: Wer misst, wie viele Erstnutzende zu Zweitnutzenden werden, misst echte Wertschöpfung.

## Worauf du achten musst

- **OMTM mit Vanity Metric verwechseln.** Page Views, Downloads, registrierte Nutzende: Diese Zahlen wachsen oft, sagen aber nichts darüber, ob das Produkt Wert schafft.
- **Zwei Dinge gleichzeitig.** Wer zwei Metriken verbessern will, hat keine OMTM.
- **OMTM als Dauerlösung.** Ist eine Metrik erreicht, muss die nächste gefunden werden. Wer dieselbe Metrik ein Jahr lang verfolgt, hat aufgehört zu denken.
- **Mit der North Star Metric verwechseln.** Die North Star ist langfristig und ändert sich selten. Die OMTM ist der Fokus für jetzt.

## Ergebnis

```markdown
# OMTM: [Team] · [Zeitraum / Phase]
Stand: [Datum]

**Problem dieser Phase:** …
**One Metric That Matters:** …
**Definition und Messquelle:** …
**Aktueller Wert:** … · **Zielwert:** …

| Eigenschaft | Erfüllt? | Begründung |
|---|---|---|
| messbar | | |
| beeinflussbar | | |
| relevant | | |
| fokussierend | | |

**Actionable:** Wenn die Zahl sich verändert, verstehen wir es so: …
**Verworfene Kandidaten und warum:** …
**Wechsel prüfen, wenn:** …
**Bezug zur North Star Metric (falls vorhanden):** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Ist es genau eine Metrik, nicht zwei?
- Ist sie eine Actionable Metric, also verstehst du, warum sie sich bewegt, und kannst reagieren?
- Kann das Team sie durch seine Arbeit selbst bewegen?
- Ist festgelegt, wann ihr die OMTM überprüft und wechselt?

## Im Flywheel

Modul SHIP, Bereich S1 Set Goals.

Verwandte Skills:
- `north-star-metric`: das langfristige, strategische Gegenstück. Das Buch grenzt OMTM ausdrücklich davon ab.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S1 Set Goals, Abschnitt OMTM. Originalquelle: Alistair Croll, Benjamin Yoskovitz: Lean Analytics.
Original: Alistair Croll, Benjamin Yoskovitz: Lean Analytics. Use Data to Build a Better Startup Faster, O'Reilly, 2013.
