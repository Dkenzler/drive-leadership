---
name: letting-go
description: Eine Trennung von einem Teammitglied prüfen, vorbereiten und würdevoll durchführen, aus dem Drive Leadership Playbook (Dominik Kenzler, Prüffragen nach Kim Scott, Muster nach Claire Hughes Johnson). Nutze diesen Skill, wenn jemand überlegt, sich von einer Person im Team zu trennen, eine Entscheidung immer wieder aufschiebt, ein Trennungsgespräch vorbereiten, die eigene Botschaft formulieren, das Gespräch mit dem People-Team abstimmen oder das Team nach einer Trennung informieren will. Führt durch drei Prüffragen vor der Entscheidung, das kurze Trennungsgespräch mit Klarheit, Kontext und Würde, und die Kommunikation danach.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L3 Hire & Let Go
  origin: Dominik Kenzler; Prüffragen nach Kim Scott, Muster nach Claire Hughes Johnson
  deep_dive: false
  version: "1.0"
---

# Letting Go

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, mit Prüffragen nach Kim Scott und Mustern nach Claire Hughes Johnson.

## Worum es geht

Hiring ist nur die eine Seite. Die andere ist die Bereitschaft, sich von Menschen zu trennen, wenn es nicht passt. Laut Molly Graham liegen die besten Hiring-Expertinnen und -Experten weltweit in etwa der Hälfte der Fälle richtig. Sich von einem Teammitglied zu trennen, ist das Schwierigste, was ein Leader lernen muss. Am Ende geht es darum, das Richtige für das Unternehmen und für alle anderen im Team zu tun.

Das Schlimmste ist, das Thema zu ignorieren oder aufzuschieben. Ein Teammitglied, das nicht passt oder schlecht performt, beeinflusst oft die Leistung mehrerer anderer negativ. Das Team muss härter arbeiten, Standards sinken, und du verlierst das Vertrauen der Leute, die ihren Job gut machen. Kim Scott: Wer schlechte Leistung toleriert, bestraft die Menschen, die gute Arbeit machen. Sitzt ein schlechter Hire auf Senior-Level, stellt er möglicherweise weitere Leute ein, die nicht passen (Claire Hughes Johnson). Deshalb: Handle schnell, aber handle gut.

Der Reframe nach Kim Scott: Es geht nicht darum, dass die Person schlecht ist, sondern dass es nicht passt. Jemand, der hier nicht funktioniert, kann in einem anderen Umfeld herausragend sein. Aus dieser Haltung verändern sich Ton, Würde und die Chance, dass die Person den nächsten Schritt als Neuanfang erlebt.

## Wann du sie einsetzt

- Wenn jemand trotz klarer Gespräche über Erwartungen und konkretem Feedback nicht ins Team passt oder dauerhaft nicht performt.
- Wenn du merkst, dass du eine Entscheidung mit immer neuen Begründungen aufschiebst.
- Im Quadranten niedriger Skill, niedriger Will der Skill-Will-Matrix: Dort ist eine Trennung in den meisten Fällen die richtige Entscheidung.
- In der Probezeit, wenn sich Bedenken aus dem Hiring bestätigen.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welche Rolle und welches Level geht es? Was ist bisher passiert (Gespräche, Feedback, Zeitraum)? Ist die Entscheidung schon getroffen, oder steht sie noch aus? Frag nichts, was die Person schon gesagt hat.
- Ist die Entscheidung noch offen, beginne mit den drei Prüffragen. Ist sie getroffen, geh direkt zur Gesprächsvorbereitung.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Erkennst du eine der vier Ausreden, benenne sie direkt.
- Arbeits- und vertragsrechtliche Fragen (Fristen, Konditionen, Formalien) beantwortest du nicht. Verweise dafür auf das People-Team, das laut Buch im Gespräch dabei ist.
- Erfinde nichts über die betroffene Person. Arbeite nur mit dem, was die Führungskraft schildert.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**1. Die Ausreden erkennen.** Kim Scott beschreibt in »Radical Candor« vier Lügen, die sich Manager erzählen, um nicht handeln zu müssen: Es wird schon besser. Jemand ist besser als niemand. Ein interner Wechsel löst das Problem. Eine Trennung wäre schlecht für die Moral.
Frage: *»Welche dieser Begründungen hast du dir in den letzten Wochen selbst gegeben?«*

**2. Drei Prüffragen vor der Entscheidung (nach Kim Scott).** Sie zwingen dich, ehrlich zu reflektieren, ob du deinen Teil getan hast.
- **Klares Feedback?** Hast du klares und konkretes Feedback gegeben, nicht ein Mal, sondern mehrmals über einen angemessenen Zeitraum? Hast du gezeigt, dass dir die Person wichtig ist, und gleichzeitig unmissverständlich benannt, was sich ändern muss? Wenn ja und sich nichts verbessert hat, ist das ein wertvolles Signal.
- **Wirkung aufs Team?** Wie beeinflusst die Performance dieser Person den Rest des Teams? In der Regel hat das Team das Problem längst bemerkt.
- **Zweite Meinung?** Hast du eine zweite Meinung eingeholt? Manchmal glaubt man, klar kommuniziert zu haben, obwohl die Botschaft nicht angekommen ist.

Wenn alle drei Fragen mit Ja beantwortet sind und keine Verbesserung eingetreten ist: handle. Ist eine Frage mit Nein beantwortet, benenne, was zuerst fehlt.

**3. Muster nach Level wählen (nach Claire Hughes Johnson).**
- **Juniorrollen:** Das Gespräch ist kurz und klar: Zusammenfassung der bisherigen Gespräche, Einschätzung, Entscheidung. Nicht verhandeln, nicht diskutieren.
- **Seniorrollen:** Der Prozess ist länger. Oft kommen beide Seiten über mehrere Gespräche gemeinsam zu dem Schluss, dass es nicht passt. Wenn nicht, musst du dir klar werden: »Ich sehe nicht, dass wir die Lücke zwischen dem, was gebraucht wird, und dem, was geliefert wird, schließen können.«

**4. Botschaft aufschreiben.** Schreib deine Botschaft vorher auf. Du musst sie nicht ablesen, aber der Text gibt dir einen Anker, weil diese Gespräche auch für dich schwierig und emotional sind. In beiden Mustern achtest du auf drei Dinge:
- **Klarheit:** Die Entscheidung steht. Es ist kein Verhandlungsgespräch.
- **Kontext:** Erkläre, wie es zu der Entscheidung kam, mit Bezug auf die vorherigen Gespräche.
- **Würde:** Wie du dieses Gespräch führst, definiert dich als Führungskraft und wie dein Team dich wahrnimmt.

Frage: *»Wie lauten deine ersten drei Sätze, und wie begründest du die Entscheidung mit Bezug auf die bisherigen Gespräche?«*

**5. Gespräch mit dem People-Team abstimmen.** Im besten Fall führst du es zusammen mit einer erfahrenen Person aus dem People-Team. Du startest und überbringst Nachricht und Begründung, in der Regel fünf Minuten. Danach erklärt die Person aus dem People-Team in etwa fünf Minuten die nächsten Schritte und den Ablauf. Insgesamt zehn bis fünfzehn Minuten, lieber ein Follow-up im Nachgang. Mache maximal faire Angebote: Eine Trennung ist für die betroffene Person ein tiefer Einschnitt, oft auch finanziell.

**6. Das Gespräch.** In den ersten Sätzen direkt zum Punkt, kein Small Talk, kein Intro. Formulierung aus dem Buch:
»Danke, dass du dir die Zeit genommen hast. Ich habe heute leider ein schwieriges Thema mit dir zu besprechen. Wir haben die Entscheidung getroffen, uns von dir zu trennen.« Pause. Auf die Reaktion warten. Dann: »Ich werde dir gleich erläutern, warum.«
Droht eine Debatte: »In dem Meeting heute geht es darum, dir diese Botschaft mitzuteilen. Wir wissen, dass es nicht leicht ist. Wir können gerne in den nächsten Tagen noch mal ausführlich über die Gründe sprechen.«
Praktischer Tipp: ein Glas Wasser bereitstellen, für eine kurze Trinkpause.

**7. Nach der Trennung.** Die Trennung betrifft das ganze Team. Es entstehen Fragen: Warum? Bin ich als Nächstes dran? War das fair? Kommuniziere offen, soweit es rechtlich und menschlich möglich ist: nicht die Details des Gesprächs, aber die Tatsache und die allgemeine Richtung. Gib dem Team Raum für Fragen und zeige, dass die Entscheidung durchdacht war.
Frage: *»Was sagst du dem Team, wann, und wo können sie Fragen stellen?«*

## Beispiel

Dominik Kenzlers erste Entlassung: Unter Zeitdruck hatte er eine Person eingestellt, die viele, aber nicht alle Boxen tickte. Einige Wochen später bestätigten sich seine Bedenken. Die Person war bemüht und brachte viel Gutes ein, aber zentrale Themen im Verhalten und bei den handwerklichen Fähigkeiten passten nicht. Er musste sie in der Probezeit entlassen. Es fühlte sich nach großem Fehler und Niederlage an.

## Worauf du achten musst

- **Aufschieben.** Noch ein Zyklus, noch ein Gespräch, vielleicht wird es von allein besser. Es wird nicht von allein besser.
- **Die vier Ausreden.** Es wird schon besser. Jemand ist besser als niemand. Ein interner Wechsel löst das Problem. Eine Trennung wäre schlecht für die Moral.
- **Trennung ohne Vorlauf.** Gab es vorher klare Gespräche über Erwartungen, konkretes Feedback und die Möglichkeit zur Veränderung, ist die Trennung das Ergebnis eines Prozesses und fair. Sonst ist sie ein plötzlicher Entschluss.
- **Drumherumreden.** In den ersten Sätzen direkt zum Punkt kommen, kein Small Talk, kein Intro.
- **Verhandeln oder debattieren.** Die Entscheidung steht. Gründe können in einem Follow-up besprochen werden.
- **Zu lange Gespräche.** Zehn bis fünfzehn Minuten.
- **Die Person als schlecht behandeln.** Es passt nicht, das ist etwas anderes.
- **Das Team vergessen.** Die Trennung betrifft das ganze Team. Es entstehen Fragen: Warum? Bin ich als Nächstes dran? War das fair?

## Ergebnis

```markdown
# Trennung: Vorbereitung [Rolle, Level]
Stand: …

## Prüffragen
- Klares, konkretes Feedback, mehrmals, über angemessenen Zeitraum: ja / nein · Belege: …
- Wirkung auf das Team: …
- Zweite Meinung eingeholt von: … · Ergebnis: …
- Erkannte Ausreden: …
→ Bereit zu handeln: ja / nein, zuerst noch: …

## Gespräch
Muster: Junior (kurz, klar) / Senior (mehrere Gespräche)
People-Team: … · Termin: … · Dauer: 10 bis 15 Min

Einstieg (wörtlich): …
Begründung mit Bezug auf bisherige Gespräche: …
Satz, falls eine Debatte droht: …
Angebot / Konditionen (mit People-Team klären): …
Follow-up: …

## Danach
Kommunikation ans Team (Tatsache, allgemeine Richtung, keine Details): …
Wann und wo: … · Raum für Fragen: …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)
- Kannst du alle drei Prüffragen mit Ja beantworten, und ist trotzdem keine Verbesserung eingetreten?
- Hast du geprüft, ob du dir gerade eine der vier Ausreden erzählst?
- Kommst du in den ersten Sätzen zum Punkt, und steht die Entscheidung, ohne Verhandlung?
- Hast du deine Botschaft aufgeschrieben und das Gespräch mit dem People-Team abgestimmt?
- Weißt du, was du dem Team danach sagst?

## Im Flywheel

Modul LEAD, Bereich L3 Hire & Let Go. Frank Slootman in »Amp It Up«: Leader sind nur so gut wie die Menschen, mit denen sie sich umgeben. Das gilt für die, die du holst, und für die, von denen du dich trennst.

Verwandte Skills:
- `skill-will-matrix`: Niedriger Skill, niedriger Will führt zu Lower the Bar statt Raise the Bar.
- `radical-candor`: Klares Feedback, das zeigt, dass dir die Person wichtig ist, ist die erste Prüffrage.
- `hiring-scorecard`: Die andere Seite von Hire & Let Go.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L3 Hire & Let Go. Prüffragen und Reframe nach Kim Scott: Radical Candor. Muster nach Claire Hughes Johnson: Scaling People.
