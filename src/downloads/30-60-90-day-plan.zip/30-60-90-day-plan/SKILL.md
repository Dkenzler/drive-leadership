---
name: 30-60-90-day-plan
description: Einen 30/60/90-Day-Plan für das Onboarding neuer Mitarbeitender erstellen und abgleichen, aus dem Drive Leadership Playbook von Dominik Kenzler (mit Bezug auf Michael Watkins, The First 90 Days). Nutze diesen Skill, wenn eine Führungskraft eine neue Person im Team onboardet, Erwartungen für die ersten drei Monate formulieren, einen Plan für weniger erfahrene Mitarbeitende vorbereiten oder den selbst erarbeiteten Plan einer erfahrenen Person mit den eigenen Erwartungen abgleichen will. Führt durch die Phasen Verstehen und Vernetzen, Beitragen, Wirken. Nicht für die eigene Transition als Führungskraft, dafür gibt es den 90-Day-Plan aus YOURSELF.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L4 Set the Stage
  origin: Dominik Kenzler; Break-even Point nach Michael Watkins
  deep_dive: false
  version: "1.0"
---

# 30/60/90-Day-Plan

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, mit Bezug auf Michael Watkins (The First 90 Days).

## Worum es geht

Der 30/60/90-Day-Plan ist eines der etabliertesten Frameworks im Onboarding neuer Mitarbeitender. Er strukturiert die ersten drei Monate in drei Phasen mit klaren Schwerpunkten: Verstehen, Beitragen, Wirken. Nicht als starres Korsett, sondern als gemeinsamer Orientierungsrahmen für dich und die neue Person.

Michael Watkins beschreibt das Ziel jeder Transition mit dem Break-even Point: dem Moment, ab dem eine neue Person mehr Wert schafft, als sie kostet. In Befragungen von über 200 CEOs lag er im Durchschnitt bei 6,2 Monaten. Deine Aufgabe ist, diesen Zeitraum zu verkürzen. Nicht durch mehr Druck, sondern durch mehr Klarheit.

Das Framework zwingt beide Seiten, explizit zu werden. Du formulierst deine Erwartungen konkret, die neue Person bekommt Klarheit, worauf es ankommt und wie Erfolg aussieht. Der Abgleich beider Sichten ist das eigentliche Herzstück. Er macht implizite Erwartungen explizit und schafft von Anfang an eine offene Kommunikationsbasis.

## Wann du sie einsetzt

- Eine neue Person startet in deinem Team.
- Du willst erfahrene neue Mitarbeitende ihren eigenen Plan erarbeiten lassen und ihn mit deinen Erwartungen abgleichen.
- Du bereitest für weniger erfahrene Mitarbeitende einen Plan vor, den ihr gemeinsam durchgeht und anpasst.
- Während der ersten 90 Tage, um den Fortschritt regelmäßig zu besprechen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Rolle und wie erfahren ist die neue Person? Wann startet sie? Arbeitest du mit der Führungskraft (Erwartungen formulieren) oder mit der neuen Person (eigenen Plan erarbeiten)? Frag nichts, was die Person schon gesagt hat.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Sind die Ziele beobachtbare Ergebnisse oder abstrakte Absichten?
- Erfinde keine Fakten über Rolle, Team oder Unternehmen. Was fehlt, markierst du als offen.
- Liegen beide Pläne vor, erstelle eine Gegenüberstellung: was übereinstimmt, wo es Unterschiede gibt. Die Unterschiede sind Gesprächsstoff für die gemeinsame Session, nicht von dir aufzulösen.
- Schließe mit dem Plan im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**1. Eigene Erwartungen formulieren (Führungskraft).** Was soll die Person nach drei Monaten verstanden haben? Was soll sie geliefert haben? Welche Beziehungen soll sie aufgebaut haben? Konkret aufschreiben, nicht als abstrakte Ziele, sondern als beobachtbare Ergebnisse.
Frage: *»Woran würdest du nach 90 Tagen konkret sehen, dass die Person auf dem richtigen Weg ist?«* Gut ist die Antwort, wenn man sie beobachten oder messen kann.

**2. Wer schreibt den Plan?** Erfahrene Mitarbeitende erarbeiten ihren eigenen 90-Tage-Plan, bevor ihr euch zum ersten Mal zusammensetzt: Was sind ihre ersten Prioritäten? Wo wollen sie in drei Monaten ankommen? Was brauchen sie, um loszulegen? Gib ihnen ein einfaches Format mit (siehe »Ergebnis«), aber lass Raum für die eigene Einschätzung. Bei weniger erfahrenen Mitarbeitenden bereitest du den Plan vor, gehst ihn mit der Person durch und passt ihn gemeinsam an.

**3. Die drei Phasen füllen.** Die Ziele für jede Phase sind konkret und messbar. Die SMART-Kriterien aus dem DRIVE-Kapitel sind ein guter Rahmen: spezifisch, messbar, erreichbar, relevant, zeitgebunden.

- **30 Tage: Verstehen und Vernetzen.** Zuhören, Beobachten, Orientieren. Die Person lernt Unternehmen, Team, Stakeholder und die wichtigsten Prozesse kennen, stellt Fragen, beobachtet, wie Entscheidungen getroffen werden, baut Beziehungen auf. Ziel ist Verständnis, nicht Veränderung.
  Fragen für diese Phase: Was sind die drei wichtigsten Dinge, die ich über mein Team und die Organisation verstehen muss? Was funktioniert gut und sollte geschützt werden? Wo sind die größten Reibungsverluste? Welche Beziehungen muss ich aufbauen? Wie funktioniert das Business, welche Prioritäten hat das Unternehmen?

- **60 Tage: Beitragen.** Die Person arbeitet eigenständig, übernimmt erste Verantwortungsbereiche, liefert erste konkrete Ergebnisse, teilt fundierte Einschätzungen und erste Verbesserungsvorschläge. Der Moment für tieferes Feedback von dir.
  Fragen für diese Phase: Was kann ich jetzt konkret beitragen? Stimmen meine Prioritäten mit den Erwartungen überein? Welches Feedback habe ich bisher erhalten, und was nehme ich daraus mit?

- **90 Tage: Wirken.** Die Person ist angekommen, arbeitet weitgehend eigenständig, hat klare Prioritäten und nimmt echten Einfluss auf Ergebnisse. Nach 90 Tagen sollte klar sein, ob sie auf dem richtigen Weg ist. Wenn nicht, warum nicht?
  Fragen für diese Phase: Was habe ich konkret geliefert? Wo bin ich hinter meinen eigenen Erwartungen zurückgeblieben und warum? Welche Prioritäten setze ich für das nächste Quartal? Was muss sich ändern, damit ich nachhaltigen Wert schaffe?

Frage pro Phase: *»Was soll am Ende dieser Phase verstanden, geliefert oder aufgebaut sein?«*

**4. Gemeinsame Session: abgleichen.** Beide Versionen nebeneinanderlegen. Was übereinstimmt, wird bestätigt. Wo es Unterschiede gibt, entsteht ein wichtiger Dialog: Vielleicht hat die Person andere Prioritäten, als du erwartet hast, vielleicht hat sie Themen übersehen, oder du merkst, dass deine Erwartungen zu hoch oder zu wenig ambitioniert sind. Ergebnis ist ein gemeinsamer Plan, hinter dem beide stehen.

**5. Regelmäßig draufschauen.** Den Plan während der ersten 90 Tage gemeinsam nutzen und den Fortschritt regelmäßig besprechen.
Frage: *»Wann schaut ihr gemeinsam auf den Plan?«*

## Worauf du achten musst

- **Sofort umgestalten.** Ein häufiger Fehler in den ersten 30 Tagen: Die neue Person verändert Dinge, bevor sie verstanden hat, warum sie so sind, wie sie sind.
- **Abstrakte Ziele.** Erwartungen als beobachtbare Ergebnisse formulieren, konkret und messbar.
- **Plan nur von einer Seite.** Der Plan funktioniert am besten, wenn er nicht nur von dir kommt. Der Abgleich ist genauso wertvoll wie der Plan selbst.
- **Starres Korsett.** Es ist ein gemeinsamer Orientierungsrahmen.
- **Mehr Druck statt mehr Klarheit.** Der Break-even Point verkürzt sich durch klare Erwartungen, nicht durch Druck.
- **Plan in der Schublade.** Nutzt den Plan gemeinsam, schaut während der ersten 90 Tage regelmäßig drauf und besprecht den Fortschritt.

## Ergebnis

```markdown
# 30/60/90-Day-Plan: [Name, Rolle]
Start: … · Führungskraft: … · Abgleich-Session am: …

## Erwartungen der Führungskraft nach 90 Tagen
- Verstanden: …
- Geliefert: …
- Beziehungen aufgebaut: …

| Phase | Fokus | Ziele (konkret, messbar) | Wichtige Beziehungen | Check-in |
|---|---|---|---|---|
| 30 Tage | Verstehen und Vernetzen | | | |
| 60 Tage | Beitragen | | | |
| 90 Tage | Wirken | | | |

## Abgleich
- Übereinstimmung: …
- Unterschiede, besprochen: …
- Was die Person braucht, um loszulegen: …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)
- Sind deine Erwartungen als beobachtbare Ergebnisse formuliert, konkret und messbar?
- Hat die Person (wenn erfahren) einen eigenen Plan erarbeitet, und habt ihr beide Versionen abgeglichen?
- Liegt der Fokus der ersten 30 Tage auf Verständnis, nicht auf Veränderung?
- Ist nach 90 Tagen klar erkennbar, ob die Person auf dem richtigen Weg ist?
- Sind regelmäßige Termine eingeplant, an denen ihr auf den Plan schaut?

## Im Flywheel

Modul LEAD, Bereich L4 Set the Stage.

Verwandte Skills:
- `90-day-plan`: Dieselbe Logik aus Michael Watkins' »The First 90 Days«, im YOURSELF-Kapitel angewandt auf deine eigene Transition als Führungskraft. Nicht verwechseln.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L4 Set the Stage. Break-even Point nach Michael Watkins: The First 90 Days.
