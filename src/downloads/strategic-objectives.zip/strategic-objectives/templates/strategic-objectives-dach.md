# Strategic Objectives: Das Dach

Nach Abb. 3.22 im Drive Leadership Playbook.

**Organisation / Ebene:**
**Stand:**
**Horizont:** etwa drei Jahre, bis
**Beteiligte:**

## Vision
(euer Zukunftsbild)

## Strategic Objectives

| Rang | Objective | Rückführung auf die Vision |
|---|---|---|
| 1 | Objective 1: | |
| 2 | Objective 2: | |
| 3 | Objective 3: | |
| + optional | Objective 4: | |
| + optional | Objective 5: | |

Qualitativ, merkbar, ohne Key Results, ohne Kennzahlen.

## Kürzere Formate (zahlen ein auf)

| Format | Ziel | Zahlt ein auf Objective |
|---|---|---|
| OKRs | | |
| Quartalsziele | | |
| Teamziele | | |

## Dach-Test

**Vorhaben, die zu keinem Objective passen** (streichen oder fehlendes Objective?):

**Objectives, auf die nichts einzahlt** (totes Papier oder Lücke in der Umsetzung?):

**Entscheidungen daraus:**
