---
name: strategic-objectives
description: Strategic Objectives festlegen, aus dem Drive Leadership Playbook von Dominik Kenzler. Drei bis fünf mehrjährige Unternehmensziele, die als Dach über OKRs, Quartals- und Teamzielen stehen. Nutze diesen Skill, wenn jemand strategische Ziele für Unternehmen, Bereich oder Abteilung aus einer Vision ableiten, zu viele Ziele auf wenige verdichten, eine Führungsrunde zu Zielen vorbereiten oder prüfen will, ob laufende Vorhaben und OKRs auf die großen Ziele einzahlen (Einzahlungs-Test, Dach-Test). Auch nützlich, wenn Teams Zielkonflikte haben und ein Maßstab für Priorisierung fehlt.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D3 Set Strategic Goals
  origin: Dominik Kenzler
  deep_dive: true
  version: "1.0"
---

# Strategic Objectives

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Strategic Objectives sind die drei bis fünf zentralen Ziele eines Unternehmens, typischerweise auf einen Horizont von etwa drei Jahren angelegt. Sie beantworten genau eine Frage: Was sind die wenigen Dinge, die wir in den nächsten Jahren unbedingt erreichen müssen, um unsere Vision zu verwirklichen?

Sie sind das Dach über allen anderen Zielformaten. OKRs, Quartalsziele und Teamziele zahlen auf diese drei bis fünf Ziele ein. Daraus leistet die Methode dreierlei:

- **Maßstab für Priorisierung.** Strategic Objectives sind der Referenzpunkt, an dem Entscheidungen gemessen werden. Zahlt ein Ziel oder Vorhaben auf keines ein, ist es entweder falsch priorisiert, oder es fehlt ein Strategic Objective. Beides ist eine wertvolle Erkenntnis.
- **Fokus auf wenige Dinge.** Die Begrenzung auf drei bis fünf zwingt zur Auswahl der Ziele, die wirklich über Erfolg oder Misserfolg der nächsten Jahre entscheiden.
- **Brücke zwischen Vision und Alltag.** Die Vision ist langfristig und abstrakt, die Quartalsplanung kurzfristig und konkret. Strategic Objectives übersetzen die Richtung in wenige mehrjährige Ziele, an die sich alle kürzeren Formate anhängen.

Abgrenzung: Strategic Objectives stehen auf Company-Level, haben einen Horizont von mindestens einem Jahr, besser mehreren, und stehen für sich, ohne Key Results. Sie sagen, was unbedingt erreicht werden muss, nicht, woran es im nächsten Quartal gemessen wird. Das ist die Aufgabe der Formate darunter.

Welche Ziele sinnvoll sind, hängt auch vom Kontext des Unternehmens ab: An der Börse zählen Quartalszahlen und Shareholder Value, bei Private Equity Effizienz und Exit-Horizont, bei Venture Capital schnelles Wachstum, bei gründergeführten Unternehmen die langfristige Vision. Wer das ignoriert, plant an der Realität vorbei.

## Wann du sie einsetzt

- Eine Vision liegt vor, aber es fehlen die wenigen großen Ziele, an denen sich alles ausrichtet.
- Es gibt zu viele Ziele: Entscheidungen dauern lange, Teams haben Zielkonflikte, Themen werden eskaliert, weil sie auf der eigenen Ebene nicht lösbar sind.
- Vor einer OKR- oder Jahresplanung, damit die kürzeren Formate ein gemeinsames Dach haben.
- Um bestehende Vorhaben zu prüfen: Was zahlt worauf ein, was bindet nur Ressourcen?

Strategic Objectives gehören auf die Führungsebene, die für die jeweilige Ebene verantwortlich ist, ob Unternehmen, Bereich oder Abteilung.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Ebene gelten die Ziele (Unternehmen, Bereich, Abteilung)? Gibt es eine formulierte Vision? Arbeitet die Person allein oder bereitet sie eine Arbeitssitzung mit der Führungsrunde vor? Frag nichts, was sie schon gesagt hat.
- Ohne Vision keine Strategic Objectives, denn sie leiten sich aus ihr ab. Fehlt die Vision, sag das und schlag vor, sie zuerst zu klären.
- Bereitet die Person eine Sitzung vor, erstelle Set-up, Ablauf und Moderationsfragen für eine Arbeitssitzung von einem halben bis ganzen Tag plus zweite Runde nach einigen Tagen. Arbeitet sie allein, geh den Ablauf mit ihr durch und markiere am Ende, was die Führungsrunde noch entscheiden muss.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen, wenn sie schon Material hat.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Sind es mehr als fünf? Stecken Kennzahlen oder Quartalslogik drin? Benenne Schwächen direkt und kurz. Kein Lob als Füllmaterial.
- Will die Person Zahlen an die Objectives hängen, verweise sie auf die Formate darunter (OKRs, Goals im OGSM). Die Objectives selbst bleiben qualitativ.
- Erfinde keine Fakten über die Organisation der Person. Fehlt etwas, markiere es als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Im Buch als kompakte Arbeitssitzung beschrieben, ein halber bis ganzer Tag, mit einer zweiten Runde nach einigen Tagen Abstand.

**Set-up.** Die Führungsrunde, die für die Ausrichtung der jeweiligen Ebene verantwortlich ist. Die Vision steht für alle sichtbar im Zentrum, auf einem digitalen Board oder einem physischen Whiteboard. Daneben analoge oder digitale Post-its. Erst wird gesammelt, reduziert wird später.

1. **Die Vision als Ausgangspunkt klären.** Bevor ihr Ziele sammelt, vergewissert ihr euch über die Vision, der die Objectives dienen sollen.
   Frage: *»Wie lautet eure Vision, und teilt die Runde dasselbe Verständnis davon?«* Gut ist die Antwort, wenn die Vision in einem Satz dasteht und nicht erst in der Sitzung erfunden wird.

2. **Alle sammeln zusammen.** Breit sammeln, ohne zu werten. In dieser Phase zählt, dass alle ihre Sicht auf die wenigen großen Themen einbringen.
   Frage: *»Was muss in etwa drei Jahren wahr sein, damit ihr eurer Vision wirklich näher gekommen seid?«* Gut ist die Antwort, wenn es Zustände oder Ergebnisse sind, keine Maßnahmen und keine Quartalsmeilensteine.

3. **Auf drei bis fünf Ziele verdichten.** Der schwierige Teil ist das Streichen. Für jeden Kandidaten die Probe: Müssen wir das unbedingt erreichen? Nur das Unbedingte bleibt. Fällt das Reduzieren schwer, helfen mehrere Runden aus Clustern und Abstimmen: verwandte Kandidaten gruppieren, die Runde die wichtigsten markieren lassen, wiederholen, bis sich die wenigen herauskristallisieren. Immer wieder fragen, ob es ein übergeordnetes Thema gibt, das mehrere Kandidaten zu einem Ziel zusammenfasst.
   Frage: *»Welcher Kandidat wäre verzichtbar, wenn ihr ehrlich seid?«* Gut ist das Ergebnis, wenn drei bis fünf Ziele bleiben und keines davon verzichtbar ist.

4. **Schärfen und formulieren.** Jedes Objective klar, qualitativ und so, dass man es sich merken kann. Keine Key Results, keine Kennzahlen an dieser Stelle. Jedes Objective steht für sich und ist ohne Erklärung verständlich. Stehen mehrere Ziele nebeneinander, braucht es eine klare Rangfolge: Wenn zwei kollidieren, muss es einen klaren Gewinner geben.
   Frage: *»Würde jemand außerhalb der Runde das Objective ohne Erklärung verstehen? Und welches gewinnt, wenn zwei kollidieren?«*

5. **Dach-Test in beide Richtungen.** Von den Vorhaben hinauf zu den Objectives und von den Objectives hinunter zu dem, was auf sie einzahlt. Der Normalfall ist die Passung. Interessant sind zwei Befunde:
   - Vorhaben, die zu keinem Objective passen: Kandidaten zum Streichen oder Hinweis auf ein fehlendes Objective.
   - Objectives, auf die nichts einzahlt: totes Papier oder eine Lücke in der Umsetzung.
   Frage: *»Nenn mir eure größten laufenden Vorhaben. Auf welches Objective zahlt jedes ein?«* Gut ist das Ergebnis, wenn jede Lücke benannt und eine Entscheidung dazu getroffen ist.

Nach einigen Tagen Abstand: zweite Runde, um Formulierungen und Auswahl mit frischem Blick zu prüfen.

## Beispiel

Microsoft: Als Satya Nadella 2014 die Führung übernahm, fasste er die Ausrichtung des Konzerns in drei Ambitionen: Produktivität und Geschäftsprozesse neu erfinden, intelligente Cloud-Plattform bauen und persönlicheres Computing schaffen. Diese drei Sätze wurden für Jahre der Bezugspunkt für Produkte, Investitionen und Reorganisationen. Wer etwas vorschlug, musste zeigen, auf welche der drei Ambitionen es einzahlt.

Durchgängiges Beispiel aus dem Buch: Eine Plattform will Handwerksbetriebe und Privatkunden zusammenbringen. Vision: handwerkliche Leistungen so einfach buchbar machen wie einen Tisch im Restaurant.

1. In den drei größten Metropolregionen die erste Anlaufstelle werden, mit so vielen aktiven Betrieben, dass auf jede Anfrage schnell ein passendes Angebot kommt.
2. Vertrauen zum Hauptgrund machen, warum man uns wählt, erkennbar daran, dass Kundschaft uns wegen Verlässlichkeit und Qualität weiterempfiehlt.
3. Pro Auftrag profitabel werden, sodass weiteres Wachstum sich aus sich selbst trägt.

Einzahlungs-Test: Ein aufwendiges Bewertungssystem für Betriebe zahlt klar auf Objective 2 ein. Der Vorschlag, früh in eine vierte Region zu expandieren, bevor die ersten drei tragen, passt zu keinem der drei. Entweder ist er falsch priorisiert, oder es fehlt ein Objective, das die Expansion rechtfertigt. Diese Frage gehört gestellt, bevor Ressourcen fließen.

Zur Rangfolge: Bei Facebook war Engagement wichtiger als Growth. Bei sevdesk war in einem Jahr Growth das wichtigste Ziel, im Folgejahr die Marge. Growth blieb zweitwichtigstes Ziel, aber wann immer ein Team zwischen beiden priorisieren musste, war die Guidance klar.

## Worauf du achten musst

- **Zu viele Objectives.** Mehr als fünf, und der Fokus ist weg. Eine lange Liste ist kein Dach, sondern die übliche Sammlung, in der alles wichtig ist. Molly Graham: »Kein Unternehmen braucht mehr als drei Unternehmensziele.«
- **Mit OKRs oder Quartalszielen verwechseln.** Strategic Objectives sind mehrjährig, auf Company-Level und stehen ohne Key Results. Wer sie quartalsweise und mit Kennzahlen formuliert, hat OKRs.
- **Zu vage, um zu priorisieren.** Konkurrieren zwei Vorhaben um Ressourcen und die Objectives helfen nicht bei der Entscheidung, sind sie zu unscharf.
- **Keine Rangfolge.** Wirken alle Ziele gleichwertig, gibt es keine Strategie, sondern eine Wunschliste. Echte Priorisierung bedeutet, Dinge nicht zu tun. Protestiert niemand im Raum, wurde nicht hart genug priorisiert.
- **Als Deko behandeln.** Objectives wirken nur, wenn sie der tatsächliche Filter für Entscheidungen sind. Stehen sie nur auf einer Folie, sind sie wertlos. Dasselbe gilt, wenn am Ende nichts wegfällt: Richtiger Fokus zeigt sich erst im bewussten Nein.
- **Aus der Vision lösen.** Ein Objective, das sich nicht auf die Vision zurückführen lässt, gehört nicht aufs Dach. Es zieht Energie ab.
- **Ziele setzen und liegen lassen.** Ziele allein reichen nicht. Ohne Follow-up, Review-Rhythmus und Lernen bleiben sie Wunschdenken.

## Ergebnis

Drei bis fünf formulierte Objectives in Rangfolge, abgeleitet aus der Vision, dazu das Ergebnis des Dach-Tests. Vorlage: `templates/strategic-objectives-dach.md`.

```markdown
# Strategic Objectives: [Organisation / Ebene]
Stand: [Datum] · Horizont: [etwa 3 Jahre, bis ...] · Beteiligte: [Namen oder Rollen]

**Vision:** …

| Rang | Strategic Objective (qualitativ, ohne Kennzahl) | Rückführung auf die Vision |
|---|---|---|
| 1 | … | … |
| 2 | … | … |
| 3 | … | … |
| (4, 5 optional) | … | … |

**Bei Kollision gewinnt:** Objective … vor Objective …

**Dach-Test**
| Vorhaben / OKR / Teamziel | Zahlt ein auf | Befund |
|---|---|---|
| … | Objective … / keines | passt · streichen · fehlendes Objective? |

**Objectives ohne Einzahlung:** … (totes Papier oder Lücke in der Umsetzung?)
**Offene Punkte:** …
```

## Mini-Check

- Habt ihr drei bis fünf Strategic Objectives?
- Lässt sich jedes Objective auf die Vision zurückführen?
- Sind sie qualitativ und mehrjährig formuliert, ohne Key Results?
- Lässt sich jedes laufende Ziel oder Vorhaben einem Objective zuordnen?
- Gibt es ein Objective, auf das nichts einzahlt, oder ein Vorhaben, das zu keinem passt?

## Im Flywheel

Modul DRIVE, Bereich D3 Set Strategic Goals.

Verwandte Skills:
- `okrs`: OKRs sind die quartalsweise Übersetzung mit Key Results. Ein Objective kann für ein Jahr zum Anker mehrerer OKRs werden.
- `ogsm`: Ein Strategic Objective kann als Objective in einen OGSM einfließen.
- `north-star-metric`: Die North Star Metric ersetzt die Strategic Objectives nicht, gibt ihnen aber eine gemeinsame Richtung.

Einordnung laut Buch: Über den Strategic Objectives steht die Vision, das langfristige, oft zeitlose Zukunftsbild. Darunter stehen die kürzeren Formate, die die Objectives in messbare, terminierte Schritte übersetzen. Der eigentliche Wert liegt in der Diagnose: Ohne das Dach bleiben Vorhaben ohne Wirkung und Objectives ohne Umsetzung meist unsichtbar, weil jedes Ziel für sich plausibel wirkt.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D3 Set Strategic Goals und Deep Dive Strategic Objectives. Zitat Molly Graham aus einem Podcast über Leadership.
