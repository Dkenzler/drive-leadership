---
name: trojan-horse-draft
description: Trojan Horse Draft (im Buch auch Draft-Prinzip), von Dominik Kenzler bei Jonathan Abon (VP Product, Utopia Music) abgeschaut, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn ein wichtiges Thema festhängt, weil ein anderes Team nicht kooperiert, eine Entscheidung außerhalb deiner Autorität liegt, niemand Ownership übernimmt oder ein Vakuum entsteht, das sonst jemand anderes füllt. Hilft, schnell einen bewusst unfertigen Entwurf zu erstellen und so einzubringen, dass er Urgency erzeugt und andere in Bewegung bringt, ohne Perfektion zu beanspruchen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S4 Make Fast Decisions
  origin: Jonathan Abon
  deep_dive: false
  version: "1.0"
---

# Trojan Horse Draft

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Jonathan Abon.

## Worum es geht

Entscheidungen scheitern oft nicht an der Entscheidung selbst, sondern an dem, was folgt: Blockaden, ungeklärte Abhängigkeiten, fehlende Ressourcen, organisatorische Trägheit. Das Draft-Prinzip arbeitet genau dagegen an: einfach anfangen, auch wenn es nicht der eigene Ownership-Bereich ist, und damit andere dazu bringen, sich zu bewegen.

Der Kern: Wenn es in einer Organisation ein Vakuum gibt und ein Draft existiert, wird dieser Draft Realität. Er ist besser als nichts, und Mitarbeitende fangen an, damit zu arbeiten.

Ein Draft gibt maximale Flexibilität. Du steuerst selbst, wie aggressiv du eine Idee pushst. Du kannst immer sagen: »Hey, das ist nur eine erste Idee, ich habe mal ein bis zwei Stunden darüber nachgedacht.« Du bist kaum angreifbar, weil du keine Perfektion beanspruchst, und hast trotzdem Momentum erzeugt.

Das Draft-Prinzip ist kein Mikromanagement. Es greift nicht in die Arbeit des eigenen Teams ein, sondern schafft Momentum in dessen Umgebung: Es räumt externe Hindernisse aus dem Weg und bringt andere in Bewegung. Wer anfängt, die internen Entscheidungen des Teams zu übernehmen, folgt keinem Draft-Prinzip mehr, sondern wird zum Flaschenhals.

## Wann du sie einsetzt

- Ein anderes Team kooperiert nicht, und dein Team kann das Problem nicht allein lösen.
- Eine organisatorische Entscheidung liegt außerhalb deiner Autorität.
- Es gibt ein Vakuum, das jemand anderes füllt, wenn du es nicht tust.
- Ein Thema ist wichtig, hat aber bei anderen eine geringere Dringlichkeit als bei dir.

In all diesen Fällen ist deine Aufgabe klar: Fang an, räum es aus dem Weg, schaffe eine Grundlage. Das setzt voraus, dass du den Punkt kennst, an dem dein Team blockiert ist. Das erfährst du nicht im Weekly Status-Update, sondern im direkten Gespräch.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welches Thema hängt fest? Wessen Ownership-Bereich ist es? Wer muss sich bewegen, damit es vorangeht? Frag nichts, was die Person schon gesagt hat.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist das ein externes Hindernis oder eine interne Entscheidung des Teams? Ist das eigene Ziel transparent? Benenne Schwächen direkt und kurz.
- Hilf beim Aufbau des Drafts nur mit Struktur und Fragen. Inhalte über Produkt, Organisation oder Kundschaft der Person erfindest du nicht. Was fehlt, markierst du als offen.
- Biete an, die Formulierung vorzubereiten, mit der die Person den Draft einbringt.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Blockade finden.** Regelmäßig fragen, statt auf Eskalation zu warten. Eine der wirkungsvollsten Fragen: »Was hält euch gerade auf?«
   Frage: *»Was hält dein Team gerade auf, und liegt das innerhalb oder außerhalb eures Einflussbereichs?«* Gut ist die Antwort, wenn die Blockade konkret ist und außerhalb der internen Teamentscheidungen liegt.

2. **Vakuum benennen.** Wo fehlt ein Entwurf, eine Vision, ein Vorschlag, auf den sich andere beziehen könnten?
   Frage: *»Was fehlt, das andere in Bewegung bringen würde, wenn es als Entwurf existierte?«*

3. **Draft schnell erstellen.** Einfach anfangen, mit wenig Aufwand, notfalls zusammen mit einer weiteren Person. Kein Anspruch auf Perfektion.
   Frage: *»Was ist die kleinste Version, die zeigt, wie es aussehen könnte, und mit wem baust du sie?«*

4. **Ziel transparent machen und Draft einbringen.** Den Draft als Startsignal kommunizieren, nicht als finale Version, und das eigene Ziel offen sagen.
   Frage: *»Wo bringst du den Draft ein, und wie sagst du, dass es eine erste Idee ist und worum es dir geht?«* Gut ist die Antwort, wenn der Draft als Startsignal gerahmt ist und das eigene Ziel, etwa Urgency, benannt wird.

5. **Dosieren.** Selbst steuern, wie stark du die Idee pushst.
   Frage: *»Wie stark willst du die Idee pushen, und woran merkst du, dass sich andere bewegen?«*

6. **Übergeben.** Wenn andere sich bewegen und eine bessere Version entsteht, ist das Ziel erreicht. Es geht nicht darum, die beste Version selbst gestaltet zu haben.
   Frage: *»Wem übergibst du das Thema, sobald es Fahrt aufnimmt?«*

## Beispiel

Bei Utopia Music war Dominik Kenzler VP Design, Jonathan Abon leitete als VP Product eine von neun Business Units. Jonathan wollte so schnell wie möglich eine holistische UX Vision über alle Business Units. Dominik fand das auch wichtig, konnte es mit seinem Team aber erst im nächsten Quartal angehen. Eine Woche später präsentierte Jonathan im Senior Leadership Meeting eine erste Vision, die er mit einer Designerin entwickelt hatte. Nur ein Draft, weit von Dominiks Qualitätsanspruch entfernt. Dominik war klar, dass er handeln musste: In zwei Nächten entwickelte er mit Max Tillich aus seinem Team eine eigene UX Vision, nahm ein Recording des Prototypen auf und teilte es im Leadership-Kreis. Jonathan kämpfte nicht um seine Version, sondern fand die neue deutlich besser. Ihm ging es nie um die beste Version, sondern um Urgency, und die erzeugte er mit seinem Draft.

Später bei sevdesk lag das Brand Design Team außerhalb von Dominiks direktem Verantwortungsbereich. Er schloss das Brand-Thema trotzdem in die Design Vision ein und schaffte so ein holistisches Redesign inklusive Brand.

## Worauf du achten musst

- **Reaktiv statt proaktiv.** Der häufigste Fehler: Führungskräfte warten, bis ein Problem eskaliert, statt regelmäßig nach Blockaden zu fragen. Bis das Problem sichtbar ist, sind Wochen vorbei.
- **Zu viel Draft-Prinzip.** Wer jedes kleine Hindernis selbst löst, verhindert, dass das Team lernt, Probleme zu navigieren.
- **Ziel verschweigen.** Wer einen Draft einbringt, ohne das eigene Ziel transparent zu machen, riskiert Konflikte. Jonathan hat es richtig gemacht, weil er den Draft als Startsignal und nicht als finale Vision kommuniziert hat.
- **In die Arbeit des Teams eingreifen.** Wer die internen Entscheidungen des Teams übernimmt, schafft kein Momentum, sondern wird zum Flaschenhals.

## Ergebnis

```markdown
# Draft: [Thema]
Datum: [Datum] · Von: [Name]

**Blockade / Vakuum:** …
**Wessen Ownership-Bereich:** …
**Wer muss sich bewegen:** …

**Draft (kleinste Version):** …
**Aufwand:** … · **Mit:** …

**Einbringen in:** [Meeting / Kanal]
**Rahmung:** »Hey, das ist nur eine erste Idee …« · **Mein Ziel:** …
**Wie stark pushen:** zurückhaltend / deutlich
**Übergabe an:** … sobald …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Fragst du regelmäßig nach Blockaden, statt auf Eskalation zu warten?
- Liegt das Hindernis außerhalb deines Teams, oder greifst du in dessen interne Entscheidungen ein?
- Hast du dein Ziel offen gesagt und den Draft als Startsignal gerahmt?
- Löst du nur die Hindernisse selbst, die dein Team nicht allein lösen kann?

## Im Flywheel

Modul SHIP, Bereich S4 Make Fast Decisions.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S4 Make Fast Decisions. Originalquelle: Jonathan Abon, VP Product bei Utopia Music.
