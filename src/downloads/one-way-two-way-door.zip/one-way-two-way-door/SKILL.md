---
name: one-way-two-way-door
description: Two-Way versus One-Way Door nach Jeff Bezos (Amazon, beschrieben in »Working Backwards« von Colin Bryar und Bill Carr), ergänzt um Magnitude mal Reversibilität von Gibson Biddle, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand einschätzen will, wie viel Zeit, Analyse und Beteiligung eine Entscheidung verdient, wenn alles nach oben eskaliert wird und Teams auf Freigaben warten, oder wenn eine Führungskraft festlegen will, welche Entscheidungen ihre Teams selbst treffen. Führt dazu, Entscheidungen als umkehrbar oder irreversibel einzuordnen und danach schnell zu entscheiden, zu delegieren oder gründlich vorzugehen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S4 Make Fast Decisions
  origin: Jeff Bezos (Amazon), beschrieben von Colin Bryar und Bill Carr
  deep_dive: false
  version: "1.0"
---

# Two-Way versus One-Way Door

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Jeff Bezos, beschrieben von Colin Bryar und Bill Carr in »Working Backwards«.

## Worum es geht

Jeff Bezos hat in seinem Amazon-Aktionärsbrief von 2015 einen der einfachsten Entscheidungsfilter formuliert: One-way Door oder Two-way Door?

Eine **One-way Door** ist eine Entscheidung, die kaum rückgängig zu machen ist. Wenn man durch sie geht, gibt es keinen einfachen Weg zurück: eine Akquisition, eine Architekturentscheidung, die das System für Jahre prägt, die Einstellung einer Produktlinie. Solche Entscheidungen verdienen gründliche Analyse, breite Einbindung und ausreichend Zeit.

Eine **Two-way Door** ist reversibel. Man kann durch sie gehen, schauen, was passiert, und bei Bedarf zurückkehren: ein neues Feature ausprobieren, eine andere Priorisierung testen, eine neue Kommunikationsstruktur einführen. Solche Entscheidungen sollten schnell getroffen werden, am besten von der Person, die am nächsten am Thema dran ist. Das sind die meisten Entscheidungen im Alltag, und gerade bei ihnen wird zu viel Zeit verbraucht.

Das Problem in den meisten Organisationen: Alle Entscheidungen werden wie One-way Doors behandelt. Alles geht nach oben, alles braucht Konsens, alles wird abgesichert. Große Unternehmen neigen laut Bryar und Carr dazu, einen Entscheidungsprozess für One-way Doors zu entwickeln und ihn routinemäßig auf Two-way Doors anzuwenden. Das Ergebnis: weniger Tempo, weniger Innovation, längere Entwicklungszyklen.

Gibson Biddle, ehemals VP Product bei Netflix, ergänzt die Türfrage um eine zweite Dimension: Wie groß ist die potenzielle Wirkung? **Magnitude mal Reversibilität** beantwortet den größten Teil der Gewichtungsdebatten, die Teams lähmen.

## Wann du sie einsetzt

- Bevor du eine Entscheidung triffst oder eskalierst.
- Wenn Teams auf Freigaben warten, die sie bei klarem Rahmen nicht bräuchten.
- Wenn eine kleine, umkehrbare Frage ein einstündiges Meeting bekommt.
- Wenn du als Führungskraft festlegen willst, welche Entscheidungen deine Beteiligung brauchen und welche deine Teams eigenständig treffen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Geht es um eine konkrete Entscheidung oder um einen Rahmen für das ganze Team? Wer entscheidet heute? Was steht auf dem Spiel? Frag nichts, was die Person schon gesagt hat.
- Bei einer einzelnen Entscheidung: Schritte 1 bis 4. Bei einem Rahmen für das Team: Schritte 1 bis 3 für typische Entscheidungen, dann Schritt 5.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Wird eine Two-way Door zur One-way Door hochgestuft, weil sich Absicherung sicherer anfühlt? Wird eine echte One-way Door zu schnell durchgewunken? Benenne Schwächen direkt und kurz.
- Erfinde keine Kosten, Risiken oder Fakten über die Organisation. Was fehlt, markierst du als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Entscheidung benennen.** Was genau wird entschieden?
   Frage: *»Welche Entscheidung steht an, in einem Satz?«*

2. **Reversibilität prüfen.** Heuristik aus dem Buch: Wenn die Entscheidung in drei bis sechs Monaten ohne unverhältnismäßig große Kosten revidiert werden könnte, ist es eine Two-way Door.
   Frage: *»Könntet ihr die Entscheidung in drei bis sechs Monaten zurücknehmen, ohne unverhältnismäßig große Kosten? Was würde das kosten?«* Gut ist die Antwort, wenn sie die Kosten der Umkehr konkret benennt, statt nur ein Gefühl zu beschreiben.

3. **Magnitude einschätzen.** Wie groß ist die potenzielle Wirkung? Geringe Wirkung und hohe Reversibilität braucht kein einstündiges Meeting. Hohe Wirkung und niedrige Reversibilität verdient echte Zeit.
   Frage: *»Wie groß ist die Wirkung, wenn die Entscheidung falsch ist: gering, mittel oder hoch?«*

4. **Vorgehen festlegen.**
   - Two-way Door: schnell entscheiden oder an die Person delegieren, die am nächsten am Thema ist.
   - One-way Door: die Zeit nehmen, die sie verdient, mit gründlicher Analyse und breiter Einbindung.

   Frage: *»Wer entscheidet, bis wann, und wer muss eingebunden werden?«* Gut ist die Antwort, wenn bei einer Two-way Door ein naher Termin und eine Person stehen und bei einer One-way Door klar ist, welche Analyse und welche Beteiligten es braucht.

5. **Rahmen für das Team kommunizieren.** Welche Entscheidungen brauchen deine direkte Beteiligung, welche treffen deine Teams eigenständig? Wenn du das klar kommunizierst, gibst du Ownership ab und beschleunigst die Organisation.
   Frage: *»Welche Arten von Entscheidungen soll dein Team ab sofort ohne dich treffen, und wie erfährt es das?«*

## Beispiel

Colin Bryar und Bill Carr beschreiben in »Working Backwards«, wie Amazon Prime als Two-way Door entstand. Hätte die Kombination aus Abomodell, kostenlosem Versand und schneller Lieferung nicht funktioniert, hätte Amazon weiter an der Formel gefeilt. Prime war nicht einmal der erste Versuch, sondern ging aus Super Saver Shipping hervor, einer anderen Two-way Door.

Das Fire Phone, Amazons erstes Smartphone, war laut Buch das Gegenteil, eine One-way Door. Als Amazon das Gerät vom Markt nahm, gab es kein »Okay, das war ein Versuch, jetzt probieren wir das nächste Smartphone«. Bezos war selbst tief in die Entwicklung involviert, trotzdem scheiterte das Produkt. Er ließ sich nicht davon abbringen, weiter zu experimentieren, und sagte sinngemäß: »Wenn ihr das für ein großes Scheitern haltet, arbeiten wir gerade an viel größeren Fehlern.«

Der Punkt ist nicht, One-way Doors zu vermeiden, sondern sie als das zu behandeln, was sie sind, und sie nicht mit Two-way Doors zu verwechseln.

## Worauf du achten musst

- **Two-way Doors als One-way Doors behandeln.** Der häufigste Fehler. Das erzeugt Bürokratie, verlangsamt das Team, verhindert Experimente und signalisiert Misstrauen.
- **One-way Doors zu schnell treffen.** Das Gegenteil: irreversible Entscheidungen ohne ausreichendes Durchdenken der Konsequenzen. Das Modell hilft nur, wenn man den Unterschied wirklich macht.
- **Alles eskalieren.** Wenn alles nach oben geht und alles Konsens braucht, warten Teams auf Freigaben, die sie nicht bräuchten.

## Ergebnis

```markdown
# Entscheidungseinordnung: [Entscheidung]
Datum: [Datum]

**Entscheidung:** …
**Umkehrbar in 3 bis 6 Monaten ohne unverhältnismäßige Kosten?** ja / nein · Kosten der Umkehr: …
**Magnitude:** gering / mittel / hoch
**Einordnung:** Two-way Door / One-way Door

**Vorgehen:**
- Two-way Door: entscheidet [Name] bis [Datum]
- One-way Door: Analyse …, einbinden …, Entscheidung bis …

## Rahmen für das Team (optional)
| Entscheidungsart | Door | Wer entscheidet |
|---|---|---|
| … | Two-way | Team / [Name] |
| … | One-way | [Führungskraft] mit … |
```

## Mini-Check (SHIP Checklist)

- Unterscheidest du konsequent zwischen One-way-Door- und Two-way-Door-Entscheidungen?
- Werden Two-way-Door-Entscheidungen schnell getroffen, ohne unnötige Eskalation oder Konsenssuche?
- Weiß dein Team, wer bei welcher Entscheidung das letzte Wort hat?
- (abgeleitet aus den typischen Fehlern) Bekommen echte One-way Doors die Zeit, Analyse und Einbindung, die sie verdienen?

## Im Flywheel

Modul SHIP, Bereich S4 Make Fast Decisions.

Verwandte Skills:
- `timely-decisions`: Verweist für den Unterschied zwischen umkehrbaren und irreversiblen Entscheidungen auf diese Methode.
- `decision-log`: Im fiktiven Decision Log des Buchs ist jede Entscheidung als One-way oder Two-way Door markiert.
- `mut-zu-entscheidungen`: Greift die Methode auf: Two-way Doors können schnell und kühn getroffen werden. Eine reversible Entscheidung ist kein Risiko, sondern ein Experiment.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel SHIP, S4 Make Fast Decisions, Decision Log (Abb. 5.13), SHIP Checklist, Kapitel YOURSELF, Mut zu Entscheidungen. Originalquelle: Jeff Bezos, Amazon-Aktionärsbrief 2015, beschrieben in Colin Bryar, Bill Carr: Working Backwards. Ergänzung: Gibson Biddle.

Original: Jeff Bezos: 2015 Letter to Shareholders (Type 1 und Type 2 Decisions), 2016, https://s2.q4cdn.com/299287126/files/doc_financials/annual/2015-Letter-to-Shareholders.PDF. Colin Bryar, Bill Carr: Working Backwards, 2021.
