# PR/FAQ

Nach dem Deep Dive PR/FAQ Article und Abb. 3.19 im Drive Leadership Playbook. Umfang: höchstens zwei Seiten, die Pressemitteilung eine halbe bis ganze Seite.

**Produkt / Initiative:**
**Stand / Entwurf Nr.:**
**Beteiligte:**

## Vorab: Kunde und Problem
Für wen ist das?

Welches konkrete Problem lösen wir (ein Satz)?

## Pressemitteilung

**Überschrift** (aus Kundensicht: Was wird möglich?):

**Unterzeile** (ein Satz: Zielgruppe und Kernnutzen):

**Datum** (gedachter Launch in der Zukunft) und Ort:

**Zusammenfassung** (ein Absatz, verständlich ohne Kontext):

**Problem** (ein Absatz: heutige Situation und warum sie schmerzt):

**Lösung** (ein Absatz: wie das Produkt das Problem löst):

**Zitat aus dem Unternehmen** (eine Stimme aus der Führung, das Warum):

**So legst du los** (wie Kundschaft konkret an das Produkt kommt):

**Kundenzitat** (fiktiv, aber realistisch):

## Externe FAQ (Kundschaft und Presse)

| Frage | Antwort |
|---|---|
| Was kostet es? | |
| Wie unterscheidet es sich von dem, was es schon gibt? | |
| Was passiert mit meinen Daten? | |
| Warum ausgerechnet ihr? | |
| | |

## Interne FAQ (eigene Organisation)

| Frage | Antwort |
|---|---|
| Welche Annahmen müssen wahr sein, damit das funktioniert? | |
| Was sind die größten Risiken? | |
| Welche Fähigkeiten oder Abhängigkeiten fehlen uns? | |
| Was kostet uns das, und ab wann rechnet es sich? | |
| An welcher einen Metrik würden wir Erfolg messen? | |

## Challenge-Runde
- Wo klingt es nach Wunschdenken?
- Welche Annahme ist am wackeligsten?
- Wo würde Kundschaft abspringen?

## Entscheidung
weiterverfolgen / verwerfen / erst Annahme testen:

Welche Annahme, welcher Test:
