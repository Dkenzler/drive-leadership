---
name: pr-faq
description: Ein Zielbild für ein neues Produkt oder eine Initiative schreiben mit dem PR/FAQ Article nach dem Working-Backwards-Prinzip von Amazon (beschrieben von Colin Bryar und Bill Carr), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Produktidee vom Kundenerlebnis her denken, eine Vision für ein Produkt oder Vorhaben greifbar machen, Annahmen und Risiken früh sichtbar machen oder vor Entwicklungsstart entscheiden will, ob sich eine Idee lohnt. Führt durch Kunde und Problem, fiktive Pressemitteilung, externe und interne FAQ, gemeinsames Challengen und die Entscheidung.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D1 Target Picture
  origin: Amazon, beschrieben von Colin Bryar und Bill Carr (Working Backwards)
  deep_dive: true
  version: "1.0"
---

# PR/FAQ Article

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Amazon, beschrieben von Colin Bryar und Bill Carr in »Working Backwards«.

## Worum es geht

Bevor ein Team mit der Entwicklung beginnt, schreibt es eine fiktive Pressemitteilung. Sie beschreibt das fertige Produkt so, als käme es gerade auf den Markt. Dazu kommen FAQs: häufig gestellte Fragen von Kundschaft, Medien und aus der eigenen Organisation. Das Prinzip heißt Working Backwards: mit dem Zielbild beginnen.

Die meisten Produktideen beginnen bei der Lösung. Jemand hat eine Technologie oder Funktion und sucht danach die Kundschaft. Das fühlt sich produktiv an und führt regelmäßig zu Produkten, die niemand will. Der PR/FAQ dreht die Richtung um und fragt zuerst nach der Experience: Wie sieht die neue Welt aus, wenn das Produkt da ist, und wie fühlt sie sich für die Nutzenden an?

Ein PR/FAQ ist ein Denkwerkzeug, kein Marketingtext. Sein Wert liegt im Prozess, nicht im fertigen Dokument. Drei Dinge passieren, wenn du ihn ernsthaft angehst:

- **Du denkst vom Ergebnis her.** Die Diskussion verschiebt sich von »Was können wir bauen?« zu »Was soll sich für wen ändern?«.
- **Du machst Annahmen sichtbar.** Die FAQ zwingt dich, Fragen zu beantworten, die sonst erst Monate später auftauchen, wenn es zu teuer ist, sie zu klären.
- **Du schaffst ein gemeinsames Zielbild.** Ein bis zwei Seiten, für alle lesbar. Anders als ein Foliensatz lässt sich der Text nicht hinter Bildern verstecken. Ist eine Idee dünn, sieht man es dem Text sofort an.

## Wann du sie einsetzt

- Vor dem Start eines neuen Produkts, Features oder einer Initiative, bevor die erste Zeile Code geschrieben wird.
- Wenn ein Team fast nur über Technik diskutiert und die Perspektive der Nutzenden fehlt.
- Wenn eine Vision für ein Produkt oder Vorhaben konkret und teilbar werden soll.
- Wenn entschieden werden muss, ob eine Idee weiterverfolgt, verworfen oder erst getestet wird.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welches Produkt oder Vorhaben geht es? Für welche Organisation und in welcher Rolle? Schreibt die Person allein oder bereitet sie eine Session mit dem Team vor? Frag nichts, was sie schon gesagt hat.
- Der PR/FAQ lässt sich allein schreiben, wirkt aber im Team. Bereitet die Person eine Session vor, biete Set-up, Ablauf und Moderationsfragen an. Arbeitet sie allein, schreib mit ihr den ersten Entwurf und markiere, was im Team gechallengt werden muss.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Hat die Person schon einen Entwurf, steig bei Schritt 5 ein.
- Formuliere Texte mit der Person, nicht für sie. Halte jede Passage kurz und schlicht. Streiche Buzzwords und Superlative sofort und sag, warum.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Rutscht die Person ins »Wie«? Fehlt die interne FAQ?
- Erfinde keine Fakten über Produkt, Kundschaft oder Markt. Kundenzitate sind fiktiv, müssen aber realistisch sein. Was offen ist, markierst du als offene Annahme.
- Schließe mit dem PR/FAQ im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Im Buch als kleiner Workshop beschrieben, verdichtet auf einen halben Tag oder verteilt auf zwei bis drei Sessions.

**Set-up.** Drei bis sechs Personen, die das Vorhaben aus verschiedenen Blickwinkeln kennen, idealerweise Produkt, Technologie und eine kundennahe Rolle. Ein bis zwei Stunden für den ersten Entwurf, danach mindestens eine zweite Runde nach ein paar Tagen Abstand. Ein gemeinsames Dokument, kein Foliendeck. Eine Person moderiert und schreibt mit.

1. **Kunde und Problem festlegen.** Für wen ist das? Welches konkrete Problem lösen wir? So spezifisch wie möglich.
   Frage: *»Für wen genau ist das, und welches Problem löst es, in einem Satz?«*
   Gut ist die Antwort, wenn sie eine greifbare Gruppe in einer greifbaren Lage beschreibt. Nicht »kleine Unternehmen«, sondern »Soloselbstständige, die ihre Belege bisher in einer Schuhschachtel sammeln und am Jahresende in Panik geraten«. Lässt sich das Problem nicht in einem Satz benennen, ist der PR/FAQ noch nicht dran. Dann fehlt das Verständnis für die Nutzenden.

2. **Die Pressemitteilung schreiben.** Feste Struktur, eine halbe bis ganze Seite. Geh die Teile einzeln durch:
   - **Überschrift:** aus Kundensicht, nicht aus Unternehmenssicht. Was wird möglich?
   - **Unterzeile:** ein Satz, der Zielgruppe und Kernnutzen benennt.
   - **Datum:** ein Datum in der Zukunft, der gedachte Launch.
   - **Zusammenfassung:** ein Absatz, der Produkt und Nutzen so erklärt, dass ihn auch jemand ohne Kontext versteht.
   - **Problem:** ein Absatz zur heutigen Situation und warum sie schmerzt.
   - **Lösung:** ein Absatz, wie das Produkt das Problem löst.
   - **Zitat aus dem Unternehmen:** eine Stimme aus der Führung, die das Warum auf den Punkt bringt.
   - **So legst du los:** wie Kundschaft konkret an das Produkt kommt.
   - **Kundenzitat:** fiktiv, aber realistisch, von einer Person aus der Zielgruppe.

   Frage pro Teil, etwa: *»Was wird für die Kundschaft möglich, in einer Zeile?«*
   Die härteste Disziplin ist Einfachheit: keine Buzzwords, keine Superlative. Lässt sich das Produkt einer außenstehenden Person in diesen Absätzen nicht erklären, ist das Zielbild noch nicht klar.

3. **Die externe FAQ.** Die Fragen, die Kundschaft und Presse stellen würden: Was kostet es? Wie unterscheidet es sich von dem, was es schon gibt? Was passiert mit meinen Daten? Warum ausgerechnet ihr?
   Frage: *»Welche Einwände hätte deine Zielgruppe als Erstes?«*
   Gut ist die Antwort, wenn sie die naheliegenden Einwände offen benennt. Diese Fragen halten die Pressemitteilung ehrlich.

4. **Die interne FAQ.** Der anstrengende Teil, der den Unterschied macht. Die unbequemen Fragen aus Sicht der eigenen Organisation:
   - Welche Annahmen müssen wahr sein, damit das funktioniert?
   - Was sind die größten Risiken?
   - Welche Fähigkeiten oder Abhängigkeiten fehlen uns?
   - Was kostet uns das, und ab wann rechnet es sich?
   - An welcher einen Metrik würden wir Erfolg messen?

   Frage: *»Welche Annahme ist die kritischste, und woran würdet ihr Erfolg messen?«*
   Gut ist die Antwort, wenn sie eine kritischste Annahme, das größte Risiko und genau eine Erfolgsmetrik nennt. Genau diese Fragen entscheiden später über das Projekt, und es ist viel billiger, sie jetzt zu stellen.

5. **Lesen, challengen, iterieren.** Den Entwurf gemeinsam lesen, zuerst in Ruhe. Dann Abschnitt für Abschnitt durchgehen: Wo klingt es nach Wunschdenken? Welche Annahme ist am wackeligsten? Wo würde Kundschaft abspringen? Der erste Entwurf ist nie der letzte. Gute PR/FAQs durchlaufen mehrere Runden.
   Frage: *»Wo in diesem Text klingt es nach Wunschdenken?«* Arbeitet die Person allein, stell du diese Fragen an ihren Entwurf.

6. **Entscheiden.** Am Ende steht eine bewusste Entscheidung: weiterverfolgen, verwerfen oder erst eine offene Annahme testen. Auch ein Nein ist ein wertvolles Ergebnis, erzielt in Tagen statt in Monaten.
   Frage: *»Weiterverfolgen, verwerfen oder erst testen? Und welche Annahme testet ihr zuerst?«*

## Beispiel

**Kindle.** Der Kindle war eines der ersten Amazon-Produkte, die mit dieser Methode entstanden. Zuvor hatte das Team fast nur über technische Themen debattiert. Das Zielbild aus dem PR/FAQ war nicht »Wir bauen einen E-Reader«, sondern sinngemäß: Jedes Buch, das je gedruckt wurde, ist in unter 60 Sekunden überall verfügbar. Dieser eine Satz traf Entscheidungen, die eine Technologiediskussion nie getroffen hätte.

**Durchgängiges Beispiel aus dem Buch (Abb. 3.19), gekürzt.** Eine Buchhaltungs-App führt einen Assistenten ein, der Belege eigenständig über alle Kanäle erfasst, von der strukturierten E-Rechnung bis zum Papierbeleg.

- *Datum:* [Stadt], 1. März des kommenden Jahres.
- *Problem:* Viele Selbstständige schieben Belege bis zum Jahresende auf und tippen dann alles von Hand ab. Auch wer schon eine App nutzt, fotografiert und korrigiert jeden Beleg einzeln.
- *Lösung:* Der Assistent holt Belege aus Postfach, verknüpften Konten, Portalen, Kontoumsatz und Foto selbst herein, ordnet zu und verbucht laufend. Nur bei echter Unklarheit fragt er gezielt nach.
- *Zitat:* »Wir wollten die unbeliebteste Aufgabe unserer Nutzer nicht beschleunigen, sondern abschaffen«, sagt die Produktverantwortliche.
- *So legst du los:* Postfach verbinden, einmal die Steuerangaben bestätigen, fertig.
- *Kundenzitat:* »Ich sammle keine Belege mehr und tippe nichts mehr ab. Am Monatsende schaue ich nur noch drüber«, sagt eine selbstständige Fotografin.
- *Extern:* Was passiert mit Belegen, die der Assistent nicht eindeutig zuordnen kann? Er markiert sie und fragt nach, statt still einen falschen Wert zu speichern.
- *Intern:* Erreichen wir eine Quote, bei der so gut wie kein Beleg mehr von Hand angefasst wird? Die kritischste Annahme. Der schwierige Rest aus ungewöhnlichen Papierbelegen, ausländischen Rechnungen und Sonderfällen entscheidet, ob das Versprechen hält.
- *Intern:* Vertrauen Nutzende einem Assistenten, der eigenständig verbucht? Zu viele Rückfragen, und der Vorteil ist dahin. Zu wenige, und ein unbemerkter Fehler kostet Vertrauen.
- *Intern, Metrik:* Anteil der Belege, die ohne manuelle Berührung verbucht werden, und Anteil der Nutzenden, die dem Assistenten nach vier Wochen noch ohne Kontrolle vertrauen.

Die Pressemitteilung klingt verlockend, aber die interne FAQ legt sofort frei, woran alles hängt. Genau diese Fragen hätte ohne PR/FAQ niemand vor dem Prozess gestellt.

## Worauf du achten musst

- **Zu früh ins »Wie« abrutschen.** Sobald Technologie oder Architektur auftauchen, bist du vorwärts unterwegs. Beschreibe den Nutzen, nicht die Mechanik.
- **Die interne FAQ weglassen.** Sie ist der unbequeme, aber wertvollste Teil.
- **Marketing-Sprache.** Superlative und Buzzwords verdecken, dass das Zielbild noch nicht klar ist. Klarheit schlägt Eloquenz.
- **Das Dokument als einmaligen Beschluss behandeln.** Der PR/FAQ lebt von Iteration und gemeinsamem Challengen. Ein Entwurf, der nie hinterfragt wurde, hat seinen Zweck verfehlt.
- **Zu lang werden.** Ein bis zwei Seiten. Wer mehr braucht, hat die Idee noch nicht verdichtet.
- **Den PR/FAQ für einen Beweis halten.** Er ersetzt keine Nutzerforschung und keine Validierung am Markt. Die Annahmen aus der internen FAQ müssen anschließend getestet werden. Der PR/FAQ sagt dir, wonach du suchen musst, nicht, dass du recht hast.

## Ergebnis

Ein PR/FAQ von höchstens zwei Seiten plus die Entscheidung. Vorlage: `templates/pr-faq.md`.

```markdown
# PR/FAQ: [Produkt / Initiative]
Stand: [Datum] · Beteiligte: [Namen oder Rollen] · Entwurf Nr. [x]

**Kundschaft:** …
**Problem in einem Satz:** …

## Pressemitteilung
**[Überschrift aus Kundensicht]**
*[Unterzeile: Zielgruppe und Kernnutzen]*

[Stadt], [Datum des gedachten Launchs]. [Zusammenfassung]

**Das Problem:** …
**Die Lösung:** …
**Zitat:** »…«, sagt [Rolle].
**So legst du los:** …
**Kundenzitat:** »…«, sagt [Person aus der Zielgruppe].

## Externe FAQ
- Was kostet es? …
- Wie unterscheidet es sich von dem, was es schon gibt? …
- …

## Interne FAQ
- Kritischste Annahme: …
- Größtes Risiko: …
- Fehlende Fähigkeiten oder Abhängigkeiten: …
- Kosten, und ab wann es sich rechnet: …
- Die eine Erfolgsmetrik: …

**Offene Annahmen und Tests:** …
**Entscheidung:** weiterverfolgen / verwerfen / erst testen, weil …
```

## Mini-Check

- Beschreibt die Überschrift einen Nutzen aus Kundensicht, kein Feature?
- Versteht jemand ohne Vorwissen in zwei Absätzen, worum es geht?
- Steht in der internen FAQ die kritischste Annahme, das größte Risiko und die eine Erfolgsmetrik?
- Habt ihr den Entwurf gemeinsam gelesen und mindestens einmal überarbeitet?
- Ist das Dokument kürzer als zwei Seiten?

## Im Flywheel

Modul DRIVE, Bereich D1 Target Picture. Eines der Formate, mit denen eine Vision ein Bild bekommt, das andere sehen und teilen können.

Verwandte Skills:
- `core-message-future-scenario`: Beide arbeiten mit einem Zukunftsbild. Der PR/FAQ ist ein Denkwerkzeug, um eine Idee zu schärfen und ihre Annahmen sichtbar zu machen. Core Message und Future Scenario setzen später an und bringen eine gefasste Botschaft vor einem Publikum auf den Punkt. Das eine hilft zu denken, das andere zu überzeugen.

Gut zu wissen: Bei Amazon ist der PR/FAQ Teil einer größeren Schreibkultur. Wichtige Entscheidungen werden in narrativen Memos vorbereitet, nicht in Folien, und zu Beginn eines Meetings gemeinsam in Stille gelesen. Fließtext zwingt zu klarem Denken, Stichpunkte erlauben, Lücken zu überspringen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D1 Target Picture, Deep Dive PR/FAQ Article, Abgrenzung im Deep Dive Core Message & Future Scenario. Originalquelle: Colin Bryar, Bill Carr: Working Backwards.

Original: Colin Bryar, Bill Carr: Working Backwards. Insights, Stories, and Secrets from Inside Amazon, St. Martin's Press, 2021. https://www.workingbackwards.com
