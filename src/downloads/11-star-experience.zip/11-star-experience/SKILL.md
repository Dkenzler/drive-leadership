---
name: 11-star-experience
description: Über das Erwartbare hinausdenken und ein differenziertes Kundenerlebnis entwickeln mit der 11-Star Experience von Brian Chesky (Airbnb), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Product Vision entwickeln, ein Service- oder Kundenerlebnis neu denken, ein Team aus rein inkrementellem Denken holen oder einen Ideen-Workshop zum Kundenerlebnis vorbereiten will. Führt von der heutigen Erfahrung Stern für Stern bis ins Absurde und zurück zu dem, was umsetzbar ist.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D1 Target Picture
  origin: Brian Chesky
  deep_dive: false
  version: "1.0"
---

# 11-Star Experience

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Brian Chesky.

## Worum es geht

Die 11-Star Experience stammt von Brian Chesky, Mitgründer von Airbnb. Sie hilft, über das Erwartbare hinaus zu denken und ein differenziertes Kundenerlebnis zu entwickeln. Man fragt nicht nur, was eine gute Kundenerfahrung wäre, sondern auch, was eine absurd gute Erfahrung wäre.

Der Punkt ist nicht, die 11-Sterne-Erfahrung am Ende zu verwirklichen. Es geht darum, den Möglichkeitsraum und das Denken zu öffnen. Wer bei 5 Sternen aufhört, optimiert das Bestehende. Wer bis 11 denkt, findet neue Räume und denkt über das Naheliegende hinaus. Die Methode zwingt, radikal die Perspektive der Nutzenden einzunehmen.

»You have to almost design the extreme to come backwards.« (Brian Chesky)

## Wann du sie einsetzt

- Product Vision entwickeln.
- Service Design.
- Wenn ein Team feststeckt und nur noch inkrementell denkt.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Um welches Produkt oder welchen Service geht es? Welcher Moment im Erleben der Kundschaft soll im Fokus stehen? Arbeitet die Person allein oder mit einem Team? Frag nichts, was sie schon gesagt hat.
- Arbeite immer an einem konkreten Moment aus Sicht der Nutzenden, so wie Airbnb am Ankommen in der Unterkunft. Ist der Fokus zu breit, hilf der Person, einen Moment zu wählen.
- Geh die Sterne nacheinander durch. Pro Stufe eine Frage, dann auf die Antwort warten. Du darfst eigene Ideen für eine Stufe anbieten, wenn die Person stockt, kennzeichnest sie aber als Vorschlag.
- Bremse nicht zu früh. Die obersten Stufen sollen absurd werden. Machbarkeit kommt erst im dritten Schritt.
- Challenge jede Antwort gegen »Worauf du achten musst«. Benenne Schwächen direkt und kurz.
- Erfinde keine Fakten über die heutige Erfahrung der Kundschaft. Was die Person nicht weiß, markierst du als offen.
- Bereitet die Person eine Session mit dem Team vor, biete Ablauf und Moderationsfragen an.
- Schließe mit der Sterneleiter im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Die Methode funktioniert in drei Schritten.

1. **Die aktuelle Erfahrung beschreiben.** Wie erlebt die Kundschaft diesen Moment heute? Oft liegt das irgendwo zwischen 3 und 5 Sternen.
   Frage: *»Was erlebt deine Kundschaft heute in genau diesem Moment, und wie viele Sterne wäre das?«*
   Gut ist die Antwort, wenn sie aus Sicht der Nutzenden beschrieben ist, konkret und ohne Beschönigung.

2. **Stern für Stern nach oben, bis ins Absurde.** Was wäre eine 6-Sterne-Erfahrung? Eine 7-Sterne-Erfahrung? Und so weiter bis 11.
   Frage pro Stufe: *»Was müsste passieren, damit es ein Stern mehr ist?«*
   Gut ist die Antwort, wenn jede Stufe spürbar über der vorherigen liegt und die obersten Stufen bewusst über die Grenze des Machbaren hinausgehen.

3. **Fragen, was umsetzbar ist.** Vom Absurden aus zurückschauen: Was davon lässt sich realisieren? Oft liegt die beste Idee irgendwo zwischen 6 und 8 Sternen.
   Frage: *»Welche Elemente aus den oberen Stufen lassen sich in eine umsetzbare Erfahrung übersetzen?«*
   Gut ist die Antwort, wenn sie über das Bestehende hinausgeht und trotzdem realisierbar ist.

## Beispiel

Brian Chesky beschreibt es so:

»Was ist eine 5-Sterne-Erfahrung? Du kommst an, und die Wohnung sieht aus wie auf den Fotos. Das war's. Was ist eine 6-Sterne-Erfahrung? Du kommst an, und da liegt eine Willkommenskarte und eine Flasche Wein. Eine 7-Sterne-Erfahrung? Eine Limousine holt dich am Flughafen ab. Und so geht es weiter. Eine 11-Sterne-Erfahrung? Du landest am Flughafen, und Elon Musk wartet, um dich ins All zu fliegen.«

Abb. 3.3 (Airbnb's 11-Star Framework) zeigt die Leiter am Ankommen beim Gastgeber:

| Sterne | Stufe | Erfahrung |
|---|---|---|
| 1 | Erstattung | An die Tür klopfen. Keine Reaktion. |
| 2 | Ich musste warten | An die Tür klopfen. 20 Minuten auf den Gastgeber gewartet. |
| 5 | Erwartete Erfahrung | An die Tür klopfen. Gastgeber öffnet und lässt dich rein. |
| 6 | Besser als ein Hotel | Gastgeber begrüßt dich und zeigt dir alles. Die Wohnung ist mit Wasser und Pflegeprodukten ausgestattet. |
| 7 | Weit darüber hinaus | Gastgeber personalisiert dein Erlebnis: »Ich weiß, du surfst gern. Hier ist ein Surfbrett. Hier ist mein Auto. Und hier ist eine Überraschungsreservierung im besten Restaurant der Stadt.« |
| 10 | Beatlesempfang | 5000 Schulkinder empfangen dich und rufen deinen Namen. Ein Auto steht bereit. Du kommst bei Airbnb an, und eine Pressekonferenz wartet auf dich. |
| 11 | Elon Musk | Verlasse den Planeten. Du erscheinst am Flughafen, und Elon Musk steht da. Er sagt nur: »Du fliegst ins All.« |

Die Abbildung markiert zusätzlich eine Grenze des Machbaren.

## Worauf du achten musst

- **Bei 5 Sternen aufhören.** Dann optimierst du nur das Bestehende.
- **Die 11 für das Ziel halten.** Die absurde Stufe soll nicht umgesetzt werden. Sie öffnet den Möglichkeitsraum.
- **Den Rückweg auslassen.** Ohne die Frage »Was ist umsetzbar?« bleibt es eine Kreativübung ohne Ergebnis.
- **Aus Unternehmenssicht denken.** Die Methode lebt davon, radikal die Perspektive der Nutzenden einzunehmen.

## Ergebnis

```markdown
# 11-Star Experience: [Produkt / Service]
Stand: [Datum] · Beteiligte: [Namen oder Rollen]

**Moment im Erleben der Kundschaft:** …
**Heute:** [x] Sterne, weil …

| Sterne | Erfahrung aus Sicht der Nutzenden |
|---|---|
| 5 | … |
| 6 | … |
| 7 | … |
| 8 | … |
| 9 | … |
| 10 | … |
| 11 | … |

**Umsetzbar (oft zwischen 6 und 8 Sternen):**
- …

**Offene Fragen / nächster Schritt:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)
- Ist die heutige Erfahrung ehrlich und aus Sicht der Nutzenden beschrieben?
- Seid ihr wirklich bis ins Absurde gegangen, oder habt ihr bei 7 oder 8 aufgehört?
- Habt ihr vom Absurden aus zurückgefragt, was umsetzbar ist?
- Geht das umsetzbare Ergebnis über das Bestehende hinaus?

## Im Flywheel

Modul DRIVE, Bereich D1 Target Picture. Eines der Formate, mit denen eine Vision ein Bild bekommt, das andere sehen und teilen können.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D1 Target Picture (Abb. 3.3). Originalquelle: Brian Chesky, Airbnb.
Original: Brian Chesky im Podcast Masters of Scale, Folge »Do things that don't scale«, 2017, https://mastersofscale.com/brian-chesky/
