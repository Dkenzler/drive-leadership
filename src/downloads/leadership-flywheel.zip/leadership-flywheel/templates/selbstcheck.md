# Leadership Flywheel: Selbstcheck

Nach dem Selbstcheck im Drive Leadership Playbook (Kapitel Leadership Flywheel). Regelmäßig nutzen, etwa alle paar Wochen für eine halbe Stunde.

**Datum:**
**Rolle / Verantwortungsbereich:**

## Zu den Themenbereichen (Inner Wheel)

- [ ] Welchen Bereich vernachlässige ich gerade?
- [ ] Wo entstehen die größten Reibungsverluste?
- [ ] Habe ich die richtigen Tools für diesen Bereich?

| Bereich | Wo läuft es rund? | Wo habe ich zu wenig investiert? |
|---|---|---|
| DRIVE (Vision & Strategy) | | |
| LEAD (People & Teams) | | |
| SHIP (Plan & Execute) | | |
| YOURSELF (Persönliche Führung) | | |

## Zum Vorgehen (Outer Wheel)

- [ ] Welchen Prozessschritt brauche ich gerade?
- [ ] Fehlt Urgency? Fehlt Coalition? Fehlt ein Set-up for Success?
- [ ] Gehe ich das Thema systematisch an?

Prozessschritte: Create Urgency · Build Coalition · Shape Direction · Set-up for Success · Enable Action · Prove Progress · Increase Pace

Benötigter Schritt:

## Zum Zusammenspiel

- [ ] Arbeite ich an den richtigen Themen?
- [ ] Gehe ich sie richtig an?
- [ ] Entsteht Momentum, oder drehe ich mich im Kreis?

## Nächster Schritt

**Wo setze ich an:**
**Bis wann:**
**Nächster Selbstcheck:**
