---
name: leadership-flywheel
description: Die eigene Führungssituation einordnen mit dem Leadership Flywheel von Dominik Kenzler, dem Rahmenmodell des Drive Leadership Playbook. Nutze diesen Skill, wenn jemand nicht weiß, wo er als Führungskraft ansetzen soll, eine neue Rolle oder ein neues Team übernimmt, ein dysfunktionales Team hat, in einem festgefahrenen Projekt steckt, an der eigenen Wirksamkeit zweifelt oder einen regelmäßigen Selbstcheck machen will. Ordnet die Situation in die vier Themenbereiche des Inner Wheel (DRIVE, LEAD, SHIP, YOURSELF) und die sieben Prozessschritte des Outer Wheel ein, bestimmt den typischen Einstiegspunkt und verweist auf die passenden Methoden-Skills des Buchs.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: FLYWHEEL
  area: Leadership Flywheel
  origin: Dominik Kenzler
  deep_dive: false
  version: "1.0"
---

# Leadership Flywheel

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler.

## Worum es geht

Führung funktioniert nicht linear. Du entwickelst dein Team, während du an der Vision arbeitest, und triffst Entscheidungen, während du dich selbst reflektierst. Das Leadership Flywheel bildet Führung deshalb als sich selbst verstärkendes System ab. Das Flywheel-Denken geht auf Jim Collins (»Good to Great«) zurück: Durchbrüche entstehen nicht durch eine spektakuläre Entscheidung, sondern durch konsequenten Aufbau von Momentum. Flywheel heißt dabei nicht langsam und geduldig: Energie, Fokus und Disziplin werden mit Drive ausgeführt, kurzfristig pushen für ein langfristiges Ziel.

**Im Zentrum steht IMPACT:** die Wirkung, die du als Führungskraft auf dein Team, deine Organisation und das Unternehmen hast. Positiv und nachhaltig, auf Ergebnisse, Kultur und Menschen. Beide Räder drehen sich um dieses Zentrum.

**Das Inner Wheel: die Themenbereiche (Was?).** Woran arbeitest du als Leader?

| Bereich | Kern | Worum es geht |
|---|---|---|
| DRIVE | Vision & Strategy | Ein klares Zielbild entwickeln, die Richtung vorgeben und kommunizieren. Zentrale Frage: Wohin wollen wir? |
| LEAD | People & Teams | Die richtigen Fähigkeiten für die Strategie identifizieren, Haltung und Verhalten verankern, das Team aufstellen, einstellen, entwickeln, sich im Zweifel trennen. Ziel: Set-up for Success. |
| SHIP | Plan & Execute | Strategie umsetzen und in Wirkung übersetzen: klare Ziele, Pläne, sichtbarer Fortschritt, schnelle Entscheidungen, Qualitätsstandards. |
| YOURSELF | Persönliche Führung | Dich selbst verstehen und bewusst managen: Antrieb, Stärken, Schwächen, Muster unter Druck, Energie, Resilienz, Wirkung auf andere. Ohne YOURSELF funktionieren DRIVE, LEAD und SHIP nicht. |

**Das Outer Wheel: die sieben Prozessschritte (Wie?).** Wie treibst du Veränderung voran, unabhängig vom Thema? Die Schritte orientieren sich an Change-Prozessen, insbesondere am 8-Stufen-Modell von J. P. Kotter.

1. **Create Urgency:** Klarheit über Relevanz und Timing schaffen.
2. **Build Coalition:** Verbündete aufbauen, Alliances formen.
3. **Shape Direction:** Richtung konkretisieren, Narrative schaffen.
4. **Set-up for Success:** Strukturen, Ressourcen, Voraussetzungen bereitstellen.
5. **Enable Action:** Handlungsfähigkeit herstellen, Hindernisse beseitigen.
6. **Prove Progress:** Fortschritt sichtbar machen, Quick Wins identifizieren.
7. **Increase Pace:** Tempo erhöhen, Momentum verstärken.

Inner und Outer Wheel funktionieren nur zusammen. Das Inner Wheel zeigt, woran du arbeiten sollst. Ohne den richtigen Prozess entsteht kein Momentum. Das Outer Wheel gibt den Prozess vor. Ohne die richtigen Themen fehlt die Substanz: viel Bewegung, wenig Wirkung.

Das Flywheel leistet dreierlei: **Orientierung** in komplexen Situationen und bei den vielen ersten Malen im Leadership, **Assessment und Reflexion** (Wo stehe ich, wo hakt es?) und eine **gemeinsame Sprache** für Führung im Team, mit Peers und mit dem eigenen Manager.

## Wann du sie einsetzt

- Du weißt nicht, wo du ansetzen sollst, oder arbeitest nur noch das nächste dringende Thema ab.
- Du steckst in einem der vier typischen Einstiegspunkte: neue Rolle oder neues Team, dysfunktionales Team, festgefahrenes Projekt, Zweifel an der eigenen Wirksamkeit.
- Als regelmäßiger Selbstcheck, etwa alle paar Wochen für eine halbe Stunde.
- Im Dialog mit dem Team oder mit Peers: zum Beispiel einmal im Quartal, in Retrospektiven oder im 1:1, um gemeinsam zu analysieren, wo ihr steht oder wo Energie verloren geht.

## So arbeitest du mit der Person

- Gib das Flywheel so wieder, wie es in diesem Skill steht. Erfinde keine weiteren Bereiche, Prozessschritte oder Einstiegspunkte, deute sie nicht um und lege keine feste Reihenfolge fest, wo das Buch keine vorgibt. Das Flywheel hat keinen festen Startpunkt.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche Rolle hast du, und wofür bist du verantwortlich? Was beschäftigt dich gerade am meisten? Seit wann? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten. Weiß die Person schon, welcher Einstiegspunkt passt, steig direkt dort ein.
- Challenge gegen »Worauf du achten musst«. Vor allem: Sucht die Person das Problem im falschen Bereich, etwa bei der Strategie, obwohl es an der Umsetzung liegt?
- Verweise auf Methoden-Skills nur so, wie das Buch es tut: auf Bereichsebene, über die Liste unter »Im Flywheel«. Nenne keine Skills, die nicht in dieser Liste stehen.
- Du ordnest ein und strukturierst. Entscheidungen, besonders über Menschen im Team, trifft die Führungskraft, nicht du.
- Erfinde keine Fakten über die Organisation der Person. Wo Informationen fehlen, markiere sie als offen.
- Schließe mit der Standortbestimmung im Format aus »Ergebnis« und geh den Mini-Check (Selbstcheck) durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Situation beschreiben.** Frage: *»Was ist gerade deine größte Herausforderung als Führungskraft, und woran merkst du sie?«* Gut ist die Antwort, wenn sie konkrete Anzeichen nennt, nicht nur ein Gefühl.

2. **Einstiegspunkt zuordnen.** Prüfe, welcher der vier typischen Einstiegspunkte passt. Passt keiner, geh direkt zu Schritt 3.

   **Neue Rolle oder neues Team.** Für dich, wenn du eine neue Führungsrolle übernimmst, ein bestehendes Team neu leitest, einen neuen Verantwortungsbereich bekommst oder nach einer Reorganisation neu startest. Häufigster Fehler: einfach weitermachen wie bisher oder sofort nach Effizienzgewinnen suchen. Das ist Verwalten, nicht Führen. Weg durchs Flywheel: Starte mit DRIVE: Gibt es ein klares Zielbild? Wenn nicht, ist das die erste Aufgabe. Dann LEAD: Hast du die richtigen Menschen? Ist Set-up for Success gegeben?

   **Dysfunktionales Team.** Für dich, wenn du Feedbackgespräche vermeidest oder aufschiebst, Konflikte im Team sich nicht auflösen, dir die heute nötigen Fähigkeiten im Team fehlen oder es dir schwerfällt, Entwicklungsmöglichkeiten aufzuzeigen und zu coachen. Häufigster Fehler: abwarten und hoffen, dass es sich von selbst löst, oder das Problem auf die Umstände schieben. Teamprobleme lösen sich selten von selbst, sie eskalieren und betreffen nie nur eine Person. Weg durchs Flywheel: Nutze SHIP als Checkliste: Sind die Aufgaben für alle klar? Sind die Ziele klar definiert? Oft sind Teamprobleme Clarity-Probleme, keine People-Probleme. Dann LEAD: Sind Rollen und Verantwortungen klar? Ist die Erwartung an Rolle und Person klar? Sind Erfahrung und Fähigkeiten vorhanden? Wird das richtige Feedback gegeben? Stimmt die Teamkomposition? Sind es fachliche oder zwischenmenschliche Probleme?

   **Festgefahrenes Projekt.** Für dich, wenn ein Projekt nicht vorankommt, Deadlines verpasst werden oder sich verschieben, das Team viel arbeitet, aber wenig Fortschritt sichtbar ist, und unklar ist, woran es liegt. Häufigster Fehler: das Problem bei der Strategie suchen, obwohl es an der Umsetzung liegt. Noch ein Workshop, noch eine Planänderung, während die eigentlichen Blocker bleiben: unklare Ziele, langsame Entscheidungen, fehlende Sichtbarkeit von Fortschritt. Weg durchs Flywheel: Nutze die Fragen aus DRIVE und LEAD als Checkliste: Ist das Zielbild klar? Sind die nötigen Ressourcen und Fähigkeiten da? Wenn ja, fokussiere dich vollständig auf SHIP. Halte dich ans Outer Wheel: Create Urgency und Prove Progress. Und hinterfrage, ob das Projekt in seiner jetzigen Form noch zielführend ist (Sunk Cost Fallacy).

   **Zweifel an der eigenen Wirksamkeit.** Für dich, wenn du das Gefühl hast, als Leader alles wissen zu müssen, dich fragst, ob du der Rolle gewachsen bist, Entscheidungen aus Unsicherheit vor dir herschiebst, dich mit deinen Führungsfragen allein fühlst oder dich hinter Aktionismus versteckst. Häufigster Fehler: glauben, du müsstest alles allein lösen, oder so tun, als hättest du keine Zweifel. Weg durchs Flywheel: Starte bei YOURSELF: Was sind deine Muster unter Druck? Wo willst du Kontrolle behalten, statt zu vertrauen? Was treibt dich an, was blockiert dich? Dann DRIVE: Ist dein Zielbild klar? Dann LEAD: Hast du die richtigen Sparringspartner? Wem vertraust du?

   Frage: *»Welche dieser Beschreibungen trifft deine Lage am ehesten, und welcher Satz passt am genauesten?«* Gut ist die Antwort, wenn sie einen Einstiegspunkt wählt oder begründet, warum keiner passt.

3. **Die vier Bereiche einschätzen (Inner Wheel).** Geh DRIVE, LEAD, SHIP und YOURSELF durch, mit den Fragen aus dem Buch:
   - DRIVE: Wie präzise ist unsere Vision, haben wir eine klare Strategie?
   - LEAD: Wie stark ist mein Team aufgestellt, haben wir die richtigen Strukturen?
   - SHIP: Wie gut ist unsere Execution, haben wir gut definierte Ziele?
   - YOURSELF: Wie klar bin ich in meiner Rolle?

   Frage: *»Wo läuft es gut, wo hakt es, und wo hast du zuletzt zu wenig investiert?«* Gut ist die Antwort, wenn sie für jeden Bereich eine ehrliche Einschätzung enthält und die größte Lücke benennt. Achte auf fehlende Verbindungen zwischen den Bereichen: Ein starkes Team ohne klare Vision läuft ins Leere, eine gute Strategie ohne solide Execution bleibt Theorie.

4. **Den nötigen Prozessschritt bestimmen (Outer Wheel).** Gleiche die Lage mit den Warnsignalen aus dem Buch ab:

   | Prozessschritt | Warnsignale laut Buch |
   |---|---|
   | Create Urgency | Neues Team oder neuer Bereich, Momentum muss schnell entstehen. Trägheit, Dinge werden auf nächste Wochen oder Quartale geschoben. Zu viele Prozesse bremsen Entscheidungen. Erfolgsdruck, sichtbare Fortschritte nötig. |
   | Build Coalition | Wenig Austausch mit Peers und Stakeholdern, kaum jemand kennt deine Pläne. Stakeholder fühlen sich von ausgereiften Konzepten übergangen. Du musst Entscheidungsträger ohne bestehende Beziehung überzeugen. Neu in der Organisation. |
   | Shape Direction | Kein Zielbild oder keine klare Strategie. Vision unklar oder veraltet. Mitarbeitende kennen Vision und Strategie nicht. Test: »Wo wollt ihr in 18 bis 24 Monaten mit eurem Thema sein?« |
   | Set-up for Success | Teams liefern nicht, Deadlines verschieben sich immer wieder, Qualität leidet, Frustration steigt. Delta zwischen aktuellem und idealem Set-up. |
   | Enable Action | Teams warten immer wieder auf Entscheidungen oder Freigaben. Du musst oft nach oben fragen. Kein Zugang zu Systemen oder KPIs. Andere Teams reagieren nicht, Abhängigkeiten blockieren. |
   | Prove Progress | Stakeholder fragen regelmäßig nach dem Status oder wirken ungeduldig. Vertrauen ins Projekt sinkt. Das Team verliert Motivation, weil Erfolge unsichtbar bleiben. Budgets stehen trotz guter Arbeit zur Diskussion. |
   | Increase Pace | Erste Quick Wins sind da und geteilt, Set-up for Success ist gegeben. Jetzt auf positiven Signalen aufbauen, ohne das Team zu überlasten. |

   Frage: *»Welcher Prozessschritt fehlt dir gerade am meisten?«* Gut ist die Antwort, wenn sie sich auf konkrete Warnsignale stützt. Du musst nicht stoisch jeden Schritt abarbeiten.

5. **Weg und nächste Tools festlegen.** Leite aus Einstiegspunkt, Bereichseinschätzung und Prozessschritt ab, wo die Person zuerst ansetzt. Verweise auf die Bereiche und Skills unter »Im Flywheel«. Frage: *»Was ist dein erster konkreter Schritt, und bis wann?«* Gut ist die Antwort, wenn sie einen Bereich, einen Prozessschritt und eine konkrete nächste Handlung verbindet.

6. **Iteration verabreden.** Das Flywheel ist kein Prozess, den man einmal durchläuft. Du arbeitest an DRIVE, merkst, dass in LEAD etwas fehlt, gehst zurück, justierst nach. Leitfrage bei jeder Iteration: Steigert das meinen Impact? Bewegt sich das Flywheel? Vereinbare, wann die Person den Selbstcheck wiederholt.

## Beispiel

Dominik Kenzler übernahm als Director ein neues Department mit dem Auftrag, die Organisation nach einer Restrukturierung neu aufzustellen. Organisation Design war für ihn Neuland, und er sah es nicht als seinen Aufgabenbereich. Heute sieht er es als zentral für jede Führungskraft, ein Set-up for Success herzustellen. Anfangs hatte er sich meist nur auf das nächste dringende Thema fokussiert, statt strategisch und geplant zu handeln. Das Flywheel soll anderen diese Orientierung früher geben. Er selbst nutzt es als Selbstcheck: Alle paar Wochen nimmt er sich eine halbe Stunde und geht die vier Bereiche durch. Wo habe ich zu wenig investiert? Wo läuft es rund?

## Worauf du achten musst

- **Das Problem im falschen Bereich suchen.** Teams, die immer neue Ziele und Strategien bekommen, obwohl die Frage nach der Execution nie gestellt wurde. Man korrigiert an der falschen Stelle und landet in einem Loop ständiger Veränderung.
- **Teamprobleme als People-Probleme lesen.** Oft sind es Clarity-Probleme: unklare Aufgaben, Ziele, Rollen.
- **Einen Bereich isoliert betrachten.** Oft liegt das Problem nicht in einem einzelnen Bereich, sondern in der fehlenden Verbindung zwischen ihnen.
- **Nur das Inner Wheel oder nur das Outer Wheel nutzen.** Richtige Themen ohne Prozess bleiben Theorie. Prozess ohne richtige Themen erzeugt viel Bewegung und wenig Wirkung.
- **Verwalten statt führen.** In neuen Rollen einfach weitermachen wie bisher. Wer zu lange verwaltet, verliert Vertrauen und Glauben.
- **Abwarten.** Teamprobleme lösen sich selten von selbst, und festgefahrene Projekte werden aus Sunk-Cost-Gründen weitergeführt.
- **Alles allein lösen wollen.** Führung ist keine Soloveranstaltung. Unsicherheit gehört dazu, entscheidend ist der Umgang damit.
- **Tempo ohne Set-up.** Increase Pace funktioniert nur, wenn das Set-up for Success weiterhin gegeben ist. Mehr Tempo ohne Ressourcen führt zu Frust.
- **Nur für Optics optimieren.** Sichtbar machen, was wirklich erreicht wurde. Alles andere fällt irgendwann auf dich zurück.

## Ergebnis

Eine kurze Standortbestimmung. Vorlage mit Selbstcheck: `templates/selbstcheck.md`.

```markdown
# Leadership Flywheel: Standortbestimmung
Stand: [Datum] · Rolle / Verantwortungsbereich: …

**Situation:** …
**Einstiegspunkt:** Neue Rolle oder neues Team / Dysfunktionales Team / Festgefahrenes Projekt / Zweifel an der eigenen Wirksamkeit / keiner

## Inner Wheel
| Bereich | Einschätzung | Größte Lücke |
|---|---|---|
| DRIVE | | |
| LEAD | | |
| SHIP | | |
| YOURSELF | | |

**Fehlende Verbindung zwischen Bereichen:** …

## Outer Wheel
**Benötigter Prozessschritt:** … · **Warnsignale:** …

## Weg durchs Flywheel
1. Bereich … , weil …
2. Bereich … , weil …

**Nächste Skills:** …
**Erster konkreter Schritt / bis:** …
**Nächster Selbstcheck:** …
**Offen:** …
```

## Mini-Check

Der Selbstcheck aus dem Buch. Nutze ihn regelmäßig, um dich zu orientieren.

Zu den Themenbereichen (Inner Wheel):
- Welchen Bereich vernachlässige ich gerade?
- Wo entstehen die größten Reibungsverluste?
- Habe ich die richtigen Tools für diesen Bereich?

Zum Vorgehen (Outer Wheel):
- Welchen Prozessschritt brauche ich gerade?
- Fehlt Urgency? Fehlt Coalition? Fehlt ein Set-up for Success?
- Gehe ich das Thema systematisch an?

Zum Zusammenspiel:
- Arbeite ich an den richtigen Themen?
- Gehe ich sie richtig an?
- Entsteht Momentum, oder drehe ich mich im Kreis?

## Im Flywheel

Grundlagenkapitel. Der Skill verbindet alle vier Module des Inner Wheel.

**Verweise je Einstiegspunkt**, so wie das Buch sie unter »Was du brauchst« nennt:

- **Neue Rolle oder neues Team:** »Im DRIVE-Kapitel findest du Tools für Zielbilder und Strategie, im LEAD-Kapitel Tools für die ersten 90 Tage und Teamaufbau.«
  - Zielbilder (D1): `keynote`, `visiontype`, `pr-faq`, `5-bold-steps`, `11-star-experience`
  - Strategie (D2): `playing-to-win`, `errc-grid-value-curve`, `dhm-glee`, `three-horizons`, `hedgehog-concept`
  - Die ersten 90 Tage: `30-60-90-day-plan`
  - Teamaufbau (L1, L3): `organisationsmap`, `faehigkeitenmatrix`, `rollen`, `job-description`, `hiring-scorecard`
- **Dysfunktionales Team:** »Im LEAD-Kapitel findest du Tools für schwierige Gespräche, Feedback und Teamstrukturen.«
  - Schwierige Gespräche: `difficult-conversations`
  - Feedback: `sbi-feedback`, `radical-candor`
  - Teamstrukturen (L1): `organisationsmap`, `rollen`
- **Festgefahrenes Projekt:** »Im SHIP-Kapitel findest du Methoden für klare Ziele, schnelle Entscheidungen und sichtbaren Fortschritt.«
  - Klare Ziele (S1): `okrs`, `omtm`, `weekly-priorities`, `commitment-ceremony`, `goal-review`
  - Schnelle Entscheidungen (S4): `timely-decisions`, `one-way-two-way-door`, `disagree-and-commit`, `trojan-horse-draft`, `decision-log`
  - Sichtbarer Fortschritt: `progress-optics`
- **Zweifel an der eigenen Wirksamkeit:** »Im YOURSELF-Kapitel findest du Tools für Selbstreflexion, Rollenklarheit und den Umgang mit Unsicherheit.«
  - Selbstreflexion (Teil 1 Dich selbst kennen): `ikigai`, `work-journal`, `feedback-einholen`, `persoenlichkeitstests`, `executive-presence`
  - Umgang mit Unsicherheit, Stress und Druck (Teil 2 Dich im Alltag steuern): `calendar-review`, `breathwork`, `shutdown-ritual`, `walk-and-talk`, `mut-zu-entscheidungen`

**Alle Bereiche im Überblick**, für den Fall, dass der Selbstcheck eine Lücke in einem Bereich zeigt:

| Modul | Bereich | Skills |
|---|---|---|
| DRIVE | D1 Target Picture (Vision) | `keynote`, `visiontype`, `pr-faq`, `5-bold-steps`, `11-star-experience` |
| DRIVE | D2 Strategy | `playing-to-win`, `errc-grid-value-curve`, `dhm-glee`, `three-horizons`, `hedgehog-concept` |
| DRIVE | D3 Set Strategic Goals | `strategic-objectives`, `north-star-metric`, `gem`, `bhag`, `wigs` |
| DRIVE | D4 Guiding Principles (im Kapitel: Strategic Planning) | `roadmap-anatomy`, `ogsm`, `hoshin-kanri`, `go-product-roadmap`, `now-next-later` |
| DRIVE | D5 Communicate Direction | `50-25-25-rule`, `minto-pyramid-principle`, `star-moment`, `presentation-strategy-worksheet`, `core-message-future-scenario` |
| LEAD | L1 Design Your Organisation | `organisationsmap`, `faehigkeitenmatrix`, `career-track-levels`, `werte-workshop`, `rollen` |
| LEAD | L2 Know Your Team | `assessment-prozess`, `watkins-assessment`, `skill-will-matrix`, `9-box-grid` |
| LEAD | L3 Hire & Let Go | `job-description`, `hiring-scorecard`, `work-trial`, `letting-go` |
| LEAD | L4 Set the Stage | `30-60-90-day-plan`, `team-charter`, `one-on-one-skip-level`, `weekly-staff-meeting`, `all-hands` |
| LEAD | L5 Grow Your People | `sbi-feedback`, `radical-candor`, `ownership-ladder`, `difficult-conversations`, `delegation-levels` |
| SHIP | S1 Set Goals | `okrs`, `commitment-ceremony`, `omtm`, `weekly-priorities`, `goal-review` |
| SHIP | S2 Plan & Prioritize | `ice-rice-scoring`, `shape-up`, `impact-effort-matrix`, `team-roadmap`, `capacity-planning` |
| SHIP | S3 Create Execution Clarity | `extreme-clarity`, `canonical-document`, `facilitation`, `dri`, `progress-optics` |
| SHIP | S4 Make Fast Decisions | `timely-decisions`, `one-way-two-way-door`, `disagree-and-commit`, `trojan-horse-draft`, `decision-log` |
| SHIP | S5 Ensure Quality | `checklist`, `definition-of-done`, `braintrust`, `show-your-work`, `performance-reviews` |
| YOURSELF | Teil 1 Dich selbst kennen | `ikigai`, `work-journal`, `feedback-einholen`, `persoenlichkeitstests`, `executive-presence` |
| YOURSELF | Teil 2 Dich im Alltag steuern | `calendar-review`, `breathwork`, `shutdown-ritual`, `walk-and-talk`, `mut-zu-entscheidungen` |
| YOURSELF | Teil 3 Dich weiterentwickeln | `90-day-plan`, `positive-future-fiction`, `leadership-blueprint`, `mentor-und-sponsor`, `designing-your-life` |

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel Leadership Flywheel: Warum ein Flywheel?, Was das Leadership Flywheel leistet, Das Leadership Flywheel Framework, Inner & Outer Wheel im Detail, Typische Einstiegspunkte, Selbstcheck. Bezugsquellen laut Buch: Jim Collins: Good to Great (Flywheel-Prinzip), J. P. Kotter: 8-Stufen-Modell (Outer Wheel).
