# Team-Update

Nach Abb. 5.12 im Drive Leadership Playbook: Fiktives Beispiel Slack Update Invoice Team. Asynchron, einmal pro Woche, fünf Minuten.

**[TEAM] UPDATE: KW [xx]**
Kurzes Update zu unseren Fortschritten diese Woche

## In Arbeit
- [Thema]: [Stand], [geplanter Termin]

Nächste Woche: …

## Erreicht
- [Thema]: [Ergebnis, mit Zahl] (Ziel: …)

## Blocker
- [Problem]. @[Name], kannst du …?

---

Die drei Fragen dahinter:
1. Was haben wir diese Woche erreicht?
2. Was kommt als Nächstes?
3. Was blockiert uns?
