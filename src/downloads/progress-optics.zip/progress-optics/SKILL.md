---
name: progress-optics
description: Progress sichtbar machen und Optics verstehen, nach den drei Ebenen Execution, Impact und Optics von Shreyas Doshi, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn die Arbeit eines Teams in der Organisation nicht gesehen wird, Stakeholder ständig nach dem Status fragen, ein Team trotz guter Arbeit gekürzt zu werden droht, oder wenn jemand ein wöchentliches Team-Update (etwa in Slack) oder ein Dashboard aufsetzen will. Führt durch das Update mit drei Fragen (erreicht, als Nächstes, blockiert) und prüft, auf welcher Ebene Team und Leadership gerade schauen.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: SHIP
  area: S3 Create Execution Clarity
  origin: Shreyas Doshi
  deep_dive: false
  version: "1.0"
---

# Progress sichtbar machen und Optics verstehen

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Shreyas Doshi.

## Worum es geht

Ein Fortschritt, der nicht sichtbar ist, existiert für die Organisation nicht. Wenn niemand weiß, was ein Team erreicht hat, wenn Erfolge nicht kommuniziert und Metriken nicht geteilt werden, entsteht ein Vakuum, und es füllt sich schnell und nachhaltig mit Vermutungen. Fortschritt sichtbar zu machen, ist deshalb keine optionale Kommunikationsaufgabe, sondern ein Führungsinstrument.

Shreyas Doshi, ehemaliger Director of Product Management bei Stripe und Twitter, beschreibt drei Ebenen, auf denen Arbeit gleichzeitig stattfindet. Sein Beispiel ist Produktarbeit, das Prinzip gilt für jede Führungsarbeit:

1. **Execution:** Was das Team tatsächlich tut, etwa Features bauen, Bugs fixen, Experimente laufen lassen. Hier sind die meisten Teams zu Hause.
2. **Impact:** Was die Arbeit bewirkt: Metriken bewegen, Kundenprobleme lösen, Businessziele voranbringen.
3. **Optics:** Wie die Arbeit von anderen wahrgenommen wird. Weiß das Leadership, was das Team tut? Verstehen Stakeholder, warum es wichtig ist? Sieht die Organisation den Fortschritt?

Das Problem entsteht, wenn Teams und ihre Führungskräfte auf verschiedenen Ebenen operieren. Ein Team, das nur auf Execution schaut, während das Leadership auf Impact oder Optics schaut, gerät fast immer in Konflikte und Missverständnisse.

Optics ist keine Eitelkeit. Doshi gibt offen zu, dass er lange eine Abneigung dagegen hatte, und sagt zugleich, er hätte vielleicht noch bessere Ergebnisse gehabt, wenn er früher mehr in Optics investiert hätte. Sein Rat: Optics nicht zur neuen Persönlichkeit machen, sondern strategisch denken. Den Execution- oder Impact-Hut aufbehalten und sich gelegentlich bewusst den Optics-Hut aufsetzen, 30 Minuten am Tag, gezielt, mit der richtigen Botschaft. Denn alle Probleme sind im Kern Kommunikationsprobleme.

## Wann du sie einsetzt

- Dein Team leistet gute Arbeit, aber die Organisation sieht es nicht.
- Stakeholder fragen regelmäßig nach dem Status oder wirken ungeduldig, das Vertrauen ins Projekt sinkt.
- Lange Projekte, in denen viel passiert, bevor ein Produkt releast oder ein kommerzieller Wert sichtbar wird.
- Leader und Team arbeiten mit unterschiedlichen Zahlen und brauchen in Meetings erst Zeit, um einen gemeinsamen Ausgangspunkt herzustellen.
- Der CEO fragt dich, woran deine Teams zuletzt gearbeitet haben. Für Dominik Kenzler ist das ein Alarmsignal: Dann ist Sichtbarkeit und Transparenz nicht gut gelungen.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welches Team und welche Ziele? Wer soll den Fortschritt sehen (eigenes Leadership, Stakeholder, ganze Organisation)? Gibt es heute schon Updates oder Dashboards? Frag nichts, was die Person schon gesagt hat.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten. Die Person kann Schritte überspringen.
- Wenn die Person nur ein Update schreiben will, spring direkt zu Schritt 3 und nutze `templates/team-update.md`.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Kommen im Update auch Blocker und verfehlte Ziele vor? Wird Kleines zu groß gemacht? Benenne Schwächen direkt und kurz.
- Erfinde keine Zahlen, Erfolge oder Namen. Was fehlt, markierst du als offen.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Ebenen abgleichen.** Klären, auf welcher Ebene das Team gerade arbeitet und kommuniziert und auf welcher das Leadership schaut.
   Frage: *»Wenn dein Team heute berichtet: Spricht es über Execution, Impact oder Optics? Und worauf schaut das Leadership, an das ihr berichtet?«* Gut ist die Antwort, wenn eine mögliche Lücke zwischen den Ebenen benannt ist.

2. **Vom Tun zur Wirkung übersetzen.** Die wichtigsten Arbeitspakete werden mit ihrer Wirkung auf Ziele und Metriken verbunden.
   Frage: *»Was bewegt diese Arbeit in Richtung eurer Ziele, und welche Zahl zeigt das?«* Gut ist die Antwort, wenn sie Wirkung beschreibt, nicht nur Aktivität.

3. **Regelmäßiges Update aufsetzen.** Die einfachste Form: asynchron, kurz, einmal pro Woche, drei Fragen, fünf Minuten.
   - Was haben wir diese Woche erreicht?
   - Was kommt als Nächstes?
   - Was blockiert uns?

   Frage: *»Was habt ihr diese Woche erreicht, was kommt als Nächstes, was blockiert euch?«* Gut ist die Antwort, wenn »erreicht« Wirkung mit Zahl oder Ziel zeigt und jeder Blocker eine Person und eine konkrete Bitte hat.

4. **Dashboard prüfen.** Wenn die wichtigsten Metriken für alle sichtbar sind, entsteht ein gemeinsames Bild der Realität.
   Frage: *»Welche zwei oder drei Metriken sollten für alle sichtbar sein, damit niemand mit anderen Zahlen arbeitet?«*

5. **Vorwärts statt rückwärts formulieren.** Progress sichtbar machen ist kein Reporting. Reporting ist oft rückwärtsgerichtet und defensiv: Was haben wir getan, um zu zeigen, dass wir aktiv waren? Fortschritt sichtbar machen ist vorwärtsgerichtet: Was bewegen wir in Richtung unserer Ziele, und was zeigen die Daten für den nächsten Schritt?
   Frage: *»Liest sich das Update wie ein Tätigkeitsnachweis oder wie ein Blick nach vorn?«*

6. **Rhythmus festlegen.** Wann das Update erscheint, wer es schreibt und wer es bekommt. Bei großen Projekten kann das Update auch Teil jedes monatlichen All-Hands sein.
   Frage: *»An welchem Tag, von wem, an wen?«*

## Beispiel

Das Buch zeigt ein fiktives Slack-Update (Abb. 5.12, Invoice Team Update KW20):

- **In Arbeit:** Rabatte: UI-Implementierung läuft, Launch für KW 22 geplant. Nächste Woche: Rabatt-Feature in Staging, Start User Testing Wiederkehrende Rechnungen.
- **Erreicht:** E-Invoice: 68 % der Nutzer:innen können XRechnung versenden (Ziel: 50 % bis Ende Monat). Wiederkehrende Rechnungen: Beta-Test mit 12 Kund:innen gestartet, erstes Feedback sehr positiv.
- **Blocker:** PDF-Rendering bei ZUGFeRD hat einen Bug. @Sarah, kannst du Alignment mit dem Platform Team koordinieren?

Dominik Kenzler hat erlebt, wie Teams großartige Arbeit geleistet haben und im nächsten Planungszyklus trotzdem gekürzt wurden, weil ihre Beiträge nicht sichtbar waren. Beim firmenweiten Redesign bei sevdesk galt: in jedem monatlichen All-Hands ein Update zum Fortschritt, in jeder Townhall ein größeres. Das Ergebnis: Die ganze Firma glaubte daran, dass es klappt.

## Worauf du achten musst

- **Nur in guten Zeiten kommunizieren.** Sinken Metriken oder werden Ziele verfehlt, schweigen viele Teams. Das ist das Gegenteil von dem, was Vertrauen schafft. Gerade wenn etwas nicht läuft, ist Transparenz wichtiger. Wer nur Erfolge kommuniziert, dem wird irgendwann nicht mehr geglaubt.
- **Optics übertreiben.** Wer aus kleinen Themen riesige Erfolge macht, wird schnell entlarvt und als jemand wahrgenommen, der redet und nicht liefert. Doshi warnt auch davor, Optics-Aktivitäten selbst zu feiern: Das sendet das Signal, dass Sichtbarkeit wichtiger ist als Wirkung.
- **Nur für Optics optimieren.** Es geht darum, echten Fortschritt sichtbar zu machen. Optimierst du nur für Optics, fällt das irgendwann auf dich zurück.
- **Optics als politisch abtun.** Viele gute Teams empfinden Optics als oberflächlich. Die Folge: Ihre Arbeit wird nicht gesehen. Als Leader ist es deine Aufgabe, dafür zu sorgen, dass die Arbeit deines Teams gesehen wird.
- **Reporting statt Fortschritt.** Ein rückwärtsgerichteter Tätigkeitsnachweis ersetzt nicht den Blick auf Ziele und nächste Schritte.
- **Ebenen verwechseln.** Das Team berichtet Execution, das Leadership fragt nach Impact. Ohne Abgleich entstehen Konflikte und Missverständnisse.

## Ergebnis

Ein wöchentliches Team-Update im Format aus dem Buch, dazu der vereinbarte Rhythmus. Vorlage: `templates/team-update.md`.

```markdown
# [Team] Update: KW [xx]
Kurzes Update zu unseren Fortschritten diese Woche

**Erreicht**
- [Thema]: [Wirkung, mit Zahl und Ziel]

**In Arbeit**
- [Thema]: [Stand, geplanter Termin]
Nächste Woche: …

**Blocker**
- [Problem]. @[Name], kannst du …?

Rhythmus: [Tag], von [Name], an [Kanal / Personen]
Dashboard: [Metriken, Link hier]
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Kommuniziert ihr auch, wenn Metriken sinken oder Ziele verfehlt werden?
- Zeigt euer Update Wirkung auf Ziele, nicht nur Aktivität?
- Wissen Team und Leadership, auf welcher Ebene (Execution, Impact, Optics) der jeweils andere schaut?
- Ist das, was ihr sichtbar macht, echter Fortschritt und nicht aufgeblasen?
- Gibt es einen festen Rhythmus, in dem der Fortschritt sichtbar wird?

## Im Flywheel

Modul SHIP, Bereich S3 Create Execution Clarity. Im Leadership Flywheel gehört dazu das Element Prove Progress: Fortschritt erzeugen und sichtbar machen, Quick Wins identifizieren und in die Organisation kommunizieren.

Verwandte Skills:
- `leadership-flywheel`: Prove Progress als Teil des Flywheel Frameworks.
- `all-hands`: Das Buch nennt Optics auch dort: Formate nutzen, um den Beitrag des Teams sichtbar zu machen und Leads die Bühne zu geben.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Flywheel Framework, Prove Progress, Kapitel LEAD, Den Wert deines Teams kommunizieren und All-Hands, Kapitel SHIP, S3 Create Execution Clarity. Originalquelle: Shreyas Doshi.

Original: Shreyas Doshi: The 3 levels of product work (Execution, Impact, Optics), Thread auf X, 2021, https://twitter.com/shreyas/status/1370248637842812936
