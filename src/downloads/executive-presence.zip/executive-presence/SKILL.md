---
name: executive-presence
description: Executive Presence entwickeln nach Sylvia Ann Hewlett, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn eine Führungskraft an ihrer Wirkung arbeiten will, weil gute Inhalte allein nicht ankommen, sie in Meetings oder vor dem Senior Leadership unsicher wirkt, unter kritischen Fragen die Souveränität verliert, zu viel absichert und rechtfertigt oder sich auf einen Auftritt vorbereitet. Führt durch die drei Elemente Gravitas, Kommunikation und Authentizität, konkrete beobachtbare Verhaltensweisen und einen Übungsplan mit ein bis zwei Verhaltensweisen und Feedback.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 1 Dich selbst kennen
  origin: Sylvia Ann Hewlett
  deep_dive: false
  version: "1.0"
---

# Executive Presence entwickeln

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Sylvia Ann Hewlett.

## Worum es geht

Gute Inhalte allein reichen nicht. Wie du wirkst, entscheidet, ob dir Menschen folgen. Der Begriff Executive Presence wurde von Sylvia Ann Hewlett geprägt und beschreibt die Fähigkeit, Glaubwürdigkeit, Souveränität und Einfluss auszustrahlen, unabhängig von der hierarchischen Position. Es geht nicht darum, laut oder charismatisch zu sein, sondern darum, wie das Gesagte ankommt.

Das Buch arbeitet mit drei Elementen. Gravitas und Kommunikation sind zwei der drei Säulen bei Hewlett, Authentizität als Grundlage ist die Setzung des Buchs:
1. **Gravitas** ist das wichtigste: Ruhe und Glaubwürdigkeit unter Druck, Souveränität auch dann, wenn es schwierig wird.
2. **Kommunikation** ist das sichtbarste: wie klar, präzise und wirkungsvoll du sprichst.
3. **Authentizität** ist die Grundlage: die Übereinstimmung zwischen dem, was du sagst, und dem, was du tust.

Executive Presence klingt nach etwas, das man hat oder nicht hat. Das Gegenteil ist der Fall. Sie ist eine Summe von Verhaltensweisen, die man beobachten, üben und lernen kann. Es geht nicht darum, jemand anderes zu werden. Susan Cain: Erwirb die Fähigkeiten, aber lerne, du selbst zu sein. Auch ein introvertierter, ruhiger Mensch kann starke Präsenz haben.

## Wann du sie einsetzt

- Wenn deine Inhalte gut sind, aber nicht die Wirkung haben, die sie haben könnten.
- Wenn du in Meetings, vor dem Senior Leadership oder unter kritischen Fragen an Souveränität verlierst.
- Bei einem Jobwechsel oder neuen Start: Dort bist du vielerorts noch ein unbeschriebenes Blatt und hast Raum, bewusst anders aufzutreten.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: In welchen Situationen willst du anders wirken? Was hast du selbst oder was haben andere an deiner Wirkung beobachtet? Gibt es einen konkreten Anlass, etwa ein wichtiges Meeting? Frag nichts, was die Person schon gesagt hat.
- Geh den Ablauf Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Will die Person an zu vielem gleichzeitig arbeiten? Versucht sie, jemand anderes zu werden? Benenne das direkt und kurz. Kein Lob als Füllmaterial.
- Du hast die Person nicht erlebt. Beurteile ihre Wirkung nicht selbst, sondern arbeite mit ihren Beobachtungen und dem Feedback anderer. Fehlt das, markiere es als offen und plane Feedback ein.
- Bereitet die Person einen konkreten Auftritt vor, biete an, ihre Kernaussagen auf kurze, klare Sätze zu prüfen und Weichmacher zu markieren.
- Schließe mit dem Übungsplan im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Beobachten.** Wer in deinem Umfeld hat starke Präsenz? Was genau macht diese Person? Achte auf Details: Tempo, Pausen, Körperhaltung, Wortwahl.
   Frage: *»Wer in deinem Umfeld hat starke Präsenz, und was genau tut diese Person im Meeting anders?«*
   Gut ist die Antwort, wenn sie beobachtbares Verhalten beschreibt, nicht »sie hat Ausstrahlung«.

2. **Mit den Verhaltensweisen abgleichen.** Wiederkehrende Muster bei Menschen mit starker Präsenz:
   - **Bewusste Sprechpausen statt hastigen Redens.** Eine Pause signalisiert Souveränität, wer hetzt, wirkt unsicher. Das ist Gravitas.
   - **Ruhig bleiben, wenn es unangenehm wird.** Bei einer kritischen Frage, einem Widerspruch, einem Fehler die Fassung behalten, statt defensiv zu werden. Wer ruhig atmet, wirkt ruhig. Gravitas beginnt im Nervensystem.
   - **Einen Punkt klar und einmal benennen,** statt ihn mehrfach abzusichern. Kurze, klare Sätze. Nicht mehr reden, sondern klarer. Kein Rechtfertigen.
   - **Aktiv nach Fragen und Gegenmeinungen fragen,** statt sie zu fürchten. Wer zum Widerspruch einlädt, zeigt, dass die Sache wichtiger ist als das eigene Ego.
   - **Zu dem stehen, was man sagt.** Eine Position auch dann vertreten, wenn sie unbequem ist, und offen zugeben, wenn man etwas nicht weiß. Ein ehrliches »Das weiß ich nicht, ich finde es heraus« wirkt souveräner als unsicheres Ausweichen. Das ist Authentizität.
   - **Aktiver Blick in die Runde,** statt den Blick zu senken.
   - **Den Elefanten im Raum ansprechen:** klar, deutlich und unaufgeregt benennen, was sich die meisten nicht auszusprechen trauen.

   Frage: *»Welche dieser Verhaltensweisen fehlt dir am meisten, und in welcher Situation hast du das zuletzt gemerkt?«*

3. **Ein bis zwei Verhaltensweisen wählen.** Nicht alle gleichzeitig. Vielleicht die bewusste Pause vor der Antwort. Vielleicht das Weglassen von Weichmachern wie »eigentlich«, »vielleicht«, »nur«.
   Frage: *»An welchen ein bis zwei Verhaltensweisen arbeitest du in den nächsten Wochen?«*
   Gut ist die Antwort, wenn es höchstens zwei sind und sie beobachtbar sind.

4. **Klein üben.** Übe in kleineren Meetings, bevor du es in großen Formaten anwendest.
   Frage: *»In welchem kleineren Meeting übst du zuerst?«*

5. **Feedback holen.** Frag jemanden, dem du vertraust und der dich in Meetings erlebt: Wie wirke ich? Wo verliere ich an Präsenz? Das ist unbequem, aber der schnellste Weg zu lernen.
   Frage: *»Wer erlebt dich regelmäßig in Meetings und gibt dir ehrlich Rückmeldung?«*

## Beispiel

Bei Native Instruments sagte Dominik Kenzlers Chef und Mentor Mate Galic nach einem Meeting zu ihm: »Dominik, deine Inhalte sind gut. Aber du führst rein über die Inhalte. Du musst dir auch deiner Wirkung bewusst werden.« Es gebe Menschen, die inhaltlich viel weniger klar seien, denen man das Gesagte aber mehr abnehme. Dominik Kenzler, mit 33 oft der Jüngste im Senior Leadership Meeting, begann, Meetings bewusst zu beobachten, und erkannte die Präsenz als eine Summe lernbarer Verhaltensweisen.

Das erste Thema, an dem er intensiv gearbeitet hat: seine Meinung klar zu benennen, dazu zu stehen und Dinge offen anzusprechen. Er hatte Widerspruch erwartet. Tatsächlich wurde es oft als starke Perspektive wahrgenommen, und die Leute im Meeting waren sogar erleichtert, wenn jemand die Themen klar benannte. Geholfen haben ihm auch Jobwechsel, weil er dort neu starten konnte.

## Worauf du achten musst

- **Präsenz für ein Talent halten.** Sie ist eine Summe von Verhaltensweisen, die man beobachten, üben und lernen kann.
- **Jemand anderes werden wollen.** Es geht darum, die eigene Art zu finden, Wirkung zu erzeugen. Präsenz heißt nicht laut oder extrovertiert.
- **Alles gleichzeitig ändern.** Ein bis zwei Verhaltensweisen, nicht alle auf einmal.
- **Nur über Inhalte führen.** Gute Inhalte allein reichen nicht. Wie du wirkst, entscheidet, ob dir Menschen folgen.
- **Mehr reden statt klarer.** Mehrfaches Absichern, verschachtelte Erklärungen und Rechtfertigen verwässern die Botschaft.
- **Überspielen statt zugeben.** Unsicheres Ausweichen wirkt schwächer als ein ehrliches »Das weiß ich nicht«.

## Ergebnis

```markdown
# Executive Presence: Übungsplan
Stand: [Datum] · Zeitraum: [Wochen]

**Situationen, in denen ich an Präsenz verliere:** …
**Vorbild und was diese Person konkret tut:** …

| Element | Verhaltensweise, an der ich arbeite | Wo ich übe | Woran ich es merke |
|---|---|---|---|
| Gravitas / Kommunikation / Authentizität | … | [kleineres Meeting] | … |
| (höchstens zwei) | … | … | … |

**Weichmacher, die ich weglasse:** …
**Feedback von:** … · **Wann:** …
**Offen:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Arbeitest du an höchstens ein bis zwei konkreten, beobachtbaren Verhaltensweisen?
- Übst du zuerst in kleineren Meetings?
- Hast du jemanden, der dich in Meetings erlebt und dir ehrlich sagt, wie du wirkst?
- Passt die Verhaltensweise zu dir, statt eine Rolle zu spielen?

## Im Flywheel

Modul YOURSELF, Teil 1 Dich selbst kennen. YOURSELF ist der äußere Ring des Leadership Flywheel, der Drive, Lead und Ship trägt.

Verwandte Skills:
- `breathwork`: Laut Buch helfen die Atemtechniken direkt, in unangenehmen Momenten ruhig zu bleiben. Gravitas beginnt im Nervensystem.
- `mentor-und-sponsor`: Den Hinweis auf Executive Presence bekam Dominik Kenzler von seinem Mentor. Solche Hinweise kommen laut Buch nur von jemandem, der dich gut kennt und ehrlich genug ist, Unbequemes anzusprechen.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Einleitung »Inhalte allein reichen nicht« und Teil 1 Dich selbst kennen, Executive Presence entwickeln. Begriff nach Sylvia Ann Hewlett. Zitierte Stimme: Susan Cain.

Original: Sylvia Ann Hewlett: Executive Presence. The Missing Link Between Merit and Success, Harper Business, 2014.
