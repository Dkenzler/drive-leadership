---
name: work-trial
description: Eine Probearbeit (Work Trial) im Hiring planen, durchführen und auswerten, aus dem Drive Leadership Playbook von Dominik Kenzler (Praxis nach Anton Osika, Lovable). Nutze diesen Skill, wenn jemand Bewerbende einen oder mehrere Tage im Team an echten Aufgaben mitarbeiten lassen will, eine Probearbeit statt einer Case Study oder eines Take-Home Assignments aufsetzen, eine passende Aufgabe aus dem Backlog auswählen, den Rahmen für Bewerbende formulieren oder das Debrief mit dem Team strukturieren will. Besonders für Senior-Positionen und Rollen, in denen Zusammenarbeit im Team entscheidend ist. Führt durch die drei Phasen Briefing, Zusammenarbeit, Debrief.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: LEAD
  area: L3 Hire & Let Go
  origin: Dominik Kenzler, nach der Praxis von Anton Osika (Lovable)
  deep_dive: false
  version: "1.0"
---

# Probearbeit / Work Trial

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Dominik Kenzler, mit Bezug auf die Praxis von Anton Osika (Lovable).

## Worum es geht

Interviews zeigen, wie jemand über Arbeit spricht. Probearbeit zeigt, wie jemand arbeitet. Die Person arbeitet einen oder mehrere Tage im Team mit, an echten Aufgaben aus dem aktuellen Backlog. Du siehst, wie sie mit dem Team interagiert, wie sie mit Ambiguität umgeht, wie sie Fragen stellt und wie sie tatsächlich arbeitet.

Der Work Trial ist kein Ersatz für den Interviewprozess, sondern eine Ergänzung. Im Hiring-Prozess des Buchs ist er eine Variante des Fachlichen Deep Dive (vier bis acht Stunden statt 90 Minuten). Für Senior-Positionen ist eine bezahlte Probearbeit eine der besten Investitionen, die du machen kannst.

## Wann du sie einsetzt

- Bei Senior-Positionen.
- Bei Rollen, in denen die Zusammenarbeit im Team entscheidend ist.
- Als Fachlicher Deep Dive im Hiring-Prozess, der je nach Rolle ein Portfolio-Review, eine Case Study oder Probearbeit mit dem Team ist.

## So arbeitest du mit der Person

- Du bereitest vor und strukturierst. Entscheidungen über Menschen trifft die Führungskraft, nicht du.
- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Rolle und welches Level? Welche Core Capabilities soll der Trial zeigen? Wer aus dem Team arbeitet mit der Person? Frag nichts, was die Person schon gesagt hat.
- Geh die drei Phasen Schritt für Schritt durch. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Ist die Aufgabe echt oder konstruiert?
- Erfinde keine Aufgaben aus dem Backlog der Person. Hilf, aus ihrem Material eine passende auszuwählen und zuzuschneiden.
- Biete an, das Briefing für die bewerbende Person und die Fragen für das Team-Debrief zu formulieren.
- Schließe mit dem Plan im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

**1. Briefing.** Die Person bekommt eine echte Aufgabe aus dem aktuellen Arbeitskontext, keine konstruierte Case Study. Die Aufgabe ist komplex genug, um relevante Fähigkeiten zu zeigen, aber machbar innerhalb des Zeitrahmens.
Frage: *»Welche Aufgabe aus eurem aktuellen Backlog zeigt die Core Capabilities dieser Rolle und ist im Zeitrahmen machbar?«* Gut ist die Antwort, wenn die Aufgabe real ist und nicht nur Fleiß misst.

**2. Rahmen klar machen und bezahlen.** Die Person muss wissen, was erwartet wird, wie lange der Trial dauert und wie die Entscheidung fällt. Die Probearbeit wird bezahlt: Sie ist Arbeitsleistung und zeigt Wertschätzung.
Frage: *»Was genau erwartet ihr, wie lange dauert es, und wie fällt die Entscheidung?«*

**3. Zusammenarbeit.** Die Person arbeitet einen Tag oder mehrere Tage im Team. Sie nimmt an Meetings teil, arbeitet mit den zukünftigen Peers und zeigt, wie sie sich in das System einfügt.
Frage: *»An welchen Meetings nimmt die Person teil, und mit wem arbeitet sie direkt?«*

**4. Debrief.** Nicht nur du bewertest, das Team bewertet mit. Leitfragen aus dem Buch:
- Wie hat die Zusammenarbeit funktioniert?
- Hat die Person Fragen gestellt?
- Wie ist sie mit Feedback umgegangen?

Frage: *»Wer aus dem Team gibt eine Einschätzung ab, und anhand welcher Kriterien?«* Am Ende des Prozessschritts steht die Entscheidung, und hier zählt die Scorecard.

## Beispiel

Anton Osika, CEO von Lovable, lässt Bewerbende mindestens einen Tag, oft eine ganze Woche, im Team mitarbeiten, an echten Aufgaben aus dem aktuellen Backlog. Das liefert laut Buch mehr valides Signal als jede Kombination aus strukturierten Interviews.

## Worauf du achten musst

- **Losgelöste Take-Home Assignments.** Das klassische Anti-Pattern. Sie zeigen wenig über die echte Arbeitsweise und messen vor allem Verfügbarkeit und Fleiß.
- **Konstruierte statt echte Aufgabe.** Die Aufgabe kommt aus dem aktuellen Arbeitskontext, nicht aus einer konstruierten Case Study.
- **Aufgabe falsch dimensioniert.** Zu simpel zeigt keine relevanten Fähigkeiten, zu groß ist im Zeitrahmen nicht machbar.
- **Unklarer Rahmen.** Die Person muss wissen, was erwartet wird, wie lange der Trial dauert und wie die Entscheidung fällt.
- **Unbezahlte Probearbeit.** Es ist Arbeitsleistung.
- **Allein bewerten.** Das Team bewertet mit.
- **Trial statt Interviews.** Er ergänzt den Prozess, er ersetzt ihn nicht.

## Ergebnis

```markdown
# Work Trial: [Rolle, Level]
Bewerbende Person: … · Zeitraum: … · Vergütung: …

**Aufgabe (aus dem aktuellen Backlog):** …
**Zeigt diese Core Capabilities:** …
**Rahmen für die Person:** Erwartung: … · Dauer: … · So fällt die Entscheidung: …

**Zusammenarbeit:** Meetings: … · Direkte Peers: …

## Debrief
| Wer | Zusammenarbeit | Fragen gestellt? | Umgang mit Feedback | Einschätzung |
|---|---|---|---|---|
| | | | | |

**Übertrag in die Scorecard:** …
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)
- Ist die Aufgabe echt, aus dem aktuellen Backlog, und im Zeitrahmen machbar?
- Weiß die Person, was erwartet wird, wie lange der Trial dauert und wie die Entscheidung fällt?
- Ist die Probearbeit bezahlt?
- Bewertet das Team mit, nicht nur du?
- Ergänzt der Trial den Interviewprozess, statt ihn zu ersetzen?

## Im Flywheel

Modul LEAD, Bereich L3 Hire & Let Go.

Verwandte Skills:
- `hiring-scorecard`: Probearbeit ist eine Variante des Fachlichen Deep Dive, die Entscheidung fällt anhand der Scorecard.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel LEAD, L3 Hire & Let Go. Praxisbeispiel: Anton Osika, Lovable.
