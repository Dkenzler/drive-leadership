---
name: playing-to-win
description: Strategie entwickeln mit Playing to Win (A.G. Lafley, Roger Martin) und der Strategy Choice Cascade, aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand eine Unternehmens-, Produkt- oder Bereichsstrategie erarbeiten, Where to Play und How to Win festlegen, eine bestehende Strategie auf Kohärenz prüfen oder einen Strategie-Workshop vorbereiten will. Führt durch die fünf Entscheidungen (Winning Aspiration, Where to Play, How to Win, Capabilities, Management Systems) und die Frage »Was müsste wahr sein?«.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: DRIVE
  area: D2 Strategy
  origin: A.G. Lafley und Roger Martin
  deep_dive: true
  version: "1.0"
---

# Playing to Win

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach A.G. Lafley und Roger Martin.

## Worum es geht

Playing to Win versteht Strategie nicht als Plan, sondern als kleine Menge eng verbundener Entscheidungen, die ein Unternehmen so positionieren, dass es in seinem Markt gewinnt. Strategie besteht aus fünf Entscheidungen, die aufeinander aufbauen, der Strategy Choice Cascade:

1. **Winning Aspiration:** Was heißt »Gewinnen« für uns?
2. **Where to Play:** Wo spielen wir, und wo nicht?
3. **How to Win:** Wie gewinnen wir dort?
4. **Capabilities:** Welche Fähigkeiten brauchen wir dafür?
5. **Management Systems:** Welche Systeme müssen wir aufbauen?

Die meisten Strategien scheitern nicht an mangelnder Analyse, sondern an mangelnder Entscheidung. Der Wert der Methode liegt nicht im ausgefüllten Schaubild, sondern in der Disziplin, die sie erzwingt: Du entscheidest statt aufzuzählen, du machst Annahmen prüfbar, und du schaffst ein gemeinsames Zielbild, das auf eine Seite passt.

Nicht alle fünf Felder wiegen gleich. Winning Aspiration und Where to Play sind der zentrale Punkt und die Grundlage für alles andere. Auf How to Win iteriert man danach mit unterschiedlichen Methoden, und was es an Capabilities und Management Systems braucht, hängt stark vom How to Win ab.

## Wann du sie einsetzt

- Unternehmens-, Produkt- oder Teamstrategie entwickeln.
- Klares Alignment in einer Führungsrunde herstellen.
- Eine bestehende Strategie prüfen: Passen die fünf Felder zueinander, oder ist sie an einer Stelle unscharf?
- Erneut, sobald eine zentrale Annahme nicht mehr hält, etwa weil sich der Markt oder ein Wettbewerber bewegt.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Für welche Ebene gilt die Strategie (Unternehmen, Produkt, Bereich)? Gibt es eine aktuelle Strategie? Arbeitet die Person allein oder bereitet sie einen Workshop vor? Frag nichts, was sie schon gesagt hat.
- Playing to Win lebt von unterschiedlichen Blickwinkeln. Bereitet die Person einen Workshop vor, erstelle Agenda, Prework und Moderationsfragen (siehe `templates/workshop-agenda.md`). Arbeitet sie allein, geh den Ablauf mit ihr durch und markiere am Ende, welche Annahmen im Team geprüft werden müssen.
- Geh Schritt für Schritt vor. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge jede Antwort gegen »Worauf du achten musst«. Vor allem: Enthält die Entscheidung ein klares Nein? Benenne Schwächen direkt und kurz.
- Die Cascade läuft logisch von oben nach unten, ist aber keine Einbahnstraße. Wenn ein How to Win nicht zum Where to Play passt, geh zurück und schärfe das Where to Play.
- Erfinde keine Fakten über Markt, Kundschaft oder Wettbewerb der Person. Fehlt etwas, markiere es als offen oder als Annahme, die getestet werden muss.
- Schließe mit der Cascade im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

Im Buch als 2-Tages-Workshop beschrieben. Die Schritte funktionieren auch verdichtet im Gespräch.

**Set-up (für den Workshop).** Fünf bis acht Personen, bewusst funktionsübergreifend: die Person, die für die Strategie geradesteht, die mittlere Führung, die sie später umsetzt, und mindestens eine kundennahe Rolle. Eine zusätzliche Person moderiert und schreibt mit, idealerweise ohne eigene Aktien in der Angelegenheit. Eine große Wand oder ein digitales Board mit den fünf Feldern und Platz für mehrere Entwürfe nebeneinander. Kein Foliendeck.

**Prework.**
1. Die verantwortliche Person benennt das strategische Problem in einem Satz, aus Kundensicht. Nicht »Unser Wachstum lässt nach«, sondern zugespitzt etwa »Im direkten Vergleich entscheidet sich unsere Kundschaft zunehmend für Wettbewerber X«.
2. Jede teilnehmende Person bringt die wichtigsten bekannten Fakten über Markt, Kundschaft und Wettbewerb mit, ohne sie zu interpretieren. Ziel ist ein gemeinsamer Faktenstand.

Frage: *»Was ist das strategische Problem, in einem Satz, aus Sicht eurer Kundschaft?«* Gut ist die Antwort, wenn sie spezifisch ist und nicht die Unternehmensperspektive beschreibt.

**Tag 1: Problem, Optionen, Where to Play**

1. **Problem schärfen (90 Min).** Spielregeln klären: Hier wird entschieden, nicht aufgezählt, und keine Option ist vorab gesetzt. Das Problem schärfen, bis es spezifisch und kundenzentriert ist. Daraus eine offene Leitfrage formulieren: *»Wie könnten wir …?«* Sie rahmt den ganzen Workshop.
2. **Status quo auf die Cascade legen (60 Min).** Die aktuelle Strategie in die fünf Felder eintragen. Das zeigt, wo sie unscharf ist oder die Felder nicht zueinander passen. Ab jetzt ist der Status quo eine Option unter mehreren, kein Fixpunkt.
3. **Winning Aspiration klären (45 Min).** Frage: *»Woran würdet ihr in zwei bis drei Jahren ablesen, dass die Strategie aufgegangen ist?«* Nicht »Marktführer werden« als Floskel. Die Aspiration ist der Bezugspunkt, an dem später alle Optionen gemessen werden.
4. **Strategische Optionen erzeugen (90 Min).** Fünf bis zehn grundsätzlich verschiedene Antworten auf die Leitfrage. Menge und Unterschiede zählen, nicht Qualität. Einziges Kriterium: Die Option könnte das Problem theoretisch lösen. Nichts verwerfen.
5. **Where to Play (120 Min).** Für die stärksten drei bis vier Optionen das Wo entscheiden: welche Kundensegmente, Regionen, Kanäle und Produktkategorien, und ebenso klar, welche nicht. Frage: *»Was lasst ihr bewusst weg?«* Eine scharfe Entscheidung enthält immer ein Nein.

**Tag 2: How to Win, Capabilities, Systeme, Test, Entscheidung**

6. **How to Win (120 Min).** Für jede verbliebene Option: Wodurch gewinnt ihr im gewählten Feld, und warum ist dieser Vorteil schwer zu kopieren? Wo und Wie müssen zusammenpassen.
7. **Capabilities (60 Min).** Welche wenigen Fähigkeiten müsst ihr wirklich beherrschen, damit dieses Wie funktioniert? Keine Liste aller Kompetenzen, sondern die zwei oder drei, die den Unterschied machen.
8. **Management Systems (90 Min).** Welche Strukturen, Prozesse und vor allem Messgrößen halten diese Fähigkeiten am Leben? Woran würdet ihr Fortschritt messen?
9. **Was müsste wahr sein (60 Min).** Der Kern. Nicht »Glauben wir daran?«, sondern »Was müsste wahr sein, damit das aufgeht?«. Prüfen durch drei Linsen:
   - **Kunde:** Was müsste über Verhalten und Bereitschaft der Zielgruppe stimmen?
   - **Unternehmen:** Was müsste über unsere Fähigkeiten und Systeme stimmen?
   - **Wettbewerb:** Wie müssten sich die Wettbewerber verhalten, damit unsere Logik trägt?

   Bedingungen als Aussagesätze formulieren, die wahr oder falsch sein können, etwa: »Dieses Segment zahlt für ein bewusst schmales Produkt.« Den Status quo derselben Prüfung unterziehen. Zum Schluss die eine oder zwei Bedingungen markieren, an denen am meisten gezweifelt wird: die fragilste Annahme, die Barriere.
10. **Test-to-learn und Entscheidung (90 Min).** Für die fragilsten Barrieren einen einfachen Test entwerfen, der ausreicht, die Annahme zu erhärten oder zu widerlegen: ein Gespräch mit der Kundschaft, eine Landing Page mit Anmeldung, ein kleiner Pilot. Den Test entwirft die Person, die an der Bedingung am stärksten zweifelt. Dann die verbliebenen Optionen ein letztes Mal durch alle fünf Felder führen und die Kohärenz prüfen. Am Ende eine bewusste Entscheidung: weiterverfolgen, verwerfen oder zuerst eine kritische Annahme testen. Auch ein begründetes »Noch nicht« ist ein Ergebnis.

## Beispiel

Olay bei Procter & Gamble war eine schrumpfende Hautpflegemarke, intern halb spöttisch als Produkt für ältere Frauen abgetan. Statt über noch eine Produktvariante nachzudenken, traf das Team eine Reihe verbundener Entscheidungen: Die Zielgruppe verschob sich von Frauen über 50 auf Frauen zwischen Mitte 30 und 50, die gerade anfangen, in Hautpflege zu investieren. Es entstand ein neues Segment zwischen Massenware und Luxus, hochwertige Produkte zum gehobenen Preis, aber im Drogerie- und Supermarktregal statt im Kaufhaus. Gewachsen wurde über echte Produktqualität, eine klare Botschaft und Partnerschaften mit dem Handel. Aus einer Marke im Niedergang wurde über die Jahre ein Milliardengeschäft. Entscheidend war nicht eine einzelne Idee, sondern dass alle fünf Entscheidungen zusammenpassten und sich gegenseitig verstärkten.

Dominik Kenzler hat das Framework für die Unternehmensstrategie bei sevdesk genutzt, die später die Grundlage für einen Exit von knapp 400 Millionen Euro wurde.

## Worauf du achten musst

- **Listen statt Entscheidungen.** Der häufigste Fehler. Stehen in Where to Play fast alle Segmente und Kanäle, ist das keine Strategie, sondern eine Bestandsaufnahme. Eine Entscheidung erkennt man an einem klaren Nein.
- **»Was müsste wahr sein?« überspringen.** Ohne die Frage fällt die Runde zurück ins Muster, Optionen nach Bauchgefühl gut oder schlecht zu finden.
- **Den Status quo schonen.** Die aktuelle Strategie muss durch dieselbe Prüfung wie jede neue Option, sonst gewinnt sie aus Bequemlichkeit.
- **Wo und Wie getrennt behandeln.** Ein How to Win, das im gewählten Feld nicht trägt, ist kein Detailproblem, sondern ein Hinweis, dass das Wo nicht stimmt. Immer als Paar prüfen.
- **Zu früh entscheiden.** Findet eine Option früh viel Zustimmung, schließt sich das Denken. Mehrere Entwürfe nebeneinander halten, bis die Prüfung beendet ist.
- **Strategie mit Planung verwechseln.** Eine lange Maßnahmenliste fühlt sich produktiv an, ist aber keine Strategie. Erst Wo und Wie, dann der Plan.

## Ergebnis

Eine, in Ausnahmefällen zwei ausformulierte und in sich stimmige Cascades, dazu ein kurzer Testplan für die fragilsten Annahmen. Vorlage: `templates/strategy-cascade.md`.

```markdown
# Strategy Choice Cascade: [Organisation / Bereich]
Stand: [Datum] · Beteiligte: [Namen oder Rollen]

**Strategisches Problem (Kundensicht):** …
**Leitfrage:** Wie könnten wir …?

| Entscheidung | Inhalt |
|---|---|
| Winning Aspiration | Woran wir in 2 bis 3 Jahren ablesen, dass wir gewonnen haben: … |
| Where to Play | Wir spielen: … · Wir spielen bewusst nicht: … |
| How to Win | Unser Vorteil im gewählten Feld: … · Warum schwer zu kopieren: … |
| Capabilities | Die 2 bis 3 Fähigkeiten, die den Unterschied machen: … |
| Management Systems | Strukturen, Prozesse, Messgrößen: … |

**Was müsste wahr sein?**
- Kunde: …
- Unternehmen: …
- Wettbewerb: …

**Fragilste Annahme:** … · **Test:** … · **Verantwortlich / bis:** …
**Entscheidung:** weiterverfolgen / verwerfen / erst testen, weil …
```

## Mini-Check

- Enthält Where to Play ein klares Nein, also Segmente oder Kanäle, die ihr bewusst auslasst?
- Trägt euer How to Win genau in dem Feld, das ihr unter Where to Play gewählt habt?
- Habt ihr für jede Option benannt, was wahr sein müsste, geprüft durch die drei Linsen Kunde, Unternehmen, Wettbewerb?
- Kennt ihr die eine fragile Annahme, und habt ihr einen Test dafür?
- Verstärken sich die fünf Entscheidungen gegenseitig, oder widerspricht sich eine?

## Im Flywheel

Modul DRIVE, Bereich D2 Strategy.

Verwandte Skills:
- `ogsm`: Eine Cascade liefert eine gute Vorlage für Objective und Richtung eines OGSM. Nötig ist sie dafür nicht.

Inhalt und Prozess auseinanderhalten: Die Strategy Choice Cascade meint den Inhalt, also wie das Ergebnis aussehen soll. Der Prozess ist ein eigener Schritt, den Roger Martin als rückwärts gedachte Logik beschreibt. Statt zu fragen »Welche Option ist richtig?«, fragst du für jede Option »Was müsste wahr sein, damit sie richtig wäre?« und testest dann die unwahrscheinlichste Bedingung. Das verschiebt die Energie von Rechthaberei zur gemeinsamen Klärung.

Abgrenzung laut Buch: Playing to Win ist ein Entscheidungsframework. Eine Branchenanalyse, etwa nach Porters fünf Kräften, ist ein Analyseframework. Die Analyse füttert die Optionen, die Entscheidung fällt in der Cascade. Das Ergebnis ist eine begründete Hypothese, kein Beweis, und ein Ausgangspunkt für die weitere Strategiearbeit, nicht ihr Abschluss.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel DRIVE, D2 Strategy und Deep Dive Playing to Win. Originalquelle: A.G. Lafley, Roger Martin: Playing to Win.
Original: A.G. Lafley, Roger L. Martin: Playing to Win. How Strategy Really Works. Harvard Business Review Press, 2013. Prozess: Roger L. Martin, Strategic Choice Structuring Process, https://rogermartin.medium.com/the-strategic-choice-structuring-process-5e116b12ae1f
