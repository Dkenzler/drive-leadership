# Strategy Choice Cascade

Nach Abb. 3.20 im Drive Leadership Playbook, nach A.G. Lafley und Roger Martin.

**Organisation / Bereich:**
**Stand:**
**Beteiligte:**

**Strategisches Problem (Kundensicht):**
**Leitfrage:** Wie könnten wir …?

## 1. Winning Aspiration
Woran wir in zwei bis drei Jahren ablesen, dass die Strategie aufgegangen ist:

## 2. Where to Play
Wir spielen (Segmente, Regionen, Kanäle, Produktkategorien):

Wir spielen bewusst nicht:

## 3. How to Win
Unser Vorteil im gewählten Feld:

Warum dieser Vorteil schwer zu kopieren ist:

## 4. Capabilities
Die zwei bis drei Fähigkeiten, die den Unterschied machen:

## 5. Management Systems
Strukturen, Prozesse, Messgrößen:

## Was müsste wahr sein?

| Linse | Bedingung (als prüfbarer Aussagesatz) | Zweifel (hoch/mittel/niedrig) |
|---|---|---|
| Kunde | | |
| Unternehmen | | |
| Wettbewerb | | |

## Test-to-learn

| Fragilste Annahme | Test | Verantwortlich | Bis |
|---|---|---|---|
| | | | |

## Entscheidung
weiterverfolgen / verwerfen / erst testen, weil:
