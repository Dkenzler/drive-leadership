# Playing to Win: Workshop-Agenda

Nach Abb. 3.21 im Drive Leadership Playbook. Zwei Tage, am Stück oder mit einigen Tagen Abstand.

**Teilnehmende:** 5 bis 8 Personen, funktionsübergreifend, plus eine moderierende Person.
**Material:** Wand oder digitales Board mit den fünf Feldern der Cascade, Platz für mehrere Entwürfe nebeneinander.

## Prework

- [ ] Strategisches Problem in einem Satz, aus Kundensicht (verantwortliche Person): …
- [ ] Bekannte Fakten zu Markt, Kundschaft, Wettbewerb, ohne Interpretation (alle)

## Agenda

| Tag | Thema | Zeit |
|---|---|---|
| 1 | Ankommen und Problem schärfen | 90 Min |
| 1 | Status quo auf die Cascade legen | 60 Min |
| 1 | Winning Aspiration klären | 45 Min |
| 1 | Strategische Optionen erzeugen | 90 Min |
| 1 | Where to Play | 120 Min |
| 2 | How to Win | 120 Min |
| 2 | Recap und Capabilities | 60 Min |
| 2 | Management Systems | 90 Min |
| 2 | Was müsste wahr sein | 60 Min |
| 2 | Test-to-learn und Entscheidung | 90 Min |

## Spielregeln

- Hier wird entschieden, nicht aufgezählt.
- Keine Option ist vorab gesetzt, auch nicht der Status quo.
- Jede Where-to-Play-Entscheidung enthält ein Nein.
