---
name: walk-and-talk
description: Bewegung in den Arbeitstag holen mit Walk and Talk (Walking Meetings nach Nilofer Merchant), aus dem Drive Leadership Playbook. Nutze diesen Skill, wenn jemand zu viel sitzt, Meetings als Energie ziehend erlebt, 1:1s oder Sparrings anders gestalten, Calls im Gehen führen oder prüfen will, welche Termine sich als Walking Meeting eignen. Unterscheidet das physische Walking Meeting und den Audio-Call im Gehen und hilft, geeignete Termine auszuwählen und vorzubereiten.
metadata:
  book: Drive Leadership Playbook
  author: Dominik Kenzler
  module: YOURSELF
  area: Teil 2 Dich im Alltag steuern
  origin: Nilofer Merchant
  deep_dive: false
  version: "1.0"
---

# Walk and Talk

Aus dem Drive Leadership Playbook von Dominik Kenzler. Methode nach Nilofer Merchant.

## Worum es geht

Ein typischer Leadership-Tag besteht aus viel Sitzen: ein Meeting nach dem anderen, am Bildschirm oder im Meetingraum. Das kostet Energie, schränkt das Denken ein und hinterlässt am Abend Müdigkeit. Walk and Talk ist die bewusste Entscheidung, Bewegung in den Arbeitstag einzubauen, statt sie ins Wochenende auszulagern.

Nilofer Merchant hat die Idee in ihrem TED-Talk »Got a meeting? Take a walk« auf den Punkt gebracht: Mach aus deinem nächsten 1:1 ein Walking Meeting und lass die Gedanken fließen, während du läufst.

Bewegung gibt Energie, statt sie zu kosten. Sie ist eines der wenigen Dinge, die einen Energie ziehenden Termin in einen neutralen oder sogar Energie gebenden verwandeln. Seite an Seite zu laufen verändert zudem die Dynamik: weniger konfrontativ, natürlichere Pausen, schwierige Themen lassen sich oft offener ansprechen. Viele Menschen denken im Gehen freier.

## Wann du sie einsetzt

- Für 1:1s, Sparring, erste Ideenrunden und schwierige Themen, also Gespräche, die vom Denken und vom Austausch leben.
- Für Calls, die keinen geteilten Bildschirm brauchen, gerade in Remote-Teams.
- Für wichtige, aber anstrengende Termine, deren Format du ändern willst (Quadrant »Umgestalten« im Calendar Review).

Nicht geeignet, sobald ihr ein Dokument, Whiteboard oder eine Präsentation braucht, und für Gespräche, in denen jemand mitschreiben muss.

## So arbeitest du mit der Person

- Kläre zuerst den Kontext mit höchstens drei Fragen: Welche wiederkehrenden Termine hat die Person? Arbeitet sie vor Ort, remote oder hybrid? Hat sie schon einen Calendar Review gemacht? Frag nichts, was sie schon gesagt hat.
- Geh die Termine der Person durch und prüf jeden gegen die Kriterien aus »Wann du sie einsetzt«. Eine Frage pro Schritt, dann auf die Antwort warten.
- Challenge Vorschläge gegen »Worauf du achten musst«. Benenne direkt, wenn ein Termin visuelles Material braucht.
- Erfinde keine Termine. Arbeite nur mit dem, was die Person nennt.
- Schließe mit dem Ergebnis im Format aus »Ergebnis« und geh den Mini-Check durch.
- Antworte in der Sprache der Person.

## Ablauf

1. **Kandidaten finden.** Frage: *»Welche deiner Termine leben vom Denken und Austausch, nicht vom Präsentieren?«* Gut sind 1:1s, Sparrings, erste Ideenrunden, schwierige Themen. Hat die Person einen Calendar Review gemacht, starte mit den Terminen im Quadranten »Umgestalten«.

2. **Variante wählen.** Für jeden Kandidaten:
   - **Physisches Walking Meeting:** Statt euch im Konferenzraum oder vor zwei Bildschirmen gegenüberzusitzen, geht ihr los. Funktioniert besonders gut für 1:1s und Gespräche, in denen es ums Denken geht.
   - **Audio-Call im Gehen:** Ein Telefonat statt eines Videocalls erlaubt dir zu laufen und nimmt etwas von der Anspannung, die ständiger Blickkontakt am Bildschirm erzeugt.

   Frage: *»Seid ihr am selben Ort, oder wird es ein Call im Gehen?«*

3. **Ausschlusskriterien prüfen.** Frage: *»Braucht ihr ein Dokument, ein Whiteboard oder eine Präsentation? Muss jemand mitschreiben?«* Wenn ja, ist Walk and Talk das falsche Format.

4. **Mit der anderen Person klären.** Frag die Gesprächspartner:innen, ob das Format für sie passt. Vereinbart, die Agenda vorab zu haben, damit am Tag davor klar ist, ob etwas am Bildschirm geteilt werden muss.

5. **Visuelles vorab teilen.** Ist doch etwas Visuelles dabei, vorab Screenshots teilen.

6. **Rhythmus festlegen.** Frage: *»Welcher Termin wird ab wann regelmäßig im Gehen stattfinden?«* Es braucht kein Extrem. Schon deutlich weniger als Merchants 30 bis 50 Kilometer pro Woche reicht, um den Unterschied zu spüren.

## Beispiel

Nicholas Goubert, langjähriger Vorgesetzter und Mentor von Dominik Kenzler, fragte ihn, ob es für ihn in Ordnung wäre, jedes zweite ihrer 1:1s als Walk and Talk per Telefon zu machen. Das gab beiden Luft in den Kalendern und inspirierte Dominik, dasselbe mit seinen Direct Reports zu machen. Sie achteten darauf, die Agenda vorher zu haben. So wussten sie am Tag davor, ob sie etwas am Bildschirm teilen wollten. War doch etwas Visuelles dabei, teilte Dominik vorab Screenshots.

## Worauf du achten musst

- **Falsches Format für den Termin.** Sobald ein Dokument, Whiteboard oder eine Präsentation gebraucht wird, passt Walk and Talk nicht.
- **Mitschreiben nötig.** Gespräche, in denen jemand protokollieren muss, eignen sich schlecht.
- **Ohne Agenda loslaufen.** Ob es funktioniert, hängt stark von den Themen ab. Mit der Agenda vorab wisst ihr am Tag davor, ob ihr etwas am Bildschirm teilen wollt.
- **Zu groß denken.** Es braucht keinen Marathon. Jedes Stück im Gehen statt im Sitzen zählt.

## Ergebnis

```markdown
# Walk and Talk: [Name]
Stand: [Datum]

| Termin | Mit wem | Variante (vor Ort / Call im Gehen) | Visuelles nötig? | Ab wann, wie oft |
|---|---|---|---|---|

**Nicht geeignet (und warum):** …
**Absprache mit Gesprächspartner:innen:** Agenda bis [Zeitpunkt] vorab, Screenshots bei Bedarf.
```

## Mini-Check

(abgeleitet aus den typischen Fehlern)

- Lebt jeder ausgewählte Termin vom Denken und Austausch, nicht vom Präsentieren?
- Braucht keiner dieser Termine Dokument, Whiteboard, Präsentation oder Protokoll?
- Liegt die Agenda am Tag vorher vor, damit ihr wisst, ob Screenshots nötig sind?

## Im Flywheel

Modul YOURSELF, Teil 2 Dich im Alltag steuern.

Verwandte Skills:
- `calendar-review`: Walk and Talk ist laut Buch eine der konkretesten Antworten auf den Quadranten »Umgestalten«.
- `one-on-one-skip-level`: Im LEAD-Kapitel nennt das Buch Walk and Talk als alternatives Format für 1:1s.

## Quelle

Dominik Kenzler: Drive Leadership Playbook, Murmann. Kapitel YOURSELF, Methode Walk and Talk. Originalquelle: Nilofer Merchant: TED-Talk »Got a meeting? Take a walk«. Das Buch verweist außerdem auf eine Metaanalyse in »Lancet Public Health« (2025), nach der rund 7000 Schritte am Tag den Großteil der gesundheitlichen Effekte bringen.

Original: Nilofer Merchant: Got a meeting? Take a walk, TED2013, https://www.ted.com/talks/nilofer_merchant_got_a_meeting_take_a_walk
